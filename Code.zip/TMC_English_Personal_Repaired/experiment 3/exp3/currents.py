"""Additive current overlay: no controller, frozen-source edit, or policy input.

The baseline current remains the environment's existing CurrentField. Added
currents are fully determined by the scenario and absolute simulation time;
asking for samples never changes their future values or a simulator RNG.
"""
from copy import deepcopy
import hashlib
import json
import math

import numpy as np

from .protocol import FORMAT, HORIZON


def _smoothstep(x):
    x = np.clip(x, 0., 1.)
    return x*x*(3.-2.*x)


class AdditiveCurrent:
    """Preserve CurrentField.velocity's (..., 2) contract for scalar time."""

    def __init__(self, base, spec):
        if isinstance(base, AdditiveCurrent):
            raise ValueError('Refusing to stack experiment current overlays')
        self.base = base
        self.spec = deepcopy(spec)
        if spec.get('format') != FORMAT:
            raise ValueError('Wrong experiment current specification format')
        self.kind = spec['kind']
        if self.kind not in ('reference', 'constant', 'time_varying', 'cross_gust', 'random'):
            raise ValueError('Unknown additive current kind')
        self.amplitude = float(spec['amplitude_mps'])
        self.onset = float(spec['onset_s'])
        self.clear = float(spec['clear_s'])
        self.ramp = float(spec['ramp_s'])
        self.period = float(spec['period_s'])
        self.correlation = float(spec['correlation_s'])
        self.knot = float(spec['knot_s'])
        numbers = (self.amplitude, self.onset, self.clear, self.ramp,
                   self.period, self.correlation, self.knot)
        if not all(math.isfinite(x) for x in numbers):
            raise ValueError('Current parameters must be finite')
        if self.amplitude < 0. or self.onset < 0. or self.clear > HORIZON:
            raise ValueError('Invalid amplitude or event bounds')
        if self.ramp <= 0. or self.clear-self.onset < 2.*self.ramp:
            raise ValueError('Current interval must contain both positive ramps')
        if min(self.period, self.correlation, self.knot) <= 0.:
            raise ValueError('Current temporal scales must be positive')
        self.direction = np.asarray(spec['direction_xy'], dtype=float)
        if self.direction.shape != (2,) or not np.all(np.isfinite(self.direction)):
            raise ValueError('Direction must be finite world XY')
        if not np.isclose(np.linalg.norm(self.direction), 1., rtol=0., atol=1.e-12):
            raise ValueError('Direction must be a unit vector')
        self._random_knots = None
        if self.kind == 'random':
            self._random_knots = self._make_random_knots()

    def __getattr__(self, name):
        # Preserve cfg/phase/center and other read-only CurrentField metadata.
        return getattr(self.base, name)

    def _make_random_knots(self):
        # Pair indices 0..14 have matched latent paths and opposite signs.
        # This couples severity levels without looking at future policy actions.
        seed = np.random.SeedSequence([
            int(self.spec['random_namespace']), int(self.spec['random_pair_index'])])
        rng = np.random.default_rng(seed)
        count = int(math.ceil(HORIZON/self.knot)) + 2
        phi = math.exp(-self.knot/self.correlation)
        innovation = math.sqrt(1.-phi*phi)
        latent = np.empty((count, 2), dtype=np.float64)
        latent[0] = rng.normal(size=2)
        for index in range(1, count):
            latent[index] = phi*latent[index-1] + innovation*rng.normal(size=2)
        norm = np.linalg.norm(latent, axis=1)
        scale = np.divide(np.tanh(norm), norm, out=np.ones_like(norm), where=norm > 0.)
        bounded = latent*scale[:, None]
        # Rotation uses the first member's direction, then explicit sign makes
        # the second member its exact antipode; no accidental double inversion.
        pair_angle = 2.*math.pi*int(self.spec['random_pair_index'])/30.
        rotation = np.array([[math.cos(pair_angle), -math.sin(pair_angle)],
                             [math.sin(pair_angle), math.cos(pair_angle)]])
        return (bounded @ rotation.T)*int(self.spec['random_pair_sign'])

    def envelope(self, time):
        time = float(time)
        if not math.isfinite(time):
            raise ValueError('Time must be finite')
        up = _smoothstep((time-self.onset)/self.ramp)
        down = _smoothstep((self.clear-time)/self.ramp)
        return float(up*down)

    def added_velocity(self, time):
        """Return a world-frame XY vector; outside the event it is exactly zero."""
        time = float(time)
        envelope = self.envelope(time)
        if self.kind == 'reference' or envelope == 0. or self.amplitude == 0.:
            return np.zeros(2, dtype=float)
        if self.kind == 'time_varying':
            vector = self.direction*math.sin(2.*math.pi*(time-self.onset)/self.period)
        elif self.kind == 'random':
            index = int(math.floor(time/self.knot))
            weight = float(_smoothstep(time/self.knot-index))
            vector = (1.-weight)*self._random_knots[index] + weight*self._random_knots[index+1]
        else:
            vector = self.direction
        return self.amplitude*envelope*vector

    def sample_components(self, positions, time):
        """Offline physical observer: arrays base/additional/total have shape (...,2)."""
        positions = np.asarray(positions, dtype=float)
        if positions.ndim < 1 or positions.shape[-1] != 2 or not np.all(np.isfinite(positions)):
            raise ValueError('Positions must be finite XY coordinates')
        base = np.asarray(self.base.velocity(positions, time), dtype=float)
        if base.shape != positions.shape:
            # Permit a spatially uniform synthetic CurrentField, same contract.
            base = np.broadcast_to(base, positions.shape).copy()
        additional = np.broadcast_to(self.added_velocity(time), positions.shape).copy()
        return {'base': base, 'additional': additional, 'total': base+additional}

    def velocity(self, positions, time):
        # Exact delegation for reference preserves original values, shapes, and
        # floating arithmetic rather than changing them with an unnecessary sum.
        if self.kind == 'reference':
            return self.base.velocity(positions, time)
        return self.sample_components(positions, time)['total']

    @property
    def speed_upper_bound(self):
        return float(self.base.speed_upper_bound + self.amplitude)

    def describe(self):
        """Reproducibility metadata; no model or environment advancement."""
        result = deepcopy(self.spec)
        result['spec_sha256'] = hashlib.sha256(
            json.dumps(self.spec, sort_keys=True, separators=(',', ':'),
                       ensure_ascii=True, allow_nan=False).encode('utf-8')).hexdigest()
        result['random_knots_sha256'] = (None if self._random_knots is None else
            hashlib.sha256(self._random_knots.astype('<f8').tobytes()).hexdigest())
        # Fixed quadrature describes the exogenous input over its complete
        # declared window; it is unaffected by an episode terminating early.
        times = np.linspace(self.onset, self.clear,
                            int(round((self.clear-self.onset)*10.))+1)
        speeds2 = np.array([float(np.dot(v, v)) for v in
                            (self.added_velocity(t) for t in times)])
        integral = float(np.sum((speeds2[:-1]+speeds2[1:])*.5*np.diff(times)))
        result['declared_window_added_rms_mps'] = math.sqrt(integral/(self.clear-self.onset))
        result['declared_window_added_sampled_peak_mps'] = float(np.sqrt(speeds2.max()))
        result['waveform_quadrature_step_s'] = .1
        result['total_speed_upper_bound_mps'] = self.speed_upper_bound
        return result


def attach_current(env, spec):
    """Attach immediately after reset, before the first physical step.

    Frozen reset creates a new original CurrentField, so callers must attach
    again after every reset. Mid-episode changes are rejected to prevent an
    unrecorded intervention or carrying a previous episode's field forward.
    """
    if float(env.time) != 0. or int(env.step_count) != 0:
        raise ValueError('Attach current only immediately after environment reset')
    if int(env.seed) != int(spec['seed']):
        raise ValueError('Environment and declared current scenario seeds differ')
    wrapper = AdditiveCurrent(env.current, spec)
    env.current = wrapper
    return wrapper

