"""Passive network--physical diagnostics for the frozen 450k systems.

Truth values are written only to evidence. No measurement, policy, queue,
random generator or network position provider is called a second time by the
network observer. Endpoint current evaluation is the deterministic field.
"""
from __future__ import annotations

import math
from collections import defaultdict

import numpy as np

from scripts.tmc_network_observer import NetworkObserver


def ratio(numerator, denominator):
    return float(numerator / denominator) if denominator else None


def sample_stats(values):
    """Keep pooled sufficient statistics and missingness; never replace N/A by 0."""
    raw = list(values)
    valid = [float(value) for value in raw if value is not None]
    if any(not math.isfinite(value) for value in valid):
        raise ValueError("Non-finite passive diagnostic")
    square_sum = sum(value * value for value in valid)
    return dict(count=len(valid), total_count=len(raw), sum=sum(valid), sum_squares=square_sum,
                mean=ratio(sum(valid), len(valid)),
                rmse=math.sqrt(square_sum / len(valid)) if valid else None,
                p95=float(np.percentile(valid, 95)) if valid else None)


class PassiveNetworkObserver(NetworkObserver):
    """Extend the frozen observer by reading its cached emission positions.

    Queue delay is the residency of this actual hop's selected queue token,
    not packet age since generation. Propagation is distance / sound speed at
    emission. All receiver trials, including failures, have those diagnostics.
    Use ``detach`` in a finally block, exactly as for NetworkObserver.
    """

    def __init__(self, network):
        self._exp3_enqueued_at = {}
        self._exp3_positions = None
        self._exp3_queue_wait = None
        super().__init__(network)

    def _observe_enqueue(self, original, *args, **kwargs):
        before = len(self.queue_events)
        result = super()._observe_enqueue(original, *args, **kwargs)
        for event in self.queue_events[before:]:
            if event['outcome'] == 'enqueued':
                self._exp3_enqueued_at[event['queue_token']] = event['time']
        return result

    def _queue_event(self, item, owner, outcome):
        token = self._queue_tokens.get(id(item))
        enqueued = self._exp3_enqueued_at.pop(token, None)
        if outcome == 'selected' and self._tx is not None:
            self._exp3_queue_wait = (float(self.network.time) - enqueued
                                     if enqueued is not None else None)
        return super()._queue_event(item, owner, outcome)

    def _observe_positions_at(self, original, *args, **kwargs):
        positions = super()._observe_positions_at(original, *args, **kwargs)
        if self._tx is not None:
            self._exp3_positions = positions.copy()
        return positions

    def _observe_transmit_slot(self, original, *args, **kwargs):
        first = len(self.hop_events)
        self._exp3_positions = None
        self._exp3_queue_wait = None
        result = super()._observe_transmit_slot(original, *args, **kwargs)
        for event in self.hop_events[first:]:
            if self._exp3_positions is None:
                raise RuntimeError('Actual emission has no cached physical positions')
            src, dst = event['transmitter'], event['receiver']
            delta = self._exp3_positions[src] - self._exp3_positions[dst]
            distance = float(np.linalg.norm(delta))
            event['geometry'] = dict(
                hop_distance_m=distance, horizontal_distance_m=float(np.linalg.norm(delta[:2])),
                propagation_delay_s=distance / self.network.sound_speed,
                serialization_delay_s=event['packet']['size_bits'] / self.network.rate_bps,
                processing_delay_s=float(self.network.processing_delay),
                queue_wait_s=self._exp3_queue_wait)
        return result


def _service_snapshot(env, previous):
    """Sensor-side truth used for equal-definition evaluation of all systems.

    All live grants count, even an old-target grant which remains active. The
    primary denominator is sensor-grant endpoints, not AUV endpoints. A true
    exit requires the same sensor/receiver grant to remain live in both samples.
    Expiry, reassignment and target switching are not counted as physical exits.
    """
    now = float(env.time)
    active, exits = {}, 0
    radius = float(env.cfg.collection_radius)
    for sensor, grant in env.grants.items():
        receiver, expiry = int(grant[0]), float(grant[1])
        if expiry < now or not 1 <= receiver <= env.cfg.n_auv:
            continue
        distance = float(np.linalg.norm(env.auv_positions[receiver - 1] - env.sensor_positions[sensor]))
        key = f'{int(sensor)}:{receiver}'
        inside = distance <= radius
        active[key] = dict(sensor=int(sensor), receiver=receiver, expires_at_s=expiry,
                           horizontal_distance_m=distance, inside=inside)
        if key in previous and previous[key]['inside'] and not inside:
            exits += 1
    targets = [int(target) for target in env.targets]
    target_grants = [active.get(f'{target}:{i + 1}') for i, target in enumerate(targets)]
    return dict(grant_samples=len(active), grant_inside_samples=sum(x['inside'] for x in active.values()),
                exits=exits, active_grants=active, targets=targets,
                target_grant_samples=sum(x is not None for x in target_grants),
                target_grant_inside_samples=sum(x is not None and x['inside'] for x in target_grants))


class Timeline:
    def __init__(self, env, spec, current):
        self.env, self.spec, self.current = env, spec, current
        self.rows = []
        self.previous_count = len(env.collected)
        self.previous_time = float(env.time)
        self.previous_positions = np.asarray(env.auv_positions).copy()
        self.previous_grants = {}
        self.initial_root_parents = list(env.network.root_parents)
        self.previous_root_parents = self.initial_root_parents.copy()
        self.initial_local_parents = {str(k): v for k, v in env.network.local_parents.items()}
        if int(env.cfg.n_auv) != 2:
            raise ValueError('Experiment 3 frozen topology diagnostics require exactly two AUVs')

    def sample(self, telemetry, topology_action):
        env, net = self.env, self.env.network
        now = float(env.time)
        elapsed = now - self.previous_time
        if not math.isclose(elapsed, float(env.cfg.dt), rel_tol=0., abs_tol=1e-8):
            raise ValueError('Timeline requires exactly one completed fast step per sample')
        positions = np.asarray(env._positions_3d(), dtype=float)

        def edge(a, b):
            return bool(np.linalg.norm(positions[a] - positions[b]) <= net.max_range
                        and not net._is_failed(a, b, now, now + 1e-9))

        feasible, installed, path_hops = [], [], []
        for source in (1, 2):
            relay = 3 - source
            feasible.append(edge(source, 0) or (edge(source, relay) and edge(relay, 0)))
            version, here, seen, usable = net.active_version[source], source, set(), True
            while here != 0:
                if here in seen or len(seen) >= 2:
                    usable = False
                    break
                seen.add(here)
                record = net.installed_routes.get(here, {}).get(version)
                if record is None or record[1] < now:
                    usable = False
                    break
                parent = record[0][here - 1]
                if not edge(here, parent):
                    usable = False
                    break
                here = parent
            installed.append(usable)
            path_hops.append(len(seen) if usable else None)
        if any(usable and not possible for usable, possible in zip(installed, feasible)):
            raise RuntimeError('Usable installed path must also be structurally feasible')

        components = self.current.sample_components(env.auv_positions, now)
        true_flow = np.asarray(components['total'], dtype=float)
        enabled = bool(getattr(env.method, 'use_usde', False))
        snapshots = [estimator.snapshot() for estimator in env.usde] if enabled else []
        estimates = [snapshot.estimate.tolist() for snapshot in snapshots] if enabled else [None, None]
        current_errors = [float(np.linalg.norm(snapshot.estimate - true_flow[i]))
                          if snapshot.initialized else None
                          for i, snapshot in enumerate(snapshots)] if enabled else [None, None]
        ground = (np.asarray(env.auv_positions) - self.previous_positions) / elapsed
        residual = ground - np.asarray(env.executed_velocities)
        service = _service_snapshot(env, self.previous_grants)
        count = len(env.collected)
        prediction_errors = [value for prediction in telemetry['matured_planner_predictions']
                             for value in prediction['error_m'].values()]
        row = dict(
            time_s=now, dt_s=elapsed, topology_request=topology_action,
            root_parents_before=self.previous_root_parents.copy(),
            root_parents=list(net.root_parents),
            local_parents={str(k): v for k, v in net.local_parents.items()},
            structural_possible=feasible, installed_path_usable=installed,
            installed_path_hops=path_hops,
            state_aoi_s=list(telemetry['state_aoi_s']),
            state_no_message=list(telemetry['state_no_message']),
            fresh30=[not absent and age <= 30. for age, absent in
                     zip(telemetry['state_aoi_s'], telemetry['state_no_message'])],
            collected_packets=count, new_packets=count - self.previous_count,
            geometry=dict(
                usv_auv_distance_m=[float(np.linalg.norm(positions[0] - positions[i])) for i in (1, 2)],
                auv_auv_distance_m=[float(np.linalg.norm(positions[1] - positions[2]))],
                active_sn_distance_m=[float(np.linalg.norm(env.auv_positions[i] - env.sensor_positions[target]))
                                      for i, target in enumerate(service['targets'])]),
            current=dict(
                base_xy_mps=np.asarray(components['base']).tolist(),
                additional_xy_mps=np.asarray(components['additional']).tolist(), total_xy_mps=true_flow.tolist(),
                current_total_speed_mps=np.linalg.norm(true_flow, axis=-1).tolist(),
                current_additional_speed_mps=np.linalg.norm(components['additional'], axis=-1).tolist(),
                estimate_xy_mps=estimates, usde_enabled=enabled,
                estimate_initialized=[bool(s.initialized) for s in snapshots] if enabled else [False, False],
                estimate_measurement_valid=[bool(s.valid) for s in snapshots] if enabled else [False, False],
                estimate_age_s=[float(s.age) for s in snapshots] if enabled else [None, None],
                usde_current_error_mps=current_errors,
                ground_command_residual_mps=np.linalg.norm(residual, axis=-1).tolist(),
                ground_command_residual_xy_mps=residual.tolist(),
                water_relative_command_xy_mps=np.asarray(env.executed_velocities).tolist(),
                realized_ground_velocity_xy_mps=ground.tolist()),
            errors=dict(local_navigation_error_m=list(telemetry['local_navigation_error_m']),
                        usv_received_hold_error_m=list(telemetry['usv_received_hold_error_m']),
                        planner_prediction_error_m=prediction_errors),
            service=service)
        self.previous_count, self.previous_time = count, now
        self.previous_positions = np.asarray(env.auv_positions).copy()
        self.previous_grants = service['active_grants']
        self.previous_root_parents = row['root_parents'].copy()
        self.rows.append(row)
        return row


def hop_window(hops, kind, start, end):
    """Use the legacy 75-metric completion-window denominator explicitly.

    A failure known immediately can still be outside the nominal completion
    window. Such a trial is excluded from the primary resolved denominator,
    but is NOT called right-censored. The all-emitted outcome counts make that
    distinction independently checkable.
    """
    cohort = [hop for hop in hops if start <= hop['time'] < end and hop['packet']['kind'] == kind]
    due = [hop for hop in cohort if hop['nominal_arrival_at'] <= end]
    resolved = [hop for hop in due if hop['outcome_at'] is not None and hop['outcome_at'] <= end]
    failed = sum(hop['outcome'] != 'arrived_accepted' for hop in resolved)
    all_resolved = [hop for hop in cohort if hop['outcome_at'] is not None and hop['outcome_at'] <= end]
    diagnostics = ('hop_distance_m', 'propagation_delay_s', 'queue_wait_s',
                   'serialization_delay_s', 'processing_delay_s')
    return dict(started=len(cohort), due=len(due), resolved=len(resolved), failed=failed,
                right_censored=len(cohort) - len(all_resolved),
                completion_window_excluded=len(cohort) - len(due),
                completion_window_pending=len(due) - len(resolved),
                all_emitted_resolved=len(all_resolved),
                all_emitted_failed=sum(hop['outcome'] != 'arrived_accepted' for hop in all_resolved),
                nondelivery=ratio(failed, len(resolved)),
                sample_stats={key: sample_stats(hop.get('geometry', {}).get(key) for hop in cohort)
                              for key in diagnostics},
                nondelivery_definition='nominal arrival by window end, resolved by window end; matches frozen completion-window 75 metrics',
                diagnostic_cohort='all actual emitted receiver hops, including failed and censored trials')


def delivered_state_paths(observer, start, end):
    """Actual completed STATE paths; first logical delivery to root only.

    STATE does not retry a generation in the frozen simulator. Its same
    (source, sequence) is retained on forwarding, so accepted hop events up to
    first root delivery identify the actual one-/two-hop path. This conditional
    metric does not assign a path length or zero delay to undelivered states.
    """
    accepted = defaultdict(list)
    for hop in observer.hop_events:
        packet = hop['packet']
        if packet['kind'] == 'STATE' and hop['outcome'] == 'arrived_accepted':
            accepted[(packet['src'], packet['seq'])].append(hop)
    seen, records = set(), []
    for delivery in getattr(observer, 'delivery_events', []):
        packet = delivery['packet']
        if packet['kind'] != 'STATE' or delivery['receiver'] != 0:
            continue
        key = packet['src'], packet['seq']
        if key in seen:
            continue
        seen.add(key)
        if not start < delivery['time'] <= end:
            continue
        path = [hop for hop in accepted[key]
                if hop['outcome_at'] is not None and hop['outcome_at'] <= delivery['time']]
        sums = {}
        for metric in ('propagation_delay_s', 'queue_wait_s'):
            values = [hop.get('geometry', {}).get(metric) for hop in path]
            sums[metric] = sum(values) if path and all(value is not None for value in values) else None
        records.append(dict(delivered_at_s=float(delivery['time']), src=int(key[0]), seq=int(key[1]),
                            hop_count=len(path), **sums))
    return dict(delivered_unique=len(records), records=records,
                sample_stats={key: sample_stats(row[key] for row in records)
                              for key in ('hop_count', 'propagation_delay_s', 'queue_wait_s')},
                definition='first STATE logical arrival at root in completion window; accepted hops of that source/sequence only; delivery-conditional')


def _service_recovery(rows, clear, pre_rate, duration, threshold=.9, window=120.):
    followup = max(0., duration - clear)
    base = dict(recovered=False, latency_s=None, followup_s=followup,
                reference_pre_rate_packet_s=pre_rate, fraction_threshold=threshold, window_s=window)
    if pre_rate is None or pre_rate <= 0:
        return dict(base, status='undefined_zero_pre_collection')
    if duration <= clear:
        return dict(base, status='not_exposed_after_clear')
    for row in rows:
        now = row['time_s']
        if now < clear + window:
            continue
        samples = [x for x in rows if now - window < x['time_s'] <= now]
        if sum(x['dt_s'] for x in samples) < window - 1e-8:
            continue
        rate = sum(x['new_packets'] for x in samples) / window
        if rate >= threshold * pre_rate:
            return dict(base, status='recovered', recovered=True, latency_s=now - clear,
                        confirmed_at_s=now, recovery_rate_packet_s=rate)
    return dict(base, status='not_recovered_before_observation_end')


def summarize(rows, no, spec, duration):
    onset, clear = float(spec['onset_s']), float(spec['clear_s'])
    horizon = 1200.
    windows = dict(pre=(380., onset), fault=(onset, clear), post=(clear, horizon), total=(0., horizon))
    result = {}
    for name, (start, end) in windows.items():
        # A sample at t measures interval (t-dt,t]; collection at onset belongs
        # to the preceding interval, and the first perturbed interval ends later.
        samples = [row for row in rows if start < row['time_s'] <= end]
        if any(usable and not possible for row in samples for usable, possible in
               zip(row['installed_path_usable'], row['structural_possible'])):
            raise ValueError('Installed path sample is not a subset of structural opportunity')
        auv_samples = 2 * len(samples)
        ages = [age for row in samples for age in row['state_aoi_s']]
        count = sum(row['new_packets'] for row in samples)
        structural = sum(sum(row['structural_possible']) for row in samples)
        installed = sum(sum(row['installed_path_usable']) for row in samples)
        raw = defaultdict(list)
        for row in samples:
            for key, values in row['errors'].items():
                raw[key].extend(values)
            for key, values in row['geometry'].items():
                raw[key].extend(values)
            for key in ('usde_current_error_mps', 'current_total_speed_mps',
                        'current_additional_speed_mps', 'ground_command_residual_mps'):
                raw[key].extend(row['current'][key])
            raw['installed_path_hops'].extend(row['installed_path_hops'])
        stat_keys = ('local_navigation_error_m', 'usv_received_hold_error_m', 'planner_prediction_error_m',
                     'usv_auv_distance_m', 'auv_auv_distance_m', 'active_sn_distance_m',
                     'usde_current_error_mps', 'current_total_speed_mps', 'current_additional_speed_mps',
                     'ground_command_residual_mps', 'installed_path_hops')
        service = {key: sum(row['service'][key] for row in samples) for key in
                   ('grant_samples', 'grant_inside_samples', 'exits',
                    'target_grant_samples', 'target_grant_inside_samples')}
        service['grant_inside_fraction'] = ratio(service['grant_inside_samples'], service['grant_samples'])
        service['target_grant_inside_fraction'] = ratio(service['target_grant_inside_samples'], service['target_grant_samples'])
        service['grant_seconds'] = sum(row['dt_s'] * row['service']['grant_samples'] for row in samples)
        service['grant_inside_seconds'] = sum(row['dt_s'] * row['service']['grant_inside_samples'] for row in samples)
        service['denominator_definition'] = 'live sensor-to-AUV grant endpoint samples; multiple live grants count individually'
        result[name] = dict(start_s=start, end_s=end, observed_seconds=sum(row['dt_s'] for row in samples),
                            budget_seconds=end - start, num_auvs=2, collected_packets=count,
                            fixed_window_goodput_bit_s=count * 2048 / (end - start),
                            aoi_sum_s=sum(ages), aoi_n=len(ages), aoi_mean_s=ratio(sum(ages), len(ages)),
                            aoi_p95_s=float(np.percentile(ages, 95)) if ages else None,
                            fresh30_samples=sum(sum(row['fresh30']) for row in samples), auv_samples=auv_samples,
                            structural_possible_samples=structural, installed_usable_samples=installed,
                            feasible_connectivity=ratio(structural, auv_samples),
                            installed_connectivity=ratio(installed, auv_samples),
                            installed_given_feasible=ratio(installed, structural),
                            sample_stats={key: sample_stats(raw[key]) for key in stat_keys}, service=service,
                            delivered_state_paths=delivered_state_paths(no, start, min(end, duration)),
                            data=hop_window(no.hop_events, 'DATA', start, min(end, duration)),
                            state=hop_window(no.hop_events, 'STATE', start, min(end, duration)))
    switches = []
    for row in rows:
        previous = row['root_parents_before']
        if row['root_parents'] != previous:
            switches.append(dict(time_s=row['time_s'], before=previous, after=row['root_parents']))
    pre = result['pre']
    pre_rate = ratio(pre['collected_packets'], pre['observed_seconds'])
    return dict(windows=result, root_parent_switches=switches, root_parent_switch_count=len(switches),
                root_parent_switches_per_minute=ratio(60 * len(switches), duration),
                service_recovery=_service_recovery(rows, clear, pre_rate, duration),
                disturbance_exposed=duration > onset, timeline_sampling_s=1.,
                diagnostics_definition=dict(
                    local_geometry='passive simulator truth only; USV-AUV and AUV-AUV are acoustic 3D distances in m; active-SN distance and service-radius checks are horizontal XY metres; never a policy or planner input',
                    current_error='initialized USDE estimate versus deterministic instantaneous endpoint total current, m/s; the estimator filters measured interval-average residuals, so this is not an interval-mean target; absent estimator is null',
                    ground_command_residual='realized interval ground velocity minus commanded water-relative velocity, m/s; equals substep-integrated mean physical current for the unchanged kinematics; not reference tracking error',
                    propagation='actual emission distance divided by sound speed; queue residency is measured separately',
                    topology_switches='changes between consecutive one-second root-parent endpoint samples, beginning from the actual reset parents',
                    service_recovery='first complete 120s post-clear window with collection rate at least 90% of own observed pre-window rate; censored failures retained',
                    planning_forecast='matured forecasts from unchanged frozen EnvironmentObserver; nonapplicable external forecast remains absent'))
