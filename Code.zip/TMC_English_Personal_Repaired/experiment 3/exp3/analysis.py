"""Offline, seed-paired analysis of frozen-policy current-disturbance experiments.

The analysis does not load policies, step environments, or modify input evidence.
Formal output requires all 13 profiles, all five systems, and all 30 scene seeds.
Ratios and bootstrap differences are recomputed from their raw denominators.
"""
from collections import Counter
import gzip
import json
import math
from pathlib import Path
import statistics

import numpy as np

from .protocol import ROOT, FORMAT, METHODS, PROFILES, SEEDS, scenario
from .runner import code_hashes, digest, verify_package, write_json


WINDOWS = ('pre', 'fault', 'post', 'total')
PRIMARY = ('collected_packets', 'pooled_aoi_s', 'data_nondelivery')
PAIRED_KEYS = PRIMARY + ('fresh30_fixed_budget',)
REPETITIONS = 4000
BOOTSTRAP_SEED = 25092026
DISPLAY_NAMES = {
    'full_v6': 'Full V6-C07', 'usde_only_v6': 'USDE-only',
    'topology_only_v6': 'Topology-only (full coordination, no USDE)',
    'synchronous_fim_rl': 'FIM+RL', 'communication_aware_tmc': 'CA-TMC',
}


def average(values):
    values = [float(v) for v in values if v is not None]
    if not all(math.isfinite(v) for v in values):
        raise ValueError('Non-finite measurements must not be silently dropped')
    return statistics.fmean(values) if values else None


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def aggregate_stats(items):
    """Pool raw sufficient statistics; never average per-episode RMSE or P95."""
    count = sum(int(item.get('count', 0)) for item in items)
    total = sum(float(item.get('sum', 0.)) for item in items)
    squares = sum(float(item.get('sum_squares', 0.)) for item in items)
    support = sum(int(item.get('total_count', item.get('count', 0))) for item in items)
    if not 0 <= count <= support or not all(math.isfinite(v) for v in (total, squares)) or squares < 0:
        raise ValueError('Invalid passive sufficient statistics')
    return dict(count=count, total_count=support, sum=total, sum_squares=squares,
                mean=ratio(total, count), rmse=math.sqrt(squares/count) if count else None,
                valid_fraction=ratio(count, support),
                p95=None, p95_note='Raw percentile samples are not retained in this summary; no average-of-percentiles substitute')


def pooled(rows, window='total'):
    if not rows:
        raise ValueError('Cannot pool an empty episode group')
    ws = [row['experiment3']['windows'][window] for row in rows]
    sums = {key: sum(float(w[key]) for w in ws) for key in
            ('aoi_sum_s', 'aoi_n', 'fresh30_samples', 'auv_samples',
             'budget_seconds', 'observed_seconds', 'collected_packets')}
    budget_samples = sum(float(w['num_auvs'])*float(w['budget_seconds']) for w in ws)
    channels = {}
    for channel in ('data', 'state'):
        raw = {key: sum(int(w[channel].get(key, 0)) for w in ws)
               for key in ('started', 'due', 'resolved', 'failed', 'right_censored',
                           'completion_window_excluded', 'completion_window_pending',
                           'all_emitted_resolved', 'all_emitted_failed')}
        raw['nondelivery'] = ratio(raw['failed'], raw['resolved'])
        keys = set().union(*(w[channel].get('sample_stats', {}) for w in ws))
        raw['sample_stats'] = {key: aggregate_stats([
            w[channel].get('sample_stats', {}).get(key, {}) for w in ws]) for key in sorted(keys)}
        channels[channel] = raw
    stat_keys = set().union(*(w.get('sample_stats', {}) for w in ws))
    sample_stats = {key: aggregate_stats([w.get('sample_stats', {}).get(key, {}) for w in ws])
                    for key in sorted(stat_keys)}
    service_keys = set().union(*(w.get('service', {}) for w in ws))
    service = {key: sum(float(w.get('service', {}).get(key, 0) or 0) for w in ws)
               for key in sorted(service_keys)
               if key.endswith('_samples') or key.endswith('_seconds') or key in ('exits', 'range_exit_count')}
    service['grant_inside_fraction'] = ratio(service.get('grant_inside_samples', 0),
                                             service.get('grant_samples', 0))
    service['target_grant_inside_fraction'] = ratio(service.get('target_grant_inside_samples', 0),
                                                    service.get('target_grant_samples', 0))
    path_records = [w.get('delivered_state_paths', {}) for w in ws]
    path_keys = set().union(*(p.get('sample_stats', {}) for p in path_records))
    delivered_paths = dict(delivered_unique=sum(p.get('delivered_unique', 0) for p in path_records),
        sample_stats={key: aggregate_stats([p.get('sample_stats', {}).get(key, {}) for p in path_records])
                      for key in sorted(path_keys)},
        cohort='first successful logical STATE delivery to root during the window; conditional on delivery')
    installed = sum(int(w.get('installed_usable_samples', 0)) for w in ws)
    possible = sum(int(w.get('structural_possible_samples', 0)) for w in ws)
    return dict(collected_packets=sums['collected_packets']/len(rows),
                fixed_budget_goodput_bit_s=ratio(2048*sums['collected_packets'], sums['budget_seconds']),
                pooled_aoi_s=ratio(sums['aoi_sum_s'], sums['aoi_n']),
                data_nondelivery=channels['data']['nondelivery'],
                state_nondelivery=channels['state']['nondelivery'],
                fresh30_observed=ratio(sums['fresh30_samples'], sums['auv_samples']),
                fresh30_fixed_budget=ratio(sums['fresh30_samples'], budget_samples),
                installed_connectivity=ratio(installed, sums['auv_samples']),
                installed_given_feasible=ratio(installed, possible),
                data=channels['data'], state=channels['state'], sample_stats=sample_stats,
                service=service, delivered_state_paths=delivered_paths,
                raw=dict(**sums, budget_auv_samples=budget_samples,
                    installed_usable_samples=installed, structural_possible_samples=possible),
                full_horizon=sum(bool(row['survived_full_horizon']) for row in rows),
                episodes=len(rows))


def _indexed(rows):
    result = {row['seed']: row for row in rows}
    if len(result) != len(rows):
        raise ValueError('Duplicate seed in paired statistical group')
    return result


def _aligned(*groups):
    maps = [_indexed(rows) for rows in groups]
    if not maps or not maps[0] or any(set(m) != set(maps[0]) for m in maps[1:]):
        raise ValueError('Unpaired scene seeds; refusing to discard unmatched or failed cases')
    return [[m[seed] for seed in sorted(maps[0])] for m in maps]


def _ratio_array(a, b):
    return np.divide(a, b, out=np.full_like(a, np.nan, dtype=float), where=b != 0)


def _draw_statistics(rows, selected, window):
    ws = [row['experiment3']['windows'][window] for row in rows]
    def sums(getter):
        array = np.asarray([getter(w) for w in ws], dtype=float)
        return array[selected].sum(axis=1)
    return dict(collected_packets=sums(lambda w: w['collected_packets'])/selected.shape[1],
        pooled_aoi_s=_ratio_array(sums(lambda w: w['aoi_sum_s']), sums(lambda w: w['aoi_n'])),
        data_nondelivery=_ratio_array(sums(lambda w: w['data']['failed']), sums(lambda w: w['data']['resolved'])),
        fresh30_fixed_budget=_ratio_array(sums(lambda w: w['fresh30_samples']),
                                         sums(lambda w: w['num_auvs']*w['budget_seconds'])))


def _interval(point, draws, repetitions, pairs):
    finite = np.asarray(draws)[np.isfinite(draws)]
    return dict(difference=point, ci95=np.quantile(finite, [.025, .975]).tolist() if finite.size else None,
                valid_bootstraps=int(finite.size), requested_bootstraps=int(repetitions),
                n_scene_pairs=pairs, multiplicity_corrected=False)


def _difference(a, b):
    return a-b if a is not None and b is not None else None


def _draw_indices(n, repetitions):
    if repetitions < 1:
        raise ValueError('At least one bootstrap draw is required')
    return np.random.default_rng(BOOTSTRAP_SEED).integers(0, n, size=(repetitions, n))


def paired_bootstrap(left, right, window='total', repetitions=REPETITIONS):
    left, right = _aligned(left, right)
    selected = _draw_indices(len(left), repetitions)
    a, b = _draw_statistics(left, selected, window), _draw_statistics(right, selected, window)
    p, q = pooled(left, window), pooled(right, window)
    return {key: _interval(_difference(p[key], q[key]), a[key]-b[key], repetitions, len(left))
            for key in PAIRED_KEYS}


def reference_change(disturbed, reference, repetitions=REPETITIONS):
    """Whole-horizon paired changes; gust stage lengths are not mixed with 300s reference stages."""
    disturbed, reference = _aligned(disturbed, reference)
    changes = paired_bootstrap(disturbed, reference, 'total', repetitions)
    selected = _draw_indices(len(disturbed), repetitions)
    a, b = _draw_statistics(disturbed, selected, 'total'), _draw_statistics(reference, selected, 'total')
    p, q = pooled(disturbed), pooled(reference)
    draws = _ratio_array(a['collected_packets'], b['collected_packets'])
    retention = _interval(ratio(p['collected_packets'], q['collected_packets']), draws,
                          repetitions, len(disturbed))
    retention['estimate'] = retention.pop('difference')
    return dict(window='total', paired_change=changes, aggregate_packet_retention=retention,
                paired_episode_packet_changes=[dict(seed=a['seed'], difference=a['collected_packets']-b['collected_packets'])
                                               for a, b in zip(disturbed, reference)])


def difference_in_differences(full, full_reference, comparator, comparator_reference,
                              repetitions=REPETITIONS):
    groups = _aligned(full, full_reference, comparator, comparator_reference)
    selected = _draw_indices(len(groups[0]), repetitions)
    draws = [_draw_statistics(g, selected, 'total') for g in groups]
    points = [pooled(g) for g in groups]
    result = {}
    for key in PRIMARY:
        changes = [_difference(points[i][key], points[i+1][key]) for i in (0, 2)]
        point = _difference(*changes)
        values = (draws[0][key]-draws[1][key])-(draws[2][key]-draws[3][key])
        result[key] = _interval(point, values, repetitions, len(groups[0]))
    return dict(window='total', formula='(full_disturbed-full_reference)-(comparator_disturbed-comparator_reference)',
                interpretation='Positive packet difference and negative AoI/nondelivery difference favor full robustness',
                estimates=result)


def read_trace(directory):
    with gzip.open(Path(directory)/'trace.jsonl.gz', 'rt', encoding='utf-8') as stream:
        rows = [json.loads(line)['experiment3'] for line in stream]
    times = [row['time_s'] for row in rows]
    if not rows or any(b <= a for a, b in zip(times, times[1:])):
        raise ValueError('Trace must contain strictly increasing observed times')
    return rows


def task_recovery(disturbed, reference, origin=800., limit=1200., onset=500.):
    """Post-clear 120s packet-rate threshold, requiring 30 consecutive one-second observations.

    The threshold is 80% of the matched reference, which must supply at least
    three packets per 120s. No interpolation after a failure and no zero-filled
    recovery. Attainment alone does not establish a prior service degradation.
    """
    def index(rows):
        result = {float(r['time_s']): float(r['collected_packets']) for r in rows}
        if len(result) != len(rows):
            raise ValueError('Duplicate trace timestamps')
        result.setdefault(0., 0.)
        return result
    f, b = index(disturbed), index(reference)
    common_end = min(max(f), max(b), limit)
    definition = dict(origin_s=origin, horizon_s=limit, common_observed_until_s=common_end,
        fault_observed_until_s=max(f), reference_observed_until_s=max(b), rolling_window_s=120,
        hold_s=30, threshold_fraction=.8, minimum_reference_packets=3,
        earliest_possible_latency_s=120., recovered=False, latency_s=None, confirmed_at_s=None)
    if common_end <= origin:
        return dict(**definition, status='no_common_post_clear_followup', eligible_windows=0,
                    post_clear_common_followup_s=0., right_censored=True,
                    disruption_observed=None)
    eligible = consecutive = during_support = 0
    last = None
    disruption = False
    for t in sorted(set(f) & set(b)):
        if t > limit or t-120 not in f or t-120 not in b:
            continue
        expected, actual = b[t]-b[t-120], f[t]-f[t-120]
        if onset < t <= origin and expected >= 3:
            during_support += 1
            disruption |= actual < .8*expected
        if t < origin+120:
            continue
        if last is not None and not math.isclose(t-last, 1., abs_tol=1e-9):
            consecutive = 0
        last = t
        if expected < 3:
            consecutive = 0
            continue
        eligible += 1
        consecutive = consecutive+1 if actual >= .8*expected else 0
        if consecutive >= 30:
            definition.update(recovered=True, latency_s=t-29-origin, confirmed_at_s=t)
            return dict(**definition, status='threshold_attained', eligible_windows=eligible,
                        post_clear_common_followup_s=common_end-origin, right_censored=False,
                        disruption_observed=disruption if during_support else None,
                        note='Sustained reference-relative service attainment; recovery claim additionally requires observed prior degradation')
    return dict(**definition,
                status='threshold_not_attained_before_observation_end' if eligible else 'insufficient_common_reference_support',
                eligible_windows=eligible, post_clear_common_followup_s=common_end-origin,
                right_censored=True, disruption_observed=disruption if during_support else None)


def recovery_summary(records):
    latencies = [r['task_recovery']['latency_s'] for r in records if r['task_recovery']['recovered']]
    return dict(episodes=len(records), threshold_attained=len(latencies),
        threshold_attained_fraction=ratio(len(latencies), len(records)),
        attained_latency_median_s=statistics.median(latencies) if latencies else None,
        observed_degradation_and_attained=sum(r['task_recovery']['recovered']
            and r['task_recovery']['disruption_observed'] is True for r in records),
        status_counts=dict(Counter(r['task_recovery']['status'] for r in records)),
        note='Conditional median excludes non-attainment; report status counts alongside it, never interpret it as unconditional recovery latency')


def validate_jobs(plan):
    if plan.get('format') != FORMAT:
        raise ValueError('Wrong Experiment-3 protocol format')
    if plan.get('formal_experiment') is not True or plan.get('mode') != 'formal' or plan.get('device') != 'cuda':
        raise ValueError('Only formally gated CUDA experiment records are reportable; smoke is excluded')
    jobs = [tuple(job) for job in plan.get('jobs', [])]
    if not jobs or len(set(jobs)) != len(jobs):
        raise ValueError('Empty or duplicate scheduled episodes')
    if any(len(job) != 3 for job in jobs):
        raise ValueError('Malformed scheduled episode')
    profiles = {p for p, _, _ in jobs}
    if not profiles <= set(PROFILES):
        raise ValueError('Unknown current-disturbance profile')
    expected = {(p, m, seed) for p in profiles for m in METHODS for seed in SEEDS}
    if set(jobs) != expected:
        raise ValueError('Each profile requires exactly five systems and 30 paired scene seeds')


def _validate_row(row, key, schemas):
    if (row['profile'], row['strategy'], row['seed']) != key or row['model_step'] != 450000:
        raise ValueError('Episode identity or frozen model step mismatch')
    if row.get('formal_experiment') is not True or row.get('method_id') != key[1]:
        raise ValueError('Episode is not the declared formal frozen system')
    spec = scenario(key[0], key[2])
    if row.get('scenario') != spec:
        raise ValueError('Episode current scenario differs from the declared paired disturbance')
    metrics = row['metrics75']
    schema = {key: (m['label'], m['unit']) for key, m in metrics.items()}
    if len(schema) != 75 or schemas and schema != schemas[0]:
        raise ValueError('Original 75-metric identities, labels, or units differ')
    if not schemas:
        schemas.append(schema)
    if not 0 < float(row['duration_s']) <= 1200:
        raise ValueError('Invalid observed episode duration')
    if not isinstance(row['steps'], int) or row['steps'] != row['duration_s']:
        raise ValueError('Expected one-second samples matching the observed duration')
    if row['survived_full_horizon'] != (not row['terminated'] and row['steps'] == 1200):
        raise ValueError('Full-horizon survival flag disagrees with termination evidence')
    if row['steps'] < 1200 and not (row['terminated'] or row['truncated']):
        raise ValueError('Formal early episode lacks a termination or truncation record')
    for metric in metrics.values():
        value = metric['value']
        if value is not None and (not isinstance(value, (int, float)) or not math.isfinite(value)):
            raise ValueError('Invalid 75-metric value')
    for window in WINDOWS:
        w = row['experiment3']['windows'][window]
        bounds = dict(pre=(380., spec['onset_s']), fault=(spec['onset_s'], spec['clear_s']),
                      post=(spec['clear_s'], 1200.), total=(0., 1200.))[window]
        if (w['start_s'], w['end_s']) != bounds or w['budget_seconds'] != bounds[1]-bounds[0]:
            raise ValueError('Window boundaries differ from the declared disturbance')
        for raw_key in ('aoi_sum_s', 'aoi_n', 'fresh30_samples', 'auv_samples', 'budget_seconds',
                        'observed_seconds', 'collected_packets'):
            if not isinstance(w[raw_key], (int, float)) or not math.isfinite(w[raw_key]) or w[raw_key] < 0:
                raise ValueError('Non-finite or negative window sufficient statistic')
        if w['num_auvs'] != 2 or not 0 <= w['observed_seconds'] <= w['budget_seconds']:
            raise ValueError('Wrong number of AUVs or inconsistent observation exposure')
        exposure = max(0., min(row['duration_s'], bounds[1])-bounds[0])
        if w['observed_seconds'] != exposure or w['auv_samples'] != 2*exposure or w['aoi_n'] != w['auv_samples']:
            raise ValueError('Window exposure disagrees with one-second two-AUV trace duration')
        if w['aoi_n'] < 0 or w['fresh30_samples'] < 0 or w['fresh30_samples'] > w['auv_samples']:
            raise ValueError('Invalid information-age raw denominator')
        for kind in ('data', 'state'):
            h = w[kind]
            if any(not isinstance(h[key], int) for key in ('failed', 'resolved', 'right_censored')) or not 0 <= h['failed'] <= h['resolved'] or h['right_censored'] < 0:
                raise ValueError('Invalid hop raw denominator')
            if 'completion_window_pending' in h and h['due'] != h['resolved']+h['completion_window_pending']:
                raise ValueError('Completion-window pending count does not reconcile')
            if 'completion_window_excluded' in h and h['started'] != h['due']+h['completion_window_excluded']:
                raise ValueError('Completion-window exclusion count does not reconcile')
    if row['experiment3']['windows']['total']['collected_packets'] != row['collected_packets']:
        raise ValueError('Episode collection and observed total-window collection disagree')


def _load_inputs(inputs):
    groups, paths, fingerprints, schemas, manifests = {}, {}, [], [], []
    for name in inputs:
        source = Path(name).resolve()
        complete = json.loads((source/'complete.json').read_text(encoding='utf-8'))
        plan = json.loads((source/'plan.json').read_text(encoding='utf-8'))
        validate_jobs(plan)
        if complete.get('status') != 'completed' or complete.get('episodes') != len(plan['jobs']) or complete.get('formal_experiment') is not True:
            raise ValueError('Incomplete run; retain partials but do not produce formal final statistics')
        fingerprints.append((plan['code_hashes'], plan['package'], plan['device']))
        manifests.append(dict(directory=str(source), plan_sha256=digest(source/'plan.json'),
                              complete_sha256=digest(source/'complete.json')))
        for profile, strategy, seed in plan['jobs']:
            key = profile, strategy, seed
            if key in paths:
                raise ValueError('Duplicate episode across inputs')
            directory = source/profile/strategy/str(seed)
            manifest = json.loads((directory/'complete.json').read_text(encoding='utf-8'))
            hashes = manifest.get('sha256', {})
            if manifest.get('status') != 'completed' or not {'episode.json', 'trace.jsonl.gz', 'events.json.gz'} <= set(hashes):
                raise ValueError('Episode lacks a complete evidence manifest')
            for filename, sha in hashes.items():
                path = (directory/filename).resolve()
                if path.parent != directory.resolve() or digest(path) != sha:
                    raise ValueError('Episode evidence path or checksum mismatch')
            row = json.loads((directory/'episode.json').read_text(encoding='utf-8'))
            _validate_row(row, key, schemas)
            if row.get('policy_sha256') != plan['package']['policies_sha256'][strategy]:
                raise ValueError('Episode policy SHA disagrees with the frozen package')
            groups.setdefault((profile, strategy), []).append(row)
            paths[key] = directory
    expected = {(p, m, seed) for p in PROFILES for m in METHODS for seed in SEEDS}
    if set(paths) != expected:
        raise ValueError('Final analysis requires all 13 profiles x five systems x 30 seeds, including reference')
    if any(f != fingerprints[0] for f in fingerprints):
        raise ValueError('Cannot combine changed code, frozen package, or inference backend')
    if fingerprints[0][0] != code_hashes() or fingerprints[0][1] != verify_package():
        raise ValueError('Current experiment source or frozen assets differ from run provenance')
    return groups, paths, fingerprints[0], manifests


def _metric_summary(rows):
    result = {}
    for key, spec in rows[0]['metrics75'].items():
        values = [r['metrics75'][key]['value'] for r in rows if r['metrics75'][key]['value'] is not None]
        result[key] = dict(label=spec['label'], unit=spec['unit'], mean=average(values),
                           valid_n=len(values), sample_sd=statistics.stdev(values) if len(values) > 1 else None)
    return result


def _fmt(value, scale=1.):
    return 'N/A' if value is None else f'{value*scale:.4f}'


def _ci(record, scale=1.):
    limits = record.get('ci95')
    interval = f"[{_fmt(limits[0], scale)}, {_fmt(limits[1], scale)}]" if limits is not None else 'N/A'
    return f"{_fmt(record.get('difference', record.get('estimate')), scale)} {interval}"


def _safe_text(value):
    return str(value).replace('|', '/').replace('\n', ' ')


def _stat(stats, key, value='mean'):
    item = stats.get(key, {})
    return f"{_fmt(item.get(value))} (n={item.get('count', 0)})"


def _report(result, output):
    lines = ['#  : current—physical', '',
        ' 45 ; environment, training. scenario, failure. ', '',
        'collectionSN→AUV ,  2048 bit. AoI AUV-timepooled; non-delivery window,  ,  PER. ',
        ' completion_window_excluded, failure; right_censoredwindow,  .  started/due/resolved/failedall. ',
        'fresh30 task ×2 ; failureAoI, collectionfresh30 . ', '',
        'topologyC07collection,  USDE; USDE-onlycollection, ACK . FIM+RL/CA-TMCenvironment system,  . ', '',
        'training; 30 . 4000scenariobootstrap 95% .  ,  . ', '',
        '##  task ', '',
        '|environment|method|collection/ | /bit·s⁻¹|pooled AoI/s|pooled AoI P95/s|DATAnon-delivery/%|STATEnon-delivery/%|fresh30 /%| /30|',
        '|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for profile in PROFILES:
        for method in METHODS:
            p = result['groups'][profile+'/'+method]['windows']['total']
            lines.append('|'+ '|'.join((profile, DISPLAY_NAMES[method], _fmt(p['collected_packets']),
                _fmt(p['fixed_budget_goodput_bit_s']), _fmt(p['pooled_aoi_s']), _fmt(p['pooled_aoi_p95_s']), _fmt(p['data_nondelivery'],100),
                _fmt(p['state_nondelivery'],100), _fmt(p['fresh30_fixed_budget'],100), str(p['full_horizon'])))+'|')
    lines += ['', '## physical service: pooled statistics', '',
        ' . errorRMSE ; USDE N/A. USDEerror current,  . ',
        ' ,  ;  N/A.  ,  . ', '',
        '|environment/ |method| RMS/m·s⁻¹| RMS/m·s⁻¹|USDEerrorRMSE/m·s⁻¹|local localizationRMSE/m|USV RMSE/m|5predictionRMSE/m| /%| /episode|',
        '|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for profile in PROFILES:
        for method in METHODS:
            for window in ('total', 'fault'):
                p = result['groups'][profile+'/'+method]['windows'][window]
                stats, service = p['sample_stats'], p['service']
                cells = (profile+'/'+window, DISPLAY_NAMES[method],
                    *(_stat(stats, key, 'rmse') for key in ('current_additional_speed_mps',
                      'current_total_speed_mps', 'usde_current_error_mps', 'local_navigation_error_m',
                      'usv_received_hold_error_m', 'planner_prediction_error_m')),
                    f"{_fmt(service['grant_inside_fraction'],100)} ({service.get('grant_inside_samples',0):.0f}/{service.get('grant_samples',0):.0f})",
                    _fmt(service.get('exits',0)/p['episodes']))
                lines.append('|'+ '|'.join(cells)+'|')
    lines += ['', '##  ', '',
        'USV–AUV . DATA ,  , failure; successful. ',
        'STATE / /statisticsUSV , successful statistics; mean.  ,  . ', '',
        '|environment/ |method|USV–AUV /m|AUV–AUV /m| SN /m|DATA /s|DATA /s|successfulSTATE |successfulSTATE /s|successfulSTATE /s|',
        '|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for profile in PROFILES:
        for method in METHODS:
            for window in ('total', 'fault'):
                p = result['groups'][profile+'/'+method]['windows'][window]
                stats, hops, delivered = p['sample_stats'], p['data']['sample_stats'], p['delivered_state_paths']['sample_stats']
                cells = (profile+'/'+window, DISPLAY_NAMES[method],
                    *(_stat(stats,key) for key in ('usv_auv_distance_m','auv_auv_distance_m','active_sn_distance_m')),
                    _stat(hops,'propagation_delay_s'), _stat(hops,'queue_wait_s'),
                    *(_stat(delivered,key) for key in ('hop_count','propagation_delay_s','queue_wait_s')))
                lines.append('|'+ '|'.join(cells)+'|')
    lines += ['', '## complete method comparator:  95% ', '',
        'complete−comparator. collection; AoInon-delivery. DATA . completeUSDE-only ,  . ', '',
        '|environment/ |comparator|collection/ |AoI /s|DATAnon-delivery/ |', '|---|---|---:|---:|---:|']
    for label, windows in result['paired_differences'].items():
        profile, comparator = label.split('/full-minus-')
        for window in ('total', 'fault'):
            p = windows[window]
            lines.append(f"|{profile}/{window}|{DISPLAY_NAMES[comparator]}|{_ci(p['collected_packets'])}|{_ci(p['pooled_aoi_s'])}|{_ci(p['data_nondelivery'],100)}|")
    lines += ['', '##  ', '',
        ' taskwindow;  60 ,  300 .  ,  . collection collection,  N/A. ', '',
        '|environment|method|collection/% 95% |collection/ |AoI /s|DATAnon-delivery/ |', '|---|---|---:|---:|---:|---:|']
    for label, p in result['within_method_reference_change'].items():
        profile, method = label.split('/')
        delta = p['paired_change']
        lines.append(f"|{profile}|{DISPLAY_NAMES[method]}|{_ci(p['aggregate_packet_retention'],100)}|{_ci(delta['collected_packets'])}|{_ci(delta['pooled_aoi_s'])}|{_ci(delta['data_nondelivery'],100)}|")
    lines += ['', '## complete method comparator', '',
        ' : (complete−complete)−(comparator−comparator).  . ', '',
        '|environment|comparator|collection/ |AoI /s|DATAnon-delivery/ |', '|---|---|---:|---:|---:|']
    for label, p in result['between_method_difference_in_differences'].items():
        profile, comparator = label.split('/full-minus-')
        v = p['estimates']
        lines.append(f"|{profile}|{DISPLAY_NAMES[comparator]}|{_ci(v['collected_packets'])}|{_ci(v['pooled_aoi_s'])}|{_ci(v['data_nondelivery'],100)}|")
    lines += ['', '##  taskservice', '',
        'current: complete120collection window80%,  30 .  120 3 ; failure.  120 , 149acknowledged. ',
        ' .  ,  ,  ;  . ', '',
        '|environment|method| /30| | /s|state|', '|---|---|---:|---:|---:|---|']
    for label, p in result['recovery_summaries'].items():
        profile, method = label.split('/')
        lines.append(f"|{profile}|{DISPLAY_NAMES[method]}|{p['threshold_attained']}|{p['observed_degradation_and_attained']}|{_fmt(p['attained_latency_median_s'])}|{_safe_text(p['status_counts'])}|")
    lines += ['', ' 75 , episode/standard deviation/  [ALL_75_METRICS_ZH.md](ALL_75_METRICS_ZH.md). ',
        'complete, localization/ / /service/statistics, episode [analysis.json](analysis.json). ',
        'episodeservice_recoverycollection90% ;  80% 30 , pooled statistics. ',
        'time9630000, failure;  .  . ',
        'USDE ;  ,  metric. ']
    with (output/'REPORT_ZH.md').open('x', encoding='utf-8') as stream:
        stream.write('\n'.join(lines)+'\n')
    appendix = ['#  ×13environment: all75 metric', '',
                'episode ± standard deviation (episode); N/A .  . ', '']
    for profile in PROFILES:
        appendix += [f'## {profile}', '', '|metric| |'+'|'.join(DISPLAY_NAMES[m] for m in METHODS)+'|',
                     '|---|---|'+'|'.join('---:' for _ in METHODS)+'|']
        first = result['groups'][profile+'/'+METHODS[0]]['metrics75']
        for key, spec in first.items():
            cells = []
            for method in METHODS:
                value = result['groups'][profile+'/'+method]['metrics75'][key]
                cells.append(f"{_fmt(value['mean'])} ± {_fmt(value['sample_sd'])} (n={value['valid_n']})")
            appendix.append('|'+ '|'.join((_safe_text(spec['label']), _safe_text(spec['unit']), *cells))+'|')
        appendix.append('')
    with (output/'ALL_75_METRICS_ZH.md').open('x', encoding='utf-8') as stream:
        stream.write('\n'.join(appendix)+'\n')


def draw_strength(groups, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    families = ('constant', 'time_varying', 'cross_gust', 'random')
    levels, x = ('weak', 'medium', 'strong'), [0., .10, .25, .40]
    keys = PRIMARY
    labels = ('Unique collection (packets)', 'Pooled STATE AoI (s)', 'DATA nondelivery (%)')
    for relative in (False, True):
        fig, axes = plt.subplots(3, 4, figsize=(17, 10), squeeze=False)
        for j, family in enumerate(families):
            for method in METHODS:
                base = groups['reference/'+method]['windows']['total']
                series = [base] + [groups[f'{family}_{level}/{method}']['windows']['total'] for level in levels]
                for i, key in enumerate(keys):
                    y = [p[key] for p in series]
                    if relative:
                        y = [_difference(value, base[key]) for value in y]
                    y = [np.nan if v is None else v*(100 if key == 'data_nondelivery' else 1) for v in y]
                    axes[i,j].plot(x, y, marker='o', markersize=3, linewidth=1., label=method)
            axes[0,j].set_title(family)
            for i in range(3):
                axes[i,j].grid(alpha=.2)
                axes[i,j].set_xlabel('Added current peak bound (m/s)')
                axes[i,j].set_ylabel(('Change vs reference: ' if relative else '')+labels[i])
        axes[0,0].legend(fontsize=7)
        fig.suptitle('Frozen 450k systems; 30 scene pairs; point estimates, all early terminations retained')
        fig.tight_layout()
        stem = 'strength_reference_change' if relative else 'strength_absolute'
        fig.savefig(output/(stem+'.png'), dpi=160)
        fig.savefig(output/(stem+'.pdf'))
        plt.close(fig)


def draw_timeline(profile, paths, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(7, 1, figsize=(12, 17), sharex=True)
    seed = 9630000  # declared before looking at results
    for method in METHODS:
        rows = read_trace(paths[(profile, method, seed)])
        t = [row['time_s'] for row in rows]
        axes[0].plot(t, [average(row['current']['current_total_speed_mps']) for row in rows], label=method, linewidth=1)
        axes[1].plot(t, [average(row['errors']['local_navigation_error_m']) for row in rows], linewidth=1)
        axes[2].plot(t, [average(row['geometry']['usv_auv_distance_m']) for row in rows], linewidth=1)
        axes[3].plot(t, [average(row['state_aoi_s']) for row in rows], linewidth=1)
        axes[4].plot(t, [row['collected_packets']*2.048 for row in rows], linewidth=1)
        axes[5].plot(t, [ratio(row['service']['grant_inside_samples'], row['service']['grant_samples']) for row in rows], linewidth=.7)
        axes[6].plot(t, [sum(row['installed_path_usable'])/2 for row in rows], linewidth=.7)
    spec = scenario(profile, seed)
    for axis in axes:
        if profile != 'reference':
            axis.axvspan(spec['onset_s'], spec['clear_s'], color='red', alpha=.08)
        axis.grid(alpha=.2)
    for axis, label in zip(axes, ('Total local current (m/s)', 'Local position estimate error (m)',
        'USV-AUV distance (m)', 'STATE AoI (s)', 'Unique collection (kbit)',
        'In-range live grant fraction', 'Installed usable path fraction')):
        axis.set_ylabel(label)
    axes[0].legend(ncol=3, fontsize=8)
    axes[-1].set_xlabel('Observed time (s); early termination is not extrapolated')
    fig.suptitle(f'{profile}; preselected scene {seed}; 450k frozen systems')
    fig.tight_layout()
    fig.savefig(output/(profile+'_timeline.png'), dpi=160)
    plt.close(fig)


def analyze_runs(inputs, output):
    output = Path(output).resolve()
    reports = (ROOT/'reports').resolve()
    if output == reports or not output.is_relative_to(reports) or output.exists():
        raise ValueError('Analysis output must be a NEW descendant of experiment 3/reports')
    groups, paths, fingerprint, manifests = _load_inputs(inputs)
    summaries, comparisons, changes, did, recoveries, recovery_summaries = {}, {}, {}, {}, {}, {}
    for profile in PROFILES:
        for method in METHODS:
            rows = sorted(groups[(profile, method)], key=lambda r: r['seed'])
            label = profile+'/'+method
            summaries[label] = dict(windows={w: pooled(rows, w) for w in WINDOWS}, metrics75=_metric_summary(rows),
                early_terminations=[dict(seed=r['seed'], time_s=r['duration_s'], reason=r['termination_reason'])
                                    for r in rows if not r['survived_full_horizon']],
                per_episode_event_summary=[dict(seed=r['seed'], **r['experiment3']) for r in rows])
            ages = {w: [] for w in WINDOWS}
            records = []
            for row in rows:
                seed = row['seed']
                sampled = read_trace(paths[(profile, method, seed)])
                if len(sampled) != row['steps'] or any(r['time_s'] != i for i,r in enumerate(sampled,1)):
                    raise ValueError('Trace steps/times disagree with the complete one-second episode evidence')
                if sampled[-1]['collected_packets'] != row['collected_packets']:
                    raise ValueError('Final trace collection disagrees with the episode record')
                for window in WINDOWS:
                    boundary = row['experiment3']['windows'][window]
                    selected = [r for r in sampled if boundary['start_s'] < r['time_s'] <= boundary['end_s']]
                    per_episode_ages = [value for r in selected for value in r['state_aoi_s']]
                    if len(per_episode_ages) != boundary['aoi_n'] or not math.isclose(sum(per_episode_ages),boundary['aoi_sum_s'],rel_tol=1e-10,abs_tol=1e-8):
                        raise ValueError('AoI trace raw samples disagree with stored sum/count')
                    ages[window].extend(per_episode_ages)
                if profile != 'reference':
                    spec = scenario(profile, seed)
                    records.append(dict(seed=seed, task_recovery=task_recovery(sampled,
                        read_trace(paths[('reference', method, seed)]),
                        origin=spec['clear_s'], onset=spec['onset_s'])))
            for window in WINDOWS:
                summary = summaries[label]['windows'][window]
                if len(ages[window]) != summary['raw']['aoi_n']:
                    raise ValueError('Group AoI sample count does not reconcile')
                summary['pooled_aoi_p95_s'] = float(np.percentile(ages[window],95)) if ages[window] else None
                summary['pooled_aoi_p95_samples'] = len(ages[window])
            if profile != 'reference':
                changes[label] = reference_change(rows, groups[('reference', method)])
                recoveries[label] = records
                recovery_summaries[label] = recovery_summary(records)
            if method != 'full_v6':
                pair = profile+'/full-minus-'+method
                comparisons[pair] = {w: paired_bootstrap(groups[(profile, 'full_v6')], rows, w) for w in WINDOWS}
                if profile != 'reference':
                    did[pair] = difference_in_differences(groups[(profile, 'full_v6')], groups[('reference', 'full_v6')],
                                                         rows, groups[('reference', method)])
    result = dict(status='completed', format=FORMAT, episodes=len(paths), groups=summaries,
        paired_differences=comparisons, within_method_reference_change=changes,
        between_method_difference_in_differences=did, paired_task_recovery=recoveries,
        recovery_summaries=recovery_summaries, input_fingerprint=fingerprint, input_manifests=manifests,
        statistical_scope='Single training seed; 4000 paired scene bootstrap draws; unadjusted pointwise 95% intervals; no automatic superiority verdict',
        directions=dict(collected_packets='higher', pooled_aoi_s='lower', data_nondelivery='lower'),
        full_horizon=sum(r['survived_full_horizon'] for rows in groups.values() for r in rows),
        early_terminations=sum(not r['survived_full_horizon'] for rows in groups.values() for r in rows),
        all_failures_retained=True, confirmation_set_accessed=False, training_steps_executed=0)
    output.mkdir(parents=True)
    write_json(output/'analysis.json', result)
    _report(result, output)
    draw_strength(summaries, output)
    for profile in PROFILES:
        draw_timeline(profile, paths, output)
    write_json(output/'audit.json', dict(status='completed', unique_episodes=len(paths), expected_episodes=1950,
        profiles=len(PROFILES), methods=len(METHODS), seeds_per_group=len(SEEDS), metric_count=75,
        all_episode_sha256_verified=True, all_failures_retained=True, duplicate_episodes=0,
        original_package_verified=verify_package(), source_hashes=code_hashes(), input_manifests=manifests,
        output_sha256={p.name: digest(p) for p in output.iterdir() if p.is_file()}))
    return dict(status='completed', episodes=len(paths), output=str(output))
