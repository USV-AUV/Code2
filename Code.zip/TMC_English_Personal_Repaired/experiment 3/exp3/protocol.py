"""Predeclared current perturbations, paired scenarios, and frozen methods."""
from pathlib import Path
import math

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT.parent / 'experiment 1'
SOURCE = PACKAGE / 'source'
METHODS = ('full_v6', 'usde_only_v6', 'topology_only_v6',
           'synchronous_fim_rl', 'communication_aware_tmc')
STRATEGIES = METHODS
FORMAT = 'experiment3-current-five-systems-v1'
SEEDS = tuple(range(9630000, 9630030))
SYNTHETIC_SEED = 42
HORIZON = 1200
START, END = 500., 800.
RAMP_SECONDS = 5.
PERIOD_SECONDS = 120.
CORRELATION_SECONDS = 20.
KNOT_SECONDS = 1.
KINDS = ('constant', 'time_varying', 'cross_gust', 'random')
INTENSITIES = {'weak': .10, 'medium': .25, 'strong': .40}
PROFILES = ('reference',) + tuple(
    f'{kind}_{strength}' for kind in KINDS for strength in INTENSITIES)
PRESETS = ('reference',) + KINDS + ('all',)


def model_for(strategy):
    if strategy not in METHODS:
        raise ValueError(f'Unknown frozen system: {strategy}')
    return strategy


def scenario(profile, seed):
    """Return a JSON-serializable, policy-independent perturbation declaration.

    A magnitude is an upper bound on the ADDITION to the original current, not
    the total speed. All methods/intensities share a seed's exogenous waveform.
    The world directions are balanced over thirty seeds; no action, route, true
    position, reward, or evaluation outcome determines a disturbance direction.
    """
    if profile not in PROFILES or seed not in SEEDS:
        raise ValueError('Only predeclared experiment-3 profiles/seeds are allowed')
    return _scenario(profile, seed, seed-SEEDS[0], formal=True)


def synthetic_scenario(profile, seed=SYNTHETIC_SEED):
    """Separate, labeled interface/smoke scenario; never part of the formal matrix."""
    if profile not in PROFILES or seed != SYNTHETIC_SEED:
        raise ValueError('Synthetic checks allow only declared profiles with seed 42')
    return _scenario(profile, seed, 0, formal=False)


def _scenario(profile, seed, index, formal):
    angle = 2. * math.pi * index / len(SEEDS)
    direction = [math.cos(angle), math.sin(angle)]
    kind, strength = ('reference', 'none') if profile == 'reference' else profile.rsplit('_', 1)
    amplitude = 0. if profile == 'reference' else INTENSITIES[strength]
    if kind == 'cross_gust':
        # "Transverse" means the declared world Y axis, not each actor's heading.
        direction = [0., 1. if index < len(SEEDS)//2 else -1.]
    end = 560. if kind == 'cross_gust' else END
    return dict(
        format=FORMAT, profile=profile, seed=int(seed), kind=kind,
        formal_experiment=bool(formal),
        intensity=strength, horizon_s=HORIZON, onset_s=START, clear_s=end,
        amplitude_mps=amplitude, direction_xy=direction,
        direction_convention='fixed world XY; paired antipodal directions across seeds',
        ramp_s=RAMP_SECONDS, period_s=PERIOD_SECONDS,
        correlation_s=CORRELATION_SECONDS, knot_s=KNOT_SECONDS,
        random_namespace=303 if formal else 403, random_pair_index=index % (len(SEEDS)//2),
        random_pair_sign=1 if index < len(SEEDS)//2 else -1,
        random_process=(
            'stationary 2D Gaussian AR(1), phi=exp(-knot_s/correlation_s); '
            'radial tanh map to open unit disk; cubic smoothstep interpolation; '
            '20s is latent AR correlation, not asserted transformed correlation'),
        envelope='cubic smoothstep ramp on [onset,onset+5] and [clear-5,clear]; zero outside',
        amplitude_definition='upper bound on instantaneous added-current Euclidean speed, not total-current speed',
        rms_definition=(
            'sqrt(integral(|added current|^2 dt)/(clear-onset)) over the full '
            'declared active interval including both ramps; also report sampled '
            'actual total current separately; equal peaks do not imply equal RMS'),
        spatial_definition='uniform additive world-frame field; original seeded space-time field retained',
        physical_scope='original AUV advection only; frozen USV kinematics retained',
        field_access='physical dynamics and offline observer only; never policy observations',
    )


def matrix(preset):
    if preset not in PRESETS:
        raise ValueError(f'Unknown experiment-3 preset: {preset}')
    if preset == 'all':
        profiles = PROFILES
    elif preset == 'reference':
        profiles = ('reference',)
    else:
        profiles = tuple(p for p in PROFILES if p.startswith(preset + '_'))
    return [(profile, method, seed) for profile in profiles
            for method in METHODS for seed in SEEDS]
