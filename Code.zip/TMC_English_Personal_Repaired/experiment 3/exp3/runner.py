"""Frozen 450k inference; an explicit execution gate is required for simulations."""
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

from .protocol import ROOT, PACKAGE, SOURCE, METHODS, FORMAT, model_for, matrix, scenario, synthetic_scenario

sys.dont_write_bytecode = True
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write('\n')


def verify_package():
    expected = json.loads((ROOT / 'asset_lock.json').read_text(encoding='utf-8'))
    registry = PACKAGE / 'checksums.sha256'
    if digest(registry) != expected['experiment1_checksums_sha256']:
        raise ValueError('Frozen experiment 1 registry changed')
    count = 0
    for line in registry.read_text(encoding='utf-8-sig').splitlines():
        sha, rel = line.split(' *', 1)
        path = (PACKAGE / rel).resolve()
        if not path.is_relative_to(PACKAGE.resolve()) or digest(path) != sha:
            raise ValueError(f'Frozen asset changed: {rel}')
        count += 1
    if set(expected['policies_sha256']) != set(METHODS):
        raise ValueError('Five-system model identities changed')
    for method, sha in expected['policies_sha256'].items():
        if digest(PACKAGE / 'models' / '45w' / method / 'policy.pt') != sha:
            raise ValueError(f'Wrong 450000-step policy: {method}')
    return dict(verified_files=count, registry_sha256=expected['experiment1_checksums_sha256'],
                policies_sha256=expected['policies_sha256'])


def code_hashes():
    paths = (list((ROOT / 'exp3').glob('*.py')) + list((ROOT / 'tests').glob('*.py'))
             + list((ROOT / 'commands').glob('*.ps1'))
             + [ROOT / name for name in ('run_experiment3.py', 'verify_deployment.py',
                                        'asset_lock.json', 'PROTOCOL_ZH.md', 'README.md')])
    return {str(path.relative_to(ROOT)): digest(path) for path in sorted(paths)}


def destination(path, category):
    result = Path(path).resolve()
    allowed = (ROOT / category).resolve()
    if result == allowed or not result.is_relative_to(allowed) or result.exists():
        raise ValueError(f'Output must be a NEW subdirectory of {allowed}')
    return result


def load(strategy, device):
    from v6_campaigns.c07_1m_20260919.workflow import Policy, load_checkpoint, make_environment_observer
    from baselines.deploy import BaselinePolicy
    from baselines.environment import BaselineEnv
    from baselines.evaluate import make_environment_observer as baseline_observer
    method = model_for(strategy)
    path = PACKAGE / 'models' / '45w' / method / 'policy.pt'
    checkpoint = load_checkpoint(path)
    if checkpoint['global_step'] != 450000 or checkpoint['method_id'] != method:
        raise ValueError('Only the frozen five 450000-step models are accepted')
    if method in METHODS[:3]:
        policy = Policy(checkpoint, device, method, verify=True)
        env = policy.make_environment()
        observer = make_environment_observer
    else:
        policy = BaselinePolicy(checkpoint, device, method, verify_sources=True)
        env = BaselineEnv(policy.cfg, method)
        policy.bind_environment(env)
        observer = baseline_observer
    if policy.cfg.fingerprint != '48caa5c4f5bf9627':
        env.close()
        raise ValueError('Base physical configuration identity mismatch')
    return policy, env, observer, checkpoint, path


def bind(policy, env):
    if hasattr(policy, 'bind_environment'):
        policy.bind_environment(env)
    else:
        policy.validate_environment(env)


def routing_decision(strategy, policy, env):
    if policy.method.method_id != model_for(strategy):
        raise ValueError('Selected strategy and policy disagree')
    if env.step_count % env.cfg.slow_period:
        return None
    return policy.topology_action(*env.slow_state()) if policy.topology is not None else None


def validate(output, execute=False):
    """Future opt-in initialization/forward checks; zero env.step, no formal seeds."""
    if not execute:
        raise ValueError('Model interface checking requires --execute')
    import numpy as np
    import torch
    from .protocol import PROFILES
    from .currents import attach_current
    output = destination(output, 'verification')
    verified, hashes = verify_package(), code_hashes()
    result = []
    for method in METHODS:
        policy, env, factory, checkpoint, path = load(method, 'cpu')
        try:
            profiles = []
            for profile in PROFILES:
                obs, info = env.reset(seed=42)
                bind(policy, env)
                config = env.cfg.to_dict()
                flow = attach_current(env, synthetic_scenario(profile, 42))
                with torch.inference_mode():
                    action = policy.act(obs)
                    topology = routing_decision(method, policy, env)
                if action.shape != (2, 2) or not np.isfinite(action).all():
                    raise ValueError('Invalid initial policy action')
                if env.time != 0 or env.step_count != 0 or env.cfg.to_dict() != config:
                    raise ValueError('Interface check mutated the base environment configuration')
                if not np.isfinite(flow.velocity(env.auv_positions, 0)).all():
                    raise ValueError('Nonfinite initial current field')
                profiles.append(dict(profile=profile, topology=topology, environment_steps=0))
            result.append(dict(method=method, model_step=checkpoint['global_step'],
                               sha256=digest(path), profiles=profiles))
        finally:
            env.close()
    if verify_package() != verified or code_hashes() != hashes:
        raise ValueError('Assets changed during interface checking')
    output.mkdir(parents=True)
    record = dict(status='interface_checks_passed', formal_experiment=False,
                  models=result, combinations=sum(len(r['profiles']) for r in result),
                  environment_steps=0, training_steps=0, package=verified, code_hashes=hashes)
    write_json(output / 'interface.json', record)
    return record


def episode(policy, env, observer_factory, strategy, profile, seed, directory, max_steps=1200,
            formal=True):
    import torch
    from usv_auv.learning import seed_all
    from usv_auv.train import json_safe
    from scripts.summarize_tmc_retest import selected_specs
    from .currents import attach_current
    from .measurement import Timeline, summarize, PassiveNetworkObserver
    spec = scenario(profile, seed) if formal else synthetic_scenario(profile, seed)
    seed_all(seed)
    obs, info = env.reset(seed=seed)
    bind(policy, env)
    configuration_before = env.cfg.to_dict()
    flow = attach_current(env, spec)
    eo = observer_factory(env, info, policy.method)
    no = PassiveNetworkObserver(env.network)
    total_reward, started = 0., time.monotonic()
    try:
        timeline = Timeline(env, spec, flow)
        with gzip.open(directory / 'trace.jsonl.gz', 'xt', encoding='utf-8') as trace:
            with torch.inference_mode():
                for index in range(max_steps):
                    topo = routing_decision(strategy, policy, env)
                    actions = policy.act(obs)
                    obs, reward, terminated, truncated, info = env.step(actions, topology_action=topo)
                    total_reward += float(reward)
                    telemetry = eo.after_step(info)
                    dynamics = timeline.sample(telemetry, topo)
                    row = dict(seed=seed, step=index + 1, actions=actions.tolist(), topology_request=topo,
                               reward=float(reward), info=info, terminated=bool(terminated),
                               truncated=bool(truncated), passive_environment=telemetry,
                               experiment3=dynamics)
                    trace.write(json.dumps(json_safe(row), ensure_ascii=False, allow_nan=False) + '\n')
                    if terminated or truncated:
                        break
        duration = float(info['time'])
        metrics = json_safe(info['metrics'])
        record = dict(seed=seed, method_id=policy.method.method_id, strategy=strategy, profile=profile,
                      scenario=spec, current_declaration=flow.describe(), model_step=450000, formal_experiment=formal,
                      policy_sha256=digest(PACKAGE / 'models' / '45w' / model_for(strategy) / 'policy.pt'),
                      steps=index + 1, duration_s=duration, terminated=bool(terminated),
                      truncated=bool(truncated), termination_reason=info['termination_reason'],
                      survived_full_horizon=not terminated and index + 1 == 1200,
                      **{'return': total_reward}, metrics_base=metrics, environment=eo.finalize(),
                      network=no.finalize(duration), collected_packets=metrics['collected_bits'] / 2048,
                      ack_packets=metrics['ack_released_bits'] / 2048,
                      collection_fraction=metrics['collected_bits'] / (metrics['initial_bits'] + metrics['arrival_bits']),
                      goodput_bit_s=metrics['collected_bits'] / duration,
                      fixed_budget_goodput_bit_s=metrics['collected_bits'] / 1200,
                      experiment3=summarize(timeline.rows, no, spec, duration),
                      wall_time_s=time.monotonic() - started)
        if not record['network']['core_counter_reconciliation']['all_observed_counters_match_core']:
            raise ValueError('Network counters disagree with passive observer')
        if record['network']['logical']['DATA']['delivered_unique'] != len(env.collected):
            raise ValueError('Collected unique DATA and observer disagree')
        if env.cfg.to_dict() != configuration_before:
            raise ValueError('Base config mutated during current-only evaluation')
        record['metrics75'] = {key: dict(label=label, unit=unit, value=getter(record))
                              for key, label, unit, _, getter in selected_specs()}
        if not record['environment']['planner_horizon_prediction'].get('applicable', True):
            for key, metric in record['metrics75'].items():
                if key.startswith('environment.planner_horizon_prediction.'):
                    metric['value'] = None
        if len(record['metrics75']) != 75:
            raise ValueError('Expected the established 75 metrics')
        with gzip.open(directory / 'events.json.gz', 'xt', encoding='utf-8') as stream:
            json.dump(json_safe(dict(scenario=spec, native_background_faults=policy.cfg.faults,
                                    hop_events=no.hop_events, emissions=no.emissions,
                                    deliveries=no.delivery_events, protocol_events=no.protocol_events,
                                    queue_events=no.queue_events)), stream,
                      ensure_ascii=False, allow_nan=False)
        write_json(directory / 'episode.json', json_safe(record))
        write_json(directory / 'complete.json', dict(status='completed',
                   sha256={p.name: digest(p) for p in directory.iterdir() if p.is_file()}))
        return record
    finally:
        no.detach()


def evaluate(preset, output, execute=False, smoke=False, smoke_steps=5):
    if not execute:
        raise ValueError('No simulation starts without --execute')
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError('Evaluation requires CUDA; CPU fallback is not automatic')
    if not 1 <= smoke_steps <= 20:
        raise ValueError('Smoke length must be between 1 and 20 steps')
    from .protocol import PROFILES
    output = destination(output, 'verification' if smoke else 'runs')
    verified, hashes = verify_package(), code_hashes()
    jobs = [(p, m, 42) for p in PROFILES for m in METHODS] if smoke else matrix(preset)
    output.mkdir(parents=True)
    write_json(output / 'plan.json', dict(format=FORMAT, preset='smoke' if smoke else preset,
               jobs=jobs, formal_experiment=not smoke, mode='smoke' if smoke else 'formal',
               code_hashes=hashes, package=verified, device='cuda', training_steps_executed=0,
               completed_model_training_step=450000, failures_retained=True,
               max_steps=smoke_steps if smoke else 1200))
    completed = 0
    policy = env = loaded_strategy = None
    try:
        for profile, strategy, seed in jobs:
            if strategy != loaded_strategy:
                if env is not None:
                    env.close()
                policy, env, factory, _, _ = load(strategy, 'cuda')
                loaded_strategy = strategy
            dest = output / profile / strategy / str(seed)
            dest.mkdir(parents=True, exist_ok=False)
            episode(policy, env, factory, strategy, profile, seed, dest,
                    max_steps=smoke_steps if smoke else 1200, formal=not smoke)
            completed += 1
            with (output / 'progress.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(dict(completed=completed, total=len(jobs), profile=profile,
                                             strategy=strategy, seed=seed, time=time.time())) + '\n')
        if code_hashes() != hashes or verify_package() != verified:
            raise RuntimeError('Frozen assets changed during evaluation')
        write_json(output / 'complete.json', dict(status='completed', episodes=completed,
                   formal_experiment=not smoke, package_unchanged=True, experiment_code_unchanged=True))
    except BaseException as exc:
        write_json(output / 'interrupted.json', dict(error=repr(exc), completed=completed,
                   note='Preserve partial evidence; do not overwrite or restart this directory'))
        raise
    finally:
        if env is not None:
            env.close()
    return dict(status='completed', output=str(output), episodes=completed, formal_experiment=not smoke)
