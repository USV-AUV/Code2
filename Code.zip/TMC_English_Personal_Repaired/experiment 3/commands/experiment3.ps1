param(
    [ValidateSet('Plan','Static','UnitTests','Validate','Smoke','Run','Analyze')]
    [string]$Action = 'Plan',
    [string]$Python = '',
    [ValidateSet('reference','constant','time_varying','cross_gust','random','all')]
    [string]$Preset = 'all',
    [string]$Output,
    [string[]]$Inputs,
    [switch]$Execute
)
$ErrorActionPreference = 'Stop'
$experimentRoot = Split-Path -Parent $PSScriptRoot
if (-not $Python) {
    $researchRoot = Split-Path -Parent (Split-Path -Parent $experimentRoot)
    $Python = Join-Path $researchRoot 'USV-AUV-delay\.venv\Scripts\python.exe'
}
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw 'Python executable not found' }
Push-Location -LiteralPath $experimentRoot
try {
    if ($Action -eq 'Plan') {
        & $Python -B -X utf8 .\run_experiment3.py plan --preset $Preset
    } elseif ($Action -eq 'Static') {
        if (-not $Output) { throw 'Provide a new verification JSON path with -Output' }
        & $Python -B -X utf8 .\verify_deployment.py --output $Output
    } elseif ($Action -eq 'UnitTests') {
        if (-not $Execute) { throw 'Unit tests require -Execute' }
        & $Python -B -X utf8 -m unittest discover -s tests -v
    } elseif ($Action -eq 'Analyze') {
        if (-not $Output -or -not $Inputs) { throw 'Analyze requires -Inputs and -Output' }
        & $Python -B -X utf8 .\run_experiment3.py analyze --input @Inputs --output $Output
    } else {
        if (-not $Execute -or -not $Output) { throw 'Simulation/model checks require -Execute and a new -Output' }
        $experimentArgs = @('-B','-X','utf8','.\run_experiment3.py',$Action.ToLower(),'--output',$Output,'--execute')
        if ($Action -eq 'Run') { $experimentArgs += @('--preset',$Preset) }
        & $Python @experimentArgs
    }
    if ($LASTEXITCODE -ne 0) { throw "Experiment 3 command exited with code $LASTEXITCODE" }
} finally {
    Pop-Location
}
