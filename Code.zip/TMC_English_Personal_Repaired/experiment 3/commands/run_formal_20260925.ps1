param()

$ErrorActionPreference = 'Stop'
$experimentRoot = Split-Path -Parent $PSScriptRoot
$researchRoot = Split-Path -Parent (Split-Path -Parent $experimentRoot)
$python = Join-Path $researchRoot 'USV-AUV-delay\.venv\Scripts\python.exe'
$runState = Join-Path $experimentRoot 'orchestration\formal_20260925'
$statusPath = Join-Path $runState 'status.json'
$presets = @('reference', 'constant', 'time_varying', 'cross_gust', 'random')

if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw "Frozen project Python was not found: $python"
}
if (Test-Path -LiteralPath $runState) {
    throw "Formal orchestration already exists: $runState"
}
New-Item -ItemType Directory -Path $runState -ErrorAction Stop | Out-Null

function Write-RunStatus {
    param([string]$Stage, [string]$Phase, [string[]]$Done, [string]$Detail = '')
    $record = [ordered]@{
        status = $Stage
        phase = $Phase
        completed_presets = @($Done)
        detail = $Detail
        updated_at_utc = [DateTime]::UtcNow.ToString('o')
        process_id = $PID
    }
    $record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $statusPath -Encoding utf8
}

$completed = @()
Write-RunStatus -Stage 'running' -Phase 'starting' -Done $completed
Push-Location -LiteralPath $experimentRoot
try {
    foreach ($preset in $presets) {
        $output = Join-Path $experimentRoot "runs\${preset}_formal_20260925"
        if (Test-Path -LiteralPath $output) {
            throw "Refusing to overwrite a formal run: $output"
        }
        Write-RunStatus -Stage 'running' -Phase $preset -Done $completed
        & $python -B -X utf8 .\run_experiment3.py run --preset $preset --output $output --execute
        if ($LASTEXITCODE -ne 0) {
            throw "Formal preset $preset exited with code $LASTEXITCODE"
        }
        $complete = Join-Path $output 'complete.json'
        if (-not (Test-Path -LiteralPath $complete -PathType Leaf)) {
            throw "Formal preset $preset produced no complete.json"
        }
        $completed += $preset
        Write-RunStatus -Stage 'running' -Phase 'next' -Done $completed
    }

    $inputs = @($presets | ForEach-Object { Join-Path $experimentRoot "runs\${_}_formal_20260925" })
    $report = Join-Path $experimentRoot 'reports\all_formal_20260925'
    if (Test-Path -LiteralPath $report) {
        throw "Refusing to overwrite analysis: $report"
    }
    Write-RunStatus -Stage 'running' -Phase 'analysis' -Done $completed
    & $python -B -X utf8 .\run_experiment3.py analyze --input @inputs --output $report
    if ($LASTEXITCODE -ne 0) {
        throw "Formal analysis exited with code $LASTEXITCODE"
    }
    if (-not (Test-Path -LiteralPath (Join-Path $report 'audit.json') -PathType Leaf)) {
        throw 'Formal analysis produced no audit.json'
    }
    Write-RunStatus -Stage 'completed' -Phase 'done' -Done $completed -Detail $report
    exit 0
} catch {
    Write-RunStatus -Stage 'failed' -Phase 'stopped' -Done $completed -Detail $_.Exception.Message
    Write-Error $_
    exit 1
} finally {
    Pop-Location
}
