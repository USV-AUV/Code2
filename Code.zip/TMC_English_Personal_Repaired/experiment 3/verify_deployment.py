"""Static-only audit: no imports of experiment code, torch, tests or environments."""
import argparse
import ast
import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent / 'experiment 1'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    out = args.output.resolve()
    if out.exists() or not out.is_relative_to((ROOT / 'verification').resolve()):
        raise ValueError('Static record must be a NEW file within verification/')
    paths = sorted((ROOT / 'exp3').glob('*.py')) + sorted((ROOT / 'tests').glob('*.py'))
    paths += [ROOT / 'run_experiment3.py', ROOT / 'verify_deployment.py']
    compiled, definitions, missing = [], {}, []
    authored_tests = 0
    for path in paths:
        source = path.read_text(encoding='utf-8')
        tree = ast.parse(source, filename=str(path))
        compile(tree, str(path), 'exec')  # creates code object only; NEVER exec/eval
        if path.parent.name == 'tests':
            authored_tests += sum(isinstance(n, ast.FunctionDef) and n.name.startswith('test_')
                                  for n in ast.walk(tree))
        compiled.append(str(path.relative_to(ROOT)))
        definitions[path.stem] = sorted(n.name for n in tree.body
                                       if isinstance(n, (ast.FunctionDef, ast.ClassDef)))
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom) and n.level == 1 and n.module:
                target = ROOT / 'exp3' / (n.module.replace('.', '/') + '.py')
                if not target.is_file():
                    missing.append(str(target))
    if missing:
        raise ValueError(f'Unresolved relative source modules: {missing}')
    required = {'runner': ['evaluate', 'episode', 'load', 'verify_package', 'code_hashes'],
                'currents': ['attach_current'], 'protocol': ['scenario', 'synthetic_scenario', 'matrix', 'model_for'],
                'measurement': ['Timeline', 'PassiveNetworkObserver', 'summarize'],
                'analysis': ['analyze_runs']}
    for module, names in required.items():
        for name in names:
            if name not in definitions.get(module, []):
                raise ValueError(f'Missing reviewed interface: {module}.{name}')
    registry = PACKAGE / 'checksums.sha256'
    lock = json.loads((ROOT / 'asset_lock.json').read_text(encoding='utf-8'))
    if digest(registry) != lock['experiment1_checksums_sha256']:
        raise ValueError('Experiment 1 registry identity mismatch')
    verified = 0
    for line in registry.read_text(encoding='utf-8-sig').splitlines():
        sha, rel = line.split(' *', 1)
        candidate = (PACKAGE / rel).resolve()
        if not candidate.is_relative_to(PACKAGE.resolve()) or digest(candidate) != sha:
            raise ValueError(f'Frozen package mismatch: {rel}')
        verified += 1
    for method, sha in lock['policies_sha256'].items():
        if digest(PACKAGE / 'models' / '45w' / method / 'policy.pt') != sha:
            raise ValueError(f'Model hash mismatch: {method}')
    dependencies = {}
    for name in ('numpy', 'torch', 'matplotlib'):
        if importlib.util.find_spec(name) is None:
            raise ModuleNotFoundError(name)
        dependencies[name] = importlib.metadata.version(name)
    evidence_paths = (paths + sorted((ROOT / 'commands').glob('*.ps1'))
                      + [ROOT / 'asset_lock.json', ROOT / 'README.md', ROOT / 'PROTOCOL_ZH.md'])
    record = dict(status='static_checks_passed_runtime_not_tested',
                  checked_at_utc=datetime.now(timezone.utc).isoformat(),
                  compiled_files=compiled, verified_frozen_files=verified,
                  model_count=len(lock['policies_sha256']), dependencies=dependencies,
                  source_sha256={str(q.relative_to(ROOT)): digest(q) for q in evidence_paths},
                  test_cases_authored=authored_tests,
                  tests_executed=0, model_forwards_executed=0, environment_steps_executed=0,
                  formal_episodes_executed=0, training_steps_executed=0,
                  limitation='Syntax, declared interface, dependency metadata and file identity checks only. '
                             'No runtime correctness or performance claim; user requested no testing.')
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('x', encoding='utf-8') as f:
        json.dump(record, f, ensure_ascii=False, allow_nan=False, indent=2)
        f.write('\n')
    print(json.dumps({k: v for k, v in record.items() if k != 'source_sha256'},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
