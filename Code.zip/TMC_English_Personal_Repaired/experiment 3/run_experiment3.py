"""Experiment 3 CLI. Nothing runs on import; simulation needs --execute."""
import argparse
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True


def main():
    from exp3.protocol import FORMAT, METHODS, matrix
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    presets = ['reference', 'constant', 'time_varying', 'cross_gust', 'random', 'all']
    plan = sub.add_parser('plan', help='List jobs only; no model loading or simulation')
    plan.add_argument('--preset', choices=presets, default='all')
    for name in ('validate', 'smoke', 'run'):
        p = sub.add_parser(name)
        p.add_argument('--output', type=Path, required=True)
        p.add_argument('--execute', action='store_true')
        if name == 'run':
            p.add_argument('--preset', choices=presets, default='all')
        if name == 'smoke':
            p.add_argument('--steps', type=int, default=5)
    p = sub.add_parser('analyze', help='Offline analysis of completed formal runs')
    p.add_argument('--input', type=Path, nargs='+', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'plan':
        jobs = matrix(args.preset)
        result = dict(status='plan_only', format=FORMAT, episodes=len(jobs), methods=METHODS,
                      profiles=list(dict.fromkeys(p for p, m, s in jobs)), environment_steps=0,
                      training_steps=0)
    elif args.command == 'validate':
        from exp3.runner import validate
        result = validate(args.output, args.execute)
    elif args.command in ('run', 'smoke'):
        from exp3.runner import evaluate
        result = evaluate(getattr(args, 'preset', 'all'), args.output, args.execute,
                          smoke=args.command == 'smoke', smoke_steps=getattr(args, 'steps', 5))
    else:
        from exp3.analysis import analyze_runs
        result = analyze_runs(args.input, args.output)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2))


if __name__ == '__main__':
    main()
