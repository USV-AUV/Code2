"""Authored diagnostic tests. Deployment does not execute these tests."""
import copy
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'experiment 1' / 'source'))

from exp3.measurement import (PassiveNetworkObserver, Timeline, _service_recovery,
                             _service_snapshot, delivered_state_paths, hop_window,
                             sample_stats, summarize)
from usv_auv.network import AcousticNetwork, Packet


def network_config():
    return dict(n_auv=2, n_sensors=0, bit_rate=8000., max_packet_bits=512,
                link_range=100., slot_duration=.2, guard_time=.01,
                base_per=0., distance_per=0., discovery_enabled=False,
                config_timeout=10., route_lease=100., report_ttl=10.)


def toy_env(use_usde=False):
    network = SimpleNamespace(
        root_parents=(0, 0), local_parents={1: 0, 2: 0}, active_version={1: 0, 2: 0},
        installed_routes={1: {0: ((0, 0), 9999.)}, 2: {0: ((0, 0), 9999.)}},
        max_range=100., _is_failed=lambda *args: False)
    env = SimpleNamespace(
        time=0., cfg=SimpleNamespace(n_auv=2, dt=1., collection_radius=5.),
        method=SimpleNamespace(use_usde=use_usde), network=network, collected=set(),
        auv_positions=np.array([[1., 0.], [2., 0.]]), usv_position=np.zeros(2),
        sensor_positions=np.array([[0., 0.], [15., 0.]]),
        grants={0: (1, 100.)}, targets=np.array([0, 1]), executed_velocities=np.zeros((2, 2)),
        usde=[])
    env._positions_3d = lambda: np.column_stack((np.vstack((env.usv_position, env.auv_positions,
                                                         env.sensor_positions)), np.zeros(5)))
    return env


class MeasurementTests(unittest.TestCase):
    def test_missing_values_are_not_zeros(self):
        result = sample_stats([None, 3., 4.])
        self.assertEqual(result['count'], 2)
        self.assertEqual(result['total_count'], 3)
        self.assertEqual(result['sum_squares'], 25.)
        self.assertIsNone(sample_stats([None])['rmse'])
        self.assertRaises(ValueError, sample_stats, [float('nan')])

    def test_hop_due_window_separates_early_failure_from_real_censoring(self):
        def hop(at, due, outcome, resolved_at):
            return dict(time=at, nominal_arrival_at=due, outcome=outcome, outcome_at=resolved_at,
                        packet={'kind': 'DATA'}, geometry={'hop_distance_m': 75., 'propagation_delay_s': .05})
        events = [hop(501., 502., 'arrived_accepted', 502.),
                  hop(510., 511., 'failed_at_start', 510.),
                  hop(799., 801., 'failed_at_start', 799.),
                  hop(799.5, 801.5, 'in_flight', None),
                  hop(800., 801., 'arrived_accepted', 801.)]
        result = hop_window(events, 'DATA', 500., 800.)
        self.assertEqual((result['started'], result['resolved'], result['failed'], result['right_censored']),
                         (4, 2, 1, 1))
        self.assertEqual(result['completion_window_excluded'], 2)
        self.assertEqual(result['completion_window_pending'], 0)
        self.assertEqual(result['all_emitted_resolved'], 3)
        self.assertEqual(result['all_emitted_failed'], 2)
        self.assertEqual(result['nondelivery'], .5)
        self.assertEqual(result['sample_stats']['propagation_delay_s']['count'], 4)
        self.assertEqual(result['sample_stats']['queue_wait_s']['count'], 0)

    def test_grant_expiry_target_switch_and_reassignment_are_not_exits(self):
        env = toy_env()
        first = _service_snapshot(env, {})
        self.assertEqual(first['grant_inside_samples'], 1)
        env.targets[0] = 1
        self.assertEqual(_service_snapshot(env, first['active_grants'])['exits'], 0)
        env.auv_positions[0] = [10., 0.]
        self.assertEqual(_service_snapshot(env, first['active_grants'])['exits'], 1)
        env.time = 101.
        self.assertEqual(_service_snapshot(env, first['active_grants'])['exits'], 0)
        env.time = 1.
        env.grants[0] = (2, 100.)
        env.auv_positions[1] = [20., 0.]
        self.assertEqual(_service_snapshot(env, first['active_grants'])['exits'], 0)

    def test_actual_state_path_is_delivery_conditional_and_not_double_counted(self):
        packet = dict(kind='STATE', src=1, seq=5)
        hops = [dict(packet=packet, outcome='arrived_accepted', outcome_at=at,
                     geometry=dict(propagation_delay_s=.1, queue_wait_s=.2)) for at in (490., 500.)]
        deliveries = [dict(packet=packet, receiver=0, time=500.),
                      dict(packet=packet, receiver=0, time=505.)]
        observer = SimpleNamespace(hop_events=hops, delivery_events=deliveries)
        result = delivered_state_paths(observer, 380., 500.)
        self.assertEqual(result['delivered_unique'], 1)
        self.assertEqual(result['sample_stats']['hop_count']['mean'], 2.)
        self.assertAlmostEqual(result['sample_stats']['propagation_delay_s']['mean'], .2)
        self.assertEqual(delivered_state_paths(observer, 500., 800.)['delivered_unique'], 0)

    def test_multiple_live_grants_keep_grant_denominator(self):
        env = toy_env()
        env.grants[1] = (1, 100.)
        state = _service_snapshot(env, {})
        self.assertEqual(state['grant_samples'], 2)
        self.assertEqual(state['grant_inside_samples'], 1)
        self.assertEqual(state['target_grant_samples'], 1)

    def test_emission_geometry_and_queue_wait_do_not_change_core(self):
        positions = np.array([[0., 0.], [30., 40.], [0., 0.]])
        results = []
        for observed in (False, True):
            net = AcousticNetwork(network_config(), seed=17)
            provider_calls = []
            def provider(time):
                provider_calls.append(time)
                return positions
            observer = PassiveNetworkObserver(net) if observed else None
            try:
                net.submit(Packet(1, 0, 'DATA', {'data_seq': 1}, 0., 512))
                delivered = net.advance(.4, provider)
                results.append((copy.deepcopy(net.metrics), copy.deepcopy(net.rng.bit_generator.state),
                                provider_calls, [(d.arrived_at, d.receiver) for d in delivered]))
                if observed:
                    hop = observer.hop_events[0]
                    self.assertAlmostEqual(hop['geometry']['hop_distance_m'], 50.)
                    self.assertAlmostEqual(hop['geometry']['propagation_delay_s'], 50. / net.sound_speed)
                    self.assertAlmostEqual(hop['geometry']['queue_wait_s'], .2)
            finally:
                if observer is not None:
                    observer.detach()
                    self.assertNotIn('_tmc_network_observer', net.__dict__)
                    for hook in observer._HOOKS:
                        self.assertNotIn(hook, net.__dict__)
        self.assertEqual(results[0], results[1])

    def test_timeline_preserves_absent_estimator_and_target_truth(self):
        env = toy_env()
        env.network.root_parents = (2, 0)
        current = SimpleNamespace(sample_components=lambda p, t: {
            'base': np.zeros_like(p), 'additional': np.tile([.25, 0.], (2, 1)),
            'total': np.tile([.25, 0.], (2, 1))})
        timeline = Timeline(env, {'onset_s': 500., 'clear_s': 800.}, current)
        env.time = 1.
        env.auv_positions += [.25, 0.]
        telemetry = dict(matured_planner_predictions=[], state_aoi_s=[1., 1.],
                         state_no_message=[True, True], local_navigation_error_m=[.1, .2],
                         usv_received_hold_error_m=[None, None])
        row = timeline.sample(telemetry, None)
        self.assertEqual(row['current']['usde_current_error_mps'], [None, None])
        self.assertEqual(row['current']['ground_command_residual_mps'], [.25, .25])
        self.assertEqual(row['geometry']['active_sn_distance_m'], [1.25, 12.75])
        self.assertEqual(row['installed_path_hops'], [1, 1])
        self.assertEqual(row['fresh30'], [False, False])
        summary = summarize(timeline.rows, SimpleNamespace(hop_events=[]), timeline.spec, 1.)
        self.assertEqual(summary['windows']['total']['sample_stats']['usde_current_error_mps']['count'], 0)
        self.assertEqual(summary['windows']['total']['aoi_n'], 2)
        self.assertEqual(summary['windows']['total']['budget_seconds'], 1200.)
        self.assertEqual(summary['root_parent_switch_count'], 0)
        self.assertEqual(row['root_parents_before'], [2, 0])
        env.time = 2.
        env.network.root_parents = (0, 0)
        timeline.sample(telemetry, None)
        changed = summarize(timeline.rows, SimpleNamespace(hop_events=[]), timeline.spec, 2.)
        self.assertEqual(changed['root_parent_switch_count'], 1)
        self.assertEqual(changed['root_parent_switches'][0]['before'], [2, 0])

    def test_summary_rejects_installed_without_structural_path(self):
        rows = [dict(time_s=1., installed_path_usable=[True, False],
                     structural_possible=[False, False])]
        with self.assertRaisesRegex(ValueError, 'not a subset'):
            summarize(rows, SimpleNamespace(hop_events=[]), {'onset_s': 500., 'clear_s': 800.}, 1.)

    def test_hop_primary_denominator_matches_frozen_completion_window(self):
        net = AcousticNetwork({**network_config(), 'faults': [dict(src=0, dst=1, start=0., end=1.)]})
        observer = PassiveNetworkObserver(net)
        try:
            net.submit(Packet(0, 1, 'DATA', {'data_seq': 4}, 0., 512))
            net.advance(.02, np.zeros((3, 2)))
            frozen = observer.finalize(.02)['by_kind']['DATA']['hop_delivery']
            measured = hop_window(observer.hop_events, 'DATA', 0., .02)
            self.assertEqual(measured['resolved'], frozen['completion_window']['resolved_trials'])
            self.assertEqual(measured['failed'], frozen['completion_window']['resolved_failures'])
            self.assertEqual(measured['all_emitted_failed'], frozen['resolved_failures'])
            self.assertEqual(measured['right_censored'], 0)
            self.assertEqual(measured['completion_window_excluded'], 1)
        finally:
            observer.detach()

    def test_service_recovery_requires_complete_post_window_and_nonzero_reference(self):
        rows = [dict(time_s=float(t), dt_s=1., new_packets=int(t % 10 == 0)) for t in range(801, 921)]
        self.assertEqual(_service_recovery(rows, 800., .1, 920.)['latency_s'], 120.)
        self.assertFalse(_service_recovery(rows[:-1], 800., .1, 919.)['recovered'])
        self.assertEqual(_service_recovery(rows, 800., 0., 920.)['status'], 'undefined_zero_pre_collection')


if __name__ == '__main__':
    unittest.main()
