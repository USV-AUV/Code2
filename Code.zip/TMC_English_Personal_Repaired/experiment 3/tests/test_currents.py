"""Synthetic current checks prepared for later explicit test execution."""
from copy import deepcopy
from types import SimpleNamespace
import unittest

import numpy as np

from exp3.currents import AdditiveCurrent, attach_current
from exp3.protocol import (FORMAT, METHODS, PROFILES, SEEDS, matrix, scenario,
                           synthetic_scenario)


class ConstantBase:
    cfg = SimpleNamespace()
    phase = 1.234
    center = np.array([50., 50.])
    speed_upper_bound = .3

    def velocity(self, positions, time):
        return np.broadcast_to(np.array([.3, 0.]), np.asarray(positions).shape).copy()


class CurrentTests(unittest.TestCase):
    def field(self, profile='constant_strong', seed=SEEDS[0]):
        return AdditiveCurrent(ConstantBase(), scenario(profile, seed))

    def test_exact_five_system_matrix_and_pairing(self):
        jobs = matrix('all')
        self.assertEqual(len(PROFILES), 13)
        self.assertEqual(len(jobs), 1950)
        self.assertEqual(len(set(jobs)), 1950)
        self.assertEqual(METHODS, ('full_v6', 'usde_only_v6', 'topology_only_v6',
                                 'synchronous_fim_rl', 'communication_aware_tmc'))
        self.assertEqual(len(matrix('reference')), 150)
        for kind in ('constant', 'time_varying', 'cross_gust', 'random'):
            self.assertEqual(len(matrix(kind)), 450)

    def test_unknown_profiles_seeds_and_presets_rejected(self):
        for p, s in [('invented', SEEDS[0]), ('reference', 9570000)]:
            with self.assertRaises(ValueError):
                scenario(p, s)
        with self.assertRaises(ValueError):
            matrix('invented')

    def test_synthetic_seed_is_separate_from_formal_matrix(self):
        with self.assertRaises(ValueError):
            scenario('reference', 42)
        with self.assertRaises(ValueError):
            synthetic_scenario('reference', SEEDS[0])
        spec = synthetic_scenario('random_weak')
        self.assertEqual(spec['seed'], 42)
        self.assertFalse(spec['formal_experiment'])
        self.assertTrue(scenario('random_weak', SEEDS[0])['formal_experiment'])
        self.assertNotEqual(spec['random_namespace'], scenario('random_weak', SEEDS[0])['random_namespace'])
        env = SimpleNamespace(time=0., step_count=0, seed=42, current=ConstantBase())
        self.assertIs(attach_current(env, spec), env.current)

    def test_reference_exact_base_and_metadata_passthrough(self):
        field = self.field('reference')
        point = np.array([[0., 0.], [1., 2.]])
        np.testing.assert_array_equal(field.velocity(point, 600.), field.base.velocity(point, 600.))
        self.assertIs(field.cfg, field.base.cfg)
        self.assertEqual(field.phase, field.base.phase)
        self.assertEqual(field.speed_upper_bound, .3)

    def test_event_support_and_five_second_smooth_ramps(self):
        field = self.field()
        for t in (0., 499., 500., 800., 1200.):
            np.testing.assert_array_equal(field.added_velocity(t), np.zeros(2))
        self.assertAlmostEqual(np.linalg.norm(field.added_velocity(502.5)), .2)
        self.assertAlmostEqual(np.linalg.norm(field.added_velocity(505.)), .4)
        self.assertAlmostEqual(np.linalg.norm(field.added_velocity(797.5)), .2)
        self.assertLess(np.linalg.norm(field.added_velocity(500.+1.e-5))/1.e-5, 1.e-5)

    def test_scalar_and_batch_xy_contract(self):
        field = self.field()
        for positions in (np.array([3., 4.]), np.zeros((3, 2)), np.zeros((2, 3, 2))):
            result = field.sample_components(positions, 600.)
            self.assertEqual(set(result), {'base', 'additional', 'total'})
            for value in result.values():
                self.assertEqual(value.shape, positions.shape)
            np.testing.assert_array_equal(result['total'], result['base']+result['additional'])

    def test_gust_world_axis_and_duration(self):
        positive = self.field('cross_gust_strong', SEEDS[0])
        negative = self.field('cross_gust_strong', SEEDS[15])
        np.testing.assert_array_equal(positive.added_velocity(520.), [0., .4])
        np.testing.assert_array_equal(negative.added_velocity(520.), [0., -.4])
        np.testing.assert_array_equal(positive.added_velocity(560.), [0., 0.])

    def test_periodic_velocity_reverses_and_has_declared_period(self):
        field = self.field('time_varying_strong')
        np.testing.assert_allclose(field.added_velocity(530.), -field.added_velocity(590.), atol=1.e-12)
        np.testing.assert_allclose(field.added_velocity(530.), field.added_velocity(650.), atol=1.e-12)

    def test_random_bounds_continuity_and_query_order_independence(self):
        field = self.field('random_strong')
        times = np.linspace(490., 810., 401)
        first = {float(t): field.added_velocity(t).copy() for t in times}
        for t in times[::-1]:
            np.testing.assert_array_equal(first[float(t)], field.added_velocity(t))
            self.assertLessEqual(np.linalg.norm(first[float(t)]), .4+1.e-12)
        self.assertLess(np.linalg.norm(field.added_velocity(601.+1.e-6)-
                                       field.added_velocity(601.-1.e-6)), 1.e-8)

    def test_severity_scales_same_random_waveform(self):
        weak = self.field('random_weak')
        strong = self.field('random_strong')
        for t in (505., 512.34, 670., 796.):
            np.testing.assert_array_equal(4.*weak.added_velocity(t), strong.added_velocity(t))

    def test_random_antipodal_pairs_and_distinct_seeds(self):
        first = self.field('random_strong', SEEDS[0])
        paired = self.field('random_strong', SEEDS[15])
        distinct = self.field('random_strong', SEEDS[1])
        for t in (505., 555.5, 700.):
            np.testing.assert_array_equal(first.added_velocity(t), -paired.added_velocity(t))
        self.assertFalse(np.array_equal(first.added_velocity(600.), distinct.added_velocity(600.)))

    def test_rms_and_hash_are_deterministic(self):
        field = self.field('constant_strong')
        meta = field.describe()
        self.assertEqual(meta['format'], FORMAT)
        self.assertGreater(meta['declared_window_added_rms_mps'], 0.)
        self.assertLess(meta['declared_window_added_rms_mps'], .4)
        self.assertEqual(meta, self.field('constant_strong').describe())
        random_meta = self.field('random_strong').describe()
        self.assertEqual(len(random_meta['random_knots_sha256']), 64)

    def test_attach_guard_seed_step_and_no_stacking(self):
        spec = scenario('constant_weak', SEEDS[0])
        env = SimpleNamespace(time=0., step_count=0, seed=SEEDS[0], current=ConstantBase())
        wrapper = attach_current(env, spec)
        self.assertIs(env.current, wrapper)
        with self.assertRaises(ValueError):
            attach_current(env, spec)
        env.current = ConstantBase()
        env.time = 1.
        with self.assertRaises(ValueError):
            attach_current(env, spec)
        env.time = 0.
        env.seed = SEEDS[1]
        with self.assertRaises(ValueError):
            attach_current(env, spec)

    def test_invalid_current_parameters_fail_closed(self):
        for key, value in [('amplitude_mps', -.1), ('ramp_s', 0.),
                           ('direction_xy', [0., 0.]), ('correlation_s', float('nan'))]:
            spec = deepcopy(scenario('constant_weak', SEEDS[0]))
            spec[key] = value
            with self.assertRaises(ValueError):
                AdditiveCurrent(ConstantBase(), spec)


if __name__ == '__main__':
    unittest.main()
