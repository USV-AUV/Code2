"""Prepared execution-gate tests; no policy loading or simulator required."""
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from exp3.protocol import ROOT, SEEDS, scenario, synthetic_scenario
from exp3.runner import destination, evaluate, validate


class RunnerSafetyTests(unittest.TestCase):
    def test_formal_gate_precedes_torch_and_output(self):
        with self.assertRaisesRegex(ValueError, '--execute'):
            evaluate('all', ROOT / 'runs' / 'never_created_gate_test')

    def test_interface_gate_precedes_model_loading(self):
        with self.assertRaisesRegex(ValueError, '--execute'):
            validate(ROOT / 'verification' / 'never_created_gate_test')

    def test_outputs_cannot_escape_designated_root(self):
        for path in (ROOT, ROOT.parent / 'experiment 1', ROOT / 'runs',
                     ROOT / 'runs' / '..' / 'README.md'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                destination(path, 'runs')

    def test_synthetic_seed_cannot_enter_formal_protocol(self):
        with self.assertRaises(ValueError):
            scenario('reference', 42)
        with self.assertRaises(ValueError):
            synthetic_scenario('reference', SEEDS[0])
        self.assertFalse(synthetic_scenario('reference', 42)['formal_experiment'])
        self.assertTrue(scenario('reference', SEEDS[0])['formal_experiment'])


if __name__ == '__main__':
    unittest.main()
