"""Synthetic offline-analysis tests; no policy loads or simulator rollouts.

Authored for a future explicitly requested verification. These tests were not
executed while preparing Experiment 3 under the user's no-testing constraint.
"""
import copy
import gzip
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from exp3 import analysis as a
from exp3.protocol import FORMAT, METHODS, SEEDS, matrix, scenario
from exp3.runner import digest, write_json


def row(seed, packets=10., failures=1, resolved=10, samples=10, aoi_sum=50.):
    window = dict(num_auvs=2, observed_seconds=samples/2, budget_seconds=1200.,
        aoi_n=samples, aoi_sum_s=aoi_sum, auv_samples=samples, fresh30_samples=samples,
        collected_packets=packets, installed_usable_samples=samples,
        structural_possible_samples=samples,
        data=dict(failed=failures, resolved=resolved, right_censored=0),
        state=dict(failed=0, resolved=resolved, right_censored=0),
        sample_stats={'local_navigation_error_m':dict(count=2,total_count=2,sum=4.,sum_squares=10.)},
        service=dict(grant_samples=4, grant_inside_samples=3, target_grant_samples=2,
                     target_grant_inside_samples=1, grant_seconds=4, grant_inside_seconds=3, exits=1))
    return dict(seed=seed, profile='reference', strategy='full_v6', model_step=450000,
        duration_s=1200., termination_reason='horizon', survived_full_horizon=True,
        collected_packets=packets, experiment3=dict(windows={w:copy.deepcopy(window) for w in a.WINDOWS}),
        metrics75={f'original_metric_{i}':dict(label=f'metric {i}', unit='original', value=float(i)) for i in range(75)})


def trace(end=1200, every=20, gap=None):
    return [dict(time_s=float(t),collected_packets=t//every) for t in range(1,end+1) if t != gap]


def evidence_row(seed, profile='reference', method='full_v6'):
    record = row(seed)
    spec = scenario(profile,seed)
    record.update(profile=profile,strategy=method,method_id=method,formal_experiment=True,
                  scenario=spec,steps=1200,terminated=False,truncated=True,policy_sha256='a'*64)
    boundaries = dict(pre=(380.,500.),fault=(500.,spec['clear_s']),post=(spec['clear_s'],1200.),total=(0.,1200.))
    for name,(start,end) in boundaries.items():
        w = record['experiment3']['windows'][name]
        w.update(start_s=start,end_s=end,observed_seconds=end-start,budget_seconds=end-start,
                 auv_samples=2*(end-start),aoi_n=2*(end-start),fresh30_samples=2*(end-start))
    return record


class PoolingTests(unittest.TestCase):
    def test_raw_denominators_not_average_episode_ratios(self):
        records = [row(1, failures=1,resolved=2,samples=2,aoi_sum=2),
                   row(2, failures=0,resolved=8,samples=8,aoi_sum=24)]
        result = a.pooled(records)
        self.assertAlmostEqual(result['data_nondelivery'], .1)
        self.assertAlmostEqual(result['pooled_aoi_s'], 2.6)
        self.assertAlmostEqual(result['fresh30_fixed_budget'], 10/4800)
        self.assertEqual(result['data']['failed'], 1)
        self.assertEqual(result['data']['resolved'], 10)

    def test_no_transmission_or_observation_is_missing(self):
        result = a.pooled([row(1,failures=0,resolved=0,samples=0,aoi_sum=0)])
        self.assertIsNone(result['data_nondelivery'])
        self.assertIsNone(result['pooled_aoi_s'])
        self.assertEqual(result['fresh30_fixed_budget'], 0.)

    def test_stage_packets_not_whole_episode_packets(self):
        record = row(1,packets=50)
        record['experiment3']['windows']['fault']['collected_packets'] = 3
        self.assertEqual(a.pooled([record],'fault')['collected_packets'], 3.)

    def test_early_failures_stay_in_packet_mean_and_budget(self):
        failed = row(2,packets=0,samples=0,aoi_sum=0)
        failed['survived_full_horizon'] = False
        result = a.pooled([row(1,packets=10),failed])
        self.assertEqual(result['collected_packets'],5)
        self.assertEqual(result['full_horizon'],1)
        self.assertEqual(result['raw']['budget_auv_samples'],4800)

    def test_pool_square_sums_not_mean_rmse(self):
        result = a.aggregate_stats([dict(count=1,total_count=1,sum=1,sum_squares=1),
                                   dict(count=3,total_count=4,sum=9,sum_squares=27)])
        self.assertEqual(result['count'],4)
        self.assertEqual(result['mean'],2.5)
        self.assertAlmostEqual(result['rmse'],7**.5)
        self.assertEqual(result['valid_fraction'],.8)
        self.assertIsNone(result['p95'])

    def test_absent_usde_stats_remain_missing(self):
        result = a.aggregate_stats([dict(count=0,total_count=2400,sum=0,sum_squares=0)])
        self.assertIsNone(result['rmse'])
        self.assertEqual(result['valid_fraction'],0)

    def test_grant_count_is_not_auv_denominator(self):
        result = a.pooled([row(1)])
        self.assertEqual(result['service']['grant_inside_fraction'],.75)
        self.assertEqual(result['service']['target_grant_inside_fraction'],.5)
        self.assertEqual(result['service']['exits'],1)


class PairedStatisticsTests(unittest.TestCase):
    def test_identical_pairs_have_zero_interval(self):
        records = [row(1),row(2,packets=20,failures=4,resolved=20)]
        result = a.paired_bootstrap(records,list(reversed(records)),repetitions=40)
        for key in a.PAIRED_KEYS:
            self.assertEqual(result[key]['difference'],0)
            self.assertEqual(result[key]['ci95'],[0.,0.])

    def test_unpaired_or_duplicate_scene_is_rejected(self):
        for comparator in ([row(2)],[row(1),row(1)]):
            with self.assertRaises(ValueError):
                a.paired_bootstrap([row(1)],comparator,repetitions=5)

    def test_draws_recompute_pooled_denominator(self):
        records = [row(1,failures=1,resolved=2),row(2,failures=0,resolved=8)]
        selected = a.np.array([[0,1],[0,0],[1,1]])
        result = a._draw_statistics(records,selected,'total')
        self.assertEqual(result['data_nondelivery'].tolist(),[.1,.5,0.])

    def test_no_valid_denominator_bootstraps_remain_na(self):
        records = [row(1,failures=0,resolved=0)]
        result = a.paired_bootstrap(records,records,repetitions=10)['data_nondelivery']
        self.assertIsNone(result['difference'])
        self.assertIsNone(result['ci95'])
        self.assertEqual(result['valid_bootstraps'],0)

    def test_ratio_of_aggregate_reference_collection(self):
        result = a.reference_change([row(1,packets=5),row(2,packets=45)],
                                    [row(1,packets=10),row(2,packets=90)],repetitions=20)
        self.assertEqual(result['aggregate_packet_retention']['estimate'],.5)
        self.assertEqual(result['aggregate_packet_retention']['ci95'],[.5,.5])

    def test_did_pairs_four_blocks_by_same_seed(self):
        result = a.difference_in_differences([row(1,packets=8)],[row(1,packets=10)],
                                            [row(1,packets=5)],[row(1,packets=10)],repetitions=20)
        self.assertEqual(result['estimates']['collected_packets']['difference'],3.)
        self.assertEqual(result['estimates']['collected_packets']['ci95'],[3.,3.])
        self.assertEqual(result['window'],'total')


class RecoveryTests(unittest.TestCase):
    def test_120s_fully_post_clear_then_30s_confirmation(self):
        result = a.task_recovery(trace(),trace(),origin=800)
        self.assertEqual(result['status'],'threshold_attained')
        self.assertEqual(result['latency_s'],120.)
        self.assertEqual(result['confirmed_at_s'],949.)
        self.assertFalse(result['disruption_observed'])

    def test_reference_failure_censors_common_followup(self):
        result = a.task_recovery(trace(),trace(end=850),origin=800)
        self.assertFalse(result['recovered'])
        self.assertTrue(result['right_censored'])
        self.assertEqual(result['common_observed_until_s'],850.)
        self.assertIsNone(result['latency_s'])

    def test_early_failure_before_clear_is_not_zero_latency(self):
        result = a.task_recovery(trace(end=700),trace(),origin=800)
        self.assertEqual(result['status'],'no_common_post_clear_followup')
        self.assertIsNone(result['latency_s'])

    def test_sparse_reference_is_insufficient_not_success(self):
        sparse = [dict(time_s=float(t),collected_packets=0) for t in range(1,1201)]
        result = a.task_recovery(sparse,sparse)
        self.assertEqual(result['status'],'insufficient_common_reference_support')
        self.assertFalse(result['recovered'])

    def test_nonconsecutive_samples_do_not_complete_hold(self):
        result = a.task_recovery(trace(end=949,gap=930),trace(end=949),origin=800)
        self.assertFalse(result['recovered'])
        self.assertIsNone(result['latency_s'])

    def test_short_gust_uses_its_actual_clear(self):
        result = a.task_recovery(trace(),trace(),origin=560)
        self.assertEqual(result['confirmed_at_s'],709.)
        self.assertEqual(result['origin_s'],560.)

    def test_duplicate_trace_time_rejected(self):
        rows = trace(end=20)
        with self.assertRaises(ValueError):
            a.task_recovery(rows+[rows[-1]],rows)


class EvidenceTests(unittest.TestCase):
    def test_full_balanced_formal_plan(self):
        a.validate_jobs(dict(format=FORMAT,mode='formal',formal_experiment=True,device='cuda',jobs=matrix('all')))

    def test_smoke_cpu_missing_duplicate_rejected(self):
        plan = dict(format=FORMAT,mode='formal',formal_experiment=True,device='cuda',jobs=matrix('all'))
        changes = [dict(mode='smoke'),dict(device='cpu'),dict(formal_experiment=False),
                   dict(jobs=plan['jobs'][:-1]),dict(jobs=plan['jobs']+[plan['jobs'][0]])]
        for change in changes:
            with self.subTest(change=list(change)):
                with self.assertRaises(ValueError):
                    a.validate_jobs(dict(plan,**change))

    def test_original_metric_unit_drift_rejected(self):
        schemas = []
        first = evidence_row(SEEDS[0])
        a._validate_row(first,('reference','full_v6',SEEDS[0]),schemas)
        other = copy.deepcopy(first)
        other['metrics75']['original_metric_1']['unit'] = 'wrong'
        with self.assertRaises(ValueError):
            a._validate_row(other,('reference','full_v6',SEEDS[0]),schemas)

    def test_raw_packet_inconsistency_rejected(self):
        record = evidence_row(SEEDS[0])
        record['collected_packets'] += 1
        with self.assertRaises(ValueError):
            a._validate_row(record,('reference','full_v6',SEEDS[0]),[])

    def test_output_must_be_new_report_child_before_reading_inputs(self):
        with tempfile.TemporaryDirectory(prefix='exp3_analysis_synthetic_') as temp:
            root = Path(temp)
            with patch.object(a,'ROOT',root):
                for output in (root,root/'reports',root/'outside'):
                    with self.assertRaises(ValueError):
                        a.analyze_runs([],output)

    def test_complete_evidence_loader_and_sha_tamper(self):
        # Tiny fabricated evidence package; not policy/environment execution.
        with tempfile.TemporaryDirectory(prefix='exp3_analysis_synthetic_') as temp:
            source = Path(temp)
            methods, seeds, profiles = METHODS[:2], SEEDS[:2], ('reference','constant_weak')
            jobs = [(p,m,s) for p in profiles for m in methods for s in seeds]
            package = dict(synthetic=True,policies_sha256={m:'a'*64 for m in methods})
            write_json(source/'plan.json',dict(format=FORMAT,mode='formal',formal_experiment=True,
                device='cuda',jobs=jobs,code_hashes={'mock':'only'},package=package))
            for profile,method,seed in jobs:
                directory = source/profile/method/str(seed)
                directory.mkdir(parents=True)
                record = evidence_row(seed,profile,method)
                write_json(directory/'episode.json',record)
                for filename in ('trace.jsonl.gz','events.json.gz'):
                    with gzip.open(directory/filename,'xt',encoding='utf-8') as stream:
                        stream.write('{}\n')
                write_json(directory/'complete.json',dict(status='completed',sha256={
                    name:digest(directory/name) for name in ('episode.json','trace.jsonl.gz','events.json.gz')}))
            write_json(source/'complete.json',dict(status='completed',episodes=len(jobs),formal_experiment=True))
            with patch.object(a,'METHODS',methods), patch.object(a,'SEEDS',seeds), patch.object(a,'PROFILES',profiles), \
                 patch.object(a,'code_hashes',return_value={'mock':'only'}), \
                 patch.object(a,'verify_package',return_value=package):
                groups, paths, _, _ = a._load_inputs([source])
                self.assertEqual(len(groups),4)
                self.assertEqual(len(paths),8)
                target = source/profiles[0]/methods[0]/str(seeds[0])/'episode.json'
                with target.open('a',encoding='utf-8') as stream:
                    stream.write(' ')
                with self.assertRaisesRegex(ValueError,'checksum'):
                    a._load_inputs([source])


if __name__ == '__main__':
    unittest.main()
