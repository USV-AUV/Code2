# Verification Report — Repaired English Personal Review Edition

## Tests executed in this environment

| Validation | Result | Scope |
|---|---|---|
| Release file manifest and localized source registry | PASS | Exact hash check of retained English files and six registered translated code modules |
| CPU smoke inference and packet-level advancement | PASS | Five recorded 450k methods; 12 fast decision steps per method, nonformal seed 42 |
| Experiment 2 tests | 35 PASS | Acoustic faults and measurement/protocol safety |
| Experiment 3 tests | 54 PASS | Current profiles, measurement and interface protections |
| Experiment 5 tests | 3 PASS | Decision-schedule matrix |
| Experiment 6 tests | 3 PASS | Mechanism-intervention definitions |
| Experiment 7 portability tests | 5 PASS, 1 SKIP | Raw 300-episode external evidence not included |
| Experiment 8 tests | 14 PASS, 1 SKIP | Original Windows private-memory test is not applicable on Linux |
| Experiment 7 manifest validation | PASS | Retained source and model files only, no raw-evaluation claim |
| `release.py audit-data --category all` | NOT INCLUDED | Zero raw archive assets supplied; no implied episode verification |

## Code and numerical integrity

- The archived `.pt` weight files are byte-identical to the supplied unmodified package.
- Experiment 2/3/8 paired views contain all 11/13/10 available scenarios without result-based conditions. Seven available aggregate tables are packaged. No CSV numbers were changed during checksum reconciliation or this documentation-only edit. The previous performance-based scenario filtering remains removed. This does not independently establish the supplied aggregates from raw episodes.
- English reporting text was repaired. No training, new full-episode evaluation, or synthetic episode data were generated.
- Scientific motion, network and TD3/DDQN structures used in the five-model smoke were not rewritten. Report-formatters and provenance/load validation were updated for this localized private package.
- `release.py train` allows an explicit optional seed. Existing archived model metadata was not edited.

## Extended historical test scope

The separate Experiment 7 historical simulator/protocol test suite is **not certified as fully passing** in this private release: the partial run verified numerous tests, revealed outdated confirmation-seed fixture assumptions and an incomplete synthetic lifecycle fixture, and a later full run exceeded the validation time limit. The scientific simulator is not claimed to be validated by that incomplete run. This package retains the test fixtures for further investigation. No such partial test has been counted as PASS above.

## Remaining scientific-evidence limitations

- Additional per-episode records are required to independently reproduce manuscript-level completion and pooled-metric estimates.
- Five independent training seed runs cannot be verified with the provided artifacts.
- Some full and historical experiment entry points still depend on external asset archives, legacy protocol documents, CUDA hardware and/or Windows instrumentation; they were not claimed to work end-to-end here.
- All recorded scenarios are now present for Experiments 2/3/8, but the convenience views for other suites remain limited by their stated reference scope. This package is an internal reading edition, not an official independent replication.

See `MANUSCRIPT_ALIGNMENT.md`, `INTEGRITY_NOTES.md`, and `selected_results/SELECTION_README.md` for precise interpretation.

## Scenario coverage and source verification (2026-11-10)

- The performance-based predicate in `selected_results/selection_manifest.json` is `null`. No condition is included or excluded based on payload, state AoI, completion or any other measured outcome.
- The two-method convenience views were checked, row by row, against the current accepted full aggregate tables: Experiment 2 **22/22 source rows across all 11 conditions**, Experiment 3 **26/26 source rows across all 13 conditions**, Experiment 8 **20/20 source rows across all 10 conditions**.
- All seven **current accepted** aggregate tables match the `packaged_table_sha256` canonical hashes in `selection_manifest.json`. The older `archived_source_table_sha256` field was retired from the active manifest; superseded historical hashes are retained in `selected_results/table_version_history.json`. Current CSVs were unchanged from the user-confirmed upload. `python release.py verify` and `python release.py verify-summaries` validate the active baseline, not prior-version bytes.
- This verifies the integrity of the provided aggregate values, **not** original individual episodes, multiple training seeds or an end-to-end rerun.
