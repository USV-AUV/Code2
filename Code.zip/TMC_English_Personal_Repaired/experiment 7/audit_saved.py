"""Portable saved-only audit. No Torch/NumPy/ENV/model load or simulation.

Uses the original arithmetic,75 getters and strict P0 functions unchanged.
Historical coordinator closure is authenticated by the shipped immutable audit,
not reconstructed from nonexistent local Windows process handles.
"""
import argparse
import ast
from copy import deepcopy
import gzip
import json
from pathlib import Path
import random
import statistics
import sys
from types import FunctionType
from types import SimpleNamespace
import latest as p

def arithmetic():
    g=p.load('portable_saved_original_gate',p.ROOT/'tools/v31_formal_gate.py')
    ns=dict(g=g,require=g.require,exact=g.exact,read=g.read,digest=g.digest,
            random=random,statistics=statistics,deepcopy=deepcopy,FunctionType=FunctionType)
    names=('original2_passive_caller','rows_identity','collection_contrast',
           'DATA_ratio_summary','recovery_and_exposure')
    tree=ast.parse((p.ROOT/'tools/review_v31_formal300_saved.py').read_text(encoding='utf-8-sig'))
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    p.require(len(nodes)==len(names),'Exact five original saved functions required')
    # No AST edit: only original stdlib definitions in an explicit namespace.
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'<unchanged_published_saved_functions>','exec'),ns)
    return ns

def audit(output):
    p.verify(data=True)
    output=Path(output).resolve()
    p.require(not output.exists() and not output.is_relative_to(p.ROOT),'New output outside publication required')
    c=p.read(p.ROOT/'provenance/FROZEN_CONTRACT.json')
    archived=p.read(p.ROOT/'reports/SAVED_REVIEW.json')
    raw=p.load('portable_saved_original_raw',p.ROOT/'tools/merge_development_blocks.py')
    strict=p.load('portable_saved_original_strict',p.ROOT/'tools/audit_passive_journal_sidecars.py')
    f=arithmetic()
    metrics=raw._module(p.CODE/'exp7_c07_scaling_20261012/metrics.py','published_saved_metrics')
    schema=raw._module(p.CODE/'c07_source/scripts/summarize_tmc_retest.py','published_saved_schema')
    specs=schema.selected_specs()
    p.require(len(specs)==75,'Exact original75')
    old_eval_prefix=str(Path(c['models']['3full']['policy']).parents[4]/'v31_formal300/evaluations')
    # The old prefix comes from a shipped source artifact, never an arbitrary
    # filesystem search. Only historical result-directory identities relocate.
    sample=p.read(p.ROOT/'results/reference/3full/passive_sidecars/complete.json')['episode_reports'][0]
    old_sidecar=sample['sidecar_directory'].replace('\\','/')
    suffix='/reference/3full/passive_sidecars/seed_10919000'
    p.require(old_sidecar.endswith(suffix),'Exact original path suffix required')
    prefix=old_sidecar[:-len(suffix)]
    def relocated_Path(value):
        text=str(value).replace('\\','/')
        if text==prefix or text.startswith(prefix+'/'):
            return p.ROOT/'results'/text[len(prefix):].lstrip('/')
        return Path(value)
    namespace={**strict.audit_sidecar.__globals__,'Path':relocated_Path}
    relocated=FunctionType(strict.audit_sidecar.__code__,namespace,'audit_sidecar',strict.audit_sidecar.__defaults__,strict.audit_sidecar.__closure__)
    relocated.__kwdefaults__=strict.audit_sidecar.__kwdefaults__
    p.require(relocated.__code__ is strict.audit_sidecar.__code__,'P0 code object unchanged')
    proxy=SimpleNamespace(native_semantic_ast_audit=strict.native_semantic_ast_audit,audit_sidecar=relocated)
    n2audit=f['original2_passive_caller'](proxy,c['models']['original2']['source_hashes'])
    findings=[];checked=0;contrasts={};by_fault={}
    for fault in p.FAULTS:
        by_fault[fault]={}
        for arm in p.ARMS:
            model=c['models'][arm];cfg=model['environment_config']
            folder=p.ROOT/'results'/fault/arm
            rows=f['rows_identity'](p.read(folder/'complete.json'),c['seed_pools'][fault],model,fault,p.digest(p.ROOT/'provenance/FROZEN_CONTRACT.json'))
            by_fault[fault][arm]={r['seed']:r for r in rows}
            receipts=[json.loads(line) for line in (folder/'progress.jsonl').read_text(encoding='utf-8').splitlines()]
            reports=p.read(folder/'passive_sidecars/complete.json')['episode_reports']
            p.require([r['seed'] for r in receipts]==[r['seed'] for r in reports]==c['seed_pools'][fault],'All ordered receipts retained')
            for row,receipt,report in zip(rows,receipts,reports):
                seed=row['seed'];episode=folder/f'seed_{seed}'
                p.require(p.read(episode/'episode.json')==row,'Original complete/episode differ')
                for name,pin in receipt['files'].items():
                    p.require(p.digest(episode/name)==pin['sha256'] and (episode/name).stat().st_size==pin['bytes'],'Original episode receipt differs')
                with gzip.open(episode/'network_evidence.json.gz','rt',encoding='utf-8') as stream:evidence=json.load(stream)
                raw._data_events(row,evidence,cfg);raw._trace_evidence(episode/'trace.jsonl.gz',row,cfg)
                unique=metrics.audit_unique_data(row['unique_data_keys'],30,expected_packets=row['collected_packets'])
                p.require(unique['per_sensor_packets']==row['per_sensor_packets'],'Unique DATA differs')
                p.require(set(row['metrics75'])=={s[0] for s in specs},'All75 keys required')
                for name,_,unit,_,getter in specs:
                    p.require(row['metrics75'][name]['unit']==unit and raw._same_number(row['metrics75'][name]['value'],getter(row)),'Original75 getter differs:'+name)
                owners=[];nodes=list(range(model['n_auv']+1,model['n_auv']+31))
                for offset in range(0,30,cfg['tdma_sensors_per_group']):
                    owners.extend(range(model['n_auv']+1));owners.extend(nodes[offset:offset+cfg['tdma_sensors_per_group']])
                identity=dict(n_auv=model['n_auv'],n_sensors=30,slot_owners=owners,slot_duration=cfg['slot_duration'],
                    source_hashes=model['source_hashes'],model_sha256=model['policy_sha256'],profile=model['profile'],
                    seed=seed,method=model['method'],model_training_step=450000)
                try:
                    result=(n2audit if arm=='original2' else relocated)(folder/'passive_sidecars'/f'seed_{seed}',
                        identity,report,original_receipts=receipt['files'],source_root=p.CODE/'c07_source')
                    p.require(result.get('success') is True,'Strict P0 did not pass')
                except Exception as error:findings.append(dict(fault=fault,arm=arm,seed=seed,error=repr(error)))
                checked+=1
            print(f'Checked saved {fault}/{arm}: {checked}/300',flush=True)
    for item in c['collection_contrasts']:
        fault,left,right=item['fault'],item['left'],item['right']
        key=fault+':'+left+'-'+right
        contrasts[key]=f['collection_contrast'](by_fault[fault][left],by_fault[fault][right],c['seed_pools'][fault])
        p.require(contrasts[key]==archived['collection_contrasts'][key],'Original paired result differs')
    p.require(checked==300 and 'torch' not in sys.modules and 'numpy' not in sys.modules,'Saved audit must be complete/stdlib only')
    result=dict(status='passed' if not findings else 'strict_findings_retained_not_passed',episodes=checked,
        original75_values_checked=22500,strict_P0_failed_episodes=len(findings),strict_P0_findings=findings,
        collection_contrasts=contrasts,model_loads=0,CPU_model_reaudits=0,simulation_steps=0,training_steps=0,
        original_saved_review_sha256=p.digest(p.ROOT/'reports/SAVED_REVIEW.json'),
        historical_exit_proof='Shipped immutable closure review, not recreated process handles',
        native_clock_ULP_waiver=False,original_strict_and_arithmetic_function_AST_unchanged=True,
        P0_external_global_bindings=['Path'] ,original2_extra_binding=['native_semantic_ast_audit'])
    p.write_new(output,result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('collection_contrasts','strict_P0_findings')}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True)
    audit(parser.parse_args().output)
