"""Saved-only formal300 review: real exits, original75, DATA/trace, strict P0.

Never loads weights/optimizers or constructs Policy/ENV. Keeps strict P0
failures without ULP exceptions. Original N2 namespace handling only clones
the trusted passive caller with one metadata-key lookup binding, as already
audited in development. Physics, permission and timing algorithms unchanged.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
from datetime import datetime
import gzip
import importlib.util
import json
from pathlib import Path
import random
import statistics
import sys
from types import FunctionType

sys.dont_write_bytecode = True
TOOLS = Path(__file__).resolve().parent


def load(name, path, sha=None):
    import hashlib
    if sha and hashlib.sha256(path.read_bytes()).hexdigest() != sha:
        raise ValueError("Certified saved helper changed: " + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


c = load("saved_formal300_recording_metadata_only", TOOLS / "run_v31_formal300.py")
g = c.g
read, digest, require, exact = g.read, g.digest, g.require, g.exact
HELPERS = {
    "review_saved_v31_late.py": "e0d92f2b77de622b30d5d8185135c973e16969bd7385bd523b254e32c80d8ac4",
    "review_closed_v31_late_identity.py": "37db6fa09040cc31aea71320c1851c8e960de1e6297351668dae24cb1c978328",
}


def original2_passive_caller(p0, native_sources):
    """Exact strict audit code object; ONE source-key namespace binding only."""
    native_ast, original = p0.native_semantic_ast_audit, p0.audit_sidecar
    def native_namespace(source_root, metadata):
        require(exact(metadata["source_hashes"], native_sources) and len(native_sources) == 107,
                "Original107 header source identity required, no fallback lookup")
        projection = {**metadata, "source_hashes": {"original/" + key: value for key, value in native_sources.items()}}
        value = native_ast(source_root, projection)
        require(value["verified"] is True, "Original semantic AST must verify without relaxation")
        value["explicit_source_key_namespace_only"] = True
        value["original_header_and_policy_source_identity_modified"] = False
        return value
    namespace = dict(original.__globals__)
    namespace["native_semantic_ast_audit"] = native_namespace
    worker = FunctionType(original.__code__, namespace, original.__name__, original.__defaults__, original.__closure__)
    worker.__kwdefaults__ = original.__kwdefaults__
    require(worker.__code__ is original.__code__
            and {k for k in namespace if namespace[k] is not original.__globals__[k]} == {"native_semantic_ast_audit"},
            "Strict P0 code or undeclared audit global changed")
    return worker


def rows_identity(complete, seeds, model, fault, contract_sha):
    require(fault in g.FAULTS and exact(seeds, g.POOLS[fault]), "Only the frozen registered30 formal rows")
    require(complete["status"] == "completed" and exact(complete["learning_steps"], 0)
            and complete["all_failures_retained"] is True and exact(complete["seeds"], seeds)
            and [r["seed"] for r in complete["rows"]] == seeds
            and complete["model_sha256"] == model["policy_sha256"], "Wrong frozen complete30 identity")
    phase = complete["evaluation_phase"]
    require(phase["phase"] == "frozen_mixed_protocol_confirmation" and phase["primary"] == "collected_packets"
            and exact(phase["model_training_step"], 450000) and phase["holdout_opened"] is True
            and phase["already_opened"] is False and phase["validation_contract_sha256"] == contract_sha
            and exact(phase["family_alpha"], .05) and exact(phase["collection_family_comparisons"], 8)
            and phase["evaluation_fault"] == fault and exact(phase["seeds"], seeds)
            and phase["checkpoint_sha256"] == model["policy_sha256"]
            and phase["native_sequential_alpha_protocol"] is False, "Wrong explicit mixed-protocol formal phase")
    faults = [] if fault == "reference" else [{"src": 0, "dst": 1, "start": 400., "end": 800., "bidirectional": True}]
    for row in complete["rows"]:
        require(exact(row["n_auv"], model["n_auv"]) and exact(row["n_sensors"], 30)
                and row["profile"] == model["profile"] and row["method"] == model["method"]
                and row["model_sha256"] == model["policy_sha256"] and exact(row["model_training_step"], 450000)
                and row["evaluation_fault"] == fault and exact(row["evaluation_faults"], faults)
                and row["ending_policy"] == "original_absorbing_safety"
                and row["termination_reason"] in ("boundary", "collision", "time_limit")
                and type(row["steps"]) is int and 1 <= row["steps"] <= 1200,
                "Actual row model/source/fault/safety identity differs")
    require(len(complete["rows"]) == 30, "All registered30 outcomes, including early safety endings, are required")
    return complete["rows"]


def collection_contrast(left, right, seeds):
    require(list(left) == list(right) == seeds, "Exact paired ordered scenarios required")
    differences = [left[s]["collected_packets"] - right[s]["collected_packets"] for s in seeds]
    rng = random.Random(20261020)
    draws = sorted(statistics.mean(rng.choices(differences, k=len(seeds))) for _ in range(40000))
    return dict(differences=differences, mean=statistics.mean(differences),
        positive=sum(v > 0 for v in differences), negative=sum(v < 0 for v in differences), ties=sum(v == 0 for v in differences),
        paired_percentile95=[draws[999], draws[38999]],
        paired_Bonferroni8_percentile_family95=[draws[124], draws[39874]],
        bootstrap_repetitions=40000, bootstrap_rng_seed=20261020,
        interval_scope="Approximate paired-scenario percentile intervals, fixed eight collection contrasts across both fault sets; not exact finite-sample coverage or across-training-seed robustness",
        user_hard_numerical_superiority_or_noninferiority_margin=None)


def DATA_ratio_summary(rows):
    numerator = sum(r["data_resolved_failures"] for r in rows)
    denominator = sum(r["data_resolved_trials"] for r in rows)
    require(0 <= numerator <= denominator, "Actual receiver-hop DATA counters differ")
    rng = random.Random(20261020)
    draws, zero_denominator_draws = [], 0
    for _ in range(40000):
        sampled = rng.choices(rows, k=len(rows))
        den = sum(r["data_resolved_trials"] for r in sampled)
        if den == 0:
            zero_denominator_draws += 1
        else:
            draws.append(sum(r["data_resolved_failures"] for r in sampled) / den)
    draws.sort()
    interval = None if not draws else [draws[max(0, int(.025 * len(draws)) - 1)], draws[max(0, int(.975 * len(draws)) - 1)]]
    return dict(resolved_DATA_failures=numerator, resolved_DATA_receiver_hop_trials=denominator,
        pooled_failure_fraction=numerator / denominator if denominator else None,
        episode_cluster_bootstrap95=interval, zero_denominator_bootstrap_draws=zero_denominator_draws,
        ratio_type="Resolved physical DATA receiver-hop failures/trials, not packet end-to-end success or independent Bernoulli trials",
        bootstrap_unit="whole episodes; original real counts retained; zero trials are unavailable, not zero failures")


def recovery_and_exposure(rows, n_auv):
    affected = [r["recovery"] for r in rows if r["recovery"]["affected"]]
    recovered = [r["recovery_s"] for r in affected if not r["censored"]]
    censored = [r["censor_followup_s"] for r in affected if r["censored"]]
    return dict(episodes=len(rows), observed_vehicle_seconds=sum(n_auv * r["duration_s"] for r in rows),
        observed_pair_seconds=sum(n_auv * (n_auv - 1) / 2 * r["duration_s"] for r in rows),
        completed_horizon=sum(r["termination_reason"] == "time_limit" for r in rows),
        collision_endings=sum(r["termination_reason"] == "collision" for r in rows),
        boundary_endings=sum(r["termination_reason"] == "boundary" for r in rows),
        affected_recovery_episodes=len(affected), unaffected_or_no_observed_loss=len(rows) - len(affected),
        recovered_episodes=len(recovered), right_censored_episodes=len(censored),
        observed_recovery_s=recovered, right_censor_followup_s=censored,
        observed_recovered_only_mean_s=statistics.mean(recovered) if recovered else None,
        interpretation="Unrecovered episodes retain right-censor followup; no loss is not a zero recovery time. Recovered-only mean is conditional, not unconditional recovery or isolated fault causality.")


def closed_identity(plan_sha):
    meta = c.META
    require((meta / "ALL_TRAINING_AND_TESTS_ENDED.json").is_file(), "Formal300 physical work not all ended")
    require(not (meta / "FORMAL_STOPPED_NO_RETRY.json").exists()
            and not list(meta.glob("*.STOPPED_NO_RETRY.json")), "Formal STOP requires diagnosis")
    require(digest(c.PLAN) == plan_sha, "Original formal PLAN byte identity required")
    c.PLAN_BOUND_SHA = plan_sha
    plan = read(c.PLAN)
    c.verify(plan)
    contract = read(g.CONTRACT)
    ended, actual = read(meta / "ALL_TRAINING_AND_TESTS_ENDED.json"), read(meta / "COORDINATOR_NATIVE_EXIT.json")
    require(exact(actual["actual_exit_code"], 0) and actual["no_process_stopped"] is True
            and ended["plan_sha256"] == plan_sha and ended["contract_sha256"] == digest(g.CONTRACT)
            and exact(ended["final_evaluation_episodes"], 300)
            and ended["all_original_dual_real_stages_closed"] is True, "Original physical complete marker/real exit differs")
    observed = {}
    def retain(path):
        pin = digest(path)
        require(str(path) not in observed or observed[str(path)] == pin, "Saved byte identity changed")
        observed[str(path)] = pin
        return pin
    started = read(meta / "COORDINATOR_STARTED.json")
    require(started["real_handle_held"] is True and started["pid"] == actual["pid"]
            and started["birth"] == actual["birth"]
            and started["arguments"] == ["-B", "-X", "utf8", str(TOOLS / "run_v31_formal300.py"),
                                          "execute", "--execute-frozen-formal300"], "Original formal coordinator identity differs")
    for kind in ("stdout", "stderr"):
        require(actual[kind + "_sha256"] == retain(meta / ("coordinator." + kind + ".log")), "Coordinator stdio differs")
    require((meta / "coordinator.stderr.log").stat().st_size == 0, "Coordinator stderr requires review")
    events = [json.loads(line) for line in (meta / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    require([(r["event"], r["label"]) for r in events if r["event"] in ("stage_dispatch", "stage_closed")
             and not r["label"].startswith("fixture_")]
            == [(kind, label) for label in c.stage_order() for kind in ("stage_dispatch", "stage_closed")],
            "Missing/duplicated/reordered formal scientific dispatch")
    require({p.name.removesuffix(".RESERVED_NO_RETRY.json") for p in meta.glob("*.RESERVED_NO_RETRY.json")} == set(c.stage_order())
            and {p.name.removesuffix(".OPENED_BEFORE_ENV.json") for p in meta.glob("*.OPENED_BEFORE_ENV.json")} == set(c.stage_order()),
            "All ten once-only reservations/openings required")
    for fault in g.FAULTS:
        seeds = g.POOLS[fault]
        pool = dict(format=g.FORMAT, contract_sha256=digest(g.CONTRACT), seeds=seeds, fault=fault,
                    all_policy_sha256={k: contract["models"][k]["policy_sha256"] for k in g.ARMS})
        registry = g.REGISTRY / (fault + "_" + str(seeds[0]) + "_" + str(seeds[-1]) + ".json")
        require(exact(read(registry), pool), "Whole pool/five-model frozen registry changed")
        retain(registry)
        for key in g.ARMS:
            label = fault + "_" + key
            spec = read(meta / (label + ".spec.json"))
            receipt = read(meta / (label + ".native_exit.json"))
            supervisor = read(meta / (label + ".supervisor_exit.json"))
            c.scope.validate_held(receipt, supervisor, spec)
            require(spec["operation"] == "evaluate" and spec["argv"] == ["-B", "-X", "utf8", *c.stage_argv(key, fault, digest(g.CONTRACT))]
                    and receipt["spec_sha256"] == retain(meta / (label + ".spec.json"))
                    and spec["entry_sha256"] == plan["tools"]["v31_formal_worker.py"]
                    and spec["wrapper_sha256"] == plan["tools"]["recorded_v31_formal300_stage.ps1"]
                    and spec["code_root"] == str(CODE) and spec["run_root"] == str(c.RUN),
                    "Formal original whole stage scope differs")
            for kind in ("stdout", "stderr"):
                require(receipt[kind + "_sha256"] == retain(spec[kind])
                        and supervisor[kind + "_sha256"] == retain(meta / (label + ".supervisor." + kind + ".log")), "Formal stdio differs")
            require(Path(spec["stderr"]).stat().st_size == (meta / (label + ".supervisor.stderr.log")).stat().st_size == 0,
                    "Formal stage stderr requires diagnosis")
            for path, pin in spec["input_pins"].items():
                require(retain(path) == pin, "Formal original stage input differs")
            reservation, opened = read(meta / (label + ".RESERVED_NO_RETRY.json")), read(meta / (label + ".OPENED_BEFORE_ENV.json"))
            require(reservation["pid"] == receipt["identities"][1]["pid"] and reservation["no_retry"] is True
                    and reservation["contract_sha256"] == digest(g.CONTRACT) and reservation["arm"] == key
                    and reservation["fault"] == fault and exact(reservation["seeds"], seeds), "Original worker reservation identity differs")
            for field, value in pool.items():
                require(exact(opened[field], value), "Original before-ENV whole-pool marker differs")
            require(opened["arm"] == key and opened["policy_sha256"] == contract["models"][key]["policy_sha256"]
                    and opened["phase"] == "frozen_mixed_protocol_confirmation" and opened["no_retry"] is True,
                    "Wrong original before-ENV opening")
            actual_process = receipt["exit_codes"][1]
            require(datetime.fromisoformat(actual_process["birth"]) <= datetime.fromisoformat(opened["observed_at"])
                    <= datetime.fromisoformat(actual_process["actual_exit_time"]), "Opening is outside actual process lifetime")
            provenance = read(meta / (label + ".PROVENANCE.json"))
            allowed = contract["original2_evaluation_global_bindings"] if key == "original2" else contract["new_V31_evaluation_global_bindings"]
            require(provenance["status"] == "completed_formal30_requires_independent_saved_audit"
                    and provenance["contract_sha256"] == digest(g.CONTRACT) and provenance["evaluation_global_bindings"] == allowed
                    and provenance["evaluator_code_object_identical"] is True
                    and provenance["original_policy_or_class_or_scientific_module_globals_patched"] is False
                    and provenance["complete_json_sha256"] == retain(c.RUN / "evaluations" / fault / key / "complete.json"),
                    "Original measurement interface proof differs")
            group = ended["groups"][label]
            complete = read(c.RUN / "evaluations" / fault / key / "complete.json")
            require(group["complete_json_sha256"] == digest(c.RUN / "evaluations" / fault / key / "complete.json")
                    and exact(group["episodes"], 30)
                    and group["actual_physical_steps"] == sum(r["steps"] for r in complete["rows"]),
                    "Original ended marker's actual group/physical counters differ")
            for suffix in (".native_exit.json", ".supervisor_exit.json", ".dispatch.json", ".reservation.json",
                           ".RESERVED_NO_RETRY.json", ".OPENED_BEFORE_ENV.json", ".PROVENANCE.json"):
                retain(meta / (label + suffix))
    for path in (c.PLAN, g.CONTRACT, meta / "COORDINATOR_STARTED.json", meta / "COORDINATOR_NATIVE_EXIT.json",
                 meta / "ALL_TRAINING_AND_TESTS_ENDED.json", meta / "FORMAL_STARTED_NO_RETRY.json", meta / "events.jsonl"):
        retain(path)
    return contract, observed, retain


CODE = g.CODE


def audit(plan_sha):
    contract, observed, retain = closed_identity(plan_sha)  # FIRST: all300 naturally closed.
    for name, pin in HELPERS.items():
        require(digest(TOOLS / name) == pin, "Trusted saved-helper metadata wrapper changed")
    helpers = load("formal_saved_original_helper_whitelist", TOOLS / "review_saved_v31_late.py", HELPERS["review_saved_v31_late.py"])
    raw = helpers.pure("formal_original_saved_arithmetic", helpers.OLD_TOOLS / "merge_development_blocks.py")
    p0 = helpers.pure("formal_original_strict_P0", helpers.OLD_TOOLS / "audit_passive_journal_sidecars.py")
    native_audit = original2_passive_caller(p0, contract["models"]["original2"]["source_hashes"])
    metrics = raw._module(CODE / "exp7_c07_scaling_20261012/metrics.py", "formal_metrics_getters_only")
    schema = raw._module(CODE / "c07_source/scripts/summarize_tmc_retest.py", "formal_original75_getters_only")
    specs = schema.selected_specs()
    require(len(specs) == len({s[0] for s in specs}) == 75, "All original75 keys required")
    checks, findings, results, rows_by_fault = [], [], {}, {}
    for fault in g.FAULTS:
        rows_by_fault[fault], groups, DATA, recovery = {}, {}, {}, {}
        for key in g.ARMS:
            model = contract["models"][key]
            cfg = model["environment_config"]
            path = c.RUN / "evaluations" / fault / key
            complete = read(path / "complete.json")
            rows = rows_identity(complete, g.POOLS[fault], model, fault, digest(g.CONTRACT))
            receipts = [json.loads(line) for line in (path / "progress.jsonl").read_text(encoding="utf-8").splitlines()]
            aggregate = read(path / "passive_sidecars/complete.json")
            reports = aggregate["episode_reports"]
            require(aggregate["original_evaluation_status"] == aggregate["observer_status"] == "completed"
                    and [r["seed"] for r in reports] == [r["seed"] for r in receipts] == g.POOLS[fault],
                    "Original/passive whole30 completion differs")
            groups[key] = metrics.summarize_groups(rows)
            rows_by_fault[fault][key] = {r["seed"]: r for r in rows}
            collision_pair_s, boundary_auv_s = 0., 0.
            for count, (row, receipt, report) in enumerate(zip(rows, receipts, reports), 1):
                seed, folder = row["seed"], path / f"seed_{row['seed']}"
                require(receipt["completed"] == count and set(receipt["files"]) == set(raw.FILES)
                        and {p.name for p in folder.iterdir()} == set(raw.FILES), "Original three artifacts/receipt count differ")
                for name, pin in receipt["files"].items():
                    require(retain(folder / name) == pin["sha256"] and (folder / name).stat().st_size == pin["bytes"], "Original episode bytes differ")
                require(exact(read(folder / "episode.json"), row), "Complete row and original episode differ")
                with gzip.open(folder / "network_evidence.json.gz", "rt", encoding="utf-8") as stream:
                    evidence = json.load(stream)
                require(exact({k: v for k, v in evidence.items() if k not in raw.EVENTS}, row["network_summary"])
                        and exact(row["network"], row["network_summary"]), "Network evidence projection differs")
                data, trace = raw._data_events(row, evidence, cfg), raw._trace_evidence(folder / "trace.jsonl.gz", row, cfg)
                collision_pair_s += trace["collision_pair_s"]
                boundary_auv_s += trace["boundary_auv_s"]
                unique = metrics.audit_unique_data(row["unique_data_keys"], 30, expected_packets=row["collected_packets"])
                require(unique["per_sensor_packets"] == row["per_sensor_packets"] and set(row["metrics75"]) == {s[0] for s in specs},
                        "Unique DATA identity or original75 key membership differs")
                for name, _, unit, _, getter in specs:
                    require(row["metrics75"][name]["unit"] == unit
                            and raw._same_number(row["metrics75"][name]["value"], getter(row)), "Original75 getter differs: " + name)
                expected = dict(n_auv=model["n_auv"], n_sensors=30, slot_owners=helpers.owners(cfg), slot_duration=cfg["slot_duration"],
                    source_hashes=model["source_hashes"], model_sha256=model["policy_sha256"], profile=model["profile"],
                    seed=seed, method=model["method"], model_training_step=450000)
                sidecar = path / "passive_sidecars" / f"seed_{seed}"
                try:
                    audit_function = native_audit if key == "original2" else p0.audit_sidecar
                    passive = audit_function(sidecar, expected, report, original_receipts=receipt["files"], source_root=CODE / "c07_source")
                    require(passive.get("success") is True, "Strict P0 did not pass")
                except Exception as error:
                    passive = dict(status="strict_failed_preserved", error=repr(error))
                    findings.append(dict(arm=key, fault=fault, seed=seed, error=repr(error)))
                for file in sidecar.iterdir():
                    if file.is_file():
                        retain(file)
                checks.append(dict(arm=key, fault=fault, seed=seed, DATA=data, trace=trace, original75=75, strict_P0=passive))
            DATA[key] = DATA_ratio_summary(rows)
            recovery[key] = recovery_and_exposure(rows, model["n_auv"])
            recovery[key].update(actual_collision_pair_seconds=collision_pair_s, actual_boundary_AUV_seconds=boundary_auv_s)
            for name in ("complete.json", "progress.jsonl", "passive_sidecars/complete.json"):
                retain(path / name)
        results[fault] = dict(groups=groups, actual_DATA_failure_ratios=DATA, recovery_and_actual_exposure=recovery)
    contrasts = {}
    for item in contract["collection_contrasts"]:
        fault, left, right = item["fault"], item["left"], item["right"]
        contrasts[fault + ":" + left + "-" + right] = collection_contrast(rows_by_fault[fault][left], rows_by_fault[fault][right], g.POOLS[fault])
    require(len(checks) == 300 and len(contrasts) == 8, "Whole300/22500 original75 and eight contrasts required")
    require(all(digest(path) == pin for path, pin in observed.items()), "Saved inputs changed during audit")
    require("torch" not in sys.modules and "numpy" not in sys.modules, "Saved audit imported numerical runtime")
    return dict(status="formal300_saved_audit_passed" if not findings else "strict_findings_retained_not_passed",
        observed_at=g.now(), formal_plan_sha256=plan_sha, contract_sha256=digest(g.CONTRACT), episodes=300,
        original75_values_checked=22500, strict_P0_failed_episodes=len(findings), strict_P0_findings=findings,
        checks=checks, fault_results=results, collection_contrasts=contrasts, observed_sha256=observed,
        original_helper_sha256=helpers.HELPER_PINS, strict_audit_code_identical=True,
        original2_audit_source_namespace_binding_only=True, native_clock_ULP_waiver=False,
        model_loads=0, CPU_audits_reexecuted=0, training_steps=0, simulation_steps=0,
        all_positive_and_negative_results_retained=True, no_automatic_tuning_or_new_physical_work=True,
        interpretation="Same-scenario frozen single-training-seed practical anchor confirmation, not equal-protocol scale causality or pure topology causality; all safety and cost outcomes retained.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan-sha", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "Exclusive new saved-review output required")
    try:
        result = audit(args.plan_sha)
    except Exception as error:
        import traceback
        g.write_new(args.output.with_suffix(args.output.suffix + ".FAILED.json"),
                    dict(status="saved_review_failed_preserved", error=repr(error), traceback=traceback.format_exc(),
                         no_physical_retry=True, model_loads=0, simulation_steps=0))
        raise
    g.write_new(args.output, result)
    print(json.dumps({k: result[k] for k in ("status", "episodes", "original75_values_checked", "strict_P0_failed_episodes")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
