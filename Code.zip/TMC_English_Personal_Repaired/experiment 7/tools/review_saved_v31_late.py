"""Closed V31 late160-episode record review: original75, DATA, trace, STRICT P0.

External, stdlib-only. Requires the whole naturally closed300k cohort and its
separate closed-identity receipt. Never imports a learner/ENV or loads weights.
200k and300k remain separate; only their common10 scenarios support paired
within-trajectory changes. No ULP waiver or automatic450k promotion.
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import gzip
import importlib.util
import json
from pathlib import Path
import random
import statistics
import sys

sys.dont_write_bytecode = True
TOOLS = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("v31_late_record_identity_only", TOOLS / "review_closed_v31_late_identity.py")
identity = importlib.util.module_from_spec(spec)
spec.loader.exec_module(identity)
ROOT, RUN, META, CODE = identity.ROOT, identity.RUN, identity.META, identity.CODE
read, digest, require, exact = identity.read, identity.digest, identity.require, identity.exact
OLD_TOOLS = ROOT.parent / "C07_V12V13_450k_20261018/tools"
HELPER_PINS = {
    "merge_development_blocks.py": "ebb834df377938728b57c0b2ed2eec2fbf6ece121a8dec4debbdea5187ae1bf3",
    "audit_passive_journal_sidecars.py": "91eae03f980ecfe5b0bf3345fb4827b162ac55172845e22fb073f34351227371",
}
PURE_IMPORTS = frozenset(("__future__", "argparse", "ast", "collections", "csv", "gzip", "hashlib",
                          "importlib", "json", "math", "pathlib", "random", "statistics", "sys"))


def pure(name, path):
    require(path.name in HELPER_PINS and digest(path) == HELPER_PINS[path.name], "Original saved-helper PIN differs")
    tree = ast.parse(path.read_text(encoding="utf-8-sig"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules = [item.name for item in node.names]
        elif isinstance(node, ast.ImportFrom):
            require(node.level == 0, "Relative scientific import forbidden")
            modules = [node.module or ""]
        else:
            continue
        require(all(value.split(".")[0] in PURE_IMPORTS for value in modules), "Non-record helper import")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require("torch" not in sys.modules and "numpy" not in sys.modules, "Numerical runtime imported")
    return module


def owners(cfg):
    result = []
    n = cfg["n_auv"]
    sensors = list(range(n + 1, n + 31))
    for offset in range(0, 30, cfg["tdma_sensors_per_group"]):
        result.extend(range(n + 1))
        result.extend(sensors[offset:offset + cfg["tdma_sensors_per_group"]])
    return result


def validate_rows(complete, receipts, seeds, arm, endpoint, policy, profile):
    require(complete["status"] == "completed" and exact(complete["learning_steps"], 0)
            and complete["all_failures_retained"] is True and complete["seeds"] == seeds
            and complete["model_sha256"] == policy, "Evaluation not complete/frozen with all failures")
    rows = complete["rows"]
    require([r["seed"] for r in rows] == [r["seed"] for r in receipts] == seeds
            and len(set(seeds)) == len(seeds), "Missing / duplicated / wrong ordered endpoint scenario set")
    for count, (row, receipt) in enumerate(zip(rows, receipts), 1):
        require(exact(receipt["completed"], count), "Append-only receipt count differs")
        require(exact(row["n_auv"], int(arm[0])) and exact(row["n_sensors"], 30)
                and row["method"] == ("full_v6" if arm.endswith("full") else "usde_only_v6")
                and row["profile"] == profile and row["evaluation_fault"] == "reference"
                and exact(row["model_training_step"], endpoint) and row["model_sha256"] == policy,
                "Cross-endpoint model / configuration / fault identity mismatch")
        require(row["ending_policy"] == "original_absorbing_safety"
                and row["termination_reason"] in ("collision", "boundary", "time_limit"), "Wrong original safety ending")
    return rows


def collection_contrast(left, right, seeds):
    """Exactly the coordinator's four prespecified endpoint collection contrasts."""
    require(list(left) == list(right) == seeds, "Paired scenario order differs")
    differences = [left[s]["collected_packets"] - right[s]["collected_packets"] for s in seeds]
    rng = random.Random(20261019)
    draws = sorted(statistics.mean(rng.choices(differences, k=len(differences))) for _ in range(40000))
    return dict(differences=differences, mean=statistics.mean(differences),
        positive_scenarios=sum(v > 0 for v in differences), negative_scenarios=sum(v < 0 for v in differences),
        exploratory_percentile95=[draws[999], draws[38999]],
        exploratory_four_endpoint_contrast_familywise95=[draws[249], draws[39749]],
        interpretation="Development-only paired scenario resampling for four N/endpoint collection comparisons; no cross-training-seed inference")


def audit(closed_path):
    identity.gate_whole()  # Must precede helper imports / episode reads.
    plan = identity.verify_plan()
    closed = read(closed_path)
    require(closed["status"] == "late_closed_identity_and_matched_control_verified"
            and closed["plan_sha256"] == identity.PLAN_SHA
            and set(closed["models"]) == set(identity.ARMS)
            and set(closed["stages"]) == set(identity.stage_labels()), "Whole closed-identity review required")
    for path, pin in closed["observed_files"].items():
        require(digest(path) == pin["sha256"] and Path(path).stat().st_size == pin["bytes"],
                "Closed identity receipt changed before saved review")
    raw = pure("late_original_saved_arithmetic", OLD_TOOLS / "merge_development_blocks.py")
    p0 = pure("late_original_strict_passive_P0", OLD_TOOLS / "audit_passive_journal_sidecars.py")
    metrics = raw._module(CODE / "exp7_c07_scaling_20261012/metrics.py", "late_metrics_only")
    schema = raw._module(CODE / "c07_source/scripts/summarize_tmc_retest.py", "late_original75_only")
    specs = schema.selected_specs()
    require(len(specs) == len({s[0] for s in specs}) == 75, "Wrong original75 schema")
    checked, findings, observed, rows_by_endpoint = [], [], {}, {s: {} for s in identity.ENDPOINTS}

    def retain(path):
        path = Path(path)
        before = digest(path)
        require(str(path) not in observed or observed[str(path)] == before, "Input changed during saved audit")
        observed[str(path)] = before

    retain(closed_path)
    for arm in identity.ARMS:
        manifest = read(Path(plan["arms"][arm]["output"]) / "learning/manifest.json")
        cfg = manifest["environment_config"]
        for endpoint in identity.ENDPOINTS:
            seeds = plan["evaluation_seeds"][str(endpoint)]
            path = RUN / "evaluations" / arm / str(endpoint)
            complete = read(path / "complete.json")
            receipts = [json.loads(line, object_pairs_hook=identity.pairs, parse_constant=identity.reject_constant)
                        for line in (path / "progress.jsonl").read_text(encoding="utf-8").splitlines()]
            selected = closed["models"][arm]["selected_endpoints"][str(endpoint)]
            policy = selected["files"]["policy.pt"]["sha256"]
            rows = validate_rows(complete, receipts, seeds, arm, endpoint, policy, plan["profile"])
            reports_list = read(path / "passive_sidecars/complete.json")["episode_reports"]
            require(len(reports_list) == len(seeds) and [r["seed"] for r in reports_list] == seeds,
                    "Missing / duplicate / reordered passive episode reports")
            reports = {r["seed"]: r for r in reports_list}
            for row, receipt in zip(rows, receipts):
                seed = row["seed"]
                folder = path / f"seed_{seed}"
                sidecar = path / "passive_sidecars" / f"seed_{seed}"
                require(set(receipt["files"]) == set(raw.FILES)
                        and {p.name for p in folder.iterdir()} == set(raw.FILES), "Wrong original three artifacts")
                for name, pin in receipt["files"].items():
                    file = folder / name
                    require(digest(file) == pin["sha256"] and file.stat().st_size == pin["bytes"], "Episode receipt differs")
                    retain(file)
                require(exact(read(folder / "episode.json"), row), "Complete row / saved episode differ")
                with gzip.open(folder / "network_evidence.json.gz", "rt", encoding="utf-8") as stream:
                    evidence = json.load(stream, object_pairs_hook=identity.pairs, parse_constant=identity.reject_constant)
                require(exact({k: v for k, v in evidence.items() if k not in raw.EVENTS}, row["network_summary"])
                        and exact(row["network_summary"], row["network"]), "Network projection differs")
                data = raw._data_events(row, evidence, cfg)
                trace = raw._trace_evidence(folder / "trace.jsonl.gz", row, cfg)
                unique = metrics.audit_unique_data(row["unique_data_keys"], 30, expected_packets=row["collected_packets"])
                require(unique["per_sensor_packets"] == row["per_sensor_packets"], "Unique per-sensor DATA differs")
                require(set(row["metrics75"]) == {s[0] for s in specs}, "Wrong original75 keys")
                for key, _, unit, _, getter in specs:
                    saved = row["metrics75"][key]
                    require(saved["unit"] == unit and raw._same_number(saved["value"], getter(row)),
                            "Original75 getter mismatch: " + key)
                expected = dict(n_auv=int(arm[0]), n_sensors=30, slot_owners=owners(cfg), slot_duration=cfg["slot_duration"],
                    source_hashes=manifest["source_hashes"], model_sha256=policy, profile=plan["profile"], seed=seed,
                    method=manifest["method_id"], model_training_step=endpoint)
                try:
                    passive = p0.audit_sidecar(sidecar, expected, reports[seed],
                        original_receipts=receipt["files"], source_root=CODE / "c07_source")
                    require(passive.get("success") is True, "Strict passive P0 did not pass")
                except Exception as error:
                    passive = dict(status="strict_failed_preserved", error=repr(error))
                    findings.append(dict(arm=arm, endpoint=endpoint, seed=seed, error=repr(error)))
                for file in sidecar.iterdir():
                    if file.is_file():
                        retain(file)
                checked.append(dict(arm=arm, endpoint=endpoint, seed=seed, DATA=data, trace=trace,
                                    original75=75, strict_P0=passive))
            rows_by_endpoint[endpoint][arm] = {r["seed"]: r for r in rows}
            for name in ("complete.json", "progress.jsonl", "passive_sidecars/complete.json"):
                retain(path / name)

    endpoints = {}
    coordinator_results = read(RUN / "LATE_RESULTS.json")
    for endpoint, arms in rows_by_endpoint.items():
        seeds = plan["evaluation_seeds"][str(endpoint)]
        allrows = [row for arm in identity.ARMS for row in arms[arm].values()]
        pairs = {str(n): collection_contrast(arms[f"{n}full"], arms[f"{n}usde"], seeds) for n in (3, 4)}
        require(exact(pairs, coordinator_results["endpoints"][str(endpoint)]["paired_full_minus_usde"]),
                "Independent saved arithmetic differs from coordinator contrasts")
        endpoints[str(endpoint)] = dict(episodes=len(allrows), seeds=seeds,
            groups=metrics.summarize_groups(allrows), paired_full_minus_usde=pairs)
    common = plan["evaluation_seeds"]["200000"]
    changes = {}
    for arm in identity.ARMS:
        before, after = rows_by_endpoint[200000][arm], rows_by_endpoint[300000][arm]
        differences = [after[s]["collected_packets"] - before[s]["collected_packets"] for s in common]
        changes[arm] = dict(common_seeds=common, differences_300k_minus_200k=differences,
            mean=statistics.mean(differences), positive_scenarios=sum(v > 0 for v in differences),
            negative_scenarios=sum(v < 0 for v in differences),
            interpretation="Descriptive change on the same10 scenarios and same continuous trajectory; not independent train-seed replicates")
    require(len(checked) == 160 and sum(r["original75"] for r in checked) == 12000, "Incomplete whole late review")
    require(all(digest(Path(path)) == pin for path, pin in observed.items()), "Saved records changed during review")
    require("torch" not in sys.modules and "numpy" not in sys.modules, "Saved audit imported numerical runtime")
    return dict(status="late_saved_audit_passed" if not findings else "strict_findings_retained_not_passed",
        observed_at=datetime.now(timezone.utc).isoformat(), plan_sha256=identity.PLAN_SHA,
        episodes=160, original75_values_checked=12000, strict_P0_failed_episodes=len(findings),
        strict_P0_findings=findings, checks=checked, endpoints=endpoints, same10_late_learning_changes=changes,
        observed_sha256=observed, helper_sha256=HELPER_PINS,
        reviewer_sha256={name: digest(TOOLS / name) for name in ("review_closed_v31_late_identity.py", "review_saved_v31_late.py")},
        model_loads=0, CPU_audits_reexecuted=0, training_steps=0, simulation_steps=0,
        original2_existing10_not_reexecuted=True, original2_additional20_still_pending=True,
        no_automatic_promotion=True, formal_confirmation_opened=False,
        limits="Saved arithmetic/strict native order evidence, not physics reintegration, cross-stream total order or cross-training-seed inference; no ULP waiver.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--closed-identity", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "New exclusive saved evidence path required")
    result = audit(args.closed_identity)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({k: result[k] for k in ("status", "episodes", "original75_values_checked", "strict_P0_failed_episodes")}))


if __name__ == "__main__":
    main()
