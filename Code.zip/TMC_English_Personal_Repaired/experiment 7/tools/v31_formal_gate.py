"""External typed mixed-protocol formal gate; metadata only, never simulate.

NOT the native same-profile validation contract. The original successful N2
keeps its original107-source/config/native Policy and historical lineage.
The four selected V31 models must be fresh450k, first-CPU-proved and frozen.
This module does not itself prepare a PLAN, import numerics, or open seeds.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / "tools"
CODE = ROOT / "candidate_v31_child_deadline/code"
TRAIN = ROOT.parent / "runs/c07_research34_20261020/v31_final450k"
FORMAL = ROOT.parent / "runs/c07_research34_20261020/v31_formal300"
CONTRACT = FORMAL / "metadata/FROZEN_CONTRACT.json"
REGISTRY = ROOT / "formal_once_seed_registry"
TRAIN_PLAN_SHA = "bbb18be17c924c05549fbc27bfaaa13d1c5c989484373dd54110e9718d1d0fe3"
FORMAT = "c07-selected-v31-frozen-mixed-protocol-confirmation-v1"
PROFILE = "adaptive_packet_grid_joint_child_deadline_v31"
N2_PROFILE = "original_c07_frozen2_anchor_confirmation"
ARMS = ("original2", "3full", "3usde", "4full", "4usde")
FAULTS = ("reference", "direct1_outage")
POOLS = {"reference": list(range(10919000, 10919030)), "direct1_outage": list(range(10920000, 10920030))}
N2_SHA = "fdb50fc648e57e43be63dd0c6edf332277c2e66122a851cccf650e2cf8c6e1c5"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def exact(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(exact(left[k], right[k]) for k in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(exact(a, b) for a, b in zip(left, right))
    return left == right


def pairs(values):
    result = {}
    for key, value in values:
        require(key not in result, "Duplicate JSON field: " + key)
        result[key] = value
    return result


def read(path):
    def nonfinite(value):
        raise ValueError("Nonfinite JSON token: " + value)
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=pairs, parse_constant=nonfinite)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def now():
    return datetime.now(timezone.utc).isoformat()


def is_sha256(value):
    return type(value) is str and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def contrast_family():
    return [dict(fault=fault, left=f"{n}full", right=right, primary="collected_packets")
            for fault in FAULTS for n in (3, 4) for right in (f"{n}usde", "original2")]


def check_design(contract):
    require(contract["format"] == FORMAT and list(contract["models"]) == list(ARMS)
            and contract["training_plan_sha256"] == TRAIN_PLAN_SHA
            and exact(contract["seed_pools"], POOLS), "Wrong typed frozen mixed-protocol design")
    require(exact(contract["episodes"], 300) and exact(contract["learning_steps"], 0)
            and exact(contract["endpoint"], 450000) and contract["device"] == "cpu"
            and exact(contract["episode_step_cap"], 1200) and contract["ending"] == "original_absorbing_safety"
            and contract["all_failures_retained"] is True and contract["once_only"] is True
            and contract["negative_result_retuning_or_reselection"] is False,
            "Frozen physical/learning/ending/once-only boundary differs")
    require(contract["comparison_scope"] == "same_scenario_practical_anchor_mixed_protocol_not_pure_scale_causality"
            and exact(contract["collection_contrasts"], contrast_family())
            and exact(contract["collection_family_alpha"], .05)
            and contract["native_same_protocol_contract_claim"] is False,
            "Do not impersonate native alpha-spending/same-protocol contract or change the eight comparisons")
    for key, model in contract["models"].items():
        require(exact(model["n_auv"], 2 if key == "original2" else int(key[0]))
                and exact(model["n_sensors"], 30) and exact(model["training_step"], 450000)
                and model["method"] == ("usde_only_v6" if key.endswith("usde") else "full_v6")
                and is_sha256(model["policy_sha256"]), "Wrong selected model identity")
        if key == "original2":
            require(model["kind"] == "original_native_historical_anchor"
                    and model["policy_sha256"] == N2_SHA and model["profile"] == N2_PROFILE
                    and model["fresh"] is False and model["repeated_training_or_CPU_audit"] is False
                    and len(model["source_hashes"]) == 107 and model["scale_context_present"] is False,
                    "Original N2 cannot be relabelled fresh/new-scale or replaced by a weaker anchor")
        else:
            require(model["kind"] == "selected_v31_fresh450k" and model["fresh"] is True
                    and model["profile"] == PROFILE and model["scale_context_present"] is True
                    and model["first_independent_CPU_passed"] is True
                    and len(model["source_hashes"]) == 152
                    and model["parent_checkpoint"] is None and model["continuation_provenance"] is None,
                    "Selected new model must be first-CPU-proved fresh final450k")
    # Same-N public manifests remain matched, but N2 is deliberately NOT
    # claimed to share a full protocol/config/source set with the new scales.
    for n in (3, 4):
        full, usde = (contract["models"][f"{n}{k}"] for k in ("full", "usde"))
        for field in ("environment_config", "routing_options", "learning_config", "revision_learning_options",
                      "training_protocol", "source_hashes"):
            require(exact(full[field], usde[field]), "Same-N public configuration differs: " + field)
        left, right = full["method_options"], usde["method_options"]
        require(left["mac_enabled"] is True and right["mac_enabled"] is False
                and exact({k: v for k, v in left.items() if k != "mac_enabled"},
                          {k: v for k, v in right.items() if k != "mac_enabled"}),
                "Control weakened beyond declared matched communication-bundle ablation")


def validate_saved_policy(saved, model):
    """Called on the actually loaded policy BEFORE the common Policy/ENV.

    Does not deserialize anything itself. Original N2 is checked before the
    separately labelled in-memory measurement-only scale_context is added.
    """
    require(exact(saved["global_step"], 450000) and saved["method_id"] == model["method"]
            and saved["run_id"] == model["run_id"]
            and exact(saved["source_hashes"], model["source_hashes"])
            and exact(saved["environment_config"], model["environment_config"]),
            "Actual frozen policy step/method/run/source/CFG differs")
    for field in ("method_options", "routing_options", "learning_config", "revision_learning_options"):
        if field in model:
            require(exact(saved[field], model[field]), "Actual saved policy typed settings differ: " + field)
    if model["kind"] == "original_native_historical_anchor":
        require("scale_context" not in saved and saved["config_fingerprint"] == model["config_fingerprint"]
                and saved["format"] == model["checkpoint_format"], "Original native N2 format/namespace must be unchanged")
    else:
        context = saved["scale_context"]
        require(context["stage"] == "full" and context["profile"] == PROFILE
                and context["attempt_id"] == model["attempt_id"]
                and exact(context["declaration"], model["declaration"]), "New final450k context/declaration differs")


def validate_invocation(contract, key, fault, seeds, policy_sha, output):
    check_design(contract)
    require(key in ARMS and fault in FAULTS and exact(seeds, POOLS[fault])
            and policy_sha == contract["models"][key]["policy_sha256"]
            and Path(output).resolve() == FORMAL / "evaluations" / fault / key,
            "Only original registered30 seeds and frozen arm/fault/output")


def verify_training_closed():
    """Read original receipts/JSON only, AFTER final training naturally exits.

    This is a closure identity review, not a second optimizer/CPU audit.
    An active train blocks at the first check, before reading any model.
    """
    meta = TRAIN / "metadata"
    require((meta / "TRAINING_ENDED_FORMAL_REQUIRED.json").is_file(), "All four final450k models not yet naturally completed")
    require(not (meta / "FINAL_TRAINING_STOPPED_NO_RETRY.json").exists(), "Training STOP requires diagnosis, never retry")
    ended, coordinator = read(meta / "TRAINING_ENDED_FORMAL_REQUIRED.json"), read(meta / "COORDINATOR_NATIVE_EXIT.json")
    require(exact(ended["training_steps"], 1800000) and exact(ended["evaluation_episodes"], 0)
            and ended["research_ended"] is False and exact(coordinator["actual_exit_code"], 0)
            and coordinator["no_process_stopped"] is True, "Wrong closed training-only boundary")
    require(digest(meta / "PLAN.json") == TRAIN_PLAN_SHA, "Final training PLAN differs")
    spec = importlib.util.spec_from_file_location("formal_gate_closed_training_only", TOOLS / "run_v31_final450k.py")
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.PLAN_BOUND_SHA = TRAIN_PLAN_SHA
    plan = read(meta / "PLAN.json")
    driver.verify(plan)
    freeze = read(meta / "ALL_FOUR_ENDPOINTS_FROZEN.json")
    require(ended["frozen_sha256"] == digest(meta / "ALL_FOUR_ENDPOINTS_FROZEN.json")
            and freeze["plan_sha256"] == TRAIN_PLAN_SHA and freeze["formal_seeds_opened"] is False
            and list(freeze["models"]) == list(ARMS[1:]), "All four endpoint SHA freeze required")
    events = [json.loads(line) for line in (meta / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    observed_order = [(r["event"], r["label"]) for r in events if r["event"] in ("stage_dispatch", "stage_closed")
                      and not r["label"].startswith("fixture_")]
    expected_order = [(kind, key + suffix) for key in ARMS[1:] for suffix in ("_train", "_cpu_audit")
                      for kind in ("stage_dispatch", "stage_closed")]
    require(observed_order == expected_order, "Duplicate, missing, reordered or unclosed scientific dispatch")
    observed = {}
    def retain(path):
        value = digest(path)
        require(str(path) not in observed or observed[str(path)] == value, "Closed input changed during review")
        observed[str(path)] = value
        return value
    for path in (meta / "PLAN.json", meta / "TRAINING_ENDED_FORMAL_REQUIRED.json", meta / "ALL_FOUR_ENDPOINTS_FROZEN.json",
                 meta / "events.jsonl", meta / "COORDINATOR_NATIVE_EXIT.json", meta / "COORDINATOR_STARTED.json"):
        retain(path)
    for kind in ("stdout", "stderr"):
        require(coordinator[kind + "_sha256"] == retain(meta / ("coordinator." + kind + ".log")), "Coordinator stdio changed")
    require((meta / "coordinator.stderr.log").stat().st_size == 0, "Training coordinator stderr requires review")
    models = {}
    for key in ARMS[1:]:
        arm = plan["arms"][key]
        learning = Path(arm["output"]) / "learning"
        manifest, summary = read(learning / "manifest.json"), read(learning / "summary.json")
        driver.scope.validate_closed_arm(manifest, summary, arm, plan["source_identities"])
        for suffix in ("_train", "_cpu_audit"):
            label = key + suffix
            stage = read(meta / (label + ".spec.json"))
            receipt = read(meta / (label + ".native_exit.json"))
            supervisor = read(meta / (label + ".supervisor_exit.json"))
            driver.scope.validate_held(receipt, supervisor, stage)
            expected = driver.scope.training_argv(plan, key) if suffix == "_train" else ["-B", "-X", "utf8",
                str(TOOLS / "inspect_v31_final450k_checkpoint.py"), "--checkpoint", str(learning / "checkpoint_latest.pt"),
                "--training-log", str(learning / "training.jsonl"), "--plan-sha", TRAIN_PLAN_SHA]
            require(stage["argv"] == expected and receipt["spec_sha256"] == retain(meta / (label + ".spec.json")),
                    "Original full stage command differs")
            for kind in ("stdout", "stderr"):
                require(receipt[kind + "_sha256"] == retain(stage[kind])
                        and supervisor[kind + "_sha256"] == retain(meta / (label + ".supervisor." + kind + ".log")),
                        "Original stage stdio differs")
            for name in (".native_exit.json", ".supervisor_exit.json", ".dispatch.json", ".reservation.json"):
                retain(meta / (label + name))
            for path, pin in stage["input_pins"].items():
                require(retain(path) == pin, "Original closed stage input differs")
            require(Path(stage["stderr"]).stat().st_size == (meta / (label + ".supervisor.stderr.log")).stat().st_size == 0,
                    "Stage stderr requires review")
        cpu = read(meta / (key + "_cpu_audit.stdout.log"))
        require(cpu["status"] == "passed" and exact(cpu["global_step"], 450000)
                and cpu["selected_v31_final_scope"]["arm"] == key
                and cpu["selected_v31_final_scope"]["plan_sha256"] == TRAIN_PLAN_SHA
                and cpu["critic_adam_steps_per_auv"] == [449000] * int(key[0])
                and cpu["actor_adam_steps_per_auv"] == [224500] * int(key[0]), "Original FIRST CPU proof differs")
        for name in ("checkpoint_latest.pt", "policy_inference.pt", "summary.json", "manifest.json", "training.jsonl"):
            pin = retain(learning / name)
            frozen_key = {"checkpoint_latest.pt": "checkpoint_sha256", "policy_inference.pt": "policy_sha256",
                          "summary.json": "summary_sha256", "manifest.json": "manifest_sha256"}.get(name)
            if frozen_key:
                require(pin == freeze["models"][key][frozen_key], "Frozen endpoint artifact differs")
        require(cpu["checkpoint_sha256"] == digest(learning / "checkpoint_latest.pt")
                and cpu["inference_policy"]["sha256"] == digest(learning / "policy_inference.pt"), "Saved CPU weight binding differs")
        models[key] = dict(kind="selected_v31_fresh450k", n_auv=int(key[0]), n_sensors=30,
            method=manifest["method_id"], profile=PROFILE, training_step=450000, fresh=True,
            scale_context_present=True, first_independent_CPU_passed=True,
            parent_checkpoint=None, continuation_provenance=None, run_id=manifest["run_id"],
            policy=str(learning / "policy_inference.pt"), policy_sha256=freeze["models"][key]["policy_sha256"],
            attempt_id=arm["attempt_id"], declaration=arm["declaration"],
            **{field: deepcopy(manifest[field]) for field in ("environment_config", "method_options", "routing_options",
                "learning_config", "revision_learning_options", "training_protocol", "source_hashes")})
    ledger = read(TRAIN / "physical_ledger.json")
    require(len(ledger["attempts"]) == 4
            and {row["attempt_id"] for row in ledger["attempts"]} == {plan["arms"][k]["attempt_id"] for k in ARMS[1:]}
            and all(row["stage"] == "full" and row["status"] == "completed"
            and exact(row["executed_steps"], 450000) and exact(row["resume_from_step"], 0)
            and row["resume_parent_attempt"] is None and row["reservation_overrun"] is False
            for row in ledger["attempts"]), "Four complete fresh physical reservations required")
    retain(TRAIN / "physical_ledger.json")
    require("torch" not in sys.modules and "numpy" not in sys.modules, "Training closure review imported numerics")
    return dict(status="four_selected450k_original_closure_verified_no_CPU_reaudit", models=models,
                observed_sha256=observed, source_files=plan["source_files"], source_identities=plan["source_identities"],
                tool_pins=plan["tools"], runtime_pins=plan["runtime"], historical_pins=plan["historical_pins"])


def verify_files(contract):
    check_design(contract)
    require(not (TRAIN / "metadata/FINAL_TRAINING_STOPPED_NO_RETRY.json").exists(), "Training STOP remains blocking")
    for path, pin in contract["input_pins"].items():
        require(digest(path) == pin, "Frozen formal input changed: " + path)
    for relative, pin in contract["source_files"].items():
        require(digest(CODE / relative) == pin, "Scientific source changed before formal evaluation")
    for model in contract["models"].values():
        require(digest(model["policy"]) == model["policy_sha256"], "Any of five frozen policies changed")
    return contract


def reserve_stage(contract_path, key, fault, output):
    """Permanent reservation before importing numeric/evaluation modules.

    A failed load after reservation is retained and does NOT permit retry.
    Creating this alone is not represented as executed physical test work.
    """
    require("torch" not in sys.modules and "numpy" not in sys.modules, "Numerical import before dispatch reservation")
    require(Path(contract_path).resolve() == CONTRACT, "Only the one externally frozen formal contract")
    contract = verify_files(read(contract_path))
    require(key in ARMS and fault in FAULTS, "Unknown formal stage")
    validate_invocation(contract, key, fault, POOLS[fault], contract["models"][key]["policy_sha256"], output)
    require(not Path(output).exists(), "Never overwrite/retry any formal episode output")
    marker = FORMAL / "metadata" / (fault + "_" + key + ".RESERVED_NO_RETRY.json")
    write_new(marker, dict(observed_at=now(), contract_sha256=digest(contract_path), arm=key, fault=fault,
        output=str(output), seeds=POOLS[fault], pid=os.getpid(), numerical_imports_before_reservation=False,
        actual_physical_steps_at_reservation=0, no_retry=True))
    require("torch" not in sys.modules and "numpy" not in sys.modules, "Numerical import before dispatch reservation")
    return contract


def open_before_environment(contract_path, key, fault, seeds, policy_sha, output):
    """Explicit replacement seed-gate binding; called before Policy/ENV.

    Does NOT pretend to be native holdout_validation or its sequential-alpha
    scheme. Marks the whole registered30 seed set and all five policy hashes.
    """
    require(Path(contract_path).resolve() == CONTRACT, "Wrong formal gate contract")
    contract = verify_files(read(contract_path))
    validate_invocation(contract, key, fault, seeds, policy_sha, output)
    sha = digest(contract_path)
    reservation = read(FORMAL / "metadata" / (fault + "_" + key + ".RESERVED_NO_RETRY.json"))
    require(reservation["contract_sha256"] == sha and reservation["pid"] == os.getpid()
            and reservation["no_retry"] is True, "Only same originally reserved worker may open its full seed set")
    registry = REGISTRY / (fault + "_" + str(seeds[0]) + "_" + str(seeds[-1]) + ".json")
    REGISTRY.mkdir(exist_ok=True)
    opening = dict(format=FORMAT, contract_sha256=sha, seeds=seeds, fault=fault,
                   all_policy_sha256={k: contract["models"][k]["policy_sha256"] for k in ARMS})
    try:
        write_new(registry, opening)
    except FileExistsError:
        require(exact(read(registry), opening), "Seed set already belongs to a different frozen campaign; no holdout reuse")
    marker = FORMAL / "metadata" / (fault + "_" + key + ".OPENED_BEFORE_ENV.json")
    write_new(marker, dict(observed_at=now(), **opening, arm=key, policy_sha256=policy_sha,
                           no_retry=True, phase="frozen_mixed_protocol_confirmation"))
    return dict(phase="frozen_mixed_protocol_confirmation", primary="collected_packets", seeds=seeds,
        holdout_opened=True, already_opened=False, checkpoint_sha256=policy_sha, model_training_step=450000,
        validation_contract_sha256=sha, evaluation_fault=fault, family_alpha=.05,
        collection_family_comparisons=8, native_sequential_alpha_protocol=False,
        original2_is_same_scenario_historical_anchor_not_new_scale=True)
