"""Future once-only formal30 worker; no dispatch from import or preparation.

Reuses the EXACT unchanged common measurement code object. New V31 replaces
two boundary globals (authenticated loader wrapper and external seed gate).
Original N2 replaces the same five publicly declared globals as its already
audited development interface; its native Policy/config/source stay original.
Only execute() after a frozen contract imports numeric/scientific modules.
"""
from __future__ import annotations
import argparse
import ast
from contextlib import contextmanager
import hashlib
import importlib.util
from pathlib import Path
import sys
import traceback
from types import FunctionType

sys.dont_write_bytecode = True
TOOLS = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("worker_explicit_mixed_protocol_gate", TOOLS / "v31_formal_gate.py")
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
NEW_GLOBAL_BINDINGS = ("load_new_checkpoint", "validate_evaluation_seeds")
N2_GLOBAL_BINDINGS = ("load_new_checkpoint", "bindings", "validate_evaluation_seeds", "source_hashes", "JOINT_PROFILES")


def measurement_AST(path):
    tree = ast.parse(Path(path).read_text(encoding="utf-8-sig"))
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "evaluate_checkpoint")
    return hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()


def derive_measurement_worker(common, model, key, fault, contract_path, output, *, native=None,
                              authorize=g.open_before_environment):
    """Boundary-only closure, also testable with synthetic stdlib fixtures.

    Actual execution always supplies the real external typed gate. There is
    no CLI option to replace Policy, measurement code or this authorization.
    """
    original = common.evaluate_checkpoint
    loaded = []
    original_n2 = key == "original2"
    native_policy = native.Policy if original_n2 else None
    native_loader = native.load_checkpoint if original_n2 else common.load_new_checkpoint

    def checked_load(path):
        g.require(Path(path).resolve() == Path(model["policy"]).resolve(), "Only the frozen selected policy")
        saved = native_loader(Path(path))  # Path, NOT str, preserves native file_digest interface.
        g.validate_saved_policy(saved, model)
        if original_n2:
            g.require(native.Policy is native_policy and g.exact(native.sources(), model["source_hashes"]),
                      "Original native class or107-source namespace changed")
            result = dict(saved)
            result["scale_context"] = dict(profile=g.N2_PROFILE, stage="original_frozen_anchor",
                original_n_auv=2, original_checkpoint_format_unchanged=True,
                not_new_scale_checkpoint=True, external_formal_confirmation_measurement_context_only=True)
        else:
            result = saved
        loaded.append(result)
        g.require(len(loaded) == 1, "No undeclared second policy load in formal stage")
        return result

    def checked_seed_gate(saved, policy_sha, seeds, validation_contract=None, *, fault_profile):
        g.require(len(loaded) == 1 and saved is loaded[0]
                  and Path(validation_contract).resolve() == Path(contract_path).resolve()
                  and fault_profile == fault, "Gate must see the actual once-loaded policy and declared fault")
        return authorize(contract_path, key, fault, seeds, policy_sha, output)

    replacements = dict(load_new_checkpoint=checked_load, validate_evaluation_seeds=checked_seed_gate)
    if original_n2:
        @contextmanager
        def original_binding(context, cap):
            g.require(context["profile"] == g.N2_PROFILE and cap == 450000 and native.Policy is native_policy,
                      "Original native Policy/config may not be replaced")
            yield native
            g.require(native.Policy is native_policy, "Original native class was patched")
        replacements.update(bindings=original_binding, source_hashes=native.sources,
                            JOINT_PROFILES=(*common.JOINT_PROFILES, g.N2_PROFILE))
    allowed = N2_GLOBAL_BINDINGS if original_n2 else NEW_GLOBAL_BINDINGS
    g.require(set(replacements) == set(allowed), "Undeclared boundary global replacement")
    namespace = dict(original.__globals__)
    namespace.update(replacements)
    worker = FunctionType(original.__code__, namespace, original.__name__, original.__defaults__, original.__closure__)
    g.require(worker.__code__ is original.__code__ and original.__defaults__ == worker.__defaults__
              and {k for k in namespace if namespace[k] is not original.__globals__[k]} == set(allowed),
              "Measurement code/defaults or an undeclared global changed")
    proof = dict(evaluator_code_object_identical=True, evaluation_global_bindings=list(allowed),
        measurement_physics_rewards_getters_timing_and_ending_code_unchanged=True,
        original2_has_explicit_measurement_context_only=original_n2,
        original_policy_or_class_or_scientific_module_globals_patched=False,
        native_same_protocol_contract_claim=False)
    return worker, loaded, proof


def execute(key, fault, contract_path, contract_sha):
    g.require("torch" not in sys.modules and "numpy" not in sys.modules, "No numerical import before frozen boundary")
    g.require(Path(contract_path).resolve() == g.CONTRACT and g.digest(contract_path) == contract_sha,
              "Originally sealed contract byte identity differs")
    output = g.FORMAL / "evaluations" / fault / key
    contract = g.reserve_stage(contract_path, key, fault, output)
    # No training, optimizer inspection or alternate profile is reachable.
    try:
        evaluator_path = g.CODE / "exp7_c07_scaling_20261012/evaluation.py"
        g.require(g.digest(evaluator_path) == contract["evaluator_source_sha256"]
                  and measurement_AST(evaluator_path) == contract["evaluator_AST_sha256"], "Original measurement code changed")
        sys.path.insert(0, str(g.CODE))
        from exp7_c07_scaling_20261012 import evaluation as common
        native = None
        if key == "original2":
            from v6_campaigns.c07_1m_20260919 import workflow as native
        model = contract["models"][key]
        worker, loaded, proof = derive_measurement_worker(common, model, key, fault, contract_path, output, native=native)
        result = worker(Path(model["policy"]), output, contract["seed_pools"][fault], device="cpu",
                        fault_profile=fault, validation_contract=Path(contract_path))
        g.require(result["status"] == "completed" and result["episodes"] == 30 and len(loaded) == 1,
                  "Whole formal group not completed; keep every partial outcome")
        complete = g.read(output / "complete.json")
        g.require(complete["learning_steps"] == 0 and complete["all_failures_retained"] is True
                  and complete["evaluation_phase"]["phase"] == "frozen_mixed_protocol_confirmation",
                  "Wrong frozen formal completion phase")
        g.verify_files(contract)
        g.write_new(g.FORMAL / "metadata" / (fault + "_" + key + ".PROVENANCE.json"),
            dict(status="completed_formal30_requires_independent_saved_audit", observed_at=g.now(),
                contract_sha256=contract_sha, arm=key, fault=fault, policy_sha256=model["policy_sha256"],
                evaluator_source_sha256=g.digest(evaluator_path), evaluator_AST_sha256=measurement_AST(evaluator_path),
                **proof, learning_steps=0, training_steps=0, CPU_model_audits_reexecuted=0,
                complete_json_sha256=g.digest(output / "complete.json"), passive_journal=result.get("passive_journal"),
                all_failures_retained=True, no_automatic_retry=True))
        print(__import__("json").dumps(result, ensure_ascii=False, allow_nan=False), flush=True)
    except BaseException as error:
        g.write_new(g.FORMAL / "metadata" / (fault + "_" + key + ".STOPPED_NO_RETRY.json"),
            dict(observed_at=g.now(), error=repr(error), traceback=traceback.format_exc(),
                 evidence_preserved=True, no_retry=True))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=g.ARMS, required=True)
    parser.add_argument("--fault", choices=g.FAULTS, required=True)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--contract-sha", required=True)
    parser.add_argument("--execute-original-frozen-formal30", action="store_true")
    args = parser.parse_args()
    g.require(args.execute_original_frozen_formal30, "Explicit original frozen formal30 stage required")
    execute(args.arm, args.fault, args.contract, args.contract_sha)


if __name__ == "__main__":
    main()
