"""Independent stdlib-only, read-only P0 sidecar integrity/timeliness audit.

Never imports an ENV/network/helper/torch, loads weights, invokes a trial,
changes the original75/three-file receipts, or writes an audit output file.
The caller supplies independent identity and the external four-file receipts.
Native stream index is append order WITHIN that stream. File order is only
serialization order. The current v1 journal does not record drain IDs/empty
drain batches: full drain-index continuity is unavailable, never invented.
"""
from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import json
import math
from pathlib import Path


SIDECAR_FORMAT = "c07_passive_native_event_sidecar_v1"
JOURNAL_FORMAT = "c07_passive_native_event_journal_v1"
AGGREGATE_FORMAT = "c07_passive_evaluation_sidecars_v1"
STREAMS = ("net.mac_events", "env.mac_scheduler_events", "env.c04_task_events",
           "env.c06_task_events", "env.c07_task_events", "env.service_end_events")
FILES = ("header.json", "passive_events.jsonl.gz", "final_summary.json", "receipt.json")
IDENTITY_FIELDS = ("n_auv", "n_sensors", "slot_owners", "slot_duration", "source_hashes",
                   "model_sha256", "profile", "seed", "method", "model_training_step")
UNAVAILABLE_DRAIN = "v1 has no persisted per-drain ID or empty-drain batch record; final counts are not full drain-index evidence"


class SidecarAuditError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise SidecarAuditError(message)


def integer(value, name, lower=0, upper=None):
    require(type(value) is int and value >= lower and (upper is None or value <= upper),
            "Invalid integer " + name)
    return value


def numeric(value, name, lower=None):
    require(type(value) in (int, float) and math.isfinite(value) and (lower is None or value >= lower),
            "Invalid finite numeric " + name)
    return value


def exact(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(type(k) is str and exact(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(exact(x, y) for x, y in zip(a, b))
    if type(a) is float:
        return math.isfinite(a) and math.isfinite(b) and a == b
    return a is None or type(a) in (str, int, bool) and a == b


def _pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def _constant(value):
    raise SidecarAuditError("Nonfinite JSON constant: " + value)


def json_text(value):
    return json.loads(value, object_pairs_hook=_pairs, parse_constant=_constant)


def read_json(path):
    return json_text(Path(path).read_text(encoding="utf-8-sig"))


def sha(value, name):
    require(type(value) is str and len(value) == 64 and
            all(c in "0123456789abcdef" for c in value), "Invalid canonical SHA256 " + name)
    return value


def file_receipt(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), "Missing/nonregular/symlink sidecar: " + path.name)
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024*1024), b""):
            digest.update(block)
    return dict(bytes=path.stat().st_size, sha256=digest.hexdigest())


def verify_receipts(directory, expected, names):
    require(type(expected) is dict and set(expected) == set(names), "Receipt names must be exact")
    actual = {}
    for name in names:
        value = expected[name]
        require(type(value) is dict and set(value) == {"bytes", "sha256"}, "Malformed own receipt " + name)
        integer(value["bytes"], "receipt bytes")
        sha(value["sha256"], "receipt " + name)
        actual[name] = file_receipt(Path(directory)/name)
        require(exact(actual[name], value), "Own SHA/size mismatch: " + name)
    return actual


def validate_identity(metadata, expected):
    require(type(metadata) is dict and type(expected) is dict, "Independent metadata identity is required")
    require(set(IDENTITY_FIELDS) <= set(metadata) and set(IDENTITY_FIELDS) <= set(expected),
            "Complete independent profile/model/source/N/seed/calendar/method identity is required")
    n = integer(metadata["n_auv"], "n_auv", 2, 4)
    sensors = integer(metadata["n_sensors"], "n_sensors", n)
    slots = metadata["slot_owners"]
    require(type(slots) is list and slots and all(type(node) is int and 0 <= node <= n+sensors for node in slots)
            and set(slots) == set(range(n+sensors+1)), "Invalid stored native calendar")
    numeric(metadata["slot_duration"], "slot_duration", 0.)
    require(metadata["slot_duration"] > 0, "slot_duration must be positive")
    integer(metadata["seed"], "seed")
    integer(metadata["model_training_step"], "model_training_step")
    for key in ("profile", "method"):
        require(type(metadata[key]) is str and metadata[key], "Invalid " + key)
    sha(metadata["model_sha256"], "model_sha256")
    sources = metadata["source_hashes"]
    require(type(sources) is dict and sources and all(type(key) is str and key for key in sources), "Missing source identities")
    for key, digest in sources.items():
        sha(digest, "source " + key)
    for key in IDENTITY_FIELDS:
        require(exact(metadata[key], expected[key]), "Independent identity/type mismatch: " + key)


def validate_context(value, name):
    require(type(value) is dict and set(value) == {"step", "time_s"}, "Malformed capture context " + name)
    integer(value["step"], name + ".step")
    numeric(value["time_s"], name + ".time_s", 0.)


def read_rows(path, *, prefix=False):
    rows, error = [], None
    try:
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                require(line.strip(), "Empty journal row")
                rows.append(json_text(line))
    except (OSError, EOFError, UnicodeError, ValueError) as problem:
        if not prefix:
            raise SidecarAuditError("Journal gzip/JSON is not a complete valid file: " + str(problem)) from problem
        error = dict(type=type(problem).__name__, message=str(problem))
    return rows, error


def validate_rows(rows):
    counts = {stream: 0 for stream in STREAMS}
    native_times = {stream: None for stream in STREAMS}
    previous = None
    for file_index, row in enumerate(rows):
        require(type(row) is dict and row.get("format") == JOURNAL_FORMAT, "Wrong journal row format")
        require({"format", "stream", "stream_index", "recorded_at_step_end", "native_time_s", "native_time_status",
                 "cross_stream_global_order", "native_record", "file_record_index", "file_index_scope"} <= set(row),
                "Journal row must explicitly preserve every wrapper field, including null native_time_s")
        require(row.get("cross_stream_global_order") == "unknown", "Cross-stream order must remain unknown")
        require(row.get("file_index_scope") == "serialization index only; native cross-stream global order unknown",
                "File ordinal must not claim native global order")
        integer(row.get("file_record_index"), "file_record_index")
        require(row["file_record_index"] == file_index, "File serialization index gap/duplicate")
        stream = row.get("stream")
        require(stream in counts, "Unknown native stream")
        integer(row.get("stream_index"), "stream_index")
        require(row["stream_index"] == counts[stream], "Native stream index gap/duplicate: " + stream)
        counts[stream] += 1
        capture = row.get("recorded_at_step_end")
        validate_context(capture, "recorded_at_step_end")
        if previous is not None:
            require(capture["step"] >= previous["step"] and capture["time_s"] >= previous["time_s"], "Capture context moves backwards")
        previous = capture
        native = row.get("native_record")
        require(type(native) is dict, "Native record must be a dictionary")
        state = row.get("native_time_status")
        if state == "missing":
            require("time" not in native and row.get("native_time_s") is None, "Missing native time was substituted")
        elif state == "null":
            require("time" in native and native["time"] is None and row.get("native_time_s") is None, "Null native time was substituted")
        else:
            require(state == "recorded" and "time" in native, "Wrong native time status")
            value = numeric(native["time"], "native time", 0.)
            require(exact(value, row.get("native_time_s")), "Native time differs from original record or type")
            require(value <= capture["time_s"]+1e-10, "Native time lies after the external capture boundary")
            old_time = native_times[stream]
            require(old_time is None or value >= old_time, "Native time moves backwards WITHIN stream: " + stream)
            native_times[stream] = value
    return counts


def validate_summary(summary, report, metadata, rows, counts):
    require(summary.get("format") == SIDECAR_FORMAT and summary.get("status") == "completed_passive_sidecar", "Summary is not completed")
    require(report.get("status") == "completed_passive_sidecar", "External report is not completed")
    require(exact(summary.get("metadata"), metadata) and exact(report.get("metadata"), metadata), "Summary/report metadata differs from header")
    for value in (summary, report):
        for key in ("execution_observation", "root_information_source", "original_episode_files_touched", "native_ending_changed"):
            require(value.get(key) is False, "Sidecar claims native authority/mutation: " + key)
        require(value.get("cross_stream_global_order") == "unknown", "Summary/report cross-stream order claim")
        require(value.get("logging_CPU_scope") == "Caller must account separately; not method inference/step CPU", "Logging CPU scope is not separate")
        require("inference_ms" not in value and "step_ms" not in value and "metrics75" not in value, "Sidecar must not replace original metric/timing fields")
    for key, value in summary.items():
        if key == "artifacts":
            continue  # Stored summary has2; returned report additionally has its summary receipt.
        require(key in report and exact(report[key], value), "External writer report differs from stored summary: " + key)
    require(type(summary.get("writer_record_counts_by_stream")) is dict and exact(summary["writer_record_counts_by_stream"], counts), "Writer per-stream counts mismatch")
    integer(summary.get("records_written"), "records_written")
    require(summary["records_written"] == len(rows), "Total journal record count mismatch")
    final = summary.get("last_recorded_context")
    validate_context(final, "last_recorded_context")
    if rows:
        tail = rows[-1]["recorded_at_step_end"]
        require(final["step"] >= tail["step"] and final["time_s"] >= tail["time_s"], "Final capture precedes journal prefix")
    drains = integer(summary.get("drain_calls"), "drain_calls", 1)
    integer(summary.get("skipped_not_due_calls"), "skipped_not_due_calls")
    stats = summary.get("final_drain_statistics")
    require(type(stats) is dict and stats.get("cross_stream_global_order") == "unknown", "Invalid final drain statistics")
    require(type(stats.get("drain_calls")) is int and stats["drain_calls"] == drains, "Final journal/writer drain call mismatch")
    require(type(stats.get("streams")) is dict and set(stats["streams"]) == set(STREAMS), "Final native stream statistics must be complete")
    require(type(summary.get("native_next_cursors")) is dict and set(summary["native_next_cursors"]) == set(STREAMS), "Native cursor map must be complete")
    missing, available, copied = [], {}, 0
    for stream in STREAMS:
        state = stats["streams"][stream]
        require(type(state) is dict and set(state) == {"availability", "native_length", "previous_cursor", "next_cursor", "records_copied", "native_times_missing_or_null"}, "Malformed stream statistics")
        if state.get("availability") == "missing":
            missing.append(stream)
            for key in ("native_length", "previous_cursor", "next_cursor", "records_copied", "native_times_missing_or_null"):
                require(state.get(key) is None, "Missing native stream was encoded as observed zero: " + stream)
            require(summary["native_next_cursors"][stream] is None and counts[stream] == 0, "Missing stream has a cursor/row")
            available[stream] = None
            continue
        require(state.get("availability") == "available", "Unknown stream availability")
        for key in ("native_length", "previous_cursor", "next_cursor", "records_copied", "native_times_missing_or_null"):
            integer(state.get(key), stream + "." + key)
        require(state["native_length"] == state["next_cursor"] == counts[stream], "Native final length/cursor mismatch")
        require(type(summary["native_next_cursors"][stream]) is int and summary["native_next_cursors"][stream] == counts[stream], "Summary native cursor type/value mismatch")
        require(state["records_copied"] == state["next_cursor"]-state["previous_cursor"], "Final cursor delta mismatch")
        records = [r for r in rows if r["stream"] == stream]
        final_rows = records[state["previous_cursor"]:]
        require(all(exact(r["recorded_at_step_end"], final) for r in final_rows), "Final-drain records have a different capture context")
        require(sum(r["native_time_status"] != "recorded" for r in final_rows) == state["native_times_missing_or_null"], "Final native missing/null time count mismatch")
        available[stream] = counts[stream]
        copied += state["records_copied"]
    require(exact(stats.get("missing_streams"), missing), "Missing stream list differs from null cursor evidence")
    require(type(stats.get("records_copied")) is int and stats["records_copied"] == copied, "Final drain total mismatch")
    logging = numeric(report.get("logging_wall_time_s"), "logging walltime", 0.)
    before = numeric(summary.get("logging_wall_time_s_before_summary_and_receipt"), "pre-summary logging walltime", 0.)
    require(logging+1e-12 >= before, "Full logging time is smaller than its recorded prefix")
    require(report.get("logging_wall_time_includes") == "Construction, every drain, close, summary/receipt serialization/fsync/hash", "Full logging time boundary absent")
    return available


def child_calendar_slots(child, metadata):
    """Independent INTEGER calendar/half-open-window kernel, not native code."""
    require(type(child) is dict and set(child) == {"parent", "child_id", "borrower", "start_frame", "end_frame"}, "Incomplete child certificate")
    parent = child["parent"]
    require(type(parent) is dict and set(parent) == {"epoch", "lease_id", "donor", "borrower", "slot_offset", "start_frame", "end_frame", "frame_stride"}, "Incomplete parent certificate")
    integer(parent["epoch"], "parent epoch", 0, 2**64-1)
    integer(parent["lease_id"], "parent id", 1, 2**32-1)
    integer(child["child_id"], "child id", 1, 2**32-1)
    n, sensors, length = metadata["n_auv"], metadata["n_sensors"], len(metadata["slot_owners"])
    integer(parent["donor"], "donor", n+1, n+sensors)
    require(type(parent["borrower"]) is int and parent["borrower"] == 0, "Child parent is not root-held")
    integer(child["borrower"], "child borrower", n+1, n+sensors)
    offset = integer(parent["slot_offset"], "slot offset", 0, length-1)
    require(metadata["slot_owners"][offset] == parent["donor"], "Parent offset does not name its original SN owner")
    ps, pe = integer(parent["start_frame"], "parent start"), integer(parent["end_frame"], "parent end")
    cs, ce = integer(child["start_frame"], "child start"), integer(child["end_frame"], "child end")
    stride = integer(parent["frame_stride"], "stride", 2, 5)
    require(0 < pe-ps <= 30 and 0 < ce-cs <= 3 and ps <= cs < ce <= pe, "Native parent/child window bounds violated")
    frames = [frame for frame in range(cs, ce) if ps <= frame < pe and (frame-ps) % stride == 0]
    require(frames, "Child certificate has no parent-active frame")
    return [frame*length+offset for frame in frames]


def child_timeliness(rows, metadata, stream_available, *, prefix=False):
    if stream_available is not True:
        return dict(available=None if prefix else False, matched_pairs=None, rows=None,
                    reason="net.mac_events availability is unknown/missing; no observed-zero permission claim")
    events = [row for row in rows if row["stream"] == "net.mac_events"]
    promises, pairs, incomplete, slots, committed = {}, [], [], {}, set()
    for row in events:
        event = row["native_record"]
        kind = event.get("event")
        if kind not in ("child_silence_promised", "child_commit_received", "child_slot"):
            continue  # Never substitute child_requested/subcommit/hop arrival.
        child = event.get("child")
        try:
            eligible = child_calendar_slots(child, metadata)
        except SidecarAuditError as error:
            incomplete.append(dict(stream_index=row["stream_index"], event=kind, timeliness=None, reason=str(error)))
            continue
        key = json.dumps(child, sort_keys=True, separators=(",", ":"), allow_nan=False)
        if kind == "child_silence_promised":
            require(key not in promises, "Duplicate silence promise identity in one native stream")
            promises[key] = row
        elif kind == "child_slot":
            index = event.get("slot_index")
            if type(index) is not int or index not in eligible:
                incomplete.append(dict(stream_index=row["stream_index"], event=kind, timeliness=None, reason="Missing/invalid original native slot_index"))
                continue
            slots.setdefault(key, []).append(row)
        else:
            require(key not in committed, "Duplicate initial child_commit_received identity")
            committed.add(key)
            promise = promises.get(key)
            if promise is None:
                incomplete.append(dict(stream_index=row["stream_index"], event=kind, timeliness=None, reason="No earlier same-certificate native silence promise"))
                continue
            pt = promise["native_time_s"] if promise["native_time_status"] == "recorded" else None
            ct = row["native_time_s"] if row["native_time_status"] == "recorded" else None
            first_index = eligible[0]
            first_time = first_index*metadata["slot_duration"]
            timely, reason = None, None
            if pt is None or ct is None:
                reason = "Missing native promise/actual-local-commit time; capture time is not a substitute"
            elif ct < pt:
                reason = "Native local commit time precedes promise time"
            elif first_time <= pt:
                reason = "First certificate slot not strictly future at promise; original proposal slot_index unavailable"
            elif ct < first_time-1e-12:
                timely = True
            elif ct > first_time+1e-12:
                timely = False
            else:
                reason = "Boundary equality/roundoff needs the original child_slot index and within-stream order"
            pairs.append(dict(child_id=child["child_id"], borrower=child["borrower"],
                promise_native_stream_index=promise["stream_index"], commit_native_stream_index=row["stream_index"],
                promise_native_time_s=pt, actual_local_child_commit_received_time_s=ct,
                promise_original_slot_index=promise["native_record"].get("slot_index"),
                commit_original_slot_index=event.get("slot_index"),
                certificate_calendar_slot_indices=eligible, certificate_first_slot_index=first_index,
                certificate_first_slot_time_s=first_time,
                receive_delay_s=ct-pt if pt is not None and ct is not None and ct>=pt else None,
                timely_before_first_strictly_future_certificate_slot=timely, limitation=reason,
                _key=key))
    for pair in pairs:
        observed = slots.get(pair.pop("_key"), [])
        first = next((row for row in observed if row["native_record"]["slot_index"] == pair["certificate_first_slot_index"]), None)
        pair["observed_first_native_child_slot"] = None if first is None else dict(
            slot_index=first["native_record"]["slot_index"], native_time_s=first["native_time_s"], native_stream_index=first["stream_index"])
        if pair["timely_before_first_strictly_future_certificate_slot"] is None and first is not None:
            ct = pair["actual_local_child_commit_received_time_s"]
            st = first["native_time_s"] if first["native_time_status"] == "recorded" else None
            if (ct is not None and st is not None and pair["promise_native_time_s"] is not None
                    and pair["certificate_first_slot_time_s"] > pair["promise_native_time_s"]
                    and pair["commit_native_stream_index"] < first["stream_index"] and ct <= st):
                pair["timely_before_first_strictly_future_certificate_slot"] = True
                pair["limitation"] = "Boundary resolved only by actual original child_slot index plus same-native-stream append order"
    values = [pair["timely_before_first_strictly_future_certificate_slot"] for pair in pairs]
    return dict(available=True, scope="observed valid certificate promise->actual local child_commit_received pairs" + ("; failed prefix only" if prefix else ""),
                observed_valid_silence_promises=len(promises), observed_valid_initial_commits=len(committed),
                unmatched_valid_silence_promises=len(set(promises)-committed),
                matched_pairs=len(pairs), timely=sum(value is True for value in values), late=sum(value is False for value in values),
                unknown=sum(value is None for value in values), rows=pairs, incomplete_events=incomplete,
                no_actual_commit_substitution=True, cross_stream_global_order="unknown",
                denominator="matched observable pairs only; unmatched/missing/future windows are not successes or full episode denominators")


def native_semantic_ast_audit(source_root, metadata):
    """Read source as text/AST only; never import or execute scientific code."""
    if source_root is None:
        return dict(verified=None, reason="No explicit original-source text directory supplied")
    root = Path(source_root)
    names = ("v6_candidates/c03/mac.py", "v6_candidates/c02/mac.py")
    trees, hashes = {}, {}
    for name in names:
        path = root/name
        digest = file_receipt(path)["sha256"]
        key = "original/"+name
        require(metadata["source_hashes"].get(key) == digest, "Native AST source SHA differs from declared source: " + key)
        hashes[key] = digest
        trees[name] = ast.parse(path.read_text(encoding="utf-8-sig"))
    def method(tree, class_name, method_name):
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name)
        return next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == method_name)
    def expr(value):return ast.dump(ast.parse(value,mode="eval").body,include_attributes=False)
    child = method(trees[names[0]],"ChildLease","active")
    parent = method(trees[names[1]],"SlotLease","active")
    require(expr("self.start_frame <= frame < self.end_frame and self.parent.active(frame)") ==
            ast.dump(child.body[0].value,include_attributes=False), "Native child half-open active semantics changed")
    require(expr("self.start_frame <= frame < self.end_frame and (frame-self.start_frame) % self.frame_stride == 0") ==
            ast.dump(parent.body[0].value,include_attributes=False), "Native parent stride semantics changed")
    receive = method(trees[names[0]],"_PoolMixin","_receive")
    assignments = [node.lineno for node in ast.walk(receive) if isinstance(node,ast.Assign)
                   and any("_child_commits" in ast.unparse(target) for target in node.targets)]
    commits = [node.lineno for node in ast.walk(receive) if isinstance(node,ast.Call)
               and isinstance(node.func,ast.Attribute) and node.func.attr=="_mac_event"
               and node.args and "child_commit_received" in ast.unparse(node.args[0])]
    require(assignments and commits and max(assignments)<min(commits), "Actual local child installation must precede native commit event")
    transmit = method(trees[names[0]],"_PoolMixin","_transmit_slot")
    require(any(isinstance(node,ast.Assign) and ast.dump(node.value,include_attributes=False)==expr("self._slot_index-1") for node in ast.walk(transmit)), "Original slot index source changed")
    require(any(isinstance(node,ast.Call) and node.args and isinstance(node.args[0],ast.Constant)
                and node.args[0].value=="child_slot" and any(kw.arg=="slot_index" and isinstance(kw.value,ast.Name) and kw.value.id=="index" for kw in node.keywords)
                for node in ast.walk(transmit)), "Native child_slot must preserve original slot_index")
    event = method(trees[names[1]],"_MacMixin","_mac_event")
    require(any(isinstance(node,ast.Call) and any(kw.arg=="time" and ast.dump(kw.value,include_attributes=False)==expr("float(self.time)") for kw in node.keywords)
                for node in ast.walk(event)), "Native MAC event time must be local network time")
    return dict(verified=True, source_hashes=hashes, half_open_parent_child_integer_kernel=True,
                actual_local_install_before_commit_event=True, original_child_slot_index=True,
                native_MAC_time_is_network_local=True, code_imported_or_executed=False)


def audit_sidecar(directory, expected_identity, episode_report, *, original_receipts=None, source_root=None):
    directory = Path(directory).resolve()
    require(type(episode_report) is dict, "External episode writer report required")
    failed = (directory/"FAILED.json").exists() or episode_report.get("observer_status") != "completed"
    header = read_json(directory/"header.json") if (directory/"header.json").is_file() else None
    if header is None:
        require(failed, "Completed sidecar is missing header")
        return dict(status="failed_prefix_preserved", success=False, four_own_receipts_verified=None,
                    native_stream_availability=None, child_timeliness=None, logging_failure=episode_report.get("logging_error"),
                    reason="No readable sidecar header; no success or observed-zero claim", original75_recomputed=False)
    require(header.get("format") == SIDECAR_FORMAT, "Wrong sidecar header format")
    require(header.get("execution_observation") is False and header.get("root_information_source") is False,
            "Passive header must not claim native execution/information authority")
    require(header.get("cross_stream_global_order") == "unknown", "Header cross-stream order must remain unknown")
    require(header.get("logging_CPU_scope") == "Separately metered observer/I/O walltime; not method inference/step CPU", "Header logging CPU is not separate")
    require(numeric(header.get("drain_period_s"),"header drain_period_s",0.)>0,"Header drain interval must be positive")
    validate_identity(header.get("metadata"), expected_identity)
    metadata = header["metadata"]
    require(type(header.get("original_three_file_directory")) is str and header["original_three_file_directory"], "Original directory identity missing")
    original = Path(header["original_three_file_directory"]).resolve()
    require(not directory.is_relative_to(original) and not original.is_relative_to(directory), "Sidecar/original directory overlap")
    require(type(episode_report.get("seed")) is int and episode_report["seed"] == metadata["seed"], "External seed identity mismatch")
    require(Path(episode_report.get("sidecar_directory", "")).resolve() == directory, "External sidecar path mismatch")
    event_path = directory/FILES[1]
    rows, prefix_error = read_rows(event_path,prefix=failed) if event_path.is_file() else ([],dict(type="missing",message="No event prefix"))
    counts = validate_rows(rows)
    if failed:
        return dict(status="failed_prefix_preserved", success=False, four_own_receipts_verified=None,
                    serialized_prefix_records=len(rows), prefix_stream_counts=counts, prefix_parse_error=prefix_error,
                    native_stream_availability=None, drain_index_continuity=None, drain_index_limitation=UNAVAILABLE_DRAIN,
                    child_timeliness=child_timeliness(rows,metadata,None,prefix=True),
                    logging_failure=episode_report.get("logging_error"), original75_recomputed=False,
                    original_three_file_receipts_verified=None,
                    reason="Logging failure/FAILED prefix is not complete episode success; absence of a stream is unknown")
    require({path.name for path in directory.iterdir()} == set(FILES), "Completed sidecar must have exactly its four own artifacts")
    report = episode_report.get("logging_report")
    require(type(report) is dict, "Completed sidecar requires external logging_report")
    receipts = verify_receipts(directory,report.get("strict_receipts"),FILES)
    receipt = read_json(directory/FILES[3])
    require(receipt.get("format") == SIDECAR_FORMAT and receipt.get("status") == "complete_sidecar_receipt", "Receipt is not completed")
    require(receipt.get("receipt_self_hash") == "Returned externally, not a recursive self-digest", "Receipt self-hash contract changed")
    verify_receipts(directory,receipt.get("artifacts"),FILES[:3])
    summary = read_json(directory/FILES[2])
    verify_receipts(directory,summary.get("artifacts"),FILES[:2])
    require(exact(report.get("artifacts"),receipt["artifacts"]), "Returned report artifacts differ from the three-file sidecar receipt")
    require(exact(summary.get("drain_period_s"),header["drain_period_s"]),"Header/summary drain interval mismatch")
    require(exact(report.get("original_episode_files_directory"),header["original_three_file_directory"]), "Original directory report mismatch")
    require(Path(report.get("sidecar_directory", "")).resolve() == directory, "Writer report path mismatch")
    observed = validate_summary(summary,report,metadata,rows,counts)
    validate_context(episode_report.get("last_completed_native_context"), "external final context")
    require(exact(episode_report["last_completed_native_context"],summary["last_recorded_context"]), "External/native final context mismatch")
    outer_cpu = numeric(episode_report.get("logging_wall_time_s"),"external logging time",0.)
    require(outer_cpu+1e-12 >= report["logging_wall_time_s"], "External logger time excludes part of writer cost")
    original_verified = None
    if original_receipts is not None:
        verify_receipts(original,original_receipts,("episode.json","trace.jsonl.gz","network_evidence.json.gz"))
        original_verified = True
    native_available = observed["net.mac_events"] is not None
    return dict(status="verified_completed_passive_sidecar", success=True, identity_verified=True,
                four_own_receipts_verified=True, actual_four_receipts=receipts,
                file_serialization_indices_contiguous=True, each_native_stream_indices_contiguous=True,
                drain_index_continuity=None, drain_index_limitation=UNAVAILABLE_DRAIN,
                native_stream_observed_counts=observed, serialization_counts=counts,
                native_times_preserved_separately_from_capture=True, cross_stream_global_order="unknown",
                logging_CPU_separate_fields_verified=True, logging_wall_time_s=report["logging_wall_time_s"],
                original_three_file_receipts_verified=original_verified, original75_recomputed=False,
                child_timeliness=child_timeliness(rows,metadata,native_available),
                native_semantic_AST=native_semantic_ast_audit(source_root,metadata),
                limits=["Own receipts require the independently supplied external four-receipt report",
                        "No original75 metric/cause/performance recomputation; original three-file integrity is optional explicit receipts only",
                        "Same-native-stream append order is available; cross-stream native order remains unknown",
                        "Native promise/commit events usually omit original slot_index; certificate slots are derived, actual child_slot indices remain separately labelled",
                        "Missing metadata/times/permission events are never filled from capture time, scheduler request, hop delivery or SUBCOMMIT generation"])


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sidecar",required=True)
    parser.add_argument("--episode-report",required=True,help="Standalone episode-report JSON or passive aggregate complete/FAILED JSON")
    parser.add_argument("--expected-identity",required=True)
    parser.add_argument("--original-receipts")
    parser.add_argument("--source-root",help="Original source text directory for matched-SHA AST checks only")
    args=parser.parse_args(argv)
    expected=read_json(args.expected_identity)
    external=read_json(args.episode_report)
    aggregate=None
    if external.get("format") == AGGREGATE_FORMAT:
        aggregate=external
        for key in ("original_three_files_per_episode_unchanged","metrics75_unchanged"):
            require(external.get(key) is True,"Aggregate original contract flag missing: "+key)
        require(external.get("native_ending_changed") is False and external.get("physics_replayed") is False
                and type(external.get("learning_steps")) is int and external["learning_steps"]==0,"Aggregate claims native changes/learning")
        require(external.get("cross_stream_global_order")=="unknown","Aggregate claims global native order")
        require(external.get("logging_CPU_scope")=="External journal construction/drain/finalize/abort only; excluded from original inference_ms/step_ms",
                "Aggregate logging CPU scope is not separate")
        episodes=external.get("episode_reports")
        require(type(episodes) is list and all(type(row) is dict for row in episodes),"Aggregate episode reports must be a list of dictionaries")
        seeds=[integer(row.get("seed"),"aggregate seed") for row in episodes]
        require(len(set(seeds))==len(seeds),"Duplicate aggregate episode seeds")
        logging_sum=sum(numeric(row.get("logging_wall_time_s"),"episode logging walltime",0.) for row in episodes)
        require(exact(numeric(external.get("logging_wall_time_s"),"aggregate logging walltime",0.),logging_sum),
                "Aggregate logging walltime is not the separately summed episode cost")
        candidates=[row for row in external.get("episode_reports",[]) if type(row) is dict
                    and type(row.get("seed")) is int and row["seed"]==expected["seed"]]
        require(len(candidates)==1,"Exactly one aggregate episode report must match independent seed")
        external=candidates[0]
    result=audit_sidecar(args.sidecar,expected,external,
        original_receipts=read_json(args.original_receipts) if args.original_receipts else None,source_root=args.source_root)
    if aggregate is not None:
        result["original_evaluation_status"]=aggregate.get("original_evaluation_status")
        result["aggregate_observer_status"]=aggregate.get("observer_status")
        result["aggregate_evaluation_success_claimed"]=False
        if aggregate.get("original_evaluation_status")!="completed" or aggregate.get("observer_status")!="completed":
            result["selected_sidecar_integrity_success"]=result["success"]
            result["success"]=False
            result["status"]="selected_sidecar_checked_in_failed_or_incomplete_aggregate"
    print(json.dumps(result,ensure_ascii=False,sort_keys=True,allow_nan=False))
    return 0 if result["success"] else 1


if __name__=="__main__":
    try:
        raise SystemExit(main())
    except (SidecarAuditError,OSError,ValueError,KeyError,TypeError) as error:
        print(json.dumps(dict(status="audit_failed",success=False,error_type=type(error).__name__,error=str(error)),ensure_ascii=False))
        raise SystemExit(2)
