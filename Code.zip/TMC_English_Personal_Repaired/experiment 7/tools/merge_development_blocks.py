"""Read-only10+20 development merge, pinned record arithmetic, stdout only.

No torch, environment, optimizer, gate opening or simulation is imported or
invoked. Original complete/episode/trace/network files remain unchanged. This
verifies file receipts, reconstructs unique DATA from receiver events, audits
recorded trace clocks/substep exposure and recomputes the original75 scalar
getters from saved observer inputs. It does not independently regenerate all
observer physics or replay a simulator, nor is it untouched confirmation.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter, defaultdict
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import sys

ARMS = frozenset(((2,"full_v6"),(3,"full_v6"),(4,"full_v6"),(3,"usde_only_v6"),(4,"usde_only_v6")))
METHODS = {"full":"full_v6","full_v6":"full_v6","usde":"usde_only_v6",
           "usde_only":"usde_only_v6","usde_only_v6":"usde_only_v6"}
ALL_SEEDS = tuple(range(10712000,10712030))
BLOCKS = (tuple(range(10712000,10712010)),tuple(range(10712010,10712030)))
FILES = ("episode.json","trace.jsonl.gz","network_evidence.json.gz")
EVENTS = ("hop_events","emissions","generation_events","delivery_events","protocol_events","queue_events")
SCALE_FIELDS = frozenset(("n_auv","declared_packet_bits","deployment_layout",
    "coordination_service_interval","service_ack_timeout","grant_ttl"))
PURE_IMPORTS = frozenset(("__future__","argparse","ast","collections","csv","gzip","hashlib",
    "json","math","pathlib","random","statistics","sys"))


def require(condition,message):
    if not condition: raise ValueError(message)


def digest(path):
    result=hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda:stream.read(1024*1024),b""): result.update(block)
    return result.hexdigest()


def reject_constant(value):
    raise ValueError("Nonfinite JSON constant:"+value)


def pairs(values):
    result={}
    for key,value in values:
        require(key not in result,"Duplicate JSON field:"+key)
        result[key]=value
    return result


def read_json(path):
    value=json.loads(Path(path).read_text(encoding="utf-8-sig"),parse_constant=reject_constant,object_pairs_hook=pairs)
    require(isinstance(value,dict),"Expected JSON object:"+str(path))
    return value


def sha(value,label):
    require(isinstance(value,str) and len(value)==64 and all(char in "0123456789abcdefABCDEF" for char in value),
            "Invalid SHA256:"+label)
    return value.lower()


def method(value):
    require(isinstance(value,str) and value in METHODS,"Unknown primary method identity")
    return METHODS[value]


def number(value,label):
    require(type(value) in (int,float) and math.isfinite(value),"Nonfinite/nonnumeric "+label)
    return float(value)


def stats(values):
    known=[number(value,"secondary metric") for value in values if value is not None]
    return dict(n_available=len(known),n_missing=len(values)-len(known),sum=sum(known) if known else None,
        mean=statistics.fmean(known) if known else None,
        standard_deviation=statistics.stdev(known) if len(known)>1 else None)


def pooled(values):
    known=[(number(a,"numerator"),number(b,"denominator")) for a,b in values if a is not None and b is not None]
    num=sum(a for a,_ in known) if known else None
    den=sum(b for _,b in known) if known else None
    return dict(n_available=len(known),n_missing=len(values)-len(known),numerator=num,denominator=den,
                ratio=num/den if den is not None and den>0 else None)


def _module(path,label):
    # Hash pin is mandatory first. This import guard also prevents accidentally
    # wiring the simulator/learner modules into this record-only tool.
    tree=ast.parse(path.read_text(encoding="utf-8-sig"))
    for node in ast.walk(tree):
        if isinstance(node,ast.Import): names=[item.name for item in node.names]
        elif isinstance(node,ast.ImportFrom):
            require(node.level==0,"Relative import forbidden in record-only arithmetic")
            names=[node.module or ""]
        else: continue
        require(all(name.split(".")[0] in PURE_IMPORTS for name in names),"Non-record import in pinned module:"+label)
    spec=importlib.util.spec_from_file_location("pinned_development_"+label,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _snapshot(code,expected_inventory_sha):
    inventory_path=code/"PACKAGE_MANIFEST.json"
    require(digest(inventory_path)==sha(expected_inventory_sha,"inventory pin"),"Snapshot inventory SHA is not its predeclared pin")
    inventory=read_json(inventory_path)
    require(inventory.get("code_only") is True and isinstance(inventory.get("files"),dict),"Missing complete code inventory")
    files=inventory["files"]
    actual={path.relative_to(code).as_posix() for path in code.rglob("*") if path.is_file()}
    require(actual==set(files)|{"PACKAGE_MANIFEST.json"},"Frozen snapshot file membership differs")
    observed={str(inventory_path):digest(inventory_path)}
    for name,identity in files.items():
        require(isinstance(name,str) and not Path(name).is_absolute(),"Invalid inventory relative name")
        path=(code/name).resolve(strict=True)
        require(path.is_relative_to(code) and path.is_file(),"Inventory path escapes frozen code")
        value=digest(path)
        require(value==sha(identity.get("sha256"),name),"Frozen codefile SHA mismatch:"+name)
        if "bytes" in identity: require(path.stat().st_size==identity["bytes"],"Frozen codefile size mismatch:"+name)
        observed[str(path)]=value
    sources=inventory.get("source_hashes")
    require(isinstance(sources,dict) and sources,"Missing native/adapter/reference source inventory")
    reference={"reference/config":"reference/provenance/frozen_config.json",
        "reference/full":"reference/models/45w/full_v6/metadata.json",
        "reference/usde_only":"reference/models/45w/usde_only_v6/metadata.json"}
    for key,identity in sources.items():
        if key.startswith("original/"): name="c07_source/"+key.removeprefix("original/")
        elif key.startswith("adapter/"): name="exp7_c07_scaling_20261012/"+key.removeprefix("adapter/")
        elif key.startswith("measurement/"): name="c07_source/scripts/"+key.removeprefix("measurement/")
        else:
            require(key in reference,"Unknown source namespace:"+key)
            name=reference[key]
        require(name in files and files[name]["sha256"]==identity,"Recorded native/source file absent or inconsistent:"+key)
    metrics_path=code/"exp7_c07_scaling_20261012"/"metrics.py"
    specs_path=code/"c07_source"/"scripts"/"summarize_tmc_retest.py"
    gate_path=code/"exp7_c07_scaling_20261012"/"evaluation_gate.py"
    require(all(str(path) in observed for path in (metrics_path,specs_path,gate_path)),"Metrics/gate/original75 schema must be pinned")
    return inventory,sources,observed,metrics_path,specs_path


def _registry(path,sources):
    raw=read_json(path)
    registry=raw.get("recommended_contract",raw)
    if "recommended_contract" in raw:
        require(raw.get("status")=="freeze_proposal_only_no_holdout_opened" and raw.get("no_holdout_seeds_opened") is True,
                "Model registry proposal is not a verified unopened freeze")
    require(registry.get("training_step")==100000 and type(registry.get("training_step")) is int and
        registry.get("training_seed")==7 and registry.get("source_hashes")==sources and
        registry.get("primary")=="collected_packets" and registry.get("fault_profile")=="reference",
        "Registry must bind exact100k/seed7/reference/packet endpoint and complete source inventory")
    profile=registry.get("profile")
    require(isinstance(profile,str) and profile,"Missing registry profile")
    entries=registry.get("models")
    require(isinstance(entries,list) and len(entries)==5,"Registry needs exactly five final model arms")
    models={}
    for item in entries:
        require(isinstance(item,dict) and type(item.get("n_auv")) is int,"Malformed registry arm")
        arm=item["n_auv"],method(item.get("method"))
        require(arm in ARMS and arm not in models,"Duplicate or unexpected registry arm")
        cfg=item.get("environment_config")
        require(isinstance(cfg,dict) and cfg.get("n_auv")==arm[0] and cfg.get("n_sensors")==30 and
            cfg.get("seed")==7 and cfg.get("episode_steps")==1200 and
            item.get("profile")==profile and item.get("training_step")==100000 and item.get("seed")==7,
            "Registry model config/profile/budget/scale mismatch")
        models[arm]=dict(item,policy_sha=sha(item.get("policy_sha"),"model policy"))
    require(set(models)==ARMS and len({item["policy_sha"] for item in models.values()})==5,"Registry is incomplete or duplicates policies")
    scopes=[{key:value for key,value in item["environment_config"].items() if key not in SCALE_FIELDS} for item in models.values()]
    require(all(value==scopes[0] for value in scopes),"Registry physical/learning scopes differ")
    for n in (3,4):
        require(models[n,"full_v6"]["environment_config"]==models[n,"usde_only_v6"]["environment_config"],
                "Registry same-scale full/USDE config differs")
    return profile,models


def _same_number(left,right):
    if left is None or right is None: return left is None and right is None
    if type(left) is bool or type(right) is bool: return left is right
    return math.isclose(number(left,"metric75"),number(right,"metric75"),rel_tol=1e-10,abs_tol=1e-10)


def _count(value,label,maximum=None):
    require(type(value) is int and value>=0 and (maximum is None or value<=maximum),"Invalid integer count:"+label)
    return value


def _data_events(record,evidence,cfg):
    """Native sensor source IDs start at n+1; final delivery receiver is an AUV."""
    n=record["n_auv"]
    claimed=record.get("unique_data_keys")
    require(isinstance(claimed,list),"Missing claimed unique DATA keys")
    keys=[]
    for key in claimed:
        require(isinstance(key,list) and len(key)==2,"Malformed claimed unique DATA key")
        keys.append((_count(key[0],"sensor",29),_count(key[1],"sequence")))
    require(len(keys)==len(set(keys)),"Duplicate claimed unique DATA key")
    sets={}
    for name in ("generation_events","emissions","delivery_events"):
        events=evidence.get(name)
        require(isinstance(events,list),"Missing original DATA event stream:"+name)
        union=set()
        for event in events:
            require(isinstance(event,dict) and isinstance(event.get("packet"),dict),"Malformed packet event")
            packet=event["packet"]
            if packet.get("kind")!="DATA": continue
            logical=packet.get("logical_key")
            require(isinstance(logical,(list,tuple)) and len(logical)==2,"DATA logical identity unavailable")
            source=_count(logical[0],"logical DATA source")
            sensor=source-n-1
            require(0<=sensor<30 and _count(packet.get("src"),"DATA source")==source,
                    "DATA source outside declared Sensor Nodes")
            if name=="delivery_events":
                receiver=_count(event.get("receiver"),"successful DATA receiver")
                require(1<=receiver<=n,"Successful DATA final receiver is not an AUV")
            union.add((sensor,_count(logical[1],"DATA sequence")))
        sets[name]=union
    received=sets["delivery_events"]
    require(received==set(keys),"Independent successful DATA delivery events disagree with claimed unique_data_keys")
    require(received<=sets["generation_events"] and received<=sets["emissions"],
            "Successful DATA lacks original generation/TX evidence")
    require(len(received)==_count(record.get("collected_packets"),"unique packets"),"Independent unique packet total differs")
    require(number(record.get("metrics_base",{}).get("collected_bits"),"collected bits")==
            len(received)*number(cfg.get("data_packet_bits"),"DATA payload bits"),"DATA event union / collected payload bits differs")
    return dict(unique_successful_DATA=len(received),unique_generated_network_DATA=len(sets["generation_events"]),
        unique_transmitted_DATA=len(sets["emissions"]),source_mapping="zero_based_sensor=logical_source-n_auv-1",
        duplicate_successful_receipts_not_double_counted=True,
        limitation="Network-packet generation, not original SN data-birth generation; no stochastic PHY replay")


def _trace_evidence(path,record,cfg):
    n=record["n_auv"]
    dt=number(cfg.get("dt"),"dt")
    substeps=_count(cfg.get("substeps"),"substeps")
    require(dt>0 and substeps>0,"Trace sampling requires positive native dt/substeps")
    h=dt/substeps
    physical=collisions=boundaries=0
    first=last=None
    minimum=math.inf
    maximum=0.
    aoi=usable=0.
    final=None
    with gzip.open(path,"rt",encoding="utf-8-sig") as stream:
        for index,line in enumerate(stream,1):
            fast=json.loads(line,parse_constant=reject_constant,object_pairs_hook=pairs)
            require(index<=record["steps"] and type(fast.get("step")) is int and fast["step"]==index and
                    fast.get("seed")==record["seed"],"Trace step count/sequence/seed mismatch")
            require(math.isclose(number(fast.get("time"),"fast time"),index*dt,rel_tol=0,abs_tol=1e-7),"Trace fast clock mismatch")
            require(type(fast.get("terminated")) is bool and type(fast.get("truncated")) is bool,
                    "Trace lacks explicit ending flags")
            if index<record["steps"]: require(not fast["terminated"] and not fast["truncated"],"Trace continues after absorbing ending")
            ages=fast.get("passive_environment",{}).get("state_aoi_s")
            installed=fast.get("installed_usable")
            require(isinstance(ages,list) and len(ages)==n and isinstance(installed,list) and len(installed)==n and
                    all(type(value) is bool for value in installed),"Trace AUV STATE/path dimensions mismatch")
            aoi+=sum(number(age,"STATE age") for age in ages)*dt
            usable+=sum(installed)*dt
            samples=fast.get("physical_substeps")
            require(isinstance(samples,list) and len(samples)==substeps,"Trace physical substep count mismatch")
            for slot,sample in enumerate(samples,1):
                time=number(sample.get("time_s"),"physical time")
                require(math.isclose(time,((index-1)*substeps+slot)*h,rel_tol=0,abs_tol=1e-7),"Trace physical substep clock mismatch")
                if first is None: first=time
                last=time
                physical+=1
                collisions+=_count(sample.get("collision_pairs"),"collision pairs",n*(n-1)//2)
                boundaries+=_count(sample.get("boundary_auvs"),"boundary AUVs",n)
                separation=number(sample.get("minimum_separation_m"),"minimum separation")
                excursion=number(sample.get("maximum_excursion_m"),"maximum excursion")
                require(separation>=0 and excursion>=0,"Negative physical distance/excursion")
                minimum=min(minimum,separation); maximum=max(maximum,excursion)
            final=fast
    require(final is not None and final["step"]==record["steps"],"Trace row count differs from actual episode steps")
    require(final["terminated"]==record["terminated"] and final["truncated"]==record["truncated"] and
            final.get("metrics")==record.get("metrics_base"),"Final trace flags/counters differ from episode")
    safety=record.get("safety",{})
    require(physical==record["steps"]*substeps==safety.get("physical_substeps"),"Safety physical sample count differs")
    for actual,saved,label in ((first,h,"first physical time"),(last,record["duration_s"],"last physical time"),
        (collisions*h,safety.get("collision_pair_s"),"collision pair exposure"),
        (boundaries*h,safety.get("boundary_auv_s"),"boundary AUV exposure"),
        (record["duration_s"]*n*(n-1)/2,safety.get("observation_pair_s"),"observed pair seconds"),
        (record["duration_s"]*n,safety.get("observation_auv_s"),"observed AUV seconds"),
        (minimum,safety.get("minimum_separation_m"),"minimum physical separation"),
        (maximum,safety.get("maximum_excursion_m"),"maximum physical excursion"),
        (aoi,record.get("aoi_sum_s"),"STATE age integral"),(usable,record.get("connectivity_usable_auv_seconds"),"usable path seconds"),
        (record["duration_s"]*n,record.get("aoi_auv_seconds"),"STATE exposure denominator"),
        (record["duration_s"]*n,record.get("connectivity_observation_auv_seconds"),"path exposure denominator")):
        require(math.isclose(number(actual,label),number(saved,label),rel_tol=1e-9,abs_tol=1e-7),"Independent trace mismatch:"+label)
    require(safety.get("had_collision") is (collisions>0) and safety.get("had_boundary") is (boundaries>0) and
            safety.get("had_any_violation") is (collisions>0 or boundaries>0),"Safety episode flags differ from trace samples")
    return dict(fast_steps=record["steps"],physical_substeps=physical,first_physical_time_s=first,last_physical_time_s=last,
        collision_pair_s=collisions*h,boundary_auv_s=boundaries*h,STATE_age_integral=aoi,usable_path_auv_s=usable,
        limitation="Independent arithmetic on recorded substep endpoints/STATE/path observations, not reintegration of dynamics or navigation observer regeneration")


def _block(path,profile,models,specs,metrics,observed,sources):
    complete_path=path/"complete.json"
    complete=read_json(complete_path)
    require("source_hashes" not in complete or complete["source_hashes"]==sources,"Complete block source identities differ")
    require(complete.get("status")=="completed" and complete.get("learning_steps")==0 and
            complete.get("all_failures_retained") is True,"Only complete zero-learning failure-retaining blocks can merge")
    seeds=complete.get("seeds")
    require(isinstance(seeds,list) and tuple(seeds) in BLOCKS,"Merge only the preregistered first10 and next20 development blocks")
    rows=complete.get("rows")
    require(isinstance(rows,list) and [row.get("seed") for row in rows]==seeds,"Complete block seed/row order differs")
    phase=complete.get("evaluation_phase")
    require(isinstance(phase,dict) and phase.get("phase")=="development" and phase.get("seeds")==seeds and
            phase.get("primary")=="collected_packets" and phase.get("evaluation_fault")=="reference" and
            phase.get("confirmation_index") is None and phase.get("validation_contract_sha256") is None and
            phase.get("family_alpha") is None and phase.get("holdout_opened") is False,
            "Development merge cannot borrow holdout/missing/wrong phase metadata")
    require("source_hashes" not in phase or phase["source_hashes"]==sources,"Phase source identities differ")
    observed[str(complete_path)]=digest(complete_path)
    progress_path=path/"progress.jsonl"
    observed[str(progress_path)]=digest(progress_path)
    receipts={}
    with progress_path.open("r",encoding="utf-8-sig") as stream:
        for index,line in enumerate(stream,1):
            receipt=json.loads(line,parse_constant=reject_constant,object_pairs_hook=pairs)
            seed=receipt.get("seed")
            require(index<=len(seeds) and seed not in receipts and seed==seeds[index-1] and receipt.get("completed")==index,
                    "Duplicate/nonconsecutive evidence receipt")
            receipts[seed]=receipt.get("files")
    require(set(receipts)==set(seeds),"Evidence receipts missing a declared seed")
    arms=set()
    verified_files=[]
    independent_episodes=[]
    expected_keys={key for key,_,_,_,_ in specs}
    for row in rows:
        require("source_hashes" not in row or row["source_hashes"]==sources,"Row source identities differ")
        arm=row.get("n_auv"),method(row.get("method"))
        require(arm in models,"Unexpected evaluation model arm")
        arms.add(arm)
        model=models[arm]
        require(row.get("profile")==profile and row.get("model_training_step")==100000 and row.get("n_sensors")==30 and
            row.get("evaluation_fault")=="reference" and row.get("evaluation_faults")==[] and
            row.get("ending_policy")=="original_absorbing_safety" and
            row.get("model_sha256")==model["policy_sha"]==complete.get("model_sha256")==phase.get("checkpoint_sha256") and
            phase.get("model_training_step")==100000,
            "Evaluation source model/profile/endpoint/SN/fault/ending differs from fixed registry")
        require(type(row.get("terminated")) is bool and type(row.get("truncated")) is bool,
                "Native ending flags must be explicit")
        require(not(row["terminated"] and row["truncated"]) and
            row.get("termination_reason") in ("collision","boundary","time_limit"),"Unknown or contradictory native ending")
        require(row["terminated"]==(row["termination_reason"] in ("collision","boundary")) and
            row["truncated"]==(row["termination_reason"]=="time_limit") and
            type(row.get("steps")) is int and 1<=row["steps"]<=1200 and
            math.isclose(number(row.get("duration_s"),"duration"),row["steps"]*model["environment_config"].get("dt",1),
                         rel_tol=0,abs_tol=1e-7),"Native ending/time/actual step exposure differs")
        require(row["termination_reason"]!="time_limit" or row["steps"]==1200,"A native time_limit must reach exactly1200steps")
        seed=row["seed"]
        folder=path/f"seed_{seed}"
        identities=receipts[seed]
        require(isinstance(identities,dict) and set(identities)==set(FILES),"Each declared episode needs exactly three original file receipts")
        for name in FILES:
            evidence_path=folder/name
            identity=identities[name]
            current=digest(evidence_path)
            require(isinstance(identity,dict) and current==sha(identity.get("sha256"),name) and
                    evidence_path.stat().st_size==identity.get("bytes"),"Evidence SHA/size receipt mismatch:"+str(evidence_path))
            observed[str(evidence_path)]=current
            verified_files.append(dict(seed=seed,path=str(evidence_path),sha256=current,bytes=evidence_path.stat().st_size))
        require(read_json(folder/"episode.json")==row,"complete.row differs from original persisted episode")
        with gzip.open(folder/"network_evidence.json.gz","rt",encoding="utf-8") as stream:
            evidence=json.load(stream,parse_constant=reject_constant,object_pairs_hook=pairs)
        projection={key:value for key,value in evidence.items() if key not in EVENTS}
        require(row.get("network_summary")==projection and row.get("network")==projection,"Episode network projection differs from original evidence")
        data_events=_data_events(row,evidence,model["environment_config"])
        trace_evidence=_trace_evidence(folder/"trace.jsonl.gz",row,model["environment_config"])
        audited=metrics.audit_unique_data(row.get("unique_data_keys",[]),30,expected_packets=row.get("collected_packets"))
        require(audited["per_sensor_packets"]==row.get("per_sensor_packets") and
                audited["distinct_sensors"]==row.get("distinct_sensors"),"Unique DATA keys/packet-depth/coverage mismatch")
        require(evidence.get("logical",{}).get("DATA",{}).get("delivered_unique")==audited["collected_packets"],
                "Unique DATA network counter differs")
        values=row.get("metrics75")
        require(isinstance(values,dict) and len(values)==75 and set(values)==expected_keys,"Original75 metric schema incomplete or changed")
        for key,_,unit,_,getter in specs:
            require(isinstance(values[key],dict) and values[key].get("unit")==unit and
                    _same_number(values[key].get("value"),getter(row)),"Original75 metric failed record-only recomputation:"+key)
        independent_episodes.append(dict(seed=seed,DATA_event_reconstruction=data_events,trace_arithmetic=trace_evidence))
    require(len(arms)==1,"One evaluation block must describe one immutable model arm")
    return next(iter(arms)),seeds,rows,dict(path=str(path),complete_sha256=observed[str(complete_path)],
        progress_sha256=observed[str(progress_path)],seeds=seeds,original_evidence_files=verified_files,
        independent_event_and_trace_checks=independent_episodes)


def secondary(rows):
    duration=sum(row["duration_s"] for row in rows)
    total_steps=sum(row["steps"] for row in rows)
    timing={}
    for prefix in ("inference","step"):
        means=[row.get("timing",{}).get(prefix+"_mean_ms") for row in rows]
        p95=[row.get("timing",{}).get(prefix+"_p95_ms") for row in rows]
        timing[prefix]=dict(episode_mean_ms=stats(means),episode_p95_ms=stats(p95),
            step_weighted_mean_ms=pooled([(mean*row["steps"],row["steps"]) if mean is not None else (None,None)
                                         for mean,row in zip(means,rows)]),
            global_step_p95_ms=None, note="Average episode p95 is not the global step p95; per-step timing samples were not preserved")
    kinds=sorted({kind for row in rows for kind in row["network_summary"].get("by_kind",{})})
    packet_kinds={}
    for kind in kinds:
        entries=[row["network_summary"].get("by_kind",{}).get(kind,{}) for row in rows]
        counters={name:stats([entry.get(name) for entry in entries]) for name in
            ("generated_packets","generated_frame_bits","transmissions","transmitted_frame_bits",
             "serialized_bits_within_horizon","airtime_s","reserved_slot_time_s")}
        queues=Counter()
        for entry in entries: queues.update(entry.get("queue_events",{}))
        counters["queue_event_totals"]=dict(queues)
        counters["queue_events_observed_episodes"]=sum("queue_events" in entry for entry in entries)
        packet_kinds[kind]=counters
    return dict(episodes=len(rows),duration_s_sum=duration,steps_sum=total_steps,
        termination_reasons=dict(Counter(row["termination_reason"] for row in rows)),
        zero_packet_episodes=sum(row["collected_packets"]==0 for row in rows),timing=timing,
        root_view_route_changes=stats([row.get("root_view_route_changes") for row in rows]),
        topology_requests=stats([row.get("topology_requests") for row in rows]),
        config_successes=stats([row.get("metrics_base",{}).get("network_config_successes") for row in rows]),
        config_timeouts=stats([row.get("metrics_base",{}).get("network_config_timeouts") for row in rows]),
        packet_kind_totals=packet_kinds,
        raw_75_episode_values=[dict(seed=row["seed"],metrics75=row["metrics75"]) for row in rows],
        missing_telemetry=["Per-step CPU timing for global p95","Per-certificate paid child/parent schedule details",
                           "Per-SN basic/donor/child service opportunity attribution"],
        interpretation="Secondary differences describe real exposure and cost; not additional independent primary wins")


def merge(paths,snapshot,inventory_sha,model_registry):
    code=Path(snapshot).resolve(strict=True)
    inventory,sources,observed,metrics_path,specs_path=_snapshot(code,inventory_sha)
    registry_path=Path(model_registry).resolve(strict=True)
    profile,models=_registry(registry_path,sources)
    observed[str(registry_path)]=digest(registry_path)
    metrics,schema=_module(metrics_path,"metrics"),_module(specs_path,"specs")
    specs=schema.selected_specs()
    require(len(specs)==75,"Pinned original75 schema itself changed")
    paths=[Path(path).resolve(strict=True) for path in paths]
    require(len(paths)==10 and len(set(paths))==10,"Need exactly10 distinct completed block directories, five arms each10+20")
    groups=defaultdict(list)
    blocks=defaultdict(set)
    provenance=[]
    for path in paths:
        arm,seeds,rows,evidence=_block(path,profile,models,specs,metrics,observed,sources)
        require(tuple(seeds) not in blocks[arm],"Duplicate model development block/seed")
        blocks[arm].add(tuple(seeds)); groups[arm].extend(rows); provenance.append(dict(arm=list(arm),**evidence))
    require(set(groups)==ARMS and all(blocks[arm]==set(BLOCKS) for arm in ARMS),"Incomplete exact five-arm development matrix")
    ordered=[]
    for arm in sorted(ARMS):
        rows=sorted(groups[arm],key=lambda row:row["seed"])
        require([row["seed"] for row in rows]==list(ALL_SEEDS),"Every primary arm must have all30 unique development seeds")
        groups[arm]=rows; ordered.extend(rows)
    summaries=metrics.summarize_groups(ordered)
    contrasts=metrics.paired_contrasts(ordered,metrics=("collected_packets",),family_alpha=.05,repetitions=10000)
    contrasts["interpretation"]="30-seed exploratory development after candidate iteration; not untouched validation or training-seed robustness"
    require(all(digest(path)==before for path,before in observed.items()),"Original evidence/code changed during read-only merge")
    return dict(status="analysis_completed_from_declared_development_blocks",profile=profile,
        evaluation_scope=dict(phase="development",seeds=list(ALL_SEEDS),training_step=100000,n_sensors=30,
            evaluation_fault="reference",primary="collected_packets",original_ending="absorbing_safety",
            all_failures_retained=True,holdout_opened=False),groups=summaries,paired=contrasts,
        secondary={f"auv{n}/{name}":secondary(rows) for (n,name),rows in sorted(groups.items())},
        provenance=dict(model_registry={"path":str(registry_path),"sha256":observed[str(registry_path)]},
            inventory_sha256=sha(inventory_sha,"inventory pin"),whole_snapshot_files=len(inventory["files"]),
            source_files=len(sources),pinned_record_metrics_sha256=observed[str(metrics_path)],
            pinned_original75_schema_sha256=observed[str(specs_path)],original_blocks=provenance,
            original_evidence_file_receipts=450,all_inputs_unchanged=True),
        no_file_writes=True,no_simulation_or_learning=True,
        audit_scope=dict(unique_packets="Independent union of successful DATA AUV delivery events, backed by generated/TX identities",
            trace="Independent fast clock/row count/substep endpoints/STATE AoI/path/safety exposure arithmetic",
            original75="Getter recomputation from saved observer inputs; not independent regeneration of all75 physical quantities",
            physical_replay=False),
        limitations="No dynamics reintegration or independent navigation-observer regeneration. All30 are DEVELOPMENT; secondary metrics descriptive, no practical superiority margin invented.")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot",required=True,type=Path)
    parser.add_argument("--inventory-sha",required=True)
    parser.add_argument("--model-registry",required=True,type=Path)
    parser.add_argument("--inputs",required=True,type=Path,nargs="+")
    args=parser.parse_args()
    try:
        result,code=merge(args.inputs,args.snapshot,args.inventory_sha,args.model_registry),0
    except Exception as error:
        result,code=dict(status="development_merge_rejected",error=f"{type(error).__name__}:{error}",
                        no_file_writes=True,no_simulation_or_learning=True),2
    print(json.dumps(result,ensure_ascii=False,allow_nan=False),flush=True)
    return code


if __name__=="__main__":
    sys.exit(main())
