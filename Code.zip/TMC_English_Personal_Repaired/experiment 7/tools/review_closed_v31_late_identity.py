"""Read saved identities only AFTER the whole sealed V31 late cohort closes.

No numerical runtime, weight deserialization, CPU audit, ENV or training.
The two actual milestones remain observations of one fresh300k trajectory.
This external reviewer is not a modification to the running sealed pipeline.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT.parent / "runs/c07_research34_20261019/v31_late300k"
META = RUN / "metadata"
CODE = ROOT / "candidate_v31_child_deadline/code"
PLAN_SHA = "57404f3aa987eac933001aa56068114d4185bc7538e2fb190babaf2b29e08843"
ARMS = ("3full", "3usde", "4full", "4usde")
ENDPOINTS = (200000, 300000)


def require(value, message):
    if not value:
        raise ValueError(message)


def pairs(values):
    result = {}
    for key, value in values:
        require(key not in result, "Duplicate JSON field: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Nonfinite JSON constant: " + value)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"),
                      object_pairs_hook=pairs, parse_constant=reject_constant)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def exact(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(exact(left[k], right[k]) for k in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(exact(a, b) for a, b in zip(left, right))
    return left == right


def gate_whole(meta=META):
    # FIRST gate, also used before importing any saved-arithmetic/P0 helpers.
    require((meta / "LATE_ENDED_REVIEW_REQUIRED.json").is_file(), "Whole late cohort is not closed")
    require(not (meta / "LATE_STOPPED_NO_RETRY.json").exists(), "New late STOP requires diagnosis")
    exit_record = read(meta / "COORDINATOR_NATIVE_EXIT.json")
    require(type(exit_record["actual_exit_code"]) is int and exit_record["actual_exit_code"] == 0
            and exit_record["no_process_stopped"] is True, "Coordinator lacks natural actual zero exit")
    ended = read(meta / "LATE_ENDED_REVIEW_REQUIRED.json")
    require(exact(ended["training_steps"], 1200000) and exact(ended["evaluation_episodes"], 160)
            and ended["automatic_next_stage"] is False, "Wrong complete-cohort boundary")
    return exit_record, ended


def verify_plan():
    require(digest(META / "PLAN.json") == PLAN_SHA, "Sealed late PLAN differs")
    plan = read(META / "PLAN.json")
    require(plan["format"] == "c07-v31-late300k-fourarm-plan-v1"
            and exact(plan["endpoint"], 300000) and exact(plan["checkpoints"], list(ENDPOINTS))
            and list(plan["arms"]) == list(ARMS) and plan["no_resume"] is True,
            "Wrong late cohort / endpoint interpretation")
    require(exact(plan["evaluation_seeds"], {
        "200000": list(range(10918010, 10918020)),
        "300000": list(range(10918010, 10918020)) + list(range(10918100, 10918120))}),
        "Predeclared ordered10/30 development split differs")
    require(len(plan["source_files"]) == 156 and len(plan["source_identities"]) == 152,
            "Wrong frozen V31 source membership")
    for name, pin in plan["source_files"].items():
        require(digest(CODE / name) == pin, "Scientific source differs: " + name)
    for name, pin in plan["tools"].items():
        require(digest(ROOT / "tools" / name) == pin, "Pinned stage tool differs: " + name)
    for path, pin in {**plan["runtime"], **plan["historical_pins"]}.items():
        require(digest(path) == pin, "Runtime / historical declaration differs: " + path)
    return plan


def stage_labels():
    return [label for arm in ARMS for label in (
        arm + "_train", arm + "_200000_cpu_audit", arm + "_200000_evaluate",
        arm + "_300000_cpu_audit", arm + "_300000_evaluate")]


def stage_argv(plan, arm, endpoint=None, kind="train"):
    """Independently reconstruct the already-declared whole scientific argv."""
    item = plan["arms"][arm]
    milestone = Path(item["output"]) / "learning/milestones" / f"step_{endpoint:07d}" if endpoint else None
    if kind == "train":
        args = [CODE / "experiment7_c07_scaling.py", "train", "--auv", str(int(arm[0])),
            "--sensors", "30", "--method", "full" if arm.endswith("full") else "usde_only",
            "--profile", plan["profile"], "--fault", "original_c07", "--steps", "300000",
            "--seed", "7", "--device", "cuda", "--output", item["output"],
            "--ledger", RUN / "physical_ledger.json", "--budget-mode", "per_model",
            "--candidate-id", "renewed_v31_late300k", "--development-limit", "300000",
            "--stage", "development", "--attempt-id", item["attempt_id"], "--milestones", "200000", "300000"]
    elif kind == "audit":
        args = [ROOT / "tools/inspect_v31_late_checkpoint.py", "--checkpoint", milestone / "checkpoint.pt",
            "--training-log", Path(item["output"]) / "learning/training.jsonl", "--plan-sha", PLAN_SHA]
    else:
        require(kind == "evaluate", "Unknown stage operation")
        args = [CODE / "experiment7_c07_scaling.py", "evaluate", "--checkpoint", milestone / "policy.pt",
            "--output", RUN / "evaluations" / arm / str(endpoint), "--device", "cpu",
            "--fault", "reference", "--seeds", *map(str, plan["evaluation_seeds"][str(endpoint)])]
    return ["-B", "-X", "utf8", *map(str, args)]


def validate_held_identities(receipt, supervisor, spec):
    require(receipt["status"] == "closed" and receipt["no_process_stopped"] is True
            and receipt["no_retry"] is True and exact(supervisor["actual_exit_code"], 0),
            "Stage not a natural closed operation")
    identities, exits = receipt["identities"], receipt["exit_codes"]
    roles = ("venv_launcher", "actual_native_python")
    require(len(identities) == len(exits) == 2 and [r["role"] for r in exits] == list(roles),
            "Distinct held launcher and actual Python required")
    require(len({r["pid"] for r in identities}) == 2, "Duplicate native PID identities")
    for identity, ended, image in zip(identities, exits, (spec["python"], spec["actual_python"])):
        require(exact(ended["actual_exit_code"], 0) and identity["pid"] == ended["pid"]
                and identity["image"] == image and identity["argv"] == [image, *spec["argv"]],
                "Whole held command / actual exit identity differs")
        born = datetime.fromisoformat(identity["birth"])
        require(abs((born - datetime.fromisoformat(ended["birth"])).total_seconds()) < .001
                and datetime.fromisoformat(ended["actual_exit_time"]) >= born, "Held process birth/exit differs")
    require(identities[0]["parent_pid"] == supervisor["pid"]
            and identities[1]["parent_pid"] == identities[0]["pid"], "Recorded stage parent chain differs")


def matched(manifests):
    for n in (3, 4):
        full, usde = manifests[f"{n}full"], manifests[f"{n}usde"]
        for field in ("environment_config", "routing_options", "learning_config",
                      "revision_learning_options", "training_protocol", "source_hashes"):
            require(exact(full[field], usde[field]), "Same-N public settings differ: " + field)
        left, right = full["method_options"], usde["method_options"]
        require(left["mac_enabled"] is True and right["mac_enabled"] is False
                and exact({k: v for k, v in left.items() if k != "mac_enabled"},
                          {k: v for k, v in right.items() if k != "mac_enabled"}),
                "Undeclared change beyond matched communication bundle ablation")


def audit():
    coordinator, ended = gate_whole()
    plan = verify_plan()
    observed = {}

    def retain(path):
        path = Path(path)
        pin = dict(bytes=path.stat().st_size, sha256=digest(path))
        if str(path) in observed:
            require(exact(observed[str(path)], pin), "Closed input changed during review")
        observed[str(path)] = pin
        return pin

    for kind in ("stdout", "stderr"):
        require(coordinator[kind + "_sha256"] == retain(META / ("coordinator." + kind + ".log"))["sha256"],
                "Coordinator closed stdio differs")
    require((META / "coordinator.stderr.log").stat().st_size == 0, "Coordinator stderr requires review")
    require(ended["result_sha256"] == retain(RUN / "LATE_RESULTS.json")["sha256"], "Closed result receipt differs")
    started = read(META / "COORDINATOR_STARTED.json")
    require(started["real_handle_held"] is True and started["pid"] == coordinator["pid"]
            and started["birth"] == coordinator["birth"]
            and started["arguments"] == ["-B", "-X", "utf8", str(ROOT / "tools/run_v31_late.py"),
                                        "execute", "--execute-fresh300k-fourarm"], "Coordinator held identity differs")
    events = [json.loads(line, object_pairs_hook=pairs, parse_constant=reject_constant)
              for line in (META / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    scientific = [r for r in events if r["event"] in ("stage_dispatch", "stage_closed")
                  and not r["label"].startswith("fixture_")]
    require([(r["event"], r["label"]) for r in scientific]
            == [(kind, label) for label in stage_labels() for kind in ("stage_dispatch", "stage_closed")],
            "Scientific stages duplicated, missing, reordered or unclosed")
    stages = {}
    for arm in ARMS:
        descriptors = [(arm + "_train", "train", None)] + [
            (f"{arm}_{step}_{suffix}", kind, step) for step in ENDPOINTS
            for suffix, kind in (("cpu_audit", "audit"), ("evaluate", "evaluate"))]
        for label, operation, step in descriptors:
            specpath = META / (label + ".spec.json")
            spec = read(specpath)
            receipt = read(META / (label + ".native_exit.json"))
            supervisor = read(META / (label + ".supervisor_exit.json"))
            require(receipt["spec_sha256"] == digest(specpath) and spec["operation"] == operation
                    and spec["argv"] == stage_argv(plan, arm, step, operation)
                    and spec["code_root"] == str(CODE) and spec["run_root"] == str(RUN)
                    and spec["input_pins"][str(META / "PLAN.json")] == PLAN_SHA,
                    "Declared whole stage command differs: " + label)
            require(spec["entry_sha256"] == digest(spec["argv"][3])
                    and spec["wrapper_sha256"] == plan["tools"]["recorded_v31_late_stage.ps1"]
                    and plan["runtime"][spec["python"]] == spec["python_sha256"]
                    and plan["runtime"][spec["actual_python"]] == spec["actual_python_sha256"],
                    "Stage executable / entry / wrapper differs")
            validate_held_identities(receipt, supervisor, spec)
            for kind in ("stdout", "stderr"):
                require(spec[kind] == str(META / (label + "." + kind + ".log")), "Wrong stdio path")
                require(receipt[kind + "_sha256"] == digest(spec[kind])
                        and supervisor[kind + "_sha256"] == digest(META / (label + ".supervisor." + kind + ".log")),
                        "Closed stage stdio changed")
            require(Path(spec["stderr"]).stat().st_size == 0
                    and (META / (label + ".supervisor.stderr.log")).stat().st_size == 0,
                    "Stage stderr requires explicit review")
            for path, pin in spec["input_pins"].items():
                require(retain(path)["sha256"] == pin, "Closed stage input changed")
            for suffix in (".native_exit.json", ".supervisor_exit.json", ".spec.json", ".dispatch.json",
                           ".reservation.json", ".stdout.log", ".stderr.log",
                           ".supervisor.stdout.log", ".supervisor.stderr.log"):
                retain(META / (label + suffix))
            stages[label] = dict(exit_codes=receipt["exit_codes"], supervisor_actual_exit_code=0)

    models, manifests = {}, {}
    for arm in ARMS:
        learning = Path(plan["arms"][arm]["output"]) / "learning"
        manifest, summary = read(learning / "manifest.json"), read(learning / "summary.json")
        require(manifest["seed"] == 7 and manifest["target_step"] == summary["global_step"] == 300000
                and summary["status"] == "completed" and summary["source_unchanged"] is True,
                "Enclosing training not naturally completed at300k")
        require(manifest["run_id"] == summary["run_id"] and manifest["resume_mode"] == "fresh"
                and manifest["parent_checkpoint"] is None and manifest["continuation_provenance"] is None
                and manifest["device"] == "cuda" and manifest["source_hashes"] == plan["source_identities"]
                and manifest["scale_context"]["attempt_id"] == plan["arms"][arm]["attempt_id"],
                "Wrong source / fresh CUDA training lineage")
        require(exact(manifest["scale_context"]["declaration"], plan["arms"][arm]["declaration"]), "Declaration differs")
        files = {name: retain(learning / name) for name in (
            "manifest.json", "summary.json", "training.jsonl", "checkpoint_latest.pt", "policy_inference.pt")}
        selected = {}
        for step in ENDPOINTS:
            milestone = learning / "milestones" / f"step_{step:07d}"
            metadata = read(milestone / "metadata.json")
            cpu_path = META / f"{arm}_{step}_cpu_audit.stdout.log"
            cpu = read(cpu_path)
            scope = cpu["fresh_long_scope"]
            require(cpu["status"] == "passed" and exact(cpu["global_step"], step)
                    and cpu["independent_cpu_only"] is True and cpu["run_id"] == manifest["run_id"]
                    and cpu["method_id"] == manifest["method_id"] and exact(cpu["n_auv"], int(arm[0]))
                    and cpu["critic_adam_steps_per_auv"] == [step - 1000] * int(arm[0])
                    and cpu["actor_adam_steps_per_auv"] == [(step - 1000) // 2] * int(arm[0]),
                    "Saved original endpoint CPU identity/counters differ")
            require(scope["sealed_plan_sha256"] == PLAN_SHA and exact(scope["enclosing_completed_endpoint"], 300000)
                    and exact(scope["actual_immutable_milestone_selected"], step)
                    and scope["learning_global_target_not_relabelled"] is True
                    and scope["selected_closed_JSON_and_full_log_verified"] is True
                    and scope["original_cpu_derivation"]["remaining_AST_identical"] is True,
                    "Saved CPU proof is not true selected milestone within completed300k")
            require(exact(metadata["global_step"], step) and metadata["run_id"] == manifest["run_id"]
                    and metadata["source_hashes"] == manifest["source_hashes"]
                    and set(metadata["files"]) == {"checkpoint.pt", "policy.pt"}, "Wrong milestone metadata")
            bundle = {name: retain(milestone / name) for name in ("metadata.json", "checkpoint.pt", "policy.pt")}
            for name, pin in metadata["files"].items():
                require(exact(bundle[name], pin), "Native immutable milestone byte receipt differs")
            require(cpu["checkpoint"] == str(milestone / "checkpoint.pt")
                    and cpu["checkpoint_sha256"] == bundle["checkpoint.pt"]["sha256"]
                    and cpu["training_log_sha256"] == files["training.jsonl"]["sha256"]
                    and cpu["inference_policy"]["checked"] is True
                    and cpu["inference_policy"]["sha256"] == bundle["policy.pt"]["sha256"],
                    "Original CPU proof not bound to actual selected bytes / whole300k log")
            evaluation = RUN / "evaluations" / arm / str(step) / "complete.json"
            complete = read(evaluation)
            require(complete["status"] == "completed" and exact(complete["learning_steps"], 0)
                    and complete["all_failures_retained"] is True
                    and complete["seeds"] == plan["evaluation_seeds"][str(step)], "Evaluation split/freeze differs")
            retain(evaluation)
            selected[str(step)] = dict(files=bundle, original_saved_cpu_sha256=digest(cpu_path))
        models[arm] = dict(run_id=manifest["run_id"], attempt_id=plan["arms"][arm]["attempt_id"],
                           enclosing_training_endpoint=300000, files=files, selected_endpoints=selected)
        manifests[arm] = manifest
    matched(manifests)
    ledger = read(RUN / "physical_ledger.json")
    require(ledger["mode"] == "per_model" and exact(ledger["development_limit"], 300000)
            and len(ledger["attempts"]) == 4
            and {r["attempt_id"] for r in ledger["attempts"]}
            == {r["attempt_id"] for r in plan["arms"].values()}, "Wrong physical budget / attempts")
    for item in ledger["attempts"]:
        require(item["status"] == "completed" and exact(item["executed_steps"], 300000)
                and exact(item["requested_steps"], 300000) and exact(item["resume_from_step"], 0)
                and item["resume_parent_attempt"] is None and item["reservation_overrun"] is False
                and exact(item["seed"], 7) and item["stage"] == "development", "Wrong fresh physical cost")
    for path in (RUN / "physical_ledger.json", META / "PLAN.json", META / "events.jsonl",
                 META / "COORDINATOR_STARTED.json", META / "COORDINATOR_NATIVE_EXIT.json",
                 META / "LATE_ENDED_REVIEW_REQUIRED.json"):
        retain(path)
    require(all(exact(dict(bytes=Path(p).stat().st_size, sha256=digest(p)), pin)
                for p, pin in observed.items()), "Closed evidence changed during read-only review")
    require("torch" not in sys.modules and "numpy" not in sys.modules, "Model runtime imported")
    return dict(status="late_closed_identity_and_matched_control_verified", observed_at=datetime.now(timezone.utc).isoformat(),
        plan_sha256=PLAN_SHA, models=models, stages=stages, observed_files=observed,
        source_files_verified=156, source_identities_verified=152, matched_public_settings_equal=True,
        method_options_only_difference="mac_enabled", physical_ledger=ledger, new_physical_steps=1200000,
        original_CPU_audits_read_not_reexecuted=8, model_deserializations=0, simulation_steps=0, training_steps=0,
        performance_success_not_claimed=True, no_automatic_promotion=True,
        limitations="Bounded saved identity/exit checks, not proof of absence of unrecorded work or independent source physics.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "New exclusive evidence path required")
    result = audit()
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps(dict(status=result["status"], models=len(result["models"]),
                         stages=len(result["stages"]), observed_files=len(result["observed_files"]))))


if __name__ == "__main__":
    main()
