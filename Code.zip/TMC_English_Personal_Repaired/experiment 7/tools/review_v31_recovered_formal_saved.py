"""Original strict P0/all75/trace/DATA/CI code objects, new receipt boundary only."""
import argparse
import ast
from copy import deepcopy
import json
from pathlib import Path
import traceback
from types import FunctionType
import v31_recovered_formal300 as c

original=c.r.load('recovered_saved_original_unchanged',c.TOOLS/'review_v31_formal300_saved.py')
ns={**original.__dict__,'c':c,'g':c.g,'CODE':c.CODE}

def derive_closed_identity():
    tree=ast.parse((c.TOOLS/'review_v31_formal300_saved.py').read_text(encoding='utf-8-sig'))
    node=deepcopy(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='closed_identity'))
    before=deepcopy(node)
    replacements={'run_v31_formal300.py':'v31_recovered_formal300.py',
        'v31_formal_worker.py':'v31_recovered_formal_worker.py',
        'recorded_v31_formal300_stage.ps1':'recorded_v31_recovery_stage.ps1'}
    hits=[];list_hits=0
    for part in ast.walk(node):
        if isinstance(part,ast.Constant) and isinstance(part.value,str) and part.value in replacements:
            hits.append(part.value);part.value=replacements[part.value]
        if isinstance(part,ast.List) and len(part.elts)==6 and isinstance(part.elts[-1],ast.Constant) and part.elts[-1].value=='--execute-frozen-formal300':
            part.elts[-1:-1]=[ast.Constant('--plan-sha'),ast.Name(id='plan_sha',ctx=ast.Load())];list_hits+=1
    c.require(sorted(hits)==sorted(replacements) and list_hits==1,'Only four explicit saved receipt metadata AST sites')
    restored=deepcopy(node)
    reverse={v:k for k,v in replacements.items()}
    for part in ast.walk(restored):
        if isinstance(part,ast.Constant) and isinstance(part.value,str) and part.value in reverse:part.value=reverse[part.value]
        if isinstance(part,ast.List) and len(part.elts)==8 and isinstance(part.elts[-1],ast.Constant) and part.elts[-1].value=='--execute-frozen-formal300':del part.elts[-3:-1]
    c.require(ast.dump(restored,include_attributes=False)==ast.dump(before,include_attributes=False),'Saved boundary AST reversal differs')
    local={**ns}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'<four_recovered_receipt_metadata_sites>','exec'),local)
    return local['closed_identity']

base_closed_identity=derive_closed_identity()

def closed_identity(plan_sha):
    contract,observed,retain=base_closed_identity(plan_sha)
    for pattern in ('*.permit.json','*.ready.json','*.identity_observation_*.json'):
        for path in c.META.glob(pattern):retain(path)
    c.require(contract['training_recovery_plan_sha256']==c.RECOVERY_SHA,'Explicit recovery bound closure required')
    return contract,observed,retain

ns['closed_identity']=closed_identity
for name,value in vars(original).items():
    if isinstance(value,FunctionType) and value.__module__==original.__name__ and name not in ('closed_identity','main'):
        clone=FunctionType(value.__code__,ns,name,value.__defaults__,value.__closure__)
        clone.__kwdefaults__=value.__kwdefaults__;ns[name]=clone
audit_original=ns['audit']

def audit(plan_sha):
    result=audit_original(plan_sha)
    result['training_recovery_plan_sha256']=c.RECOVERY_SHA
    result['original_failed_coordinator_and_STOP_preserved']=True
    result['original_first_3full_CPU_actual_exits']='unknown_not_reconstructed'
    result['closed_CPU_execution_counts']={'3full':2,'3usde':1,'4full':1,'4usde':1}
    result['strict_saved_numerical_and_P0_code_objects_unchanged']=True
    result['receipt_boundary_explicit_AST_sites']=4
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--plan-sha',required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();c.require(not a.output.exists(),'Exclusive saved review output')
    try:result=audit(a.plan_sha)
    except Exception as error:
        c.write_new(a.output.with_suffix(a.output.suffix+'.FAILED.json'),dict(status='saved_review_failed_preserved',
            error=repr(error),traceback=traceback.format_exc(),no_physical_retry=True,model_loads=0,simulation_steps=0));raise
    c.write_new(a.output,result)
    print(json.dumps({k:result[k] for k in ('status','episodes','original75_values_checked','strict_P0_failed_episodes')}))

if __name__=='__main__':main()
