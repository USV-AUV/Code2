"""Portable entrypoint; --help/check/prepare never start training."""
from exp7_c07_scaling_20261012.cli import main

if __name__=="__main__":
    main()
