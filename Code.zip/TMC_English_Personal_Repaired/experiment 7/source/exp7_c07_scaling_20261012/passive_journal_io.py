"""Default-OFF P0 sidecar I/O; no simulator, policy, hooks or native getters.

The external evaluator supplies all static metadata and step/time contexts.
Sidecars are disjoint from the original three-file episode directory. A source
or I/O error is terminal for this writer, preserves evidence, and never retries
physics. The caller decides how to report that logging failure; native ending
and all original episode files remain outside this module's authority.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import time

from .passive_journal import make_passive_journal, STREAMS

FORMAT = "c07_passive_native_event_sidecar_v1"
HEADER_NAME = "header.json"
EVENT_NAME = "passive_events.jsonl.gz"
SUMMARY_NAME = "final_summary.json"
RECEIPT_NAME = "receipt.json"


class PassiveJournalIOError(RuntimeError):
    """Terminal sidecar failure; do not retry/replay the physical episode."""


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _plain(value, path="header", ancestors=None):
    kind = type(value)
    if value is None or kind in (bool, int, str):
        return value
    if kind is float:
        _require(math.isfinite(value), "Nonfinite static metadata: " + path)
        return value
    _require(kind in (dict, list, tuple), "Only plain JSON metadata accepted: " + path)
    ancestors = set() if ancestors is None else ancestors
    _require(id(value) not in ancestors and len(ancestors) < 64, "Cyclic/deep metadata: " + path)
    nested = ancestors | {id(value)}
    if kind is dict:
        _require(all(type(key) is str for key in value), "Metadata keys must be strings: " + path)
        return {key: _plain(item, path+"."+key, nested) for key, item in value.items()}
    return [_plain(item, path+"["+str(index)+"]", nested) for index, item in enumerate(value)]


def _sha(value, name):
    _require(type(value) is str and len(value) == 64 and
        all(letter in "0123456789abcdefABCDEF" for letter in value), "Invalid SHA256: " + name)
    return value.lower()


def _header(value):
    _require(type(value) is dict, "Caller must supply a complete static metadata dict")
    result = _plain(value)
    required = {"n_auv", "n_sensors", "slot_owners", "slot_duration", "source_hashes",
                "model_sha256", "profile", "seed"}
    _require(required <= set(result), "Missing static sidecar identity fields")
    n, sensors = result["n_auv"], result["n_sensors"]
    _require(type(n) is int and n in (2, 3, 4) and type(sensors) is int and sensors >= n,
             "Declare integer n2/3/4 and sensor count")
    slots = result["slot_owners"]
    _require(type(slots) is list and slots and all(type(node) is int and 0 <= node <= n+sensors for node in slots)
        and set(slots) == set(range(n+sensors+1)), "Caller slot_owners must represent every declared native node")
    _require(type(result["slot_duration"]) in (int, float) and math.isfinite(result["slot_duration"])
        and result["slot_duration"] > 0, "Declare positive finite slot_duration")
    _require(type(result["seed"]) is int and result["seed"] >= 0 and
        type(result["profile"]) is str and result["profile"], "Declare seed/profile identity")
    result["model_sha256"] = _sha(result["model_sha256"], "model_sha256")
    sources = result["source_hashes"]
    _require(type(sources) is dict and sources and all(type(key) is str and key for key in sources),
             "Caller must provide static complete source identities")
    result["source_hashes"] = {key: _sha(digest, "source_hashes."+key) for key, digest in sources.items()}
    return result


def _exclusive_json(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, allow_nan=False)
        stream.write("\n"); stream.flush(); os.fsync(stream.fileno())


def _receipt(path):
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""):
            hasher.update(block)
    return dict(bytes=path.stat().st_size, sha256=hasher.hexdigest())


class PassiveJournalWriter:
    def __init__(self, env, directory, *, enabled=False, header=None,
                 episode_files_directory=None, network=None, drain_period_s=10.):
        _require(type(enabled) is bool and enabled, "Writer requires explicit enabled=True; factory defaults OFF")
        began = time.perf_counter()
        self.logging_wall_time_s = 0.
        self._stream = self._raw = None
        self._failed = self._completed = False
        self._directory_owned = False
        self._last_context = None
        self._last_drain_time = 0.
        self._written = 0
        self._indices = {stream: 0 for stream, _, _ in STREAMS}
        self._last_statistics = None
        self._drain_calls = 0
        self._skipped_calls = 0
        self.directory = Path(directory).resolve()
        _require(episode_files_directory is not None, "Declare original three-file episode directory")
        self.original_directory = Path(episode_files_directory).resolve()
        self._disjoint()
        if self.directory.exists():
            raise FileExistsError("Passive journal needs a new sidecar directory; do not overwrite")
        _require(type(drain_period_s) in (int, float) and math.isfinite(drain_period_s) and drain_period_s > 0,
                 "Drain interval must be positive finite logical seconds")
        self.drain_period_s = drain_period_s
        metadata = _header(header)
        self.header = dict(format=FORMAT, metadata=metadata, drain_period_s=drain_period_s,
            execution_observation=False, root_information_source=False,
            cross_stream_global_order="unknown", original_three_file_directory=str(self.original_directory),
            logging_CPU_scope="Separately metered observer/I/O walltime; not method inference/step CPU")
        # Bind only registered stored event lists through the unchanged P0 API.
        self._journal = make_passive_journal(env, enabled=True, network=network)
        try:
            self.directory.mkdir(parents=True, exist_ok=False)
            self._directory_owned = True
            _exclusive_json(self.directory/HEADER_NAME, self.header)
            self._raw = (self.directory/EVENT_NAME).open("xb")
            compressed = gzip.GzipFile(filename="", mode="wb", fileobj=self._raw, mtime=0)
            self._stream = io.TextIOWrapper(compressed, encoding="utf-8", newline="\n")
        except BaseException as error:
            self._fail("construction", error)
        finally:
            self.logging_wall_time_s += time.perf_counter()-began

    def _disjoint(self):
        _require(not self.directory.is_relative_to(self.original_directory) and
                 not self.original_directory.is_relative_to(self.directory),
                 "Sidecar directory must be disjoint from original three-file episode folder")

    def _active(self):
        if self._failed or self._completed:
            raise PassiveJournalIOError("Sidecar writer is terminal; no retry or overwrite")
        _require(self.directory.resolve() == self.directory and self.original_directory.resolve() == self.original_directory,
                 "Sidecar/original path binding changed")
        self._disjoint()

    def _close(self):
        errors = []
        if self._stream is not None:
            stream, self._stream = self._stream, None
            try:
                stream.close()
            except BaseException as error:
                errors.append(error)
        if self._raw is not None:
            raw, self._raw = self._raw, None
            try:
                raw.flush(); os.fsync(raw.fileno())
            except BaseException as error:
                errors.append(error)
            finally:
                try:
                    raw.close()
                except BaseException as error:
                    errors.append(error)
        if errors:
            cancellation=next((error for error in errors if not isinstance(error,Exception)),None)
            raise cancellation if cancellation is not None else errors[0]

    def _fail(self, stage, error):
        self._failed = True
        cancellation=error if not isinstance(error,Exception) else None
        try:
            self._close()
        except BaseException as close_error:
            if cancellation is None and not isinstance(close_error,Exception):cancellation=close_error
        evidence = dict(format=FORMAT, status="failed_passive_sidecar_preserved", stage=stage,
            error_type=type(error).__name__, error=str(error), completed_records=self._written,
            writer_record_counts_by_stream=dict(self._indices), physics_replayed=False,
            original_episode_files_touched=False, native_ending_changed=False,
            cross_stream_global_order="unknown")
        if cancellation is not None:
            evidence["cancellation_type"]=type(cancellation).__name__
        try:
            if self._directory_owned and self.directory.is_dir() and not (self.directory/"FAILED.json").exists():
                _exclusive_json(self.directory/"FAILED.json", evidence)
        except BaseException as evidence_error:
            if cancellation is None and not isinstance(evidence_error,Exception):cancellation=evidence_error
            # I/O failure evidence can itself fail; existing bytes survive.
        if cancellation is not None:raise cancellation
        raise PassiveJournalIOError("Passive sidecar failed; preserve existing files, do not replay physics: "+stage) from error

    def drain(self, *, step_end, time_s, force=False):
        began = time.perf_counter()
        try:
            self._active()
            _require(type(step_end) is int and step_end >= 0 and type(time_s) in (int, float) and
                math.isfinite(time_s) and time_s >= 0 and type(force) is bool, "Explicit typed nonnegative step/time context required")
            if self._last_context is not None:
                _require(step_end >= self._last_context["step"] and time_s >= self._last_context["time_s"],
                         "Caller context cannot move backwards")
            self._last_context = dict(step=step_end, time_s=time_s)
            if not force and time_s-self._last_drain_time < self.drain_period_s:
                self._skipped_calls += 1
                return dict(status="not_due", records_written=0)
            batch = self._journal.drain(step_end=step_end, time_s=time_s)
            pending = dict(self._indices); serialized = []
            for record in batch["records"]:
                stream, index = record["stream"], record["stream_index"]
                _require(stream in pending and type(index) is int and index == pending[stream],
                         "Every native stream index must be written exactly once")
                pending[stream] += 1
                value = dict(record, file_record_index=self._written+len(serialized),
                    file_index_scope="serialization index only; native cross-stream global order unknown")
                serialized.append((stream, json.dumps(value, ensure_ascii=False, allow_nan=False)+"\n"))
            for stream, line in serialized:
                self._stream.write(line)
                self._indices[stream] += 1; self._written += 1
            self._stream.flush(); self._raw.flush()
            self._last_drain_time = time_s
            self._last_statistics = batch["statistics"]
            self._drain_calls += 1
            return dict(status="drained", records_written=len(serialized), statistics=batch["statistics"])
        except BaseException as error:
            if self._failed or self._completed:
                raise
            self._fail("drain", error)
        finally:
            self.logging_wall_time_s += time.perf_counter()-began

    def abort(self, *, stage, error):
        """Close/preserve logging only; caller retains its ORIGINAL exception.

        No retry, final-summary success, native call or replacement exception.
        An already terminal sidecar is left byte-for-byte unchanged.
        """
        _require(type(stage) is str and bool(stage) and isinstance(error, BaseException),
                 "Abort needs an explicit stage and original caller exception")
        began = time.perf_counter()
        try:
            if self._failed or self._completed:
                return dict(status="already_terminal_preserved", original_exception_untouched=True)
            try:
                self._fail(stage, error)
            except PassiveJournalIOError:
                return dict(status="aborted_passive_sidecar_preserved", original_exception_untouched=True)
        finally:
            self.logging_wall_time_s += time.perf_counter()-began

    def finalize(self, *, step_end, time_s):
        self._active()
        self.drain(step_end=step_end, time_s=time_s, force=True)
        began = time.perf_counter()
        try:
            self._close()
            known = {HEADER_NAME, EVENT_NAME}
            _require({path.name for path in self.directory.iterdir()} == known,
                     "Sidecar contains unexpected files; no silent receipt omission")
            artifacts = {name: _receipt(self.directory/name) for name in sorted(known)}
            summary = dict(format=FORMAT, status="completed_passive_sidecar", metadata=self.header["metadata"],
                last_recorded_context=dict(self._last_context), records_written=self._written,
                writer_record_counts_by_stream=dict(self._indices),
                native_next_cursors={stream: state["next_cursor"] for stream, state in self._last_statistics["streams"].items()},
                final_drain_statistics=self._last_statistics,
                drain_calls=self._drain_calls, skipped_not_due_calls=self._skipped_calls,
                drain_period_s=self.drain_period_s, artifacts=artifacts,
                logging_wall_time_s_before_summary_and_receipt=self.logging_wall_time_s+time.perf_counter()-began,
                logging_CPU_scope="Caller must account separately; not method inference/step CPU",
                cross_stream_global_order="unknown", execution_observation=False, root_information_source=False,
                original_episode_files_touched=False, native_ending_changed=False)
            _exclusive_json(self.directory/SUMMARY_NAME, summary)
            artifacts[SUMMARY_NAME] = _receipt(self.directory/SUMMARY_NAME)
            manifest = dict(format=FORMAT, status="complete_sidecar_receipt", artifacts=artifacts,
                receipt_self_hash="Returned externally, not a recursive self-digest")
            _exclusive_json(self.directory/RECEIPT_NAME, manifest)
            returned_artifacts = dict(artifacts, **{RECEIPT_NAME: _receipt(self.directory/RECEIPT_NAME)})
            self._completed = True
            report = dict(summary, sidecar_directory=str(self.directory), strict_receipts=returned_artifacts,
                          original_episode_files_directory=str(self.original_directory))
        except BaseException as error:
            self._fail("finalize", error)
        finally:
            self.logging_wall_time_s += time.perf_counter()-began
        report["logging_wall_time_s"] = self.logging_wall_time_s
        report["logging_wall_time_includes"] = "Construction, every drain, close, summary/receipt serialization/fsync/hash"
        return report


def make_passive_journal_writer(env=None, directory=None, *, enabled=False, header=None,
                               episode_files_directory=None, network=None, drain_period_s=10.):
    """Default OFF does not inspect env/path/metadata and creates nothing."""
    _require(type(enabled) is bool, "enabled must be bool")
    if not enabled:
        return None
    return PassiveJournalWriter(env, directory, enabled=True, header=header,
        episode_files_directory=episode_files_directory, network=network, drain_period_s=drain_period_s)
