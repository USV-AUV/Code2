"""Pure-record development/holdout gate; no simulator or learner imports.

Calling the holdout branch is an irreversible declaration that those seeds are
opened. The exclusive started marker survives failures; retries cannot silently
claim the same set was untouched. The five policy digests are supplied by the
coordinator's separately audited freeze, not read or trained here.

The coordinator must pin one persistent absolute history_directory. Copies of
the contract still share its seed-set/model markers in that directory. This
module cannot prevent a malicious caller changing that path, removing history,
or modifying the verifier itself; such changes are not fresh confirmation.
Later confirmation blocks are only a finite preregistration interface, not
authorization to open them or to tune on a previous block and rename it unseen.
"""
from datetime import datetime, timezone
from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path


DEVELOPMENT_SEEDS = (*range(10712000,10712030), *range(10918000,10918030), *range(10918100,10918130))
MAX_CONFIRMATION_INDEX = 20
# Compatibility aliases refer to confirmation1 only, never every later block.
HOLDOUT_SEEDS = tuple(range(10919000, 10919030))
CONTRACT_FORMAT = "original-c07-scale-validation-contract-v1"
MARKER_FORMAT = "original-c07-scale-holdout-opened-v1"
SEED_HISTORY_NAME = "holdout_10919000_10919029.started.json"
FAULT_PROFILES = frozenset(("reference", "direct1_outage", "training"))
REQUIRED_ARMS = frozenset(((2, "full_v6"), (3, "full_v6"), (4, "full_v6"),
                           (3, "usde_only_v6"), (4, "usde_only_v6")))
METHODS = {"full": "full_v6", "full_v6": "full_v6", "usde": "usde_only_v6",
           "usde_only": "usde_only_v6", "usde_only_v6": "usde_only_v6"}
# Only these explicitly declared scale-port fields can differ across scales.
# Every field, including these, must match exactly within a full/USDE scale.
SCALE_CONFIG_FIELDS = frozenset(("n_auv", "declared_packet_bits", "deployment_layout", "coordination_service_interval",
                               "service_ack_timeout", "grant_ttl"))
REQUIRED_PHYSICAL_FIELDS = frozenset(("seed", "n_auv", "n_sensors", "area_size",
    "auv_depth", "sensor_depth", "dt", "substeps", "slow_period", "episode_steps",
    "max_speed", "min_separation", "collection_radius", "data_packet_bits",
    "data_header_bits", "initial_packets", "arrival_rate", "slot_duration",
    "tdma_sensors_per_group", "sound_speed", "guard_time", "processing_delay",
    "bit_rate", "bandwidth_hz", "faults", "service_ack_timeout", "grant_ttl"))

# A CLOSED copy of the reviewed joint_clocks registry, not a generic exemption.
# This record-only module never imports that native runtime or its dependencies.
JOINT_HORIZONS = {
    "adaptive_packet_grid_joint_h3_1_h4_1_v12": {2:1, 3:1, 4:1},
    "adaptive_packet_grid_joint_h3_1_h4_2_v12": {2:1, 3:1, 4:2},
    "adaptive_packet_grid_joint_h3_2_h4_1_v12": {2:1, 3:2, 4:1},
    "adaptive_packet_grid_joint_h3_2_h4_2_v12": {2:1, 3:2, 4:2},
    "adaptive_packet_grid_heterogeneous_g3_6_g4_4_h2_v13": {2:1, 3:2, 4:2},
    "adaptive_packet_grid_heterogeneous_n4_hello48_v15": {2:1, 3:2, 4:2},
    "adaptive_packet_grid_heterogeneous_n4_pool12_v16": {2:1, 3:2, 4:2},
    "adaptive_packet_grid_heterogeneous_n4_coord8_pool12_v26": {2:1, 3:2, 4:2},
    "adaptive_packet_grid_heterogeneous_state8_11_coord8_pool12_v27": {2:1, 3:2, 4:2},
    "adaptive_packet_grid_joint_child_deadline_v31": {2:1, 3:2, 4:2},
}
HETEROGENEOUS_PROFILE = "adaptive_packet_grid_heterogeneous_g3_6_g4_4_h2_v13"
HELLO48_PROFILE = "adaptive_packet_grid_heterogeneous_n4_hello48_v15"
POOL12_PROFILE = "adaptive_packet_grid_heterogeneous_n4_pool12_v16"
N4_COORD8_PROFILE = "adaptive_packet_grid_heterogeneous_n4_coord8_pool12_v26"
N34_STATE8_11_PROFILE = "adaptive_packet_grid_heterogeneous_state8_11_coord8_pool12_v27"
JOINT_PHY_LOC_ROOT16_PROFILE = "adaptive_packet_grid_joint_child_deadline_v31"
JOINT_FRAMES = {profile:{2:36.0,3:50*0.5 if profile==JOINT_PHY_LOC_ROOT16_PROFILE else 30.0,
    4:55*0.5625 if profile==JOINT_PHY_LOC_ROOT16_PROFILE else 42.0 if profile in (HETEROGENEOUS_PROFILE,HELLO48_PROFILE,POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE) else 33.0}
                for profile in JOINT_HORIZONS}
JOINT_SOURCE_PINS = {
    # PREPARED only. ROOT must independently bind BOTH final reviewed sources.
    "adapter/joint_clocks.py": "20e1eaac675f0922602253a6563d9010f078d2d84adf58a3c4cdf327ea8ffdc9",
    "adapter/environment.py": "8056d20d318950b3bafd20346e1497de46e56f11b59b520e68741acec6bde26a",
    "adapter/root_budget.py": "914ed5dedf239a62ea12165b443a2e1c93a4badba949dabde678b1987b617860",
    "original/v6_candidates/c04/environment.py": "de47f545838bef42c2735a2ab7c92a63faa8ef351ec49ea82a19205630001e21",
    "adapter/child_deadline.py": "83ef4ead2b889055fdd80b9f5e26995628d199bf9d9bf0c0f7268a7f03b6eeea",
}
JOINT_REFERENCES = {
    "reference/config": ("provenance/frozen_config.json", "9465309c17f69fd196385f33e7bf5eba15ce1b51a1441fdd7b081028ced1ffe7"),
    "reference/full": ("models/45w/full_v6/metadata.json", "8b6eca4e085217d92dc5f387f8414ed1fa104d4639a086227b13de3063484128"),
    "reference/usde_only": ("models/45w/usde_only_v6/metadata.json", "cff0604e677109d7baf6ca596a6e9031e7cfe16f12cf40b94661bcc5b3570084"),
}
JOINT_DECL_FIELDS = frozenset(("version", "profile", "n_auv", "n_sensors", "method",
    "config", "method_options", "routing_options", "learning", "training_protocol",
    "scale_diagnostics", "old_weights_allowed", "reward", "ending"))


class EvaluationGateError(ValueError):
    """Invalid or previously opened confirmation; preserve its evidence."""


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise EvaluationGateError(f"{name} must be an integer >= {minimum}")
    return value


def confirmation_seeds(index):
    """Exactly30 ordered seeds in registered blockj; no data is opened here."""
    _integer(index, "confirmation_index", 1)
    if index > MAX_CONFIRMATION_INDEX:
        raise EvaluationGateError(f"confirmation_index must be <= {MAX_CONFIRMATION_INDEX}")
    start = 10919000 + 1000 * (index - 1)
    return tuple(range(start, start + 30))


def _sha(value, name):
    if not isinstance(value, str) or len(value) != 64:
        raise EvaluationGateError(f"{name} must be a SHA256 hex digest")
    try:
        int(value, 16)
    except ValueError as error:
        raise EvaluationGateError(f"{name} must be a SHA256 hex digest") from error
    if any(character not in "0123456789abcdefABCDEF" for character in value):
        raise EvaluationGateError(f"{name} must be a SHA256 hex digest")
    return value.lower()


def _method(value):
    if not isinstance(value, str) or value not in METHODS:
        raise EvaluationGateError("Only declared full and USDE model identities are allowed")
    return METHODS[value]


def _pairs(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise EvaluationGateError(f"Duplicate JSON field: {key}")
        value[key] = item
    return value


def _reject_constant(value):
    raise EvaluationGateError(f"Nonfinite JSON constant: {value}")


def _read_json(path):
    try:
        raw = Path(path).read_bytes()
        if len(raw) > 4 * 1024 * 1024:
            raise EvaluationGateError("Validation records must be <=4MiB")
        value = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_pairs,
                           parse_constant=_reject_constant)
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise EvaluationGateError(f"Cannot read validation record: {path}") from error
    if not isinstance(value, dict):
        raise EvaluationGateError("Validation record must be a JSON object")
    return value, hashlib.sha256(raw).hexdigest()


def _record_digest(value):
    try:
        raw = json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError) as error:
        raise EvaluationGateError("Frozen record must be finite JSON data") from error
    return hashlib.sha256(raw).hexdigest()


def _source_hashes(value):
    if not isinstance(value, dict) or not value or any(not isinstance(key, str) or not key for key in value):
        raise EvaluationGateError("source_hashes must contain the audited frozen source identities")
    return {key: _sha(digest, "source_hashes." + key) for key, digest in value.items()}


def _config(value, n):
    if not isinstance(value, dict) or not REQUIRED_PHYSICAL_FIELDS.issubset(value):
        raise EvaluationGateError("Each model needs its complete environment_config and physical scope")
    _record_digest(value)
    if (type(value.get("n_auv")) is not int or value["n_auv"] != n or
            type(value.get("n_sensors")) is not int or value["n_sensors"] != 30 or
            type(value.get("seed")) is not int or value["seed"] != 7 or
            type(value.get("episode_steps")) is not int or value["episode_steps"] != 1200):
        raise EvaluationGateError("All five arms need declared n, common30SN/seed7/1200-step scope")
    return value


def _typed_exact(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return (all(type(k) is str for k in left) and left.keys() == right.keys()
                and all(_typed_exact(left[k], right[k]) for k in left))
    if type(left) is list:
        return len(left) == len(right) and all(_typed_exact(a, b) for a, b in zip(left, right))
    if type(left) is float:
        return math.isfinite(left) and math.isfinite(right) and left == right
    return (left is None or type(left) in (str, bool, int)) and left == right


def _joint_reference_records(sources):
    _require_joint_source_pins()
    if any(sources.get(key) != pin for key, pin in JOINT_SOURCE_PINS.items()):
        raise EvaluationGateError("Joint registry/runtime source PIN differs")
    records = {}
    root = Path(__file__).resolve().parents[1] / "reference"
    for key, (relative, pin) in JOINT_REFERENCES.items():
        value, actual = _read_json(root / relative)
        if sources.get(key) != pin or actual != pin:
            raise EvaluationGateError("Joint original reference bytes/source PIN differs")
        records[key] = value
    for key in ("reference/full", "reference/usde_only"):
        original = records[key].get("source_hashes")
        if type(original) is not dict or not original or any(
                sources.get("original/" + name) != pin for name, pin in original.items()):
            raise EvaluationGateError("Joint original C07 source set differs from reference")
    return records


def _require_joint_source_pins():
    """No source-selected records/paths may be opened from an unbound template."""
    keys={"adapter/joint_clocks.py","adapter/environment.py","adapter/root_budget.py","adapter/child_deadline.py",
          "original/v6_candidates/c04/environment.py"}
    if (type(JOINT_SOURCE_PINS) is not dict or set(JOINT_SOURCE_PINS)!=keys or
            any(type(pin) is not str or len(pin)!=64 or any(c not in "0123456789abcdef" for c in pin)
                for pin in JOINT_SOURCE_PINS.values())):
        raise EvaluationGateError("PREPARED joint source PINs require independent ROOT binding before IO")


def _joint_v28_clock_queue_records(n, cfg):
    """Pure original-owner arithmetic, never a native ENV or observed capacity."""
    owners=[]
    sensors=list(range(n+1,n+31))
    group=cfg["tdma_sensors_per_group"]
    for offset in range(0,30,group):
        owners.extend(range(n+1));owners.extend(sensors[offset:offset+group])
    gaps=[]
    for node in range(n+1):
        positions=[i for i,owner in enumerate(owners) if owner==node]
        gaps.extend(b-a for a,b in zip(positions,positions[1:]+[positions[0]+len(owners)]))
    gap=max(gaps)*cfg["slot_duration"];frame=len(owners)*cfg["slot_duration"]
    turn=(n+2)*gap*(1+1/max(1,2))
    clock=dict(frame_s=frame,cooperative_turn_s=turn,
        service_renew_lead_s=frame+turn+cfg["slot_duration"],
        service_retry_interval_s=2*frame+turn+cfg["slot_duration"],
        protected_sensor_home_gap_s=2*frame,slot_count=len(owners),bit_rate=cfg["bit_rate"],
        slot_s=cfg["slot_duration"],max_packet_bits=cfg.get("declared_packet_bits",
            max(cfg["data_packet_bits"]+cfg["data_header_bits"],cfg["state_packet_bits"],cfg["control_packet_bits"])))
    queue=dict(management_burst=1,management_rescue_burst=2,hello_ack_rescue_fraction=0.5,
        state_service_s=6.0,coord_service_s=cfg.get("coordination_service_interval",8.0),
        ack_service_s=3.0,request_service_s=6.0,localization_service_s=cfg.get("localization_service_interval",12.0),
        data_service_s=6.0,other_service_s=12.0,deadline_weight=0.5,deadline_bonus_cap=2.0)
    return clock,queue,owners,gap


def _joint_expected_records(n, method, profile, references):
    """Pure copies of pinned V9/new-joint declarations; no native constructor."""
    cfg = deepcopy(references["reference/config"])
    cfg["n_auv"] = n
    reference = references["reference/full" if method == "full_v6" else "reference/usde_only"]
    mo = deepcopy(reference["method_options"])
    if n > 2:
        cfg.update(declared_packet_bits=max(8*(40+112*n), 8*(40+112*(n-1)+8+128)),
            deployment_layout="scale_grid", coordination_service_interval=16./n,
            tdma_sensors_per_group=4 if n==4 and profile in (HETEROGENEOUS_PROFILE,HELLO48_PROFILE,POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE) else 6,
            hello_period=48. if n==4 and profile==HELLO48_PROFILE else {3:30., 4:40.}[n],
            service_ack_timeout=106. if n==3 else 134. if profile in (HETEROGENEOUS_PROFILE,HELLO48_PROFILE,POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE) else 126.,
            grant_ttl=106. if n==3 else 134. if profile in (HETEROGENEOUS_PROFILE,HELLO48_PROFILE,POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE) else 126.)
        mo.update(mac_pool_slots={3:15, 4:20}[n], mac_auv_slots=2,
            mac_max_leases={3:21, 4:28}[n], mac_child_max_active=2*n,
            mac_child_slots_per_sensor=2, mac_child_lease_frames=3,
            mac_child_lead_s=float(JOINT_HORIZONS[profile][n]*JOINT_FRAMES[profile][n]-12))
    if n==4 and profile in (POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE):
        mo["mac_pool_slots"]=12
    if n==4 and profile in (N4_COORD8_PROFILE,N34_STATE8_11_PROFILE):
        cfg["coordination_service_interval"]=8.0
    if n>2 and profile==N34_STATE8_11_PROFILE:
        cfg["state_period"]={3:8.0,4:11.0}[n]
    if n>2 and profile==JOINT_PHY_LOC_ROOT16_PROFILE:
        cfg.update(slot_duration={3:0.5,4:0.5625}[n],tdma_sensors_per_group=6,
            hello_period={3:45.0,4:80.0}[n],state_period={3:8.0,4:11.0}[n],
            coordination_service_interval=16./n,localization_service_interval={3:8.0,4:6.0}[n],
            service_ack_timeout={3:88.0,4:119.0}[n],grant_ttl={3:100.0,4:119.0}[n])
        if n==4:
            mo.update(mac_pool_slots=16,mac_child_max_active=4)
    return cfg, mo, reference


def _joint_contract_scope(models, saved, profile, sources):
    """Authenticate all five WHOLE declarations BEFORE exempting G/HELLO."""
    references = _joint_reference_records(sources)
    horizon_map = {str(n): h for n, h in JOINT_HORIZONS[profile].items()}
    for (n, method), model in models.items():
        cfg, mo, reference = _joint_expected_records(n, method, profile, references)
        declaration = model.get("declaration")
        if (type(declaration) is not dict or set(declaration) != JOINT_DECL_FIELDS
                or type(declaration.get("version")) is not str or not declaration["version"]
                or not _typed_exact(declaration.get("profile"), profile)
                or not _typed_exact(declaration.get("n_auv"), n)
                or not _typed_exact(declaration.get("n_sensors"), 30)
                or not _typed_exact(declaration.get("method"), method)
                or declaration.get("old_weights_allowed") is not False
                or not _typed_exact(model["environment_config"], cfg)
                or not _typed_exact(declaration.get("config"), cfg)
                or not _typed_exact(declaration.get("method_options"), mo)
                or not _typed_exact(declaration.get("routing_options"), reference["routing_options"])
                or not _typed_exact(declaration.get("learning"), reference["learning_config"])
                or not _typed_exact(declaration.get("training_protocol"), reference["training_protocol"])
                or model.get("declaration_sha256") != _record_digest(declaration)
                or declaration.get("reward") != "original same team reward to every TD3 replay; original topology_reward"
                or declaration.get("ending") != "original collision/boundary absorbing terminal; unfinished timeout macro discarded"):
            raise EvaluationGateError("Joint full typed CFG/MO/RO/learning/declaration identity differs")
        diagnostics = declaration.get("scale_diagnostics")
        if type(diagnostics) is not dict or type(diagnostics.get("joint_clock_adaptation")) is not dict:
            raise EvaluationGateError("Joint complete diagnostic declaration missing")
        adaptation = diagnostics["joint_clock_adaptation"]
        selector = adaptation.get("selector", {})
        h = JOINT_HORIZONS[profile][n]
        lead = 14.4 if n == 2 else float(h*JOINT_FRAMES[profile][n]-12)
        port = method == "full_v6" and h == 2
        required = dict(profile=profile, n_auv=n, horizon=h, fixed_horizon_mapping=horizon_map,
                        minimum_command_lead_s=lead, installed_H2_hook=port)
        proof = selector.get("selector_port", {})
        if (type(selector) is not dict or type(proof) is not dict
                or not _typed_exact(adaptation.get("registered_H3_H4"), horizon_map)
                or any(not _typed_exact(selector.get(k), v) for k, v in required.items())
                or proof.get("source_sha256") != JOINT_SOURCE_PINS["original/v6_candidates/c04/environment.py"]
                or not _typed_exact(proof.get("changed_AST_sites"), 1 if port else 0)
                or proof.get("MAX_delta") != ("F -> 2*F" if port else "original F")
                or proof.get("reverse_AST_identical") is not True):
            raise EvaluationGateError("Joint fixed MIN/H/actual selector declaration differs")
        if profile==JOINT_PHY_LOC_ROOT16_PROFILE:
            clock,queue,owners,gap=_joint_v28_clock_queue_records(n,cfg)
            local=diagnostics.get("joint_phy_localization_adaptation",{})
            expected_priority=dict(name="root_local_child_first_future_opportunity_bounded_urgency",
                enabled=n in (3,4) and method=="full_v6",n_auv=n,
                eligibility="owner0/src0 MAC_SUBCOMMIT in local transmitter queue only",
                window="next strictly future immutable child certificate opportunity within one native frame",
                bonus="one native frame / original mac_control_service_s3.0",
                original_rank_and_tie_breakers_preserved=True,native_unbounded_flow_age_preserved=True,
                real_slots_bits_TTL_received_permissions_and_management_rescue_unchanged=True,
                private_receiver_state_or_truth_read=False,no_delivery_or_collection_guarantee=True)
            if not _typed_exact(diagnostics.get("child_delivery_priority"),expected_priority):
                raise EvaluationGateError("V31 independent declared bounded priority identity differs")
            if (not _typed_exact(diagnostics.get("clock"),clock) or type(local) is not dict or
                    not _typed_exact(local.get("expected_actual_queue_options"),queue) or
                    not _typed_exact(local.get("coordination_service_interval"),queue["coord_service_s"]) or
                    not _typed_exact(local.get("localization_service_interval"),queue["localization_service_s"]) or
                    not _typed_exact(adaptation.get("actual_slot_owners"),owners) or
                    not _typed_exact(adaptation.get("actual_slot_duration_s"),cfg["slot_duration"]) or
                    not _typed_exact(adaptation.get("actual_cooperative_gap_s"),gap) or
                    not _typed_exact(adaptation.get("actual_max_management_run"),2) or
                    local.get("same_N_full_USDE_whole_config_and_queue_numerics_shared") is not True or
                    local.get("conditional_preparation_not_launch_authority") is not True):
                raise EvaluationGateError("V28 whole derived calendar/clock and declared actual QueueOptions differ")
    cfg = saved.get("environment_config", {})
    if type(cfg) is not dict or type(saved.get("scale_context")) is not dict:
        raise EvaluationGateError("Current Joint policy lacks complete typed context")
    arm = cfg.get("n_auv"), _method(saved.get("method_id"))
    model = models.get(arm, {})
    context = saved.get("scale_context", {})
    declaration = model.get("declaration")
    if (not _typed_exact(context.get("declaration"), declaration)
            or context.get("declaration_sha256") != model.get("declaration_sha256")
            or not _typed_exact(cfg, model.get("environment_config"))
            or any(not _typed_exact(saved.get(k), declaration.get(d)) for k, d in
                   (("method_options", "method_options"), ("routing_options", "routing_options"),
                    ("learning_config", "learning"), ("training_protocol", "training_protocol")))):
        raise EvaluationGateError("Current Joint policy differs from whole registered declaration")
    # Only this closed whole-typed profile may differ in STATE across N.
    # Earlier profiles retain the original cross-scale equality check.
    return (frozenset(("tdma_sensors_per_group", "hello_period", "state_period", "slot_duration", "localization_service_interval"))
            if profile==JOINT_PHY_LOC_ROOT16_PROFILE else frozenset(("tdma_sensors_per_group", "hello_period", "state_period"))
            if profile==N34_STATE8_11_PROFILE else frozenset(("tdma_sensors_per_group", "hello_period")))


def _validate_contract(contract, saved, checkpoint_sha, seeds, fault_profile):
    if contract.get("profile") in JOINT_HORIZONS:
        _require_joint_source_pins()
    if contract.get("format") != CONTRACT_FORMAT:
        raise EvaluationGateError("Unknown validation contract format")
    if contract.get("primary") != "collected_packets":
        raise EvaluationGateError("The sole primary endpoint is unique collected_packets")
    index = _integer(contract.get("confirmation_index"), "confirmation_index", 1)
    registered_seeds = list(confirmation_seeds(index))
    if contract.get("seeds") != registered_seeds or seeds != registered_seeds:
        raise EvaluationGateError("Validation must open the complete registered30 seeds for its confirmation_index in order")
    if contract.get("fault_profile") != fault_profile:
        raise EvaluationGateError("Evaluation fault_profile must match its explicitly frozen contract")
    history_path = contract.get("history_directory")
    if not isinstance(history_path, str) or not history_path or not Path(history_path).is_absolute():
        raise EvaluationGateError("Contract must declare the coordinator's persistent absolute history_directory")
    try:
        history_directory = Path(history_path).resolve(strict=True)
    except (OSError, RuntimeError) as error:
        raise EvaluationGateError("The pinned history_directory must already exist") from error
    if not history_directory.is_dir():
        raise EvaluationGateError("history_directory must be a directory, not a file")
    profile = contract.get("profile")
    if not isinstance(profile, str) or not profile:
        raise EvaluationGateError("Freeze one named candidate profile before opening holdout")
    training_step = _integer(contract.get("training_step"), "training_step", 1)
    if type(contract.get("training_seed")) is not int or contract["training_seed"] != 7:
        raise EvaluationGateError("The registered confirmation uses common training seed7")
    sources = _source_hashes(contract.get("source_hashes"))
    alpha = contract.get("family_alpha")
    try:
        expected_alpha = math.ldexp(.05, -index)
    except OverflowError as error:
        raise EvaluationGateError("confirmation_index is too large for a nonzero finite alpha") from error
    if (isinstance(alpha, bool) or not isinstance(alpha, (int, float)) or
            not math.isfinite(alpha) or expected_alpha <= 0 or
            not math.isclose(alpha, expected_alpha, rel_tol=1e-12, abs_tol=0)):
        raise EvaluationGateError("family_alpha must spend .05/(2**confirmation_index)")
    entries = contract.get("models")
    if not isinstance(entries, list) or len(entries) != len(REQUIRED_ARMS):
        raise EvaluationGateError("Freeze exactly the five primary model arms")
    models = {}
    for item in entries:
        if not isinstance(item, dict):
            raise EvaluationGateError("Each frozen model record must be an object")
        n = _integer(item.get("n_auv"), "models.n_auv", 2)
        arm = n, _method(item.get("method"))
        if arm not in REQUIRED_ARMS or arm in models:
            raise EvaluationGateError("Missing, duplicate or unexpected primary model arm")
        if (item.get("profile") != profile or type(item.get("training_step")) is not int or
                item["training_step"] != training_step or type(item.get("seed")) is not int or item["seed"] != 7):
            raise EvaluationGateError("All five model profiles, actual budgets and training seeds must match")
        models[arm] = dict(item, policy_sha=_sha(item.get("policy_sha"), "models.policy_sha"),
                           environment_config=_config(item.get("environment_config"), n))
    if set(models) != REQUIRED_ARMS:
        raise EvaluationGateError("The five primary model arms are not complete")
    joint = profile in JOINT_HORIZONS
    additional = _joint_contract_scope(models, saved, profile, sources) if joint else frozenset()
    exact = _typed_exact if joint else lambda a, b: a == b
    common_scopes = [{key: value for key, value in item["environment_config"].items()
                      if key not in SCALE_CONFIG_FIELDS | additional} for item in models.values()]
    if any(not exact(scope, common_scopes[0]) for scope in common_scopes[1:]):
        raise EvaluationGateError("Channel, workload, reward/learner config and common physical scope must match")
    for n in (3, 4):
        if not exact(models[n, "full_v6"]["environment_config"], models[n, "usde_only_v6"]["environment_config"]):
            raise EvaluationGateError("Full and USDE of the same scale must use identical environment_config")
    if len({item["policy_sha"] for item in models.values()}) != len(models):
        raise EvaluationGateError("Independent model arms cannot all point at duplicated policy artifacts")
    context = saved.get("scale_context")
    if not isinstance(context, dict) or context.get("stage") not in ("development", "full"):
        raise EvaluationGateError("Current model must carry an authenticated scale training stage")
    config = saved.get("environment_config")
    if not isinstance(config, dict):
        raise EvaluationGateError("Current model lacks its frozen environment_config")
    arm = _integer(config.get("n_auv"), "current n_auv", 2), _method(saved.get("method_id"))
    if arm not in models:
        raise EvaluationGateError("Current model is not one of the five frozen primary arms")
    model = models[arm]
    if (context.get("profile") != profile or saved.get("global_step") != training_step or
            type(saved.get("global_step")) is not int or type(saved.get("seed")) is not int or saved["seed"] != 7 or
            config != model["environment_config"] or checkpoint_sha != model["policy_sha"] or
            _source_hashes(saved.get("source_hashes")) != sources):
        raise EvaluationGateError("Current policy SHA, configuration, budget, seed, profile or source differs from freeze")
    declaration = context.get("declaration")
    if (not isinstance(declaration, dict) or declaration.get("config") != config or
            declaration.get("profile") != profile or declaration.get("n_auv") != arm[0] or
            declaration.get("n_sensors") != 30 or _method(declaration.get("method")) != arm[1]):
        raise EvaluationGateError("Current scale declaration and actual policy configuration disagree")
    return dict(arm=arm, profile=profile, training_step=training_step, source_hashes=sources,
                confirmation_index=index, family_alpha=float(alpha), checkpoint_stage=context["stage"],
                fault_profile=fault_profile, history_directory=history_directory, seeds=registered_seeds)


def _exclusive_json(path, value):
    """Never replace evidence. A failed/partial write remains conservatively blocking."""
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0)
    descriptor = os.open(path, flags, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, sort_keys=True, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def validate_evaluation_seeds(saved, checkpoint_sha, seeds, contract_path=None, *, fault_profile="reference"):
    """Return phase evidence; a valid holdout call creates exclusive started markers.

    The caller must invoke this after loading/verifying the checkpoint and
    before constructing/stepping physics. Only development has repeatable
    evaluations. This function never opens any model, optimizer or simulator.
    All holdout records use the contract's persistent history_directory, not
    contract_path.parent. A caller must not reset or substitute that history.
    """
    if not isinstance(saved, dict):
        raise EvaluationGateError("saved must be the already verified checkpoint record")
    if (isinstance(saved.get("scale_context"),dict) and
            saved["scale_context"].get("profile")==JOINT_PHY_LOC_ROOT16_PROFILE):
        _require_joint_source_pins()
    if not isinstance(fault_profile, str) or fault_profile not in FAULT_PROFILES:
        raise EvaluationGateError("Unknown declared evaluation fault_profile")
    checkpoint_sha = _sha(checkpoint_sha, "checkpoint_sha")
    seeds = list(seeds)
    if (not seeds or len(seeds) > 30 or any(type(seed) is not int for seed in seeds) or
            len(set(seeds)) != len(seeds)):
        raise EvaluationGateError("Declare1..30 unique integer evaluation seeds")
    context = saved.get("scale_context") or {}
    if all(seed in DEVELOPMENT_SEEDS for seed in seeds):
        if contract_path is not None:
            raise EvaluationGateError("A validation contract cannot relabel development seeds as holdout")
        return dict(phase="development", seeds=seeds, primary="collected_packets", holdout_opened=False,
            fault_profile=fault_profile, evaluation_fault=fault_profile,
            already_opened=False, seed_provenance="Historical development10712000..029; renewed development10918000..029 and10918100..129, never formal confirmation",
            checkpoint_sha256=checkpoint_sha, checkpoint_stage=context.get("stage"),
            model_training_step=saved.get("global_step"), validation_contract_sha256=None,
            confirmation_index=None, family_alpha=None,
            interpretation="Development evidence; no untouched-validation or sequential-confirmation claim")
    if contract_path is None:
        raise EvaluationGateError("Holdout remains sealed without a complete registered frozen validation contract")
    try:
        contract_path = Path(contract_path).resolve(strict=True)
    except (OSError, RuntimeError) as error:
        raise EvaluationGateError("The frozen validation contract must already exist") from error
    contract, contract_sha = _read_json(contract_path)
    checked = _validate_contract(contract, saved, checkpoint_sha, seeds, fault_profile)
    n, method = checked["arm"]
    history_directory = checked["history_directory"]
    block_prefix = f"holdout_{seeds[0]}_{seeds[-1]}"
    marker = history_directory / f"{block_prefix}_{n}_{method}.started.json"
    if marker.exists():
        raise EvaluationGateError(f"Holdout already opened for this model; preserve failure/evidence, no retry: {marker}")
    source_identity = _record_digest(checked["source_hashes"])
    global_marker = history_directory / f"{block_prefix}.started.json"
    binding = dict(format=MARKER_FORMAT, validation_contract_sha256=contract_sha,
        confirmation_index=checked["confirmation_index"], family_alpha=checked["family_alpha"],
        seeds=seeds, primary="collected_packets", source_identity_sha256=source_identity,
        fault_profile=fault_profile, evaluation_fault=fault_profile, history_directory=str(history_directory))
    try:
        _exclusive_json(global_marker, binding)
    except FileExistsError:
        existing, _ = _read_json(global_marker)
        if existing != binding:
            raise EvaluationGateError("This shared seed-set history is already bound to another immutable contract/index/fault")
    metadata = dict(binding, phase="holdout_validation", n_auv=n, method=method,
        profile=checked["profile"], model_training_step=checked["training_step"], training_seed=7,
        checkpoint_stage=checked["checkpoint_stage"], checkpoint_sha256=checkpoint_sha,
        holdout_opened=True, already_opened=False,
        seed_provenance=f"Complete preregistered confirmation{checked['confirmation_index']} set{seeds[0]}..{seeds[-1]}; opened by this exclusive start",
        started_at_utc=datetime.now(timezone.utc).isoformat(), started_marker=str(marker),
        seed_set_marker=str(global_marker),
        history_scope_limitation="Coordinator must pin this persistent directory; changing/removing history is not fresh confirmation",
        interpretation="Frozen-candidate confirmation; subsequent tuning makes these seeds previously seen")
    try:
        _exclusive_json(marker, metadata)
    except FileExistsError as error:
        raise EvaluationGateError(f"Holdout already opened; exclusive model marker exists: {marker}") from error
    return metadata
