"""Isolated, original-C07 2/3/4-AUV scale adaptation (12 October 2026)."""
VERSION = "c07-scale-20261012-v1"
