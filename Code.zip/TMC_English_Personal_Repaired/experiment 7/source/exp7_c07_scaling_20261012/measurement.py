"""Passive physical-substep safety and installed-path measurements.

Nothing here is an execution observation, motion controller, shield or reward.
The network's existing advance call receives an unchanged interpolation; this
observer samples its already-integrated endpoint after the native call.
"""
from itertools import combinations
import math
import numpy as np

def usable_installed_path(net,node,positions,at):
    version = net.active_version[node]
    current,seen = node,set()
    for _ in range(net.n_auvs):
        if current==0: return True
        if current in seen: return False
        seen.add(current)
        nxt = net._next_hop(current,0,version)
        if nxt is None: return False
        if np.linalg.norm(positions[current]-positions[nxt])>net.max_range: return False
        # This is an installed/geometrically usable bidirectional path, not
        # guaranteed stochastic packet reception or instantaneous RF sum-rate.
        if net._is_failed(current,nxt,at,at+1e-9) or net._is_failed(nxt,current,at,at+1e-9): return False
        current = nxt
    return current==0

class PhysicalAudit:
    def __init__(self,env):
        self.env=env
        self.samples=[]
        self.previous_collision=np.zeros(env.cfg.n_auv*(env.cfg.n_auv-1)//2,bool)
        self.previous_boundary=np.zeros(env.cfg.n_auv,bool)
        self.collision_onsets=self.boundary_onsets=0
        original=env.network.advance
        self._original_advance=original
        def advance(end,positions):
            result=original(end,positions)
            xy=(positions(end) if callable(positions) else positions)[1:1+env.cfg.n_auv,:2]
            distances=[float(np.linalg.norm(xy[i]-xy[j])) for i,j in combinations(range(env.cfg.n_auv),2)]
            collisions=np.array([d<env.cfg.min_separation for d in distances])
            excursion=np.linalg.norm(np.maximum(-xy,0)+np.maximum(xy-env.cfg.area_size,0),axis=1)
            boundary=excursion>0
            self.collision_onsets+=int(np.sum(collisions&~self.previous_collision))
            self.boundary_onsets+=int(np.sum(boundary&~self.previous_boundary))
            self.previous_collision,self.previous_boundary=collisions,boundary
            self.samples.append(dict(time_s=float(end),collision_pairs=int(np.sum(collisions)),
                boundary_auvs=int(np.sum(boundary)),minimum_separation_m=min(distances),
                maximum_excursion_m=float(np.max(excursion))))
            return result
        env.network.advance=advance

    def finalize(self):
        cfg=self.env.cfg
        h=cfg.dt/cfg.substeps
        expected=self.env.step_count*cfg.substeps
        if len(self.samples)!=expected: raise ValueError("Physical substep audit cadence changed")
        pair_s=len(self.samples)*h*len(self.previous_collision)
        auv_s=len(self.samples)*h*cfg.n_auv
        collision_s=sum(row["collision_pairs"] for row in self.samples)*h
        boundary_s=sum(row["boundary_auvs"] for row in self.samples)*h
        return dict(physical_substeps=len(self.samples),had_collision=collision_s>0,had_boundary=boundary_s>0,
            had_any_violation=collision_s>0 or boundary_s>0,collision_pair_s=collision_s,observation_pair_s=pair_s,
            boundary_auv_s=boundary_s,observation_auv_s=auv_s,collision_onsets=self.collision_onsets,
            boundary_onsets=self.boundary_onsets,
            minimum_separation_m=min(row["minimum_separation_m"] for row in self.samples),
            maximum_excursion_m=max(row["maximum_excursion_m"] for row in self.samples),
            definition="Original substep endpoints; native absorbing failure unmodified; no continuous-time guarantee")
