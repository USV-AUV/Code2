"""Opt-in P0 cursor copies of existing native events; never execution state.

This module uses only standard-library record operations. It installs no hook,
calls no environment/network method, observes no cache/queue/mask/actor state,
and writes no file. Construct externally after reset and explicitly drain at a
step boundary. A missing stream is unavailable evidence, not an observed zero.
"""
from __future__ import annotations

import inspect
import json
import math


FORMAT = "c07_passive_native_event_journal_v1"
STREAMS = (
    ("net.mac_events", "net", "mac_events"),
    ("env.mac_scheduler_events", "env", "mac_scheduler_events"),
    ("env.c04_task_events", "env", "c04_task_events"),
    ("env.c06_task_events", "env", "c06_task_events"),
    ("env.c07_task_events", "env", "c07_task_events"),
    ("env.service_end_events", "env", "service_end_events"),
)
_MISSING = object()


class PassiveJournalContractError(ValueError):
    """Preserve native state and reject an invalid passive stream contract."""


def _require(condition, message):
    if not condition:
        raise PassiveJournalContractError(message)


def _stored(owner, name):
    if owner is _MISSING or owner is None:
        return _MISSING
    # Unlike getattr, this never runs a property, __getattr__ or custom lookup.
    value = inspect.getattr_static(owner, name, _MISSING)
    _require(not isinstance(value, property) and not inspect.isdatadescriptor(value),
             "Passive journal requires a simple stored attribute: " + name)
    return value


def _json_copy(value, path, ancestors=None):
    """Copy only plain data; no to_dict/tolist/default callback or custom type."""
    kind = type(value)
    if value is None or kind in (bool, int, str):
        return value
    if kind is float:
        _require(math.isfinite(value), "Nonfinite passive value: " + path)
        return value
    _require(kind in (dict, list, tuple), "Unsupported non-JSON passive value: " + path)
    ancestors = set() if ancestors is None else ancestors
    _require(id(value) not in ancestors, "Cyclic passive value: " + path)
    _require(len(ancestors) < 64, "Passive event nesting exceeds64: " + path)
    nested = ancestors | {id(value)}
    if kind is dict:
        _require(all(type(key) is str for key in value), "Passive object keys must be strings: " + path)
        return {key: _json_copy(item, path + "." + key, nested) for key, item in value.items()}
    return [_json_copy(item, path + "[" + str(index) + "]", nested) for index, item in enumerate(value)]


def _native_time(event, stream, index):
    if "time" not in event:
        return None, "missing"
    value = event["time"]
    if value is None:
        return None, "null"
    _require(type(value) in (int, float) and math.isfinite(value),
             "Native time must be finite numeric or explicitly missing/null: " + stream + "[" + str(index) + "]")
    return value, "recorded"


class PassiveEventJournal:
    """One explicit episode binding; only observer-owned cursors are mutated.

    Producers must append immutable event dictionaries to the same plain lists.
    Replacement/shrink/consumed-entry replacement or reorder are rejected. Old
    event contents are not repeatedly serialized or rehashed: their immutability
    is a producer contract. Returned snapshots never alias a native dictionary.
    A new reset/network/list requires a new explicit journal, never auto-rebind.
    """

    def __init__(self, env, network=None):
        _require(env is not None, "Explicit env binding is required")
        self._env = env
        self._external_network = network is not None
        self._network = network if self._external_network else _stored(env, "network")
        self._bindings = {}
        self._consumed = {}
        self._drains = 0
        self._last_context = None
        for stream, owner_name, attribute in STREAMS:
            owner = self._network if owner_name == "net" else env
            source = _stored(owner, attribute)
            _require(source is _MISSING or type(source) is list,
                     "Native passive stream must be a plain list or absent: " + stream)
            self._bindings[stream] = source
            self._consumed[stream] = []

    def drain(self, *, step_end, time_s):
        """Return new records/statistics only; never infer native global order.

        Call context comes from the external evaluator, not a behavior getter.
        All streams validate before any cursor advances, so a failed drain can
        be repaired/retried without silently consuming a preceding good stream.
        """
        _require(type(step_end) is int and step_end >= 0, "step_end must be a nonnegative integer, not bool")
        _require(type(time_s) in (int, float) and math.isfinite(time_s) and time_s >= 0,
                 "time_s must be finite nonnegative numeric, not bool")
        context = dict(step=step_end, time_s=time_s)
        if self._last_context is not None:
            _require(step_end >= self._last_context["step"] and time_s >= self._last_context["time_s"],
                     "Step-end context may not move backwards")
        if not self._external_network:
            _require(_stored(self._env, "network") is self._network,
                     "Native network binding replaced; explicitly create a new episode journal")
        records, stream_statistics, prepared = [], {}, {}
        for stream, owner_name, attribute in STREAMS:
            owner = self._network if owner_name == "net" else self._env
            source = _stored(owner, attribute)
            bound = self._bindings[stream]
            _require(source is bound, "Native stream replaced/appeared/disappeared; new journal required: " + stream)
            if bound is _MISSING:
                stream_statistics[stream] = dict(availability="missing", native_length=None,
                    previous_cursor=None, next_cursor=None, records_copied=None, native_times_missing_or_null=None)
                continue
            _require(type(source) is list, "Native passive stream no longer a plain list: " + stream)
            consumed = self._consumed[stream]
            cursor = len(consumed)
            _require(len(source) >= cursor, "Native append-only stream shrank: " + stream)
            _require(all(source[index] is old for index, old in enumerate(consumed)),
                     "Native consumed prefix entry replaced/reordered: " + stream)
            prepared[stream] = list(source)
            missing_times = 0
            for index in range(cursor, len(source)):
                event = source[index]
                _require(type(event) is dict, "Native event must be a plain dictionary: " + stream + "[" + str(index) + "]")
                native_time, time_status = _native_time(event, stream, index)
                missing_times += time_status != "recorded"
                records.append(dict(format=FORMAT, stream=stream, stream_index=index,
                    recorded_at_step_end=dict(context), native_time_s=native_time,
                    native_time_status=time_status, cross_stream_global_order="unknown",
                    native_record=_json_copy(event, stream + "[" + str(index) + "]")))
            stream_statistics[stream] = dict(availability="available", native_length=len(source),
                previous_cursor=cursor, next_cursor=len(source), records_copied=len(source)-cursor,
                native_times_missing_or_null=missing_times)
        statistics = dict(drain_calls=self._drains+1, records_copied=len(records), streams=stream_statistics,
            missing_streams=[stream for stream, state in stream_statistics.items() if state["availability"] == "missing"],
            cross_stream_global_order="unknown",
            record_list_order="fixed stream enumeration then native stream_index; serialization order only",
            cursor_contract="same append-only list and consumed-entry identities; prior content immutability is producer-owned")
        result = dict(format=FORMAT, recorded_at_step_end=dict(context), records=records, statistics=statistics,
            execution_observation=False, root_information_source=False)
        # Confirm serialization before committing this observer's cursors.
        try:
            json.dumps(result, ensure_ascii=False, allow_nan=False)
        except (TypeError, ValueError, OverflowError) as error:
            raise PassiveJournalContractError("Passive records are not JSON serializable") from error
        for stream, consumed in prepared.items():
            self._consumed[stream] = consumed
        self._last_context = context
        self._drains += 1
        return result


def make_passive_journal(env=None, *, enabled=False, network=None):
    """Disabled by default; explicit external opt-in, no hook/file/RNG work."""
    _require(type(enabled) is bool, "enabled must be bool")
    if not enabled:
        return None
    return PassiveEventJournal(env, network=network)
