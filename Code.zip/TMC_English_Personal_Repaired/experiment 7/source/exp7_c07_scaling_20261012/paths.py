"""Resolve either the research checkout or a standalone code-only package."""
from pathlib import Path
import sys

PACKAGE = Path(__file__).resolve().parent
EXPERIMENT = PACKAGE.parent
PROJECT = EXPERIMENT.parent
SOURCE = EXPERIMENT / "c07_source"
REFERENCE = EXPERIMENT / "reference"
if not SOURCE.is_dir():
    SOURCE = PROJECT.parent / "experiment 1" / "source"
if not REFERENCE.is_dir():
    REFERENCE = PROJECT.parent / "experiment 1"
if not (SOURCE / "v6_candidates" / "c07" / "environment.py").is_file():
    raise FileNotFoundError("Original C07 dependency source is missing")
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

def reference_config():
    return REFERENCE / "provenance" / "frozen_config.json"

def reference_metadata(method):
    return REFERENCE / "models" / "45w" / method / "metadata.json"
