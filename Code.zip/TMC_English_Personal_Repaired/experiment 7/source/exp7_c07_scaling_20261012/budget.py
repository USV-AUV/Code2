"""Physical-work budget accounting; this module never trains or simulates.

The default development limit is 100,000 *aggregate* environment transitions.
``per_model`` must be chosen explicitly when creating the ledger. A model's
identity includes its arm, seed and complete declared configuration; changing
its label cannot reset its budget. Retries and discarded work remain charged.

``requested_steps`` reserves additional physical work in ONE attempt.
``executed_steps`` is that attempt's cumulative physical work, not a checkpoint
counter. Thus a 30k failed attempt resumed from a 20k checkpoint still costs
30k before any continuation. Updates should be persisted before publishing a
checkpoint and at the executor's agreed accounting cadence. After a crash an
active reservation is retained; reconcile its actual work before finishing it.

Full-stage accounting is separate and requires the explicit confirmation below
for every reservation. It never rewrites or waives development consumption.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile
import time


DEVELOPMENT_CAP = 100_000
FULL_CONFIRMATION = "I explicitly authorize full training"
FORMAT = "c07-scaling-physical-budget-v1"
MODES = ("aggregate", "per_model")
FINISH_STATUSES = ("completed", "failed", "discarded")


class BudgetError(ValueError):
    """Invalid identity, accounting transition or reservation."""


class BudgetExceeded(BudgetError):
    """Capacity unavailable, or actual executor work exceeded its reservation."""


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise BudgetError(f"{name} must be an integer >= {minimum}")
    return value


def _name(value, name):
    if not isinstance(value, str) or not value.strip() or len(value) > 512:
        raise BudgetError(f"{name} must be a nonempty string of at most 512 characters")
    return value


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _configuration(config):
    if not isinstance(config, dict):
        raise BudgetError("config must contain the complete declared configuration as a JSON object")
    try:
        encoded = json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False)
        value = json.loads(encoded)
    except (TypeError, ValueError) as error:
        raise BudgetError("config must be finite, JSON serializable data") from error
    return value, hashlib.sha256(encoded.encode("utf-8")).hexdigest()


@contextmanager
def _file_lock(path, timeout=10.0):
    """Separate lock file; atomic replacement must not replace the locked inode.

    Windows uses a one-byte msvcrt advisory lock. POSIX uses flock so isolated
    unit tests can run on either platform. All ledger accesses use this lock.
    """
    if not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or timeout < 0:
        raise BudgetError("lock timeout must be finite and nonnegative")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as handle:
        if os.fstat(handle.fileno()).st_size == 0:
            handle.write(b"\0")
            handle.flush()
            os.fsync(handle.fileno())
        start = time.monotonic()
        while True:
            handle.seek(0)
            try:
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as error:
                if time.monotonic() - start >= timeout:
                    raise TimeoutError(f"Budget ledger lock is busy: {path}") from error
                time.sleep(min(.05, max(0., timeout - (time.monotonic() - start))))
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _atomic_json(path, value):
    """Flush a complete same-directory temporary file before atomic replace."""
    path = Path(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix=path.name + ".", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        temporary = None
        if os.name != "nt":
            descriptor = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


class BudgetLedger:
    """Reserve, update and finish independent attempts under an immutable cap.

    A missing ledger is created. ``fresh=True`` additionally rejects an existing
    ledger. Reopening must specify the same mode and limit; defaults never
    silently switch an existing per-model ledger to aggregate accounting.
    """

    def __init__(self, path, mode="aggregate", limit=DEVELOPMENT_CAP, *, fresh=False,
                 lock_timeout=10.0,allow_extended_development=False):
        if mode not in MODES:
            raise BudgetError(f"mode must be one of {MODES}")
        _integer(limit, "development limit", 1)
        if limit > DEVELOPMENT_CAP and not allow_extended_development:
            raise BudgetError("Explicit iterative-development authorization is required above the100k reference endpoint")
        self.path = Path(path).resolve()
        self.lock_path = self.path.with_name(self.path.name + ".lock")
        self.mode, self.limit, self.lock_timeout = mode, limit, lock_timeout
        with _file_lock(self.lock_path, self.lock_timeout):
            if self.path.exists():
                if fresh:
                    raise FileExistsError(f"A fresh budget ledger is required: {self.path}")
                self._read()
            else:
                _atomic_json(self.path, dict(format=FORMAT, mode=mode, development_limit=limit,
                                             created_at=_stamp(), attempts=[]))

    def _read(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            raise BudgetError("Budget ledger is unreadable; do not recreate or reset it") from error
        if (not isinstance(data, dict) or data.get("format") != FORMAT or
                data.get("mode") != self.mode or data.get("development_limit") != self.limit or
                not isinstance(data.get("attempts"), list)):
            raise BudgetError("Ledger format, mode or development limit differs")
        ids, outputs, identities, models, active = set(), set(), {}, {}, set()
        for item in data["attempts"]:
            if not isinstance(item, dict):
                raise BudgetError("Invalid attempt record")
            try:
                attempt = _name(item["attempt_id"], "attempt_id")
                model = _name(item["model_id"], "model_id")
                arm = _name(item["arm"], "arm")
                seed = _integer(item["seed"], "seed")
                config, fingerprint = _configuration(item["config"])
                requested = _integer(item["requested_steps"], "requested_steps", 1)
                executed = _integer(item["executed_steps"], "executed_steps")
                _integer(item["resume_from_step"], "resume_from_step")
                stage, status = item["stage"], item["status"]
                output = os.path.normcase(str(Path(item["output_dir"]).resolve()))
            except (KeyError, TypeError, ValueError) as error:
                raise BudgetError("Malformed attempt record") from error
            if (attempt in ids or output in outputs or stage not in ("development", "full") or
                    status not in ("active", *FINISH_STATUSES) or item.get("config_sha256") != fingerprint or
                    item.get("reservation_overrun") is not (executed > requested) or
                    (stage == "full" and item.get("full_training_confirmation") != FULL_CONFIRMATION)):
                raise BudgetError("Attempt identity, stage, counter or authorization is invalid")
            identity = (arm, seed, fingerprint)
            if ((model in models and models[model] != identity) or
                    (identity in identities and identities[identity] != model)):
                raise BudgetError("Model identity was changed or relabeled")
            if status == "active" and model in active:
                raise BudgetError("Duplicate active model attempts")
            ids.add(attempt)
            outputs.add(output)
            identities[identity], models[model] = model, identity
            if status == "active":
                active.add(model)
        return data

    @staticmethod
    def _usage(data, stage="development", model_id=None):
        rows = [item for item in data["attempts"] if item["stage"] == stage and
                (model_id is None or item["model_id"] == model_id)]
        actual = sum(item["executed_steps"] for item in rows)
        unexecuted_reservations = sum(max(0, item["requested_steps"] - item["executed_steps"])
                                     for item in rows if item["status"] == "active")
        return dict(executed_steps=actual, active_unexecuted_reserved_steps=unexecuted_reservations,
                    capacity_used=actual + unexecuted_reservations)

    def snapshot(self):
        """Return complete attempt evidence, total usage and per-model usage."""
        with _file_lock(self.lock_path, self.lock_timeout):
            data = self._read()
            data["development_usage"] = self._usage(data)
            data["full_usage"] = self._usage(data, "full")
            data["development_usage_by_model"] = {
                model: self._usage(data, model_id=model)
                for model in sorted({item["model_id"] for item in data["attempts"]})}
            return copy.deepcopy(data)

    def reserve(self, attempt_id, model_id, arm, seed, config, output_dir, requested_steps,
                *, resume_from_step=0, resume_parent_attempt=None, stage="development",
                full_training_confirmation=None):
        """Create a fresh output directory and charge its active reservation.

        Full-stage reservations require the exact CLI confirmation phrase; this
        does not authorize any execution and does not reduce development usage.
        A resume parent must already be closed, match the model and stage, and
        cover the declared checkpoint step. Earlier failed work remains charged.
        """
        attempt_id = _name(attempt_id, "attempt_id")
        model_id, arm = _name(model_id, "model_id"), _name(arm, "arm")
        _integer(seed, "seed")
        _integer(requested_steps, "requested_steps", 1)
        _integer(resume_from_step, "resume_from_step")
        config, fingerprint = _configuration(config)
        if stage not in ("development", "full"):
            raise BudgetError("stage must be development or full")
        if stage == "full" and full_training_confirmation != FULL_CONFIRMATION:
            raise BudgetError("Full stage requires --confirm-full-training with the explicit confirmation phrase")
        if stage == "development" and full_training_confirmation is not None:
            raise BudgetError("Full authorization cannot alter a development reservation")
        if resume_from_step and resume_parent_attempt is None:
            raise BudgetError("A nonzero checkpoint step requires a recorded, finished resume parent")
        output = Path(output_dir).resolve()
        with _file_lock(self.lock_path, self.lock_timeout):
            data = self._read()
            if any(item["attempt_id"] == attempt_id for item in data["attempts"]):
                raise BudgetError("Attempt IDs are never reusable, including finished or failed attempts")
            if output.exists() or any(os.path.normcase(item["output_dir"]) == os.path.normcase(str(output))
                                      for item in data["attempts"]):
                raise FileExistsError(f"A fresh, never-used output directory is required: {output}")
            identity = (arm, seed, fingerprint)
            for item in data["attempts"]:
                previous_identity = (item["arm"], item["seed"], item["config_sha256"])
                if item["model_id"] == model_id:
                    if previous_identity != identity:
                        raise BudgetError("A model's arm, seed and configuration cannot change")
                    if item["status"] == "active":
                        raise BudgetError("Finish/reconcile the existing active model attempt before resuming")
                elif previous_identity == identity:
                    raise BudgetError("Relabeling an identical model cannot reset its development budget")
            if resume_parent_attempt is not None:
                parent = next((item for item in data["attempts"]
                               if item["attempt_id"] == resume_parent_attempt), None)
                if (parent is None or parent["status"] == "active" or parent["model_id"] != model_id or
                        parent["stage"] != stage or resume_from_step >
                        parent["resume_from_step"] + parent["executed_steps"]):
                    raise BudgetError("Resume parent identity, stage, completion or checkpoint step differs")
            if stage == "development":
                usage = self._usage(data, model_id=model_id if self.mode == "per_model" else None)
                if usage["capacity_used"] + requested_steps > self.limit:
                    raise BudgetExceeded(f"Development {self.mode} capacity: {usage['capacity_used']} used/reserved + "
                                         f"{requested_steps} requested > {self.limit}")
            record = dict(attempt_id=attempt_id, model_id=model_id, arm=arm, seed=seed,
                          config=config, config_sha256=fingerprint, output_dir=str(output),
                          stage=stage, status="active", requested_steps=requested_steps,
                          executed_steps=0, resume_from_step=resume_from_step,
                          resume_parent_attempt=resume_parent_attempt, reservation_overrun=False,
                          full_training_confirmation=full_training_confirmation,
                          created_at=_stamp(), updated_at=_stamp(), finished_at=None)
            # If publication fails, reserve raises and no executor may start;
            # leave the new directory visible for diagnosis rather than delete it.
            output.mkdir(parents=True, exist_ok=False)
            data["attempts"].append(record)
            _atomic_json(self.path, data)
            return copy.deepcopy(record)

    def _record_progress(self, attempt_id, executed_steps, status=None):
        _integer(executed_steps, "executed_steps")
        with _file_lock(self.lock_path, self.lock_timeout):
            data = self._read()
            record = next((item for item in data["attempts"] if item["attempt_id"] == attempt_id), None)
            if record is None or record["status"] != "active":
                raise BudgetError("Only a recorded active attempt can be updated or finished")
            if executed_steps < record["executed_steps"]:
                raise BudgetError("Executed work cannot decrease after checkpoint rollback")
            record["executed_steps"] = executed_steps
            record["updated_at"] = _stamp()
            record["reservation_overrun"] = executed_steps > record["requested_steps"]
            if status is not None:
                record["status"], record["finished_at"] = status, _stamp()
            _atomic_json(self.path, data)
            # Actual overrun is still durably charged. Refusing to record it
            # would hide work which the executor has already performed.
            if record["reservation_overrun"]:
                raise BudgetExceeded("Actual work exceeded its reservation; the overrun was recorded, never forgiven")
            return copy.deepcopy(record)

    def update(self, attempt_id, executed_steps):
        """Persist this attempt's cumulative physical work; monotonic only."""
        return self._record_progress(attempt_id, executed_steps)

    def finish(self, attempt_id, executed_steps, *, status="completed"):
        """Close one attempt, retaining actual work and releasing unused reserve.

        A crash is never treated as zero work automatically: first reconcile
        actual execution, then explicitly finish failed/discarded attempts.
        """
        if status not in FINISH_STATUSES:
            raise BudgetError(f"finish status must be one of {FINISH_STATUSES}")
        return self._record_progress(attempt_id, executed_steps, status)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ledger", required=True, type=Path)
    parser.add_argument("--mode", choices=MODES, default="aggregate")
    parser.add_argument("--limit", type=int, default=DEVELOPMENT_CAP)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("create", help="Create a new ledger; never overwrite an existing one")
    sub.add_parser("status")
    reserve = sub.add_parser("reserve")
    reserve.add_argument("--attempt-id", required=True)
    reserve.add_argument("--model-id", required=True)
    reserve.add_argument("--arm", required=True)
    reserve.add_argument("--seed", required=True, type=int)
    reserve.add_argument("--config", required=True, type=Path)
    reserve.add_argument("--output", required=True, type=Path)
    reserve.add_argument("--requested-steps", required=True, type=int)
    reserve.add_argument("--resume-from-step", type=int, default=0)
    reserve.add_argument("--resume-parent-attempt")
    reserve.add_argument("--stage", choices=("development", "full"), default="development")
    reserve.add_argument("--confirm-full-training", metavar='"I explicitly authorize full training"',
                         help="Separate explicit full-stage confirmation; never inferred from a development command")
    for command in ("update", "finish"):
        action = sub.add_parser(command)
        action.add_argument("--attempt-id", required=True)
        action.add_argument("--executed-steps", required=True, type=int)
        if command == "finish":
            action.add_argument("--status", choices=FINISH_STATUSES, default="completed")
    args = parser.parse_args(argv)
    ledger = BudgetLedger(args.ledger, args.mode, args.limit, fresh=args.command == "create")
    if args.command == "reserve":
        result = ledger.reserve(args.attempt_id, args.model_id, args.arm, args.seed,
            json.loads(args.config.read_text(encoding="utf-8")), args.output, args.requested_steps,
            resume_from_step=args.resume_from_step, resume_parent_attempt=args.resume_parent_attempt,
            stage=args.stage, full_training_confirmation=args.confirm_full_training)
    elif args.command == "update":
        result = ledger.update(args.attempt_id, args.executed_steps)
    elif args.command == "finish":
        result = ledger.finish(args.attempt_id, args.executed_steps, status=args.status)
    else:
        result = ledger.snapshot()
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
