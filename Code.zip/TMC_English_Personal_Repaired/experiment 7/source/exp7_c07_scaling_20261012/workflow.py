"""Isolated bindings around the unchanged original C07 long-budget learner.

This adapter is deliberately NOT based on the later R2 shared/local reward
experiment. Old checkpoints are rejected before any format migration.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from dataclasses import asdict, fields
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import threading
from types import FunctionType, MethodType
import uuid

from . import VERSION
from .paths import PACKAGE, SOURCE, reference_config, reference_metadata
from .environment import (ScaleConfig, ScaledC07Env, build_settings, canonical_method,
                          PROFILES,MethodOptions,environment_class,validate_declared_selector,DeclaredV11C07Env,DeclaredJointC07Env)
from .root_budget import ROOT_BUDGET_PROFILE, build_root_budget_method_options
from . import n4_child_h2, joint_clocks
from .budget import BudgetLedger, FULL_CONFIRMATION
from usv_auv.deploy import load_checkpoint as raw_load
from usv_auv.train import atomic_json, file_digest
from v6_campaigns.c07_1m_20260919 import workflow as native

TRAIN_FORMAT = "original-c07-scale-20261012-training-v1"
INFERENCE_FORMAT = "original-c07-scale-20261012-inference-v1"
_BINDING_LOCK = threading.RLock()
_WRITER_WRAPPER_MARKER = object()
_native_sources = native.sources
_ORIGINAL_POLICY = native.Policy
_ORIGINAL_POLICY_VALIDATE = native.Policy.__dict__["validate_environment"]
_ORIGINAL_POLICY_MEMBERS = dict(native.Policy.__dict__)
_ORIGINAL_POLICY_CODES = {name:value.__code__ for name,value in native.Policy.__dict__.items() if type(value) is FunctionType}
_ORIGINAL_POLICY_CALLABLE_META = {name:(deepcopy(value.__defaults__),deepcopy(value.__kwdefaults__),deepcopy(value.__annotations__))
    for name,value in native.Policy.__dict__.items() if type(value) is FunctionType}
_STRICT_PROFILES = (ROOT_BUDGET_PROFILE,n4_child_h2.PROFILE,*joint_clocks.PROFILES)

def source_hashes():
    original=_native_sources()
    reference=json.loads(reference_metadata("full_v6").read_text(encoding="utf-8-sig"))["source_hashes"]
    if any(reference.get(key)!=value for key,value in original.items()):
        raise ValueError("Original C07 source differs from authenticated2AUV reference")
    hashes = {"original/"+key:value for key,value in original.items()}
    hashes["measurement/summarize_tmc_retest.py"]=file_digest(SOURCE/"scripts"/"summarize_tmc_retest.py")["sha256"]
    for path in sorted(PACKAGE.rglob("*.py")):
        hashes["adapter/"+path.relative_to(PACKAGE).as_posix()] = file_digest(path)["sha256"]
    refs = {"config":reference_config(),"full":reference_metadata("full_v6"),
            "usde_only":reference_metadata("usde_only_v6")}
    hashes.update({"reference/"+key:file_digest(path)["sha256"] for key,path in refs.items()})
    return hashes

def digest_json(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()

def json_value_type_exact(left,right):
    """Compare declaration JSON values without bool/int/float coercion."""
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return (all(type(key) is str for key in left) and
                all(type(key) is str for key in right) and left.keys()==right.keys() and
                all(json_value_type_exact(left[key],right[key]) for key in left))
    if type(left) is list:
        return len(left)==len(right) and all(json_value_type_exact(a,b) for a,b in zip(left,right))
    if type(left) is float:
        return math.isfinite(left) and math.isfinite(right) and left==right
    if left is None or type(left) in (str,int,bool):
        return left==right
    return False

def declaration(n_auv,n_sensors,method,profile="adaptive_v1",faults=None):
    cfg,mo,ro,diagnostics = build_settings(n_auv,n_sensors,method,profile,faults)
    return dict(version=VERSION, profile=profile, n_auv=n_auv, n_sensors=n_sensors,
        method=canonical_method(method), config=cfg.to_dict(), method_options=asdict(mo), routing_options=asdict(ro),
        learning=asdict(native.learning_config(cfg)), training_protocol=native.training_protocol(cfg,False),
        scale_diagnostics=diagnostics, old_weights_allowed=False,
        reward="original same team reward to every TD3 replay; original topology_reward",
        ending="original collision/boundary absorbing terminal; unfinished timeout macro discarded")

def _context_method_options_factory(context):
    """A declaration-only bridge for native reconstructors, scoped by bindings.

    Native default_method_options must keep creating the untouched original
    defaults. Complete V9 records require a type-exact full declaration/SHA;
    n3/n4 additionally require common30 and their exact registered budget.
    Authenticated n2 still constructs the unchanged original option class.
    No original MethodOptions method/class/source is patched or widened.
    """
    frozen_context=deepcopy(context)
    field_names=frozenset(field.name for field in fields(MethodOptions))
    authenticated=None
    def authenticate():
        nonlocal authenticated
        if authenticated is not None:
            return authenticated
        declared=frozen_context.get("declaration") if type(frozen_context) is dict else None
        if (type(declared) is not dict or frozen_context.get("version")!=VERSION or
                frozen_context.get("profile") not in _STRICT_PROFILES or
                declared.get("profile")!=frozen_context.get("profile") or frozen_context.get("profile") not in PROFILES or
                type(declared.get("n_auv")) is not int or declared["n_auv"] not in (2,3,4) or
                type(declared.get("n_sensors")) is not int or declared["n_sensors"]<declared["n_auv"] or
                (declared["n_auv"]>2 and declared["n_sensors"]!=30) or
                type(declared.get("config")) is not dict or
                type(declared.get("method_options")) is not dict):
            raise ValueError("V9 MethodOptions require an authenticated original-n2 or n3/n4-common30 declaration context")
        expected=declaration(declared["n_auv"],declared["n_sensors"],declared.get("method"),
            frozen_context["profile"],declared["config"].get("faults"))
        if (type(frozen_context.get("declaration_sha256")) is not str or
                frozen_context["declaration_sha256"]!=digest_json(expected) or
                not json_value_type_exact(declared,expected)):
            raise ValueError("V9 MethodOptions declaration/SHA or JSON value/type identity mismatch")
        authenticated=expected
        return authenticated
    def factory(*args,**kwargs):
        # Keep the actual native default constructor path and bool validation.
        if not args and set(kwargs)=={"mac_enabled"}:
            return MethodOptions(**kwargs)
        is_v9=type(frozen_context) is dict and frozen_context.get("profile") in _STRICT_PROFILES
        if not args and set(kwargs)==field_names and is_v9:
            expected=authenticate()
            if not json_value_type_exact(kwargs,expected["method_options"]):
                raise ValueError("V9 MethodOptions must exactly match the context declaration by JSON value and type")
            if expected["profile"] in joint_clocks.PROFILES:
                return joint_clocks.build_options(expected["n_auv"],expected["n_sensors"],
                    expected["profile"],expected["method"],kwargs)
            if expected["profile"]==n4_child_h2.PROFILE:
                return n4_child_h2.build_options(expected["n_auv"],expected["n_sensors"],
                    expected["profile"],expected["method"],kwargs)
            return build_root_budget_method_options(expected["n_auv"],expected["n_sensors"],
                ROOT_BUDGET_PROFILE,kwargs,registered_profiles=PROFILES)
        # Old contexts and partial/non-keyword native calls
        # never reach the expanded pool domain. Original errors stay original.
        return MethodOptions(*args,**kwargs)
    return factory

def _binding_writer_target(writer,kind):
    """Skip only our tagged metadata wrappers; preserve native/mock writers."""
    if type(writer) is FunctionType and writer.__dict__.get("_scale_writer_marker") is _WRITER_WRAPPER_MARKER:
        if writer.__dict__.get("_scale_writer_kind")!=kind:
            raise RuntimeError("Mismatched scoped metadata writer kind")
        return writer.__dict__["_scale_writer_target"]
    return writer

def validate_checkpoint_metadata(saved):
    """Same loader checks, also before an H2 facade constructs native Policy."""
    if saved.get("format") not in (TRAIN_FORMAT,INFERENCE_FORMAT):
        raise ValueError("Old C07, R2, pilot and transferred weights are not new-scale checkpoints")
    context = saved.get("scale_context")
    if not isinstance(context,dict) or context.get("version")!=VERSION or context.get("profile") not in PROFILES:
        raise ValueError("Missing authenticated new-scale declaration")
    expected = declaration(saved["environment_config"]["n_auv"],saved["environment_config"]["n_sensors"],
        saved["method_id"],context["profile"],saved["environment_config"]["faults"])
    exact=json_value_type_exact if context["profile"] in _STRICT_PROFILES else lambda a,b:a==b
    if context.get("declaration_sha256") != digest_json(expected):
        raise ValueError("Scale declaration/configuration does not match this adapter")
    if not exact(context.get("declaration"),expected):
        raise ValueError("Checkpoint carries an inconsistent scale declaration")
    for key,actual in (("environment_config",expected["config"]),("method_options",expected["method_options"]),
                       ("routing_options",expected["routing_options"])):
        if not exact(saved.get(key),actual):
            raise ValueError("Frozen new-scale "+key+" mismatch")
    if saved.get("source_hashes")!=source_hashes():
        raise ValueError("New-scale checkpoint source identities changed")
    cfg = ScaleConfig.from_dict(expected["config"])
    native.validate_method_identity(saved)
    if saved.get("config_fingerprint")!=cfg.fingerprint or not exact(saved.get("learning_config"),expected["learning"]):
        raise ValueError("Checkpoint config/learner fingerprint differs from original C07")
    revision = asdict(native.RevisionLearningOptions(area_size=cfg.area_size,max_speed=cfg.max_speed,
        dt=cfg.dt,action_frame=cfg.action_frame))
    if not exact(saved.get("revision_learning_options"),revision) or not exact(saved.get("training_protocol"),expected["training_protocol"]):
        raise ValueError("Checkpoint learner/auxiliary loss/schedule was changed or used smoke overrides")
    cap = context.get("development_model_limit",100000) if context.get("stage")=="development" else 450000 if context.get("stage")=="full" else 0
    if type(saved.get("global_step")) is not int or not 0<=saved["global_step"]<=cap:
        raise ValueError("Checkpoint does not have a valid declared stage/budget")
    return saved

def load_new_checkpoint(path):
    # torch pickle: use only trusted, locally created checkpoints.
    return validate_checkpoint_metadata(raw_load(path))

def _authenticate_v11_context(context):
    require= n4_child_h2.require
    require(type(context) is dict and context.get("version")==VERSION and context.get("profile")==n4_child_h2.PROFILE,
        "Complete new V11 context required before native wiring")
    value=context.get("declaration")
    require(type(value) is dict and type(value.get("n_auv")) is int and value["n_auv"] in (2,3,4)
        and type(value.get("n_sensors")) is int and value["n_sensors"]==30 and type(value.get("config")) is dict,
        "Complete typed V11 scale declaration required")
    expected=declaration(value["n_auv"],30,value.get("method"),n4_child_h2.PROFILE,value["config"].get("faults"))
    require(json_value_type_exact(value,expected) and context.get("declaration_sha256")==digest_json(expected),
        "V11 complete declaration/type/SHA differs before native wiring")
    source_hashes()  # Original sources/reference and all new adapter files, no ENV/weights.
    return expected

class _V11NativeFacade:
    """Private entry facade; never assign to native.Policy or its class."""
    def __init__(self,context):
        self.context=deepcopy(context)
        self.owned_environments=[]
        _authenticate_v11_context(self.context)

    def __getattr__(self,name):
        return getattr(native,name)

    def Policy(self,checkpoint,*args,**kwargs):
        _authenticate_v11_context(self.context)
        saved=validate_checkpoint_metadata(checkpoint)
        if not json_value_type_exact(saved.get("scale_context"),self.context):
            raise ValueError("V11 facade Policy context differs from its authenticated scope")
        if (native.Policy is not _ORIGINAL_POLICY or set(_ORIGINAL_POLICY.__dict__)!=set(_ORIGINAL_POLICY_MEMBERS)
                or any(_ORIGINAL_POLICY.__dict__[name] is not value for name,value in _ORIGINAL_POLICY_MEMBERS.items())
                or any(_ORIGINAL_POLICY.__dict__[name].__code__ is not value for name,value in _ORIGINAL_POLICY_CODES.items())
                or any(not n4_child_h2.exact((_ORIGINAL_POLICY.__dict__[name].__defaults__,
                    _ORIGINAL_POLICY.__dict__[name].__kwdefaults__,_ORIGINAL_POLICY.__dict__[name].__annotations__),value)
                    for name,value in _ORIGINAL_POLICY_CALLABLE_META.items())
                or _ORIGINAL_POLICY.__dict__.get("validate_environment") is not _ORIGINAL_POLICY_VALIDATE):
            raise ValueError("Original native Policy class/global/validator changed")
        policy=_ORIGINAL_POLICY(saved,*args,**kwargs)
        original=policy.validate_environment
        if type(original) is not MethodType or original.__self__ is not policy or original.__func__ is not _ORIGINAL_POLICY_VALIDATE:
            raise ValueError("V11 facade must call the actual original native instance validator")
        original_make=policy.make_environment
        if type(original_make) is not MethodType or original_make.__self__ is not policy or original_make.__func__ is not _ORIGINAL_POLICY.__dict__["make_environment"]:
            raise ValueError("V11 facade must call the actual original native make_environment")
        making=ContextVar("private_V11_policy_make_ownership",default=None)
        profile=self.context["profile"]
        def validate(instance,env):
            current=making.get()
            if current is not None and isinstance(env,DeclaredV11C07Env) and not any(value is env for value in current):
                current.append(env)
            original(env)  # Preserve the original validator and error first.
            validate_declared_selector(env,profile)
        def make_environment(instance):
            current=[];token=making.set(current)
            try:
                env=original_make()
                if not any(value is env for value in current):
                    raise ValueError("Original make_environment did not validate its own returned environment")
                for value in current:
                    if not any(value is owned for owned in self.owned_environments):
                        self.owned_environments.append(value)
                return env
            except BaseException as error:
                self._cleanup_environments(current,error)
                raise
            finally:
                making.reset(token)
        policy.validate_environment=MethodType(validate,policy)
        policy.make_environment=MethodType(make_environment,policy)
        return policy

    @staticmethod
    def _cleanup_environments(environments,active_error=None):
        errors=[]
        for env in reversed(environments):
            try:
                if not isinstance(env,DeclaredV11C07Env):
                    raise ValueError("V11 scoped cleanup must not close a non-owned legacy/foreign environment")
                if getattr(env,"_v11_close_attempted",False):
                    previous=getattr(env,"_v11_close_error",None)
                    if previous is not None:
                        raise previous
                    env.verify_closed_identity()
                else:
                    env.close()
                    env.verify_closed_identity()
            except BaseException as error:
                errors.append(error)
        if active_error is not None:
            for error in errors:
                if error is not active_error:
                    active_error.add_note("Secondary owned V11 environment cleanup failure: "+repr(error))
            return
        if errors:
            primary=next((error for error in errors if not isinstance(error,Exception)),errors[0])
            for error in errors:
                if error is not primary:
                    primary.add_note("Secondary owned V11 environment cleanup failure: "+repr(error))
            raise primary

    def cleanup_owned(self,active_error=None):
        self._cleanup_environments(self.owned_environments,active_error)

def _authenticate_joint_context(context):
    require= joint_clocks.require
    require(type(context) is dict and context.get("version")==VERSION and context.get("profile") in joint_clocks.PROFILES,
        "Complete new Joint context required before native wiring")
    value=context.get("declaration")
    require(type(value) is dict and type(value.get("n_auv")) is int and value["n_auv"] in (2,3,4)
        and type(value.get("n_sensors")) is int and value["n_sensors"]==30 and type(value.get("config")) is dict,
        "Complete typed Joint scale declaration required")
    expected=declaration(value["n_auv"],30,value.get("method"),context["profile"],value["config"].get("faults"))
    require(json_value_type_exact(value,expected) and context.get("declaration_sha256")==digest_json(expected),
        "Joint complete declaration/type/SHA differs before native wiring")
    source_hashes()  # Original sources/reference and all new adapter files, no ENV/weights.
    return expected

class _JointNativeFacade:
    """Private entry facade; never assign to native.Policy or its class."""
    def __init__(self,context):
        self.context=deepcopy(context)
        self.owned_environments=[]
        _authenticate_joint_context(self.context)

    def __getattr__(self,name):
        return getattr(native,name)

    def Policy(self,checkpoint,*args,**kwargs):
        _authenticate_joint_context(self.context)
        saved=validate_checkpoint_metadata(checkpoint)
        if not json_value_type_exact(saved.get("scale_context"),self.context):
            raise ValueError("Joint facade Policy context differs from its authenticated scope")
        if (native.Policy is not _ORIGINAL_POLICY or set(_ORIGINAL_POLICY.__dict__)!=set(_ORIGINAL_POLICY_MEMBERS)
                or any(_ORIGINAL_POLICY.__dict__[name] is not value for name,value in _ORIGINAL_POLICY_MEMBERS.items())
                or any(_ORIGINAL_POLICY.__dict__[name].__code__ is not value for name,value in _ORIGINAL_POLICY_CODES.items())
                or any(not joint_clocks.exact((_ORIGINAL_POLICY.__dict__[name].__defaults__,
                    _ORIGINAL_POLICY.__dict__[name].__kwdefaults__,_ORIGINAL_POLICY.__dict__[name].__annotations__),value)
                    for name,value in _ORIGINAL_POLICY_CALLABLE_META.items())
                or _ORIGINAL_POLICY.__dict__.get("validate_environment") is not _ORIGINAL_POLICY_VALIDATE):
            raise ValueError("Original native Policy class/global/validator changed")
        policy=_ORIGINAL_POLICY(saved,*args,**kwargs)
        original=policy.validate_environment
        if type(original) is not MethodType or original.__self__ is not policy or original.__func__ is not _ORIGINAL_POLICY_VALIDATE:
            raise ValueError("Joint facade must call the actual original native instance validator")
        original_make=policy.make_environment
        if type(original_make) is not MethodType or original_make.__self__ is not policy or original_make.__func__ is not _ORIGINAL_POLICY.__dict__["make_environment"]:
            raise ValueError("Joint facade must call the actual original native make_environment")
        making=ContextVar("private_Joint_policy_make_ownership",default=None)
        profile=self.context["profile"]
        def validate(instance,env):
            current=making.get()
            if current is not None and isinstance(env,DeclaredJointC07Env) and not any(value is env for value in current):
                current.append(env)
            original(env)  # Preserve the original validator and error first.
            validate_declared_selector(env,profile)
        def make_environment(instance):
            current=[];token=making.set(current)
            try:
                env=original_make()
                if not any(value is env for value in current):
                    raise ValueError("Original make_environment did not validate its own returned environment")
                for value in current:
                    if not any(value is owned for owned in self.owned_environments):
                        self.owned_environments.append(value)
                return env
            except BaseException as error:
                self._cleanup_environments(current,error)
                raise
            finally:
                making.reset(token)
        policy.validate_environment=MethodType(validate,policy)
        policy.make_environment=MethodType(make_environment,policy)
        return policy

    @staticmethod
    def _cleanup_environments(environments,active_error=None):
        errors=[]
        for env in reversed(environments):
            try:
                if not isinstance(env,DeclaredJointC07Env):
                    raise ValueError("Joint scoped cleanup must not close a non-owned legacy/foreign environment")
                if getattr(env,"_joint_close_attempted",False):
                    previous=getattr(env,"_joint_close_error",None)
                    if previous is not None:
                        raise previous
                    env.verify_closed_identity()
                else:
                    env.close()
                    env.verify_closed_identity()
            except BaseException as error:
                errors.append(error)
        if active_error is not None:
            for error in errors:
                if error is not active_error:
                    active_error.add_note("Secondary owned Joint environment cleanup failure: "+repr(error))
            return
        if errors:
            primary=next((error for error in errors if not isinstance(error,Exception)),errors[0])
            for error in errors:
                if error is not primary:
                    primary.add_note("Secondary owned Joint environment cleanup failure: "+repr(error))
            raise primary

    def cleanup_owned(self,active_error=None):
        self._cleanup_environments(self.owned_environments,active_error)

@contextmanager
def bindings(context, *, cap=100000, on_step=None):
    """Scoped process-local wiring; never modify original source files."""
    with _BINDING_LOCK:
        is_v9=type(context) is dict and context.get("profile") in _STRICT_PROFILES
        bound_context=deepcopy(context) if is_v9 else context
        is_v11=type(bound_context) is dict and bound_context.get("profile")==n4_child_h2.PROFILE
        is_joint=type(bound_context) is dict and bound_context.get("profile") in joint_clocks.PROFILES
        if is_joint:
            _authenticate_joint_context(bound_context)
        if is_v11:
            _authenticate_v11_context(bound_context)
        base_environment=environment_class(bound_context["profile"]) if is_v11 or is_joint else ScaledC07Env
        names = ("Config","TaskV4Env","MethodOptions","sources","TRAIN_FORMAT","INFERENCE_FORMAT","MAX_TRAIN_STEPS",
                 "load_checkpoint","save_bundle","atomic_json")
        old = {name:getattr(native,name) for name in names}
        save_target=_binding_writer_target(old["save_bundle"],"save_bundle")
        publish_target=_binding_writer_target(old["atomic_json"],"atomic_json")
        class BoundEnvironment(base_environment):
            def __init__(self,*args,**kwargs):
                super().__init__(*args,**kwargs)
                # Native train setup constructs ENV before its try/finally.
                # Register every successfully constructed Joint ENV before
                # later reset/Agent/output/manifest setup can fail or cancel.
                # Legacy profiles retain their original lifetime behavior.
                if is_joint:
                    try:
                        if facade is None:
                            raise RuntimeError("Joint environment has no authenticated binding owner")
                        if not any(self is value for value in facade.owned_environments):
                            facade.owned_environments.append(self)
                    except BaseException as error:
                        _JointNativeFacade._cleanup_environments([self],error)
                        raise
            def step(self,*args,**kwargs):
                # Conservatively charge an invoked physical transition even
                # if partial integration throws before its fast-step counter.
                # Record BEFORE replay/Adam or a simulator exception can fail.
                if on_step is not None:
                    on_step()
                if is_v11 or is_joint:
                    validate_declared_selector(self,bound_context["profile"])
                return super().step(*args,**kwargs)
        def save_bundle(checkpoint,output,milestone=False):
            checkpoint = {**checkpoint,"scale_context":deepcopy(bound_context) if is_v9 else bound_context}
            save_target(checkpoint,output,milestone)
        def publish(value,path):
            if isinstance(value,dict) and Path(path).name in ("manifest.json","summary.json"):
                value = {**value,"scale_context":deepcopy(bound_context) if is_v9 else bound_context}
            publish_target(value,path)
        # An inner binding owns the metadata on its own writes. Calling an
        # outer wrapper would tag the same payload again with the wrong scope.
        # Tags exist only on these new local wrappers, never on native writers.
        for writer,kind,target in ((save_bundle,"save_bundle",save_target),
                                   (publish,"atomic_json",publish_target)):
            writer._scale_writer_marker=_WRITER_WRAPPER_MARKER
            writer._scale_writer_kind=kind
            writer._scale_writer_target=target
        replacements = dict(Config=ScaleConfig,TaskV4Env=BoundEnvironment,
            MethodOptions=_context_method_options_factory(bound_context),sources=source_hashes,
            TRAIN_FORMAT=TRAIN_FORMAT,INFERENCE_FORMAT=INFERENCE_FORMAT,MAX_TRAIN_STEPS=cap,
            load_checkpoint=load_new_checkpoint,save_bundle=save_bundle,atomic_json=publish)
        facade=None;active_error=None
        try:
            for name,value in replacements.items(): setattr(native,name,value)
            facade=_JointNativeFacade(bound_context) if is_joint else _V11NativeFacade(bound_context) if is_v11 else None
            yield facade if is_v11 or is_joint else native
        except BaseException as error:
            active_error=error
            raise
        finally:
            try:
                if facade is not None:
                    facade.cleanup_owned(active_error)
            finally:
                for name,value in old.items(): setattr(native,name,value)

def train_declared(args):
    training_faults={"reference":[],"original_c07":[{"src":0,"dst":1,"start":200.,"end":350.,"bidirectional":True}],
                     "direct1_outage":[{"src":0,"dst":1,"start":400.,"end":800.,"bidirectional":True}]}
    declared = declaration(args.auv,args.sensors,args.method,args.profile,
                           training_faults[args.fault])
    cfg = ScaleConfig.from_dict(declared["config"])
    method = canonical_method(args.method)
    stage = args.stage
    if stage not in ("development","full"):
        raise ValueError("Unknown training stage")
    if stage=="full" and args.confirm_full_training != FULL_CONFIRMATION:
        raise ValueError("Full training is prepared but needs later explicit authorization")
    configured_limit=getattr(args,"development_limit",100000)
    if type(configured_limit)is not int or not 1<=configured_limit<=1000000:
        raise ValueError("Declare a finite endpoint before each exploratory candidate")
    cap = configured_limit if stage=="development" else 450000
    saved = load_new_checkpoint(args.resume) if args.resume else None
    start = int(saved["global_step"]) if saved else 0
    if args.steps<1 or start+args.steps>cap:
        raise ValueError("Cumulative model endpoint exceeds the declared stage cap")
    if saved and saved["scale_context"]["declaration_sha256"]!=digest_json(declared):
        raise ValueError("Cannot change the candidate or physical workload during continuation")
    if saved and saved["seed"]!=args.seed:
        raise ValueError("Cannot change training seed on continuation")
    if not __import__("torch").cuda.is_available():
        raise RuntimeError("Native original C07 research training requires available CUDA")
    if shutil.disk_usage(Path(args.output).resolve().anchor).free < 15*1024**3:
        raise RuntimeError("Less than15GiB disk free; do not launch or clean unrelated assets")
    attempt = args.attempt_id or str(uuid.uuid4())
    ledger = BudgetLedger(args.ledger,mode=args.budget_mode,limit=configured_limit,
        allow_extended_development=configured_limit>100000)
    candidate=getattr(args,"candidate_id","initial")
    model_id = f"{candidate}-{args.profile}-auv{args.auv}-{method}-sn{args.sensors}-{args.fault}-seed{args.seed}"
    ledger_config = {**declared,"source_hashes":source_hashes()}
    ledger.reserve(attempt,model_id,method,args.seed,ledger_config,args.output,args.steps,
        resume_from_step=start,resume_parent_attempt=args.resume_parent_attempt,stage=stage,
        full_training_confirmation=args.confirm_full_training)
    output = Path(args.output).resolve()
    context = dict(version=VERSION,profile=args.profile,declaration_sha256=digest_json(declared),
        declaration=declared,attempt_id=attempt,stage=stage,budget_mode=args.budget_mode,
        candidate_id=candidate,development_model_limit=configured_limit,
        physical_work_semantics="Each env.step before any learner update; retries/discarded transitions stay charged")
    executed = 0
    def physical_step():
        nonlocal executed
        executed += 1
        if executed%1000==0 or executed==args.steps:
            ledger.update(attempt,executed)
    native_args = argparse.Namespace(method=method,output=output/"learning",config=output/"config.json",
        steps=args.steps,device=args.device,seed=args.seed,resume=args.resume,
        method_options=declared["method_options"],routing_options=declared["routing_options"],
        milestones=sorted(set(getattr(args,"milestones",[]) or [])|{start+args.steps}),checkpoint_every=10000,log_every=1000,
        allow_long_run=True,smoke=False)
    try:
        cfg.save(output/"config.json")
        atomic_json(declared,output/"declaration.json")
        with bindings(context,cap=cap,on_step=physical_step):
            summary = native.train(native_args)
        if executed!=args.steps or summary.get("global_step")!=start+args.steps:
            raise RuntimeError("Executor did not reach its declared physical/model endpoint")
        ledger.finish(attempt,executed,status="completed")
        return {"status":"completed","physical_steps_this_attempt":executed,"global_step":summary["global_step"],
                "attempt_id":attempt,"output":str(output),"not_performance_validation":True}
    except BaseException as error:
        # A caught exception can be reconciled exactly. Hard process termination
        # cannot, so its active reservation deliberately stays held on disk.
        try:
            record=next(item for item in ledger.snapshot()["attempts"] if item["attempt_id"]==attempt)
            if record["status"]=="active": ledger.finish(attempt,executed,status="failed")
        except BaseException as accounting_error:
            error.add_note("Budget reconciliation also failed; preserve active reservation and all evidence: "+repr(accounting_error))
        raise
