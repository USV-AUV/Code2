"""Unselected common30 joint-clock profiles; no evaluation/probe imports.

Four fixed legacy H3/H4 choices, heterogeneous G4/H2 and HELLO48/native-pool12 descendants,
original N2 H1. Only the PIN-derived single inner
MAX comparison is changed for full H2 arms. Native fields/algorithms otherwise
remain original. New pool20 options use their own profile/token/serialization.
"""
import ast
import hashlib
import inspect
import json
import math
from collections import Counter
from contextvars import ContextVar
from copy import deepcopy
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from types import FunctionType, MappingProxyType, MethodType

from . import paths, root_budget
from v6_candidates.c04.environment import TaskV4Env as OriginalC04Environment

LEGACY_PROFILES = tuple(f"adaptive_packet_grid_joint_h3_{h3}_h4_{h4}_v12" for h3 in (1,2) for h4 in (1,2))
HETEROGENEOUS_PROFILE = "adaptive_packet_grid_heterogeneous_g3_6_g4_4_h2_v13"
HELLO48_PROFILE = "adaptive_packet_grid_heterogeneous_n4_hello48_v15"
POOL12_PROFILE = "adaptive_packet_grid_heterogeneous_n4_pool12_v16"
N4_COORD8_PROFILE = "adaptive_packet_grid_heterogeneous_n4_coord8_pool12_v26"
N34_STATE8_11_PROFILE = "adaptive_packet_grid_heterogeneous_state8_11_coord8_pool12_v27"
JOINT_PHY_LOC_ROOT16_PROFILE = "adaptive_packet_grid_joint_child_deadline_v31"
N34_STATE_PERIODS = MappingProxyType({2:5.0,3:8.0,4:11.0})
POOL12_TUPLE = (12,2,28,8,2,30,2,3)
ROOT16_CHILD4_TUPLE = (16,2,28,4,2,30,2,3)
JOINT_PHY_LOC_SETTINGS = MappingProxyType({
    3: MappingProxyType(dict(tdma_sensors_per_group=6,slot_duration=0.5,hello_period=45.0,
        state_period=8.0,coordination_service_interval=16./3,localization_service_interval=8.0)),
    4: MappingProxyType(dict(tdma_sensors_per_group=6,slot_duration=0.5625,hello_period=80.0,
        state_period=11.0,coordination_service_interval=4.0,localization_service_interval=6.0)),
})
PROFILES = (*LEGACY_PROFILES, HETEROGENEOUS_PROFILE, HELLO48_PROFILE, POOL12_PROFILE, N4_COORD8_PROFILE, N34_STATE8_11_PROFILE, JOINT_PHY_LOC_ROOT16_PROFILE)
HORIZONS = MappingProxyType({profile: MappingProxyType({2:1,3:h3,4:h4})
    for profile,(h3,h4) in zip(PROFILES, ((1,1),(1,2),(2,1),(2,2),(2,2),(2,2),(2,2),(2,2),(2,2),(2,2)))})
# Keep the legacy public frame map untouched; new clocks are profile-scoped.
FRAMES = MappingProxyType({2:36.0,3:30.0,4:33.0})
PROFILE_FRAMES = MappingProxyType({profile: MappingProxyType({2:36.0,
    3:50*0.5 if profile==JOINT_PHY_LOC_ROOT16_PROFILE else 30.0,
    4:55*0.5625 if profile==JOINT_PHY_LOC_ROOT16_PROFILE else 42.0 if profile in (HETEROGENEOUS_PROFILE,HELLO48_PROFILE,POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE) else 33.0}) for profile in PROFILES})
MINIMUMS = MappingProxyType({profile: MappingProxyType({2:14.4,
    3:float(h[3]*PROFILE_FRAMES[profile][3]-12),4:float(h[4]*PROFILE_FRAMES[profile][4]-12)})
    for profile,h in HORIZONS.items()})


def registered(profile,n):
    require(type(profile) is str and profile in PROFILES and type(n) is int and n in (2,3,4),
        "Exact registered joint profile and typed N2/3/4 required")
    return HORIZONS[profile][n], MINIMUMS[profile][n]


def registered_frame(profile,n):
    registered(profile,n)
    return PROFILE_FRAMES[profile][n]


def registered_group(profile,n):
    registered(profile,n)
    return 3 if n==2 else 4 if n==4 and profile in (HETEROGENEOUS_PROFILE,HELLO48_PROFILE,POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE) else 6
C04_SHA = "de47f545838bef42c2735a2ab7c92a63faa8ef351ec49ea82a19205630001e21"
BUDGET_SHA = "914ed5dedf239a62ea12165b443a2e1c93a4badba949dabde678b1987b617860"
REFERENCE_PINS = MappingProxyType({
    "models/45w/full_v6/metadata.json": "8b6eca4e085217d92dc5f387f8414ed1fa104d4639a086227b13de3063484128",
    "models/45w/usde_only_v6/metadata.json": "cff0604e677109d7baf6ca596a6e9031e7cfe16f12cf40b94661bcc5b3570084",
    "provenance/frozen_config.json": "9465309c17f69fd196385f33e7bf5eba15ce1b51a1441fdd7b081028ced1ffe7"})
INNER = "_c04_child_tick"
OWNER = "_v12_joint_selector_owner"
_ORIGINAL = OriginalC04Environment.__dict__[INNER]
_OPTIONS = root_budget.OriginalC07Options
_ANCHOR = root_budget.OriginalC03Options
_FIELDS = frozenset(field.name for field in fields(_OPTIONS))
_SCOPE = ContextVar("independent_c07_joint_clocks_v12_options", default=None)
_ROOT = Path(__file__).resolve().parents[1]
_SOURCE = _ROOT / "c07_source"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def exact(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return (all(type(k) is str for k in a) and all(type(k) is str for k in b)
                and a.keys() == b.keys() and all(exact(a[k], b[k]) for k in a))
    if type(a) in (list, tuple):
        return len(a) == len(b) and all(exact(x, y) for x, y in zip(a, b))
    if type(a) is float:
        return math.isfinite(a) and math.isfinite(b) and a == b
    return (a is None or type(a) in (str, int, bool)) and a == b


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def constant_signature(value):
    if inspect.iscode(value):
        return ("code", code_signature(value))
    if type(value) is tuple:
        return ("tuple", tuple(constant_signature(x) for x in value))
    if type(value) is frozenset:
        return ("frozenset", frozenset(constant_signature(x) for x in value))
    require(value is None or type(value) in (bool, int, float, complex, str, bytes),
            "Unexpected compiler constant")
    return (type(value).__name__, value)


def code_signature(code):
    return (code.co_code, code.co_argcount, code.co_posonlyargcount, code.co_kwonlyargcount,
            code.co_flags & 0x3ff, getattr(code, "co_exceptiontable", b""), code.co_names,
            code.co_varnames, code.co_freevars, code.co_cellvars,
            tuple(constant_signature(x) for x in code.co_consts))


def dependencies():
    require(Path(paths.SOURCE).resolve() == _SOURCE and
            Path(paths.REFERENCE).resolve() == _ROOT / "reference" and
            Path(paths.PACKAGE).resolve() == Path(__file__).resolve().parent,
            "H2 runtime refuses live/fallback dependency roots")
    require(Path(root_budget.__file__).resolve() == Path(__file__).with_name("root_budget.py")
            and digest(root_budget.__file__) == BUDGET_SHA, "Original V9 budget primitive PIN/origin differs")
    require(all(digest(_ROOT / "reference" / key)==value for key,value in REFERENCE_PINS.items()),
            "Original full/USDE/config reference byte identity differs")
    for cls in (_OPTIONS, _ANCHOR, root_budget.OriginalC04Options, OriginalC04Environment):
        require(Path(inspect.getsourcefile(cls)).resolve().is_relative_to(_SOURCE),
                "H2 runtime refuses cached classes from another source tree")
    path = _SOURCE / "v6_candidates/c04/environment.py"
    require(digest(path) == C04_SHA and Path(_ORIGINAL.__code__.co_filename).resolve() == path,
            "Original C04 selector source PIN/origin differs")
    return path


def _derive():
    path = dependencies()
    tree = ast.parse(path.read_text(encoding="utf-8-sig"))
    cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == "TaskV4Env")
    original = next(x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == INNER)
    dump = lambda x: ast.dump(x, include_attributes=False)
    expected = ast.fix_missing_locations(ast.Module(body=[deepcopy(original)], type_ignores=[]))
    code = next(x for x in compile(expected, str(path), "exec", dont_inherit=True).co_consts if inspect.iscode(x))
    require(type(_ORIGINAL) is FunctionType and _ORIGINAL.__closure__ is None and
            _ORIGINAL.__defaults__ is None and _ORIGINAL.__kwdefaults__ is None and
            code_signature(_ORIGINAL.__code__) == code_signature(code),
            "Actual typed C04 selector code/defaults differ from pinned source")
    require(_ORIGINAL.__globals__.get("Counter") is Counter, "Original Counter binding differs")
    modified = deepcopy(original)
    signature = dump(ast.parse("first-net.time > net.frame_duration", mode="eval").body)
    sites = [x for x in ast.walk(modified) if isinstance(x, ast.If) and dump(x.test) == signature]
    require(len(sites) == 1, "Exactly one original inner MAX site required")
    comparator = deepcopy(sites[0].test.comparators[0])
    sites[0].test.comparators[0] = ast.BinOp(left=ast.Constant(2), op=ast.Mult(), right=deepcopy(comparator))
    restored = deepcopy(modified)
    signature2 = dump(ast.parse("first-net.time > 2*net.frame_duration", mode="eval").body)
    back = [x for x in ast.walk(restored) if isinstance(x, ast.If) and dump(x.test) == signature2]
    require(len(back) == 1, "Exactly one registered H2 MAX site required")
    back[0].test.comparators[0] = comparator
    require(dump(restored) == dump(original), "Non-MAX C04 behavior changed")
    namespace = dict(_ORIGINAL.__globals__)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[modified], type_ignores=[])),
                 "<source-pinned-native-N4-H2-inner>", "exec", dont_inherit=True), namespace)
    function = namespace[INNER]
    function.__defaults__ = _ORIGINAL.__defaults__
    function.__kwdefaults__ = _ORIGINAL.__kwdefaults__
    function.__annotations__ = dict(_ORIGINAL.__annotations__)
    proof = dict(source_key="original/v6_candidates/c04/environment.py", source_sha256=C04_SHA,
        changed_AST_sites=1, MAX_delta="F -> 2*F", reverse_AST_identical=True,
        original_AST_sha256=hashlib.sha256(dump(original).encode()).hexdigest(),
        derived_AST_sha256=hashlib.sha256(dump(modified).encode()).hexdigest(),
        actual_typed_code_verified=True, actual_Counter_preserved=True,
        outer_MIN_score_ties_clip_overlap_caps_unchanged=True, original_class_or_globals_modified=False)
    return function, proof, code_signature(code)


_H2, _PROOF, _ORIGINAL_CODE = _derive()
_H2_CODE = code_signature(_H2.__code__)
_ORIGINAL_GLOBALS = dict(_ORIGINAL.__globals__)
_H2_GLOBALS = dict(_H2.__globals__)
_ANNOTATIONS = dict(_ORIGINAL.__annotations__)
_PRIMITIVE = root_budget._PORTED_C03_POST_INIT
_PRIMITIVE_CODE = code_signature(_PRIMITIVE.__code__)
_PRIMITIVE_GLOBALS = dict(_PRIMITIVE.__globals__)
_PRIMITIVE_DEFAULTS = (_PRIMITIVE.__defaults__,_PRIMITIVE.__kwdefaults__)


def selector_proof(n, profile, method):
    horizon,minimum=registered(profile,n)
    require(type(method) is str and method in ("full_v6","usde_only_v6"),"Canonical method required")
    validate_code()
    proof = deepcopy(_PROOF)
    if horizon == 1 or method != "full_v6":
        proof.update(changed_AST_sites=0, MAX_delta="original F", derived_AST_sha256=proof["original_AST_sha256"])
    return dict(profile=profile, n_auv=n, horizon=horizon, fixed_horizon_mapping={str(k):v for k,v in HORIZONS[profile].items()},
        minimum_command_lead_s=minimum, selector_port=proof, installed_H2_hook=method=="full_v6" and horizon==2,
        total_behavior_deltas=("Conditional V28 preparation only: N3 G6/slot0.5/HELLO45/STATE8/COORD16/3/LOC8; N4 G6/slot0.55/HELLO80/STATE11/COORD4/LOC6 and native P16/q2/global28/child4; derive ACK/grant/MIN from actual original calendar with exact float order. Same original paid C03 protocol, H2 selector, QueueOptions algorithm/three LOC flow keys, polling/sourceTTL90/stale25, learning/reward/bytes/bitrate/guard/safety; N2 scientific numerics unchanged, profile identity differs. Multiple declared parameters, narrow modeled slot margin, no success or activation claim"
            if profile==JOINT_PHY_LOC_ROOT16_PROFILE else "K26 descendant: only existing float Config.state_period N3 5.0->8.0 and N4 5.0->11.0; N2 whole science unchanged; retain coord16/3 or8.0, G6/F30 orG4/F42/H2/P12, native C03, stale25/sourceTTL90, LOC, slow5 and all learning/reward/PHY/safety rules; off-grid STATE and ordinary COORD submission clocks differ, dirty rules unchanged; no gain guaranteed"
            if profile==N34_STATE8_11_PROFILE else "V16 descendant: only N4 existing float Config.coordination_service_interval4.0->8.0; native weighted-age priority denominator, not polling; same state5/G4/F42/H2/MIN72/P12, deadline/intent/conflict bonuses, native C03 chain, stale25/sourceTTL90 and all other science unchanged; N2/N3 unchanged; no gain guaranteed"
            if profile==N4_COORD8_PROFILE else "V13 descendant: only N4 native integer MO.mac_pool_slots20->12; original complete C03 validator, no pool20 validator insertion; V13 HELLO40/visit4/G4/F42/H2/MIN72 and all other scientific fields unchanged"
            if profile==POOL12_PROFILE else "V13 descendant: only N4 native Config.hello_period40.0->48.0; original V13 visit4.0/G4/F42/H2/MIN72 and probe/rescue/retry clocks unchanged; N2/N3 scientific fields unchanged"
            if profile==HELLO48_PROFILE else "N3 unchanged V12 G6/H2; N4 native G4/retry clocks plus existing MIN; full H2 only the unchanged innerMAX F->2F; N2 unchanged"
            if profile==HETEROGENEOUS_PROFILE else "N3/N4 original G6/HELLO/retry clocks plus existing MIN; full H2 only innerMAX F->2F; N2 unchanged"),
        source_keys_are_portable=True, constructor_selects_or_trains=False)


def fast_runtime_check():
    """Actual memory identity only; no disk reads, JSON, AST or compilation."""
    require(OriginalC04Environment.__dict__.get(INNER) is _ORIGINAL and
            code_signature(_ORIGINAL.__code__) == _ORIGINAL_CODE and
            _ORIGINAL.__globals__.get("Counter") is Counter and
            code_signature(_H2.__code__) == _H2_CODE and _H2.__globals__.get("Counter") is Counter,
            "Original/derived selector code, class or Counter drift")
    require(set(_ORIGINAL.__globals__)==set(_ORIGINAL_GLOBALS) and
            all(_ORIGINAL.__globals__[k] is v for k,v in _ORIGINAL_GLOBALS.items()) and
            set(_H2.__globals__)==set(_H2_GLOBALS) and all(_H2.__globals__[k] is v for k,v in _H2_GLOBALS.items()) and
            _ORIGINAL.__closure__ is None and _H2.__closure__ is None and
            _ORIGINAL.__defaults__ is None and _H2.__defaults__ is None and
            _ORIGINAL.__kwdefaults__ is None and _H2.__kwdefaults__ is None and
            exact(_ORIGINAL.__annotations__,_ANNOTATIONS) and exact(_H2.__annotations__,_ANNOTATIONS),
            "Original/derived selector globals/defaults/closure drift")
    require(root_budget._PORTED_C03_POST_INIT is _PRIMITIVE and
            code_signature(_PRIMITIVE.__code__) == _PRIMITIVE_CODE and
            set(_PRIMITIVE.__globals__)==set(_PRIMITIVE_GLOBALS) and
            all(_PRIMITIVE.__globals__[k] is v for k,v in _PRIMITIVE_GLOBALS.items()) and
            exact((_PRIMITIVE.__defaults__,_PRIMITIVE.__kwdefaults__),_PRIMITIVE_DEFAULTS) and
            len(_PRIMITIVE.__closure__)==1 and
            _PRIMITIVE.__closure__[0].cell_contents is _ANCHOR and
            JointN4Options.__mro__==_EXPECTED_OPTIONS_MRO and tuple(fields(JointN4Options))==_EXPECTED_OPTIONS_FIELDS,
            "Private C03 primitive code/MRO anchor drift")
    _check_native_pool12_shape()
    _check_native_root16_child4_shape()


def full_source_validate():
    """Boundary proof: disk/source/reference PIN and recompiled C03 primitive."""
    dependencies()
    fresh, proof = root_budget._ported_c03_validator()
    require(code_signature(_PRIMITIVE.__code__) == code_signature(fresh.__code__)
            and _PRIMITIVE.__globals__ is fresh.__globals__ and _PRIMITIVE.__closure__[0].cell_contents is _ANCHOR
            and proof["changed_ast_sites"] == 1 and proof["remaining_validator_AST_identical"] is True,
            "Private C03 source proof differs")
    fast_runtime_check()


def validate_code():
    # Existing proof/test API remains the FULL boundary check.
    full_source_validate()


def expected_options(n, method, profile):
    _,minimum=registered(profile,n)
    require(type(method) is str and method in ("full_v6", "usde_only_v6"), "Typed joint scale/method required")
    dependencies()
    path = _ROOT / "reference/models/45w" / method / "metadata.json"
    value = json.loads(path.read_text(encoding="utf-8-sig"))["method_options"]
    require(set(value) == _FIELDS and type(value.get("mac_enabled")) is bool and
            value["mac_enabled"] is (method == "full_v6"), "Complete original reference MO schema/ablation required")
    if n > 2:
        value.update(root_budget.registered_budget_values(n))
        value["mac_child_lead_s"] = minimum
    if n == 4 and profile in (POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE):
        value["mac_pool_slots"] = 12
    if n == 4 and profile==JOINT_PHY_LOC_ROOT16_PROFILE:
        value.update(dict(zip(root_budget.BUDGET_FIELDS,ROOT16_CHILD4_TUPLE)))
    return value


def _scope_check(options):
    scope = _SCOPE.get()
    require(type(scope) is dict and type(scope.get("profile")) is str and scope.get("profile") in PROFILES and exact(scope.get("n_auv"), 4)
            and exact(scope.get("n_sensors"), 30) and type(scope.get("method")) is str and scope.get("method") in ("full_v6", "usde_only_v6"),
            "Independent V12 joint N4 construction token absent/wrong")
    require(scope["profile"] not in (POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE,JOINT_PHY_LOC_ROOT16_PROFILE), "Native pool12/root16 must not use the historical pool20 validator insertion")
    require(exact(scope.get("method_options"), expected_options(4, scope["method"],scope["profile"])) and
            exact(asdict(options), scope["method_options"]), "Full typed V12 joint N4 options differ")
    validate_code()


class _JointC03Insertion(_ANCHOR):
    def __post_init__(self):
        _scope_check(self)
        _PRIMITIVE(self)


@dataclass(frozen=True)
class JointN4Options(_OPTIONS, _JointC03Insertion):
    def __post_init__(self):
        _scope_check(self)
        super().__post_init__()

    def __reduce_ex__(self, protocol):
        return _restore_options, (self._joint_profile, asdict(self))


def _native_pool12_scope_check(options):
    scope = _SCOPE.get()
    require(type(scope) is dict and type(scope.get("profile")) is str and scope["profile"] in (POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE) and
            exact(scope.get("n_auv"),4) and exact(scope.get("n_sensors"),30) and
            type(scope.get("method")) is str and scope["method"] in ("full_v6","usde_only_v6"),
            "Exact registered native N4 pool12/common30 constructor token required")
    require(type(options) is NativePool12N4Options and
            exact(scope.get("method_options"),expected_options(4,scope["method"],scope["profile"])) and
            exact(asdict(options),scope["method_options"]), "Complete typed native pool12 options differ")
    values=asdict(options)
    require(all(type(values[key]) is int for key in root_budget.BUDGET_FIELDS) and
            tuple(values[key] for key in root_budget.BUDGET_FIELDS)==POOL12_TUPLE and
            values["mac_child_max_active"]<values["mac_pool_slots"] and
            values["mac_pool_slots"]+4*values["mac_auv_slots"]<=values["mac_max_leases"]<=30,
            "Only native pool12/AUV2/global28/child8/perSN2/parent30/stride2/child3 tuple")
    validate_code()


@dataclass(frozen=True)
class NativePool12N4Options(_OPTIONS):
    """Exact V16 scope, then the FULL unmodified original C06/C04/C03 chain."""
    def __post_init__(self):
        _native_pool12_scope_check(self)
        super().__post_init__()

    def __reduce_ex__(self, protocol):
        return _restore_options, (self._joint_profile, asdict(self))


def _check_native_pool12_shape():
    require(NativePool12N4Options is _NATIVE_POOL12_CLASS and
            NativePool12N4Options.__mro__==_NATIVE_POOL12_MRO and
            tuple(fields(NativePool12N4Options))==_NATIVE_POOL12_FIELDS and
            NativePool12N4Options.__dict__["__post_init__"] is _NATIVE_POOL12_POST and
            code_signature(_NATIVE_POOL12_POST.__code__)==_NATIVE_POOL12_POST_CODE,
            "Native pool12 original MRO/schema/constructor identity drift")


def native_pool12_validation_proof():
    validate_code()
    path=_SOURCE/"v6_candidates/c03/environment.py"
    source_sha="41afe4006a28b6652d19308b9ce3402109542af122154dc2af570097cd247c2e"
    require(digest(path)==source_sha and _ANCHOR in NativePool12N4Options.__mro__ and
            _JointC03Insertion not in NativePool12N4Options.__mro__ and
            root_budget._C03RootBudgetValidation not in NativePool12N4Options.__mro__,
            "Native C03 source/chain must remain intact without either pool20 insertion")
    return dict(source_key="original/v6_candidates/c03/environment.py",source_sha256=source_sha,
        original_pool_validation_lower=2,original_pool_validation_upper=16,
        registered_budget_tuple=list(POOL12_TUPLE),original_C03_validator_used=True,
        pool20_validator_insertion_used=False,full_original_validation_MRO=True,
        effective_options_mro=[cls.__module__+"."+cls.__qualname__ for cls in NativePool12N4Options.__mro__],
        original_field_names=[field.name for field in fields(_OPTIONS)],method_options_schema_unchanged=True,
        original_class_or_globals_modified=False,constructor_selects_or_trains=False)


def _native_root16_child4_scope_check(options):
    scope=_SCOPE.get()
    require(type(scope) is dict and exact(scope.get("profile"),JOINT_PHY_LOC_ROOT16_PROFILE) and
            exact(scope.get("n_auv"),4) and exact(scope.get("n_sensors"),30) and
            type(scope.get("method")) is str and scope["method"] in ("full_v6","usde_only_v6"),
            "Exact registered native N4 root16/child4/common30 constructor token required")
    require(type(options) is NativeRoot16Child4N4Options and
            exact(scope.get("method_options"),expected_options(4,scope["method"],scope["profile"])) and
            exact(asdict(options),scope["method_options"]),"Complete typed native root16/child4 options differ")
    values=asdict(options)
    require(all(type(values[key]) is int for key in root_budget.BUDGET_FIELDS) and
            tuple(values[key] for key in root_budget.BUDGET_FIELDS)==ROOT16_CHILD4_TUPLE and
            values["mac_child_max_active"]<values["mac_pool_slots"] and
            values["mac_pool_slots"]+4*values["mac_auv_slots"]<=values["mac_max_leases"]<=30,
            "Only native root16/AUV2/global28/child4/perSN2/parent30/stride2/child3 tuple")
    validate_code()


@dataclass(frozen=True)
class NativeRoot16Child4N4Options(_OPTIONS):
    """Explicit V28 tuple; FULL unmodified original C06/C04/C03 validation."""
    def __post_init__(self):
        _native_root16_child4_scope_check(self)
        super().__post_init__()

    def __reduce_ex__(self,protocol):
        return _restore_options,(self._joint_profile,asdict(self))


def _check_native_root16_child4_shape():
    require(NativeRoot16Child4N4Options is _NATIVE_ROOT16_CHILD4_CLASS and
            NativeRoot16Child4N4Options.__mro__==_NATIVE_ROOT16_CHILD4_MRO and
            tuple(fields(NativeRoot16Child4N4Options))==_NATIVE_ROOT16_CHILD4_FIELDS and
            NativeRoot16Child4N4Options.__dict__["__post_init__"] is _NATIVE_ROOT16_CHILD4_POST and
            code_signature(_NATIVE_ROOT16_CHILD4_POST.__code__)==_NATIVE_ROOT16_CHILD4_POST_CODE,
            "Native root16/child4 original MRO/schema/constructor identity drift")


def native_root16_child4_validation_proof():
    validate_code()
    source_sha="41afe4006a28b6652d19308b9ce3402109542af122154dc2af570097cd247c2e"
    require(digest(_SOURCE/"v6_candidates/c03/environment.py")==source_sha and
            _ANCHOR in NativeRoot16Child4N4Options.__mro__ and
            _JointC03Insertion not in NativeRoot16Child4N4Options.__mro__ and
            root_budget._C03RootBudgetValidation not in NativeRoot16Child4N4Options.__mro__,
            "Native root16 requires the complete original C03 validator without a pool-domain insertion")
    return dict(source_key="original/v6_candidates/c03/environment.py",source_sha256=source_sha,
        original_pool_validation_lower=2,original_pool_validation_upper=16,
        registered_budget_tuple=list(ROOT16_CHILD4_TUPLE),original_C03_validator_used=True,
        pool20_validator_insertion_used=False,full_original_validation_MRO=True,
        effective_options_mro=[cls.__module__+"."+cls.__qualname__ for cls in NativeRoot16Child4N4Options.__mro__],
        original_field_names=[field.name for field in fields(_OPTIONS)],method_options_schema_unchanged=True,
        original_class_or_globals_modified=False,constructor_selects_or_trains=False)


def _restore_options(profile, values):
    require(type(values) is dict and type(values.get("mac_enabled")) is bool, "Typed serialized H2 MO required")
    method = "full_v6" if values["mac_enabled"] else "usde_only_v6"
    return build_options(4, 30, profile, method, values)


def build_options(n, sensors, profile, method, values):
    require(type(profile) is str and profile in PROFILES and type(n) is int and n in (2,3,4)
            and type(sensors) is int and sensors == 30, "Explicit V12 joint/common30 identity required")
    require(type(values) is dict and exact(values, expected_options(n, method,profile)), "Complete typed V12 joint MO required")
    if n != 4:
        return _OPTIONS(**deepcopy(values))
    token = _SCOPE.set(dict(profile=profile, n_auv=4, n_sensors=30, method=method, method_options=deepcopy(values)))
    try:
        constructor=(NativeRoot16Child4N4Options if profile==JOINT_PHY_LOC_ROOT16_PROFILE else
            NativePool12N4Options if profile in (POOL12_PROFILE,N4_COORD8_PROFILE,N34_STATE8_11_PROFILE) else JointN4Options)
        value=constructor(**deepcopy(values))
        object.__setattr__(value,"_joint_profile",profile)
        return value
    finally:
        _SCOPE.reset(token)


_mro = JointN4Options.__mro__
_pos = _mro.index(root_budget.OriginalC04Options)
require(_mro[_pos:_pos+3] == (root_budget.OriginalC04Options, _JointC03Insertion, _ANCHOR)
        and tuple(fields(JointN4Options)) == tuple(fields(_OPTIONS)), "Original native MRO/schema must remain intact")
_EXPECTED_OPTIONS_MRO = JointN4Options.__mro__
_EXPECTED_OPTIONS_FIELDS = tuple(fields(JointN4Options))
_NATIVE_POOL12_CLASS=NativePool12N4Options
_NATIVE_POOL12_MRO=(NativePool12N4Options,*_OPTIONS.__mro__)
_NATIVE_POOL12_FIELDS=tuple(fields(_OPTIONS))
_NATIVE_POOL12_POST=NativePool12N4Options.__dict__["__post_init__"]
_NATIVE_POOL12_POST_CODE=code_signature(_NATIVE_POOL12_POST.__code__)
_NATIVE_ROOT16_CHILD4_CLASS=NativeRoot16Child4N4Options
_NATIVE_ROOT16_CHILD4_MRO=(NativeRoot16Child4N4Options,*_OPTIONS.__mro__)
_NATIVE_ROOT16_CHILD4_FIELDS=tuple(fields(_OPTIONS))
_NATIVE_ROOT16_CHILD4_POST=NativeRoot16Child4N4Options.__dict__["__post_init__"]
_NATIVE_ROOT16_CHILD4_POST_CODE=code_signature(_NATIVE_ROOT16_CHILD4_POST.__code__)
_check_native_pool12_shape()
_check_native_root16_child4_shape()


class SelectorHandle:
    """Single instance ownership; reset may delete only our owned override."""
    def __init__(self, env):
        full_source_validate()
        require(getattr(type(env), INNER) is _ORIGINAL, "Foreign class selector cannot enter H2")
        require(OWNER not in env.__dict__, "Another H2 handle owns this instance, including a reset-deleted method")
        self.env = env
        self.had_original_entry = INNER in env.__dict__
        self.original_entry = env.__dict__.get(INNER)
        require(not self.had_original_entry or type(self.original_entry) is MethodType and
                self.original_entry.__self__ is env and self.original_entry.__func__ is _ORIGINAL,
                "Foreign instance selector cannot enter H2")
        self.bound = MethodType(_H2, env)
        self.closed = False
        env.__dict__[OWNER] = self
        env.__dict__[INNER] = self.bound
        try:
            self.check()
        except BaseException as error:
            preserve_cleanup(error,self.restore,"H2 install ownership cleanup also failed")
            raise

    def check(self, *, reset_deleted=False):
        fast_runtime_check()
        require(not self.closed and getattr(type(self.env), INNER) is _ORIGINAL
                and self.env.__dict__.get(OWNER) is self, "Closed/foreign H2 selector class/ownership")
        if INNER not in self.env.__dict__ and reset_deleted:
            self.env.__dict__[INNER] = self.bound
        require(self.env.__dict__.get(INNER) is self.bound, "Foreign/missing registered H2 instance selector")

    def restore(self):
        if self.closed:
            return
        # Cleanup is identity-only: a corrupted code/global must stop behavior,
        # but must not itself prevent removal of our owned instance method.
        # Never overwrite a foreign owner/method, including during cancellation.
        require(self.env.__dict__.get(OWNER) is self and
                (INNER not in self.env.__dict__ or self.env.__dict__[INNER] is self.bound),
                "Foreign selector ownership must not be overwritten during cleanup")
        if self.had_original_entry:
            self.env.__dict__[INNER] = self.original_entry
        else:
            self.env.__dict__.pop(INNER,None)
        del self.env.__dict__[OWNER]
        self.closed = True


def validate_environment_selector(env, n, profile, method):
    horizon,_=registered(profile,n)
    require(type(method) is str and method in ("full_v6","usde_only_v6"),"Canonical declared method required")
    fast_runtime_check()
    if horizon == 2 and method=="full_v6":
        handle = getattr(env, "_joint_selector_handle", None)
        require(type(handle) is SelectorHandle and handle.env is env, "registered H2 owned selector missing")
        handle.check()
    else:
        require(OWNER not in env.__dict__ and getattr(env,"_joint_selector_handle",None) is None,
            "H1/USDE cannot carry an H2 owner/handle")
        method = getattr(env, INNER)
        require(type(method) is MethodType and method.__self__ is env and method.__func__ is _ORIGINAL
                and getattr(type(env), INNER) is _ORIGINAL, "H1 and USDE require untouched original selector without any MAC hook")


def preserve_cleanup(error, callback, description):
    try:
        callback()
    except BaseException as cleanup:
        error.add_note(description + ": " + repr(cleanup))


