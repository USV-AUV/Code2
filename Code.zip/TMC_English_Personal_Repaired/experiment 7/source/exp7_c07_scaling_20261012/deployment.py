"""A declared fixed initial deployment, not a controller or a safety shield.

For scale_grid, three AUVs use an equilateral triangle and four use a square.
Their centroid is the original (.5,.45)*area and minimum spacing is the
original two-AUV .4*area. IDs and orientation are fixed before any scene seed.
All other original reset statements, measurements and RNG calls are retained.
This changes the scale experiment's setup and cannot isolate fleet size alone.
"""
from __future__ import annotations

import ast
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import inspect
import math
import textwrap
import threading

import numpy as np

from . import paths as _paths  # Resolve the original dependency source first.
from usv_auv import environment as _core


_LOCK = threading.RLock()
_ORIGINAL_RESET = _core.CooperativeEnv.reset
_CANONICAL_EXPRESSION = (
    "np.column_stack((np.linspace(.30,.70,c.n_auv)*c.area_size,"
    "np.full(c.n_auv,.45*c.area_size)))"
)


def deployment_positions(cfg):
    """Read only n_auv, area_size and deployment_layout; no scene information.

    Non-grid layouts and all two-AUV cases use the exact original expression.
    Square IDs1..4 are southwest, southeast, northeast, northwest, respectively.
    Triangle IDs1..3 are the left base, right base and upper apex, respectively.
    """
    n = cfg.n_auv
    if type(n) is not int or n not in (2, 3, 4):
        raise ValueError("Fixed C07 scale deployment supports only2/3/4 AUVs")
    area = cfg.area_size
    if isinstance(area, bool) or not math.isfinite(float(area)) or area <= 0:
        raise ValueError("Deployment area_size must be finite and positive")
    if n == 2 or getattr(cfg, "deployment_layout", None) != "scale_grid":
        return np.column_stack((np.linspace(.30, .70, n)*area,
                                np.full(n, .45*area)))
    if n == 3:
        lower = .45-.4/(2*math.sqrt(3))
        upper = .45+.4/math.sqrt(3)
        normalized = ((.3, lower), (.7, lower), (.5, upper))
    else:
        normalized = ((.3, .25), (.7, .25), (.7, .65), (.3, .65))
    return np.asarray(normalized, dtype=float)*area


def _position_assignments(tree):
    return [node for node in ast.walk(tree) if isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Attribute)
            and isinstance(node.targets[0].value, ast.Name)
            and node.targets[0].value.id == "self"
            and node.targets[0].attr == "auv_positions"]


def _dump(tree):
    return ast.dump(tree, annotate_fields=True, include_attributes=False)


def _transform_reset_ast(tree):
    """Replace exactly one audited assignment value; reject source drift."""
    changed = deepcopy(tree)
    assignments = _position_assignments(changed)
    if len(assignments) != 1:
        raise ValueError("Original reset must have exactly one AUV deployment assignment")
    original_value = deepcopy(assignments[0].value)
    canonical = ast.parse(_CANONICAL_EXPRESSION, mode="eval").body
    if _dump(original_value) != _dump(canonical):
        raise ValueError("Original C07 deployment expression changed; refusing an ambiguous port")
    replacement = ast.Call(func=ast.Name(id="deployment_positions", ctx=ast.Load()),
                           args=[ast.Name(id="c", ctx=ast.Load())], keywords=[])
    assignments[0].value = ast.copy_location(replacement, assignments[0].value)
    ast.fix_missing_locations(changed)
    restored = deepcopy(changed)
    _position_assignments(restored)[0].value = original_value
    if _dump(restored) != _dump(tree):
        raise AssertionError("Deployment port changed another original reset statement")
    audit = dict(assignment_count=1, only_assignment_value_changed=True,
        canonical_original_expression=_CANONICAL_EXPRESSION,
        replacement_expression="deployment_positions(c)",
        original_AST_sha256=hashlib.sha256(_dump(tree).encode("utf-8")).hexdigest(),
        restored_AST_sha256=hashlib.sha256(_dump(restored).encode("utf-8")).hexdigest(),
        transformed_AST_sha256=hashlib.sha256(_dump(changed).encode("utf-8")).hexdigest(),
        remaining_reset_AST_identical=True,
        note="AST semantics outside one assignment are identical. Compiled instruction offsets/name indices need not be byte-identical.")
    return changed, audit


def _compile_ported_reset(original):
    if original.__code__.co_freevars:
        raise ValueError("Original reset unexpectedly captures a closure")
    source = textwrap.dedent(inspect.getsource(original))
    parsed = ast.parse(source)
    if len(parsed.body) != 1 or not isinstance(parsed.body[0], ast.FunctionDef) or parsed.body[0].name != "reset":
        raise ValueError("Expected the original reset function only")
    if parsed.body[0].decorator_list:
        raise ValueError("Unexpected original reset decorators")
    changed, audit = _transform_reset_ast(parsed)
    namespace = dict(original.__globals__)
    namespace["deployment_positions"] = deployment_positions
    exec(compile(changed, "<c07-declared-scale-grid-reset>", "exec"), namespace)
    ported = namespace["reset"]
    ported.__module__ = original.__module__
    ported.__qualname__ = original.__qualname__
    ported.__doc__ = original.__doc__
    audit["original_reset_source_sha256"] = hashlib.sha256(source.encode("utf-8")).hexdigest()
    return ported, audit


_PORTED_RESET, _AST_AUDIT = _compile_ported_reset(_ORIGINAL_RESET)


def deployment_ast_audit():
    """Return an independent copy of the construction-time AST identity proof."""
    return deepcopy(_AST_AUDIT)


@contextmanager
def deployment_port():
    """Scope the in-memory reset port and restore exactly the preceding method.

    Nested calls are safe under an RLock. Unknown external reset replacements
    are rejected, never overwritten. No original source file is edited.
    """
    with _LOCK:
        previous = _core.CooperativeEnv.reset
        if previous is not _ORIGINAL_RESET and previous is not _PORTED_RESET:
            raise RuntimeError("Another reset patch is active; refusing to replace it")
        _core.CooperativeEnv.reset = _PORTED_RESET
        try:
            yield
        finally:
            _core.CooperativeEnv.reset = previous


__all__ = ("deployment_positions", "deployment_ast_audit", "deployment_port")
