"""Build a portable code-only folder/ZIP; never publish, train or overwrite."""
import argparse
import json
from pathlib import Path
import shutil
import zipfile
from .paths import PACKAGE,SOURCE,EXPERIMENT,reference_config,reference_metadata
from .workflow import source_hashes
from usv_auv.train import atomic_json,file_digest

def build(output,readme=None):
    output=Path(output).resolve()
    archive=output.with_suffix(".zip")
    if output.exists() or archive.exists(): raise FileExistsError("Refusing to overwrite a package")
    before=source_hashes()
    output.mkdir(parents=True,exist_ok=False)
    # Only the frozen workflow's complete declared dependency packages plus the
    # original75metric summarizer. No unrelated historical experiment launchers,
    # checkpoint, rollout, Git directory or private key is added.
    dependencies=[SOURCE/key[len("original/"):] for key in before if key.startswith("original/")]
    dependencies.append(SOURCE/"scripts"/"summarize_tmc_retest.py")
    for path in sorted(dependencies):
        target=output/"c07_source"/path.relative_to(SOURCE)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,target)
    for path in sorted(PACKAGE.rglob("*.py")):
        target=output/PACKAGE.name/path.relative_to(PACKAGE)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,target)
    assets={"experiment7_c07_scaling.py":EXPERIMENT/"experiment7_c07_scaling.py",
            "README_EN.txt":Path(readme) if readme else (EXPERIMENT/"README_EN.txt" if (EXPERIMENT/"README_EN.txt").is_file() else EXPERIMENT/"README_EN.txt"),
            "requirements.txt":EXPERIMENT/"requirements.txt" if (EXPERIMENT/"requirements.txt").is_file() else EXPERIMENT/"C07fleet_extension_20261012_requirements.txt",
            "reference/provenance/frozen_config.json":reference_config(),
            "reference/models/45w/full_v6/metadata.json":reference_metadata("full_v6"),
            "reference/models/45w/usde_only_v6/metadata.json":reference_metadata("usde_only_v6")}
    for name,path in assets.items():
        target=output/name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,target)
    if source_hashes()!=before: raise RuntimeError("Source changed while packaging")
    inventory={path.relative_to(output).as_posix():file_digest(path) for path in sorted(output.rglob("*")) if path.is_file()}
    atomic_json(dict(code_only=True,source_hashes=before,files=inventory,training_executed=False,
        performance_claim="not empirically validated"),output/"PACKAGE_MANIFEST.json")
    with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED) as stream:
        for path in sorted(output.rglob("*")):
            if path.is_file(): stream.write(path,output.name+"/"+path.relative_to(output).as_posix())
    return {"output":str(output),"archive":str(archive),"archive_digest":file_digest(archive),"files":len(inventory)+1}

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",required=True,type=Path)
    p.add_argument("--readme",type=Path)
    args=p.parse_args()
    print(json.dumps(build(args.output,args.readme),ensure_ascii=False),flush=True)
