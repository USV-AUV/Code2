"""V31: bounded first-future-opportunity urgency on a root's OWN child command.

Only the existing paid application selector rank changes. No ACK, private
receiver table, actual position/queue, free slot, TTL or packet is changed.
Native unbounded flow-age ranks, management/rescue limits, tie breakers and
all transmission/permission rules remain in force. This is not a delay bound.
"""
import math
from types import MethodType
from v6_candidates.c06.mac import _ConflictMixin

PROFILE = "adaptive_packet_grid_joint_child_deadline_v31"
OWNER = "_v31_child_deadline_rank_owner"
ORIGINAL_RANK = _ConflictMixin.__dict__["_application_rank"]
ORIGINAL_CODE = ORIGINAL_RANK.__code__


def require(ok, message):
    if not ok:
        raise ValueError(message)


def next_certificate_opportunity(payload, now, frame_s, slot_s):
    """Public immutable certificate calendar only; no permission inference."""
    if type(payload) is not dict or type(payload.get("parent")) is not dict:
        return None
    parent = payload["parent"]
    names = (payload.get("start_frame"), payload.get("end_frame"),
             parent.get("frame_stride"), parent.get("slot_offset"))
    if any(type(v) is not int for v in names):
        return None
    start, end, stride, offset = names
    if not (0 <= start < end and 2 <= stride <= 5 and offset >= 0
            and math.isfinite(now) and frame_s > 0 and slot_s > 0):
        return None
    first = start * frame_s + offset * slot_s
    if first <= now:
        first += (math.floor((now-first)/(stride*frame_s)) + 1) * stride * frame_s
    if first >= end * frame_s:
        return None
    return first


def bounded_bonus(packet, owner, n_auv, enabled, now, frame_s, slot_s, service_s):
    if not (enabled is True and n_auv in (3, 4) and owner == 0
            and packet.src == 0 and packet.kind == "MAC_SUBCOMMIT"):
        return 0.0
    future = next_certificate_opportunity(packet.payload, now, frame_s, slot_s)
    if future is None or not 0 < future-now <= frame_s:
        return 0.0
    # Exactly one frame of the original control-flow age, finite, not strict
    # preemption. Other application ages remain unbounded and can outrank it.
    return frame_s / service_s


def _rank_with_deadline(net, owner, index):
    handle = net.__dict__[OWNER]
    rank = handle.original(owner, index)  # Entire original C06/C04/V4 rank first.
    packet = net._queues[owner][index].packet  # This transmitting owner only.
    bonus = bounded_bonus(packet, owner, net.n_auvs, net.intent_enabled,
                          net.time, net.frame_duration, net.slot_duration,
                          net.mac_options.mac_control_service_s)
    return (rank[0] + bonus, *rank[1:]) if bonus else rank


RANK_CODE = _rank_with_deadline.__code__
BONUS_CODE = bounded_bonus.__code__
CALENDAR_CODE = next_certificate_opportunity.__code__


class RankHandle:
    """Own one instance hook and restore it without touching native classes."""
    def __init__(self, net):
        require(OWNER not in net.__dict__ and "_application_rank" not in net.__dict__,
                "Foreign rank override cannot enter V31")
        original = net._application_rank
        require(type(original) is MethodType and original.__self__ is net
                and original.__func__ is ORIGINAL_RANK and ORIGINAL_RANK.__code__ is ORIGINAL_CODE,
                "V31 requires actual original native C06 rank")
        require(net.n_auvs in (3, 4) and net.intent_enabled is True,
                "V31 instance hook only belongs to scale3/4 FULL")
        self.net, self.original, self.closed = net, original, False
        self.bound = MethodType(_rank_with_deadline, net)
        net.__dict__[OWNER] = self
        net._application_rank = self.bound
        self.check()

    def check(self):
        require(not self.closed and self.net.__dict__.get(OWNER) is self
                and self.net.__dict__.get("_application_rank") is self.bound
                and type(self.original) is MethodType and self.original.__self__ is self.net
                and self.original.__func__ is ORIGINAL_RANK
                and ORIGINAL_RANK.__code__ is ORIGINAL_CODE
                and _ConflictMixin.__dict__["_application_rank"] is ORIGINAL_RANK
                and _rank_with_deadline.__code__ is RANK_CODE
                and bounded_bonus.__code__ is BONUS_CODE
                and next_certificate_opportunity.__code__ is CALENDAR_CODE,
                "V31 local rank ownership or original/derived function changed")

    def restore(self):
        if self.closed:
            return self.verify_closed()
        self.check()
        del self.net.__dict__["_application_rank"]
        del self.net.__dict__[OWNER]
        self.closed = True
        self.verify_closed()

    def verify_closed(self):
        require(self.closed and OWNER not in self.net.__dict__
                and "_application_rank" not in self.net.__dict__
                and self.net._application_rank.__func__ is ORIGINAL_RANK,
                "V31 close cannot hide a foreign rank override")


def declaration(n, method):
    return dict(name="root_local_child_first_future_opportunity_bounded_urgency",
                enabled=n in (3, 4) and method == "full_v6", n_auv=n,
                eligibility="owner0/src0 MAC_SUBCOMMIT in local transmitter queue only",
                window="next strictly future immutable child certificate opportunity within one native frame",
                bonus="one native frame / original mac_control_service_s3.0",
                original_rank_and_tie_breakers_preserved=True, native_unbounded_flow_age_preserved=True,
                real_slots_bits_TTL_received_permissions_and_management_rescue_unchanged=True,
                private_receiver_state_or_truth_read=False, no_delivery_or_collection_guarantee=True)


def verify_environment(env):
    handle = env._child_delivery_handle
    if env._joint_declared_n_auv in (3, 4) and env._joint_expected_DTO["method"] == "full_v6":
        require(type(handle) is RankHandle and handle.net is env.network, "V31 actual rank hook missing")
        handle.check()
    else:
        require(handle is None and OWNER not in env.network.__dict__
                and "_application_rank" not in env.network.__dict__, "N2/USDE cannot carry V31 priority")
