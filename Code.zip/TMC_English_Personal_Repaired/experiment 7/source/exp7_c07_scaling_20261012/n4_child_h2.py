"""Conditional N4-only H2 runtime port, not a selected/frozen candidate.

No verification/Fake/probe executor imports. Original C07 source/class/globals
are never changed. Reuse only the PIN-bound local C03 domain-port primitive;
new options have their own profile/token/serialization. N2/N3 stay H1.
"""
import ast
import hashlib
import inspect
import json
import math
from collections import Counter
from contextvars import ContextVar
from copy import deepcopy
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from types import FunctionType, MappingProxyType, MethodType

from . import paths, root_budget
from v6_candidates.c04.environment import TaskV4Env as OriginalC04Environment

PROFILE = "adaptive_packet_grid_n4_child_h2_v11"
HORIZONS = MappingProxyType({2: 1, 3: 1, 4: 2})
MINIMUMS = MappingProxyType({2: 14.4, 3: 30.0, 4: 84.0})
C04_SHA = "de47f545838bef42c2735a2ab7c92a63faa8ef351ec49ea82a19205630001e21"
BUDGET_SHA = "914ed5dedf239a62ea12165b443a2e1c93a4badba949dabde678b1987b617860"
REFERENCE_PINS = MappingProxyType({
    "models/45w/full_v6/metadata.json": "8b6eca4e085217d92dc5f387f8414ed1fa104d4639a086227b13de3063484128",
    "models/45w/usde_only_v6/metadata.json": "cff0604e677109d7baf6ca596a6e9031e7cfe16f12cf40b94661bcc5b3570084",
    "provenance/frozen_config.json": "9465309c17f69fd196385f33e7bf5eba15ce1b51a1441fdd7b081028ced1ffe7"})
INNER = "_c04_child_tick"
OWNER = "_v11_selector_owner"
_ORIGINAL = OriginalC04Environment.__dict__[INNER]
_OPTIONS = root_budget.OriginalC07Options
_ANCHOR = root_budget.OriginalC03Options
_FIELDS = frozenset(field.name for field in fields(_OPTIONS))
_SCOPE = ContextVar("independent_c07_n4_child_h2_v11_options", default=None)
_ROOT = Path(__file__).resolve().parents[1]
_SOURCE = _ROOT / "c07_source"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def exact(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return (all(type(k) is str for k in a) and all(type(k) is str for k in b)
                and a.keys() == b.keys() and all(exact(a[k], b[k]) for k in a))
    if type(a) in (list, tuple):
        return len(a) == len(b) and all(exact(x, y) for x, y in zip(a, b))
    if type(a) is float:
        return math.isfinite(a) and math.isfinite(b) and a == b
    return (a is None or type(a) in (str, int, bool)) and a == b


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def constant_signature(value):
    if inspect.iscode(value):
        return ("code", code_signature(value))
    if type(value) is tuple:
        return ("tuple", tuple(constant_signature(x) for x in value))
    if type(value) is frozenset:
        return ("frozenset", frozenset(constant_signature(x) for x in value))
    require(value is None or type(value) in (bool, int, float, complex, str, bytes),
            "Unexpected compiler constant")
    return (type(value).__name__, value)


def code_signature(code):
    return (code.co_code, code.co_argcount, code.co_posonlyargcount, code.co_kwonlyargcount,
            code.co_flags & 0x3ff, getattr(code, "co_exceptiontable", b""), code.co_names,
            code.co_varnames, code.co_freevars, code.co_cellvars,
            tuple(constant_signature(x) for x in code.co_consts))


def dependencies():
    require(Path(paths.SOURCE).resolve() == _SOURCE and
            Path(paths.REFERENCE).resolve() == _ROOT / "reference" and
            Path(paths.PACKAGE).resolve() == Path(__file__).resolve().parent,
            "H2 runtime refuses live/fallback dependency roots")
    require(Path(root_budget.__file__).resolve() == Path(__file__).with_name("root_budget.py")
            and digest(root_budget.__file__) == BUDGET_SHA, "Original V9 budget primitive PIN/origin differs")
    require(all(digest(_ROOT / "reference" / key)==value for key,value in REFERENCE_PINS.items()),
            "Original full/USDE/config reference byte identity differs")
    for cls in (_OPTIONS, _ANCHOR, root_budget.OriginalC04Options, OriginalC04Environment):
        require(Path(inspect.getsourcefile(cls)).resolve().is_relative_to(_SOURCE),
                "H2 runtime refuses cached classes from another source tree")
    path = _SOURCE / "v6_candidates/c04/environment.py"
    require(digest(path) == C04_SHA and Path(_ORIGINAL.__code__.co_filename).resolve() == path,
            "Original C04 selector source PIN/origin differs")
    return path


def _derive():
    path = dependencies()
    tree = ast.parse(path.read_text(encoding="utf-8-sig"))
    cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == "TaskV4Env")
    original = next(x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == INNER)
    dump = lambda x: ast.dump(x, include_attributes=False)
    expected = ast.fix_missing_locations(ast.Module(body=[deepcopy(original)], type_ignores=[]))
    code = next(x for x in compile(expected, str(path), "exec", dont_inherit=True).co_consts if inspect.iscode(x))
    require(type(_ORIGINAL) is FunctionType and _ORIGINAL.__closure__ is None and
            _ORIGINAL.__defaults__ is None and _ORIGINAL.__kwdefaults__ is None and
            code_signature(_ORIGINAL.__code__) == code_signature(code),
            "Actual typed C04 selector code/defaults differ from pinned source")
    require(_ORIGINAL.__globals__.get("Counter") is Counter, "Original Counter binding differs")
    modified = deepcopy(original)
    signature = dump(ast.parse("first-net.time > net.frame_duration", mode="eval").body)
    sites = [x for x in ast.walk(modified) if isinstance(x, ast.If) and dump(x.test) == signature]
    require(len(sites) == 1, "Exactly one original inner MAX site required")
    comparator = deepcopy(sites[0].test.comparators[0])
    sites[0].test.comparators[0] = ast.BinOp(left=ast.Constant(2), op=ast.Mult(), right=deepcopy(comparator))
    restored = deepcopy(modified)
    signature2 = dump(ast.parse("first-net.time > 2*net.frame_duration", mode="eval").body)
    back = [x for x in ast.walk(restored) if isinstance(x, ast.If) and dump(x.test) == signature2]
    require(len(back) == 1, "Exactly one N4 H2 MAX site required")
    back[0].test.comparators[0] = comparator
    require(dump(restored) == dump(original), "Non-MAX C04 behavior changed")
    namespace = dict(_ORIGINAL.__globals__)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[modified], type_ignores=[])),
                 "<source-pinned-native-N4-H2-inner>", "exec", dont_inherit=True), namespace)
    function = namespace[INNER]
    function.__defaults__ = _ORIGINAL.__defaults__
    function.__kwdefaults__ = _ORIGINAL.__kwdefaults__
    function.__annotations__ = dict(_ORIGINAL.__annotations__)
    proof = dict(source_key="original/v6_candidates/c04/environment.py", source_sha256=C04_SHA,
        changed_AST_sites=1, MAX_delta="F -> 2*F", reverse_AST_identical=True,
        original_AST_sha256=hashlib.sha256(dump(original).encode()).hexdigest(),
        derived_AST_sha256=hashlib.sha256(dump(modified).encode()).hexdigest(),
        actual_typed_code_verified=True, actual_Counter_preserved=True,
        outer_MIN_score_ties_clip_overlap_caps_unchanged=True, original_class_or_globals_modified=False)
    return function, proof, code_signature(code)


_H2, _PROOF, _ORIGINAL_CODE = _derive()
_H2_CODE = code_signature(_H2.__code__)
_ORIGINAL_GLOBALS = dict(_ORIGINAL.__globals__)
_H2_GLOBALS = dict(_H2.__globals__)
_ANNOTATIONS = dict(_ORIGINAL.__annotations__)
_PRIMITIVE = root_budget._PORTED_C03_POST_INIT
_PRIMITIVE_CODE = code_signature(_PRIMITIVE.__code__)
_PRIMITIVE_GLOBALS = dict(_PRIMITIVE.__globals__)
_PRIMITIVE_DEFAULTS = (_PRIMITIVE.__defaults__,_PRIMITIVE.__kwdefaults__)


def selector_proof(n):
    require(type(n) is int and n in HORIZONS, "Typed fixed N2/N3/N4 horizon only")
    validate_code()
    proof = deepcopy(_PROOF)
    if n != 4:
        proof.update(changed_AST_sites=0, MAX_delta="original F", derived_AST_sha256=proof["original_AST_sha256"])
    return dict(profile=PROFILE, n_auv=n, horizon=HORIZONS[n], fixed_horizon_mapping={str(k):v for k,v in HORIZONS.items()},
        minimum_command_lead_s=MINIMUMS[n], selector_port=proof,
        total_behavior_deltas="Only N4 innerMAX F->2F and existing MIN36->84; N2/N3 H1 unchanged",
        source_keys_are_portable=True, constructor_selects_or_trains=False)


def fast_runtime_check():
    """Actual memory identity only; no disk reads, JSON, AST or compilation."""
    require(OriginalC04Environment.__dict__.get(INNER) is _ORIGINAL and
            code_signature(_ORIGINAL.__code__) == _ORIGINAL_CODE and
            _ORIGINAL.__globals__.get("Counter") is Counter and
            code_signature(_H2.__code__) == _H2_CODE and _H2.__globals__.get("Counter") is Counter,
            "Original/derived selector code, class or Counter drift")
    require(set(_ORIGINAL.__globals__)==set(_ORIGINAL_GLOBALS) and
            all(_ORIGINAL.__globals__[k] is v for k,v in _ORIGINAL_GLOBALS.items()) and
            set(_H2.__globals__)==set(_H2_GLOBALS) and all(_H2.__globals__[k] is v for k,v in _H2_GLOBALS.items()) and
            _ORIGINAL.__closure__ is None and _H2.__closure__ is None and
            _ORIGINAL.__defaults__ is None and _H2.__defaults__ is None and
            _ORIGINAL.__kwdefaults__ is None and _H2.__kwdefaults__ is None and
            exact(_ORIGINAL.__annotations__,_ANNOTATIONS) and exact(_H2.__annotations__,_ANNOTATIONS),
            "Original/derived selector globals/defaults/closure drift")
    require(root_budget._PORTED_C03_POST_INIT is _PRIMITIVE and
            code_signature(_PRIMITIVE.__code__) == _PRIMITIVE_CODE and
            set(_PRIMITIVE.__globals__)==set(_PRIMITIVE_GLOBALS) and
            all(_PRIMITIVE.__globals__[k] is v for k,v in _PRIMITIVE_GLOBALS.items()) and
            exact((_PRIMITIVE.__defaults__,_PRIMITIVE.__kwdefaults__),_PRIMITIVE_DEFAULTS) and
            len(_PRIMITIVE.__closure__)==1 and
            _PRIMITIVE.__closure__[0].cell_contents is _ANCHOR and
            N4H2Options.__mro__==_EXPECTED_OPTIONS_MRO and tuple(fields(N4H2Options))==_EXPECTED_OPTIONS_FIELDS,
            "Private C03 primitive code/MRO anchor drift")


def full_source_validate():
    """Boundary proof: disk/source/reference PIN and recompiled C03 primitive."""
    dependencies()
    fresh, proof = root_budget._ported_c03_validator()
    require(code_signature(_PRIMITIVE.__code__) == code_signature(fresh.__code__)
            and _PRIMITIVE.__globals__ is fresh.__globals__ and _PRIMITIVE.__closure__[0].cell_contents is _ANCHOR
            and proof["changed_ast_sites"] == 1 and proof["remaining_validator_AST_identical"] is True,
            "Private C03 source proof differs")
    fast_runtime_check()


def validate_code():
    # Existing proof/test API remains the FULL boundary check.
    full_source_validate()


def expected_options(n, method):
    require(type(n) is int and n in HORIZONS and method in ("full_v6", "usde_only_v6"), "Typed H2 scale/method required")
    dependencies()
    path = _ROOT / "reference/models/45w" / method / "metadata.json"
    value = json.loads(path.read_text(encoding="utf-8-sig"))["method_options"]
    require(set(value) == _FIELDS and type(value.get("mac_enabled")) is bool and
            value["mac_enabled"] is (method == "full_v6"), "Complete original reference MO schema/ablation required")
    if n > 2:
        value.update(root_budget.registered_budget_values(n))
        value["mac_child_lead_s"] = MINIMUMS[n]
    return value


def _scope_check(options):
    scope = _SCOPE.get()
    require(type(scope) is dict and scope.get("profile") == PROFILE and exact(scope.get("n_auv"), 4)
            and exact(scope.get("n_sensors"), 30) and scope.get("method") in ("full_v6", "usde_only_v6"),
            "Independent V11 N4 construction token absent/wrong")
    require(exact(scope.get("method_options"), expected_options(4, scope["method"])) and
            exact(asdict(options), scope["method_options"]), "Full typed V11 N4 options differ")
    validate_code()


class _H2C03Insertion(_ANCHOR):
    def __post_init__(self):
        _scope_check(self)
        _PRIMITIVE(self)


@dataclass(frozen=True)
class N4H2Options(_OPTIONS, _H2C03Insertion):
    def __post_init__(self):
        _scope_check(self)
        super().__post_init__()

    def __reduce_ex__(self, protocol):
        return _restore_options, (PROFILE, asdict(self))


def _restore_options(profile, values):
    require(type(values) is dict and type(values.get("mac_enabled")) is bool, "Typed serialized H2 MO required")
    method = "full_v6" if values["mac_enabled"] else "usde_only_v6"
    return build_options(4, 30, profile, method, values)


def build_options(n, sensors, profile, method, values):
    require(type(profile) is str and profile == PROFILE and type(n) is int and n in HORIZONS
            and type(sensors) is int and sensors == 30, "Explicit V11/common30 identity required")
    require(type(values) is dict and exact(values, expected_options(n, method)), "Complete typed V11 MO required")
    if n != 4:
        return _OPTIONS(**deepcopy(values))
    token = _SCOPE.set(dict(profile=PROFILE, n_auv=4, n_sensors=30, method=method, method_options=deepcopy(values)))
    try:
        return N4H2Options(**deepcopy(values))
    finally:
        _SCOPE.reset(token)


_mro = N4H2Options.__mro__
_pos = _mro.index(root_budget.OriginalC04Options)
require(_mro[_pos:_pos+3] == (root_budget.OriginalC04Options, _H2C03Insertion, _ANCHOR)
        and tuple(fields(N4H2Options)) == tuple(fields(_OPTIONS)), "Original native MRO/schema must remain intact")
_EXPECTED_OPTIONS_MRO = N4H2Options.__mro__
_EXPECTED_OPTIONS_FIELDS = tuple(fields(N4H2Options))


class SelectorHandle:
    """Single instance ownership; reset may delete only our owned override."""
    def __init__(self, env):
        full_source_validate()
        require(getattr(type(env), INNER) is _ORIGINAL, "Foreign class selector cannot enter H2")
        require(OWNER not in env.__dict__, "Another H2 handle owns this instance, including a reset-deleted method")
        self.env = env
        self.had_original_entry = INNER in env.__dict__
        self.original_entry = env.__dict__.get(INNER)
        require(not self.had_original_entry or type(self.original_entry) is MethodType and
                self.original_entry.__self__ is env and self.original_entry.__func__ is _ORIGINAL,
                "Foreign instance selector cannot enter H2")
        self.bound = MethodType(_H2, env)
        self.closed = False
        env.__dict__[OWNER] = self
        env.__dict__[INNER] = self.bound
        try:
            self.check()
        except BaseException as error:
            preserve_cleanup(error,self.restore,"H2 install ownership cleanup also failed")
            raise

    def check(self, *, reset_deleted=False):
        fast_runtime_check()
        require(not self.closed and getattr(type(self.env), INNER) is _ORIGINAL
                and self.env.__dict__.get(OWNER) is self, "Closed/foreign H2 selector class/ownership")
        if INNER not in self.env.__dict__ and reset_deleted:
            self.env.__dict__[INNER] = self.bound
        require(self.env.__dict__.get(INNER) is self.bound, "Foreign/missing N4 H2 instance selector")

    def restore(self):
        if self.closed:
            return
        # Cleanup is identity-only: a corrupted code/global must stop behavior,
        # but must not itself prevent removal of our owned instance method.
        # Never overwrite a foreign owner/method, including during cancellation.
        require(self.env.__dict__.get(OWNER) is self and
                (INNER not in self.env.__dict__ or self.env.__dict__[INNER] is self.bound),
                "Foreign selector ownership must not be overwritten during cleanup")
        if self.had_original_entry:
            self.env.__dict__[INNER] = self.original_entry
        else:
            self.env.__dict__.pop(INNER,None)
        del self.env.__dict__[OWNER]
        self.closed = True


def validate_environment_selector(env, n):
    require(type(n) is int and n in HORIZONS, "Typed declared selector scale required")
    fast_runtime_check()
    if n == 4:
        handle = getattr(env, "_v11_selector_handle", None)
        require(type(handle) is SelectorHandle and handle.env is env, "N4 H2 owned selector missing")
        handle.check()
    else:
        method = getattr(env, INNER)
        require(type(method) is MethodType and method.__self__ is env and method.__func__ is _ORIGINAL
                and getattr(type(env), INNER) is _ORIGINAL, "N2/N3 require untouched original H1 selector")


def preserve_cleanup(error, callback, description):
    try:
        callback()
    except BaseException as cleanup:
        error.add_note(description + ": " + repr(cleanup))
