"""Pure record arithmetic for the isolated C07 scale study.

No environment, model, training, or simulator module is imported. Missing
observations remain None. Failed episodes are never removed. Bootstrap
intervals describe paired development seeds, not a performance guarantee.
"""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Mapping
import math
import random
import statistics


METHOD_ALIASES = {
    "full": "full", "full_v6": "full",
    "usde": "usde_only", "usde_only": "usde_only", "usde_only_v6": "usde_only",
}
CONTRASTS = {
    "full4-full3": ((4, "full"), (3, "full")),
    "full3-full2": ((3, "full"), (2, "full")),
    "full3-usde3": ((3, "full"), (3, "usde_only")),
    "full4-usde4": ((4, "full"), (4, "usde_only")),
}
REQUIRED_FIELDS = ("n_auv", "method", "seed", "distinct_sensors", "collected_packets",
                   "duration_s", "terminated", "truncated", "safety", "metrics75", "network_summary")


def _number(value, name, *, nonnegative=True):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be a finite number or None")
    if nonnegative and value < 0:
        raise ValueError(f"{name} must not be negative")
    return float(value)


def _integer(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _at(mapping, path):
    if not isinstance(mapping, Mapping):
        return None
    if path in mapping:
        return mapping[path]
    value = mapping
    for key in path.split("."):
        if not isinstance(value, Mapping) or key not in value:
            return None
        value = value[key]
    return value


def _scalar(value):
    return value.get("value") if isinstance(value, Mapping) else value


def _first(row, row_paths=(), metric_paths=(), network_paths=()):
    for source, paths in ((row, row_paths), (row.get("metrics75"), metric_paths),
                          (row.get("network_summary"), network_paths)):
        for path in paths:
            value = _scalar(_at(source, path))
            if value is not None:
                return value
    return None


def _stats(values):
    present = [value for value in values if value is not None]
    return dict(n_available=len(present), n_missing=len(values) - len(present),
                sum=sum(present) if present else None,
                mean=statistics.fmean(present) if present else None,
                minimum=min(present) if present else None,
                maximum=max(present) if present else None,
                standard_deviation=statistics.stdev(present) if len(present) > 1 else None)


def _pooled(pairs, numerator_unit, denominator_unit):
    present = [(a, b) for a, b in pairs if a is not None and b is not None]
    numerator = sum(a for a, _ in present) if present else None
    denominator = sum(b for _, b in present) if present else None
    return dict(n_available=len(present), n_missing=len(pairs) - len(present),
                numerator=numerator, denominator=denominator,
                numerator_unit=numerator_unit, denominator_unit=denominator_unit,
                ratio=numerator / denominator if denominator is not None and denominator > 0 else None)


def audit_unique_data(keys: Iterable, n_sensors: int, expected_packets=None):
    """Audit collection from unique zero-based (sensor, sequence) DATA keys.

    Duplicate receipts count once; repeated packets from one SN do not increase
    distinct-SN coverage. A zero-total Jain index is undefined, not perfect.
    """
    n_sensors = _integer(n_sensors, "n_sensors", 1)
    unique, receipts = set(), 0
    for key in keys:
        if not isinstance(key, (tuple, list)) or len(key) != 2:
            raise ValueError("Every DATA key must be (sensor, sequence)")
        sensor = _integer(key[0], "sensor")
        sequence = _integer(key[1], "sequence")
        if sensor >= n_sensors:
            raise ValueError("DATA sensor outside declared deployment")
        receipts += 1
        unique.add((sensor, sequence))
    counts = [0] * n_sensors
    for sensor, _ in unique:
        counts[sensor] += 1
    packets = len(unique)
    if expected_packets is not None and packets != _number(expected_packets, "expected_packets"):
        raise ValueError("Unique DATA keys disagree with collected_packets")
    distinct = sum(count > 0 for count in counts)
    squares = sum(count * count for count in counts)
    return dict(collected_packets=packets, distinct_sensors=distinct, n_sensors=n_sensors,
                coverage_fraction=distinct / n_sensors, per_sensor_packets=counts,
                duplicate_receipts=receipts - packets,
                packets_per_served_sensor=packets / distinct if distinct else None,
                jain_packets_all_sensors=packets * packets / (n_sensors * squares) if squares else None,
                zero_service_sensor_fraction=(n_sensors - distinct) / n_sensors)


def _validate_rows(rows):
    result, identities = [], set()
    for row in rows:
        if not isinstance(row, Mapping) or any(key not in row for key in REQUIRED_FIELDS):
            raise ValueError(f"Each normalized row requires {REQUIRED_FIELDS}")
        n = _integer(row["n_auv"], "n_auv", 2)
        if n not in (2, 3, 4):
            raise ValueError("Only declared 2/3/4-AUV scales are supported")
        method = row["method"]
        if not isinstance(method, str) or not method:
            raise ValueError("method must be a nonempty string")
        method = METHOD_ALIASES.get(method, method)
        seed = _integer(row["seed"], "seed")
        identity = (n, method, seed)
        if identity in identities:
            raise ValueError(f"Duplicate arm/scale/seed {identity}")
        identities.add(identity)
        for key in ("distinct_sensors", "collected_packets", "duration_s"):
            _number(row[key], key)
        for key in ("terminated", "truncated"):
            if type(row[key]) is not bool:
                raise ValueError(f"{key} must be boolean")
        for key in ("safety", "metrics75", "network_summary"):
            if row[key] is not None and not isinstance(row[key], Mapping):
                raise ValueError(f"{key} must be a mapping or None")
        result.append((n, method, seed, row))
    return result


def _collection(row):
    n_sensors = _first(row, ("n_sensors",), ("environment.collection.n_sensors",))
    if n_sensors is not None:
        n_sensors = _integer(n_sensors, "n_sensors", 1)
    distinct = _number(row["distinct_sensors"], "distinct_sensors")
    packets = _number(row["collected_packets"], "collected_packets")
    if any(value is not None and not value.is_integer() for value in (distinct, packets)):
        raise ValueError("Distinct sensors and unique packets must be whole counts")
    if distinct is not None and n_sensors is not None and distinct > n_sensors:
        raise ValueError("distinct_sensors exceeds n_sensors")
    if distinct is not None and packets is not None and distinct > packets:
        raise ValueError("distinct_sensors exceeds unique collected_packets")
    counts = row.get("per_sensor_packets")
    audit = None
    if row.get("unique_data_keys") is not None:
        if n_sensors is None:
            raise ValueError("unique_data_keys require n_sensors")
        audit = audit_unique_data(row["unique_data_keys"], n_sensors, packets)
        counts = audit["per_sensor_packets"]
    if counts is not None:
        counts = [_integer(value, "per_sensor_packets") for value in counts]
        if not counts or (n_sensors is not None and len(counts) != n_sensors):
            raise ValueError("per_sensor_packets must cover every declared sensor, including zeros")
        n_sensors = len(counts)
        if packets is not None and sum(counts) != packets:
            raise ValueError("per_sensor_packets disagree with unique packet total")
        counted_distinct = sum(value > 0 for value in counts)
        if distinct is not None and counted_distinct != distinct:
            raise ValueError("per_sensor_packets disagree with distinct_sensors")
        if distinct is None:
            distinct = float(counted_distinct)
        squares = sum(value * value for value in counts)
        jain = sum(counts) ** 2 / (len(counts) * squares) if squares else None
    else:
        jain = _number(_first(row, ("jain_packets_all_sensors",),
            ("environment.collection.jain_collected_packets_all_sensors",)), "Jain")
    coverage = distinct / n_sensors if distinct is not None and n_sensors is not None else _number(
        _first(row, ("coverage_fraction",), ("environment.collection.service_coverage_fraction",)), "coverage")
    if coverage is not None and not 0 <= coverage <= 1:
        raise ValueError("Coverage must lie in [0, 1]")
    return dict(distinct_sensors=distinct, collected_packets=packets, n_sensors=n_sensors,
                coverage_fraction=coverage, jain_packets_all_sensors=jain,
                packets_per_served_sensor=packets / distinct if packets is not None and distinct else None,
                zero_service_sensor_fraction=1 - coverage if coverage is not None else None,
                packet_depth_available=counts is not None)


def _field_values(rows, row_paths=(), metric_paths=(), network_paths=()):
    return [_number(_first(row, row_paths, metric_paths, network_paths),
                    str(row_paths or metric_paths or network_paths)) for row in rows]


def summarize_groups(rows):
    """Summarize all supplied episodes; every rate names its actual denominator.

    Include n_sensors for auditable coverage denominators. True resolved DATA
    failures/trials must be supplied; a reported failure ratio is never inverted
    to invent trial counts. Optional per_sensor_packets or unique_data_keys
    enable an independently reconciled packet-depth/Jain audit.
    """
    groups = defaultdict(list)
    for n, method, seed, row in _validate_rows(rows):
        groups[n, method].append((seed, row))
    summaries = {}
    for (n, method), entries in sorted(groups.items()):
        entries.sort(key=lambda item: item[0])
        group = [row for _, row in entries]
        collections = [_collection(row) for row in group]
        safety = [row.get("safety") or {} for row in group]
        durations = [_number(row["duration_s"], "duration_s") for row in group]
        def pairs(first, second):
            return list(zip(first, second))
        fail = _field_values(group, ("data_resolved_failures", "data_hop_failures"), network_paths=(
            "data_resolved_failures", "data_hop_failures", "by_kind.DATA.hop_delivery.completion_window.resolved_failures",
            "by_kind.DATA.hop_delivery.resolved_failures", "DATA.resolved_failures"))
        trials = _field_values(group, ("data_resolved_trials", "data_hop_resolved_trials"), network_paths=(
            "data_resolved_trials", "data_hop_resolved_trials", "by_kind.DATA.hop_delivery.completion_window.resolved_trials",
            "by_kind.DATA.hop_delivery.resolved_trials", "DATA.resolved_trials"))
        if any(a is not None and b is not None and a > b for a, b in zip(fail, trials)):
            raise ValueError("Resolved DATA failures exceed resolved trials")
        energy = _field_values(group, ("energy_j", "total_energy_j"), ("metrics_base.total_energy_j",))
        aoi_sum = _field_values(group, ("aoi_sum_s",))
        aoi_den = _field_values(group, ("aoi_auv_seconds",))
        usable = _field_values(group, ("connectivity_usable_auv_seconds",))
        observed = _field_values(group, ("connectivity_observation_auv_seconds",))
        if any(a is not None and b is not None and a > b for a, b in zip(usable, observed)):
            raise ValueError("Usable connectivity exceeds observed AUV seconds")
        safety_result = {}
        for name in ("had_collision", "had_boundary", "had_any_violation"):
            values = [value.get(name) for value in safety]
            if any(value is not None and type(value) is not bool for value in values):
                raise ValueError(f"safety.{name} must be boolean or None")
            safety_result[name] = _pooled([(int(value), 1) if value is not None else (None, None)
                                         for value in values], "episodes", "observed episodes")
        for num, den, unit in (("collision_pair_s", "observation_pair_s", "pair seconds"),
                              ("boundary_auv_s", "observation_auv_s", "AUV seconds")):
            safety_result[num] = _pooled([(_number(value.get(num), num), _number(value.get(den), den))
                                         for value in safety], unit, unit)
        for name in ("collision_onsets", "boundary_onsets", "maximum_excursion_m", "minimum_separation_m"):
            safety_result[name] = _stats([_number(value.get(name), name) for value in safety])
        recovery_rows = [row.get("recovery") for row in group]
        known_recovery = [value for value in recovery_rows if isinstance(value, Mapping)
                          and type(value.get("affected")) is bool]
        affected = [value for value in known_recovery if value["affected"]]
        recovered_times, censored_followup = [], []
        recovered_count = censored_count = 0
        for value in affected:
            censored = value.get("censored")
            delay = _number(value.get("recovery_s"), "recovery_s")
            if censored is True:
                if delay is not None:
                    raise ValueError("Censored recovery must not have a recovered delay")
                censored_count += 1
                censored_followup.append(_number(value.get("censor_followup_s"), "censor_followup_s"))
            elif censored is False and delay is not None:
                recovered_count += 1
                recovered_times.append(delay)
        unresolved_recovery = len(affected) - recovered_count - censored_count
        recovery_complete = bool(known_recovery) and unresolved_recovery == 0
        metrics75 = {}
        for key in sorted({key for row in group for key in (row.get("metrics75") or {})}):
            values = [_scalar(_at(row.get("metrics75"), key)) for row in group]
            if all(value is None or isinstance(value, (int, float)) for value in values):
                metrics75[key] = _stats([_number(int(value) if type(value) is bool else value, key,
                                                    nonnegative=False) for value in values])
        summaries[f"auv{n}/{method}"] = dict(
            episodes=len(group), n_auv=n, method=method, seeds=[seed for seed, _ in entries],
            terminated_episodes=sum(row["terminated"] for row in group),
            truncated_episodes=sum(row["truncated"] for row in group),
            duration_s=_stats(durations),
            distinct_sensors=_stats([value["distinct_sensors"] for value in collections]),
            coverage_fraction=_stats([value["coverage_fraction"] for value in collections]),
            coverage_pooled=_pooled([(value["distinct_sensors"], value["n_sensors"]) for value in collections],
                                    "distinct served sensors", "deployed sensors summed over episodes"),
            collected_packets=_stats([value["collected_packets"] for value in collections]),
            packet_depth=dict(episodes_with_audited_per_sensor_counts=sum(value["packet_depth_available"] for value in collections),
                packets_per_served_sensor=_stats([value["packets_per_served_sensor"] for value in collections]),
                pooled_packets_per_served_sensor=_pooled([(value["collected_packets"], value["distinct_sensors"])
                                                          for value in collections], "unique packets", "distinct served sensors"),
                jain_packets_all_sensors=_stats([value["jain_packets_all_sensors"] for value in collections]),
                zero_service_sensor_fraction=_stats([value["zero_service_sensor_fraction"] for value in collections])),
            data_nondelivery=_pooled(pairs(fail, trials), "resolved DATA failures", "resolved DATA trials"),
            energy_j=_stats(energy), energy_j_per_unique_packet=_pooled(
                pairs(energy, [value["collected_packets"] for value in collections]), "joules", "unique packets"),
            airtime_s=_stats(_field_values(group, ("airtime_s",), network_paths=("airtime_s", "totals.airtime_s"))),
            control_airtime_s=_stats(_field_values(group, ("control_airtime_s",), network_paths=("control_plane.airtime_s",))),
            control_reserved_slot_s=_stats(_field_values(group, ("control_reserved_slot_s",), network_paths=("control_plane.reserved_slot_time_s",))),
            state_aoi_pooled=_pooled(pairs(aoi_sum, aoi_den), "summed STATE age seconds", "AUV seconds"),
            state_aoi_episode_mean_s=_stats(_field_values(group, ("aoi_mean_s",), ("environment.state_aoi.pooled.mean",))),
            installed_connectivity=_pooled(pairs(usable, observed), "usable AUV seconds", "observed AUV seconds"),
            safety=safety_result,
            recovery=dict(observed_episodes=len(known_recovery), missing_episodes=len(group)-len(known_recovery),
                affected_episodes=len(affected) if known_recovery else None,
                recovered_episodes=recovered_count if recovery_complete else None,
                right_censored_episodes=censored_count if recovery_complete else None,
                observed_recovered_episodes=recovered_count if known_recovery else None,
                observed_right_censored_episodes=censored_count if known_recovery else None,
                unresolved_affected_episodes=unresolved_recovery if known_recovery else None,
                recovered_fraction=_pooled([(recovered_count, len(affected))] if recovery_complete else [(None, None)],
                                          "recovered episodes", "affected episodes"),
                recovered_delay_s=_stats(recovered_times), censor_followup_s=_stats(censored_followup)),
            metrics75=metrics75)
    return summaries


def _quantile(values, probability):
    ordered = sorted(values)
    position = probability * (len(ordered) - 1)
    low = math.floor(position)
    high = math.ceil(position)
    return ordered[low] + (position - low) * (ordered[high] - ordered[low])


def paired_contrasts(rows, metrics=("distinct_sensors", "collected_packets"), *, repetitions=10000, seed=20261012,
                     family_alpha=.05):
    """Four shared-seed, unfiltered paired contrasts: left minus right.

    Bonferroni family size is four contrasts times the requested metric count.
    The same bootstrap seed indices are reused for all complete contrasts and
    metrics. Missing values keep descriptive paired means but suppress CIs;
    they are never converted to zero or used to remove failed episodes.
    """
    repetitions = _integer(repetitions, "repetitions", 2)
    seed = _integer(seed, "bootstrap seed")
    if not 0 < family_alpha < 1:
        raise ValueError("family_alpha must lie in (0,1)")
    metrics = tuple(metrics)
    if not metrics or len(set(metrics)) != len(metrics) or any(not isinstance(key, str) for key in metrics):
        raise ValueError("metrics must be distinct metric names")
    groups = defaultdict(dict)
    for n, method, episode_seed, row in _validate_rows(rows):
        groups[n, method][episode_seed] = row
    required = set(arm for contrast in CONTRASTS.values() for arm in contrast)
    if any(arm not in groups for arm in required):
        raise ValueError("All five declared contrast arms must be present")
    reference = set(groups[2, "full"])
    if any(set(groups[arm]) != reference for arm in required):
        raise ValueError("Contrast arms must have exactly identical seed sets; no intersection-only pairing")
    seeds = sorted(reference)
    if not seeds:
        raise ValueError("At least one paired seed is required")
    rng = random.Random(seed)
    samples = [tuple(rng.randrange(len(seeds)) for _ in seeds) for _ in range(repetitions)]
    family_size = len(CONTRASTS) * len(metrics)
    corrected_alpha = family_alpha / family_size
    results = {}
    for name, (left, right) in CONTRASTS.items():
        comparisons = {}
        for metric in metrics:
            def value(row):
                if metric in ("distinct_sensors", "collected_packets", "coverage_fraction"):
                    return _collection(row)[metric]
                return _number(_first(row, (metric,), (metric,)), metric, nonnegative=False)
            differences = []
            for episode_seed in seeds:
                a, b = value(groups[left][episode_seed]), value(groups[right][episode_seed])
                differences.append(a - b if a is not None and b is not None else None)
            available = [difference for difference in differences if difference is not None]
            entry = dict(direction="left minus right", paired_seeds=seeds, paired_seed_denominator=len(seeds),
                n_available_pairs=len(available), n_missing_pairs=len(seeds)-len(available),
                mean_difference=statistics.fmean(available) if available else None,
                ci95_uncorrected=None, ci_familywise=None, family_alpha=family_alpha,
                marginal_alpha_bonferroni=corrected_alpha, family_size=family_size,
                bootstrap_repetitions=repetitions, bootstrap_seed=seed,
                expected_resamples_in_each_corrected_tail=repetitions * corrected_alpha / 2,
                interval_status="unavailable_missing_values" if len(available) != len(seeds) else "unavailable_one_pair")
            if len(seeds) >= 2 and len(available) == len(seeds):
                means = [statistics.fmean(differences[index] for index in sample) for sample in samples]
                entry["ci95_uncorrected"] = [_quantile(means, .025), _quantile(means, .975)]
                entry["ci_familywise"] = [_quantile(means, corrected_alpha/2), _quantile(means, 1-corrected_alpha/2)]
                entry["interval_status"] = "available"
            comparisons[metric] = entry
        results[name] = dict(left=dict(n_auv=left[0], method=left[1]),
                             right=dict(n_auv=right[0], method=right[1]), metrics=comparisons)
    return dict(contrasts=results, family_size=family_size, requested_metrics=list(metrics),
                family_alpha=family_alpha, simultaneous_method="Bonferroni across all requested contrasts and metrics",
                interval_method="paired percentile bootstrap with shared seed resamples",
                paired_seeds=seeds, failures_retained=True,
                interpretation="Development-seed uncertainty; not a guarantee, training-seed robustness, or final-test claim")
