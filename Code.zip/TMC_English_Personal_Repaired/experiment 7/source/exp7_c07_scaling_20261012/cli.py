"""Prepare by default; training requires an explicit train invocation."""
import argparse
from pathlib import Path
import json
import sys
from .environment import PROFILES,make_environment
from .workflow import declaration,source_hashes,train_declared,digest_json
from .budget import FULL_CONFIRMATION,BudgetLedger

def prepare(output,profile="adaptive_v1"):
    output=Path(output).resolve()
    if output.exists(): raise FileExistsError("Plan output must be new")
    plans=[]
    for n in (2,3,4):
        for method in ("full","usde_only"):
            plans.append(declaration(n,30,method,profile,faults=None))
    hashes=source_hashes()
    output.mkdir(parents=True,exist_ok=False)
    from usv_auv.train import atomic_json
    for value in plans:
        atomic_json(value,output/f"auv{value['n_auv']}_{value['method']}.json")
    plan=dict(format="original-c07-scale-plan-20261012-v1",profile=profile,
        training_seed=7,primary_workload="shared30SN/same arena, rate, slots, arrival process and1200s maximum",
        models=plans,development_budget_default="declared per-candidate endpoints;100k reference, iterative tests authorized20261012",
        development_seeds=list(range(10712000,10712010)),unopened_holdout_seeds=list(range(10713000,10713030)),
        future_full_training_endpoint=450000,full_training_authorized_now=False,
        contrast_targets=["full4 > full3","full3 > full2","full3 > usde3","full4 > usde4"],
        primary_collection="unique(sensor,sequence) DATA packets; SN coverage ancillary only",
        source_hashes=hashes,plan_sha256=digest_json(plans),
        claim="Engineering candidate, not evidence that ordering or superiority has been achieved")
    atomic_json(plan,output/"PLAN.json")
    return {"status":"prepared_no_training","models":len(plans),"output":str(output),"plan_sha256":plan["plan_sha256"]}

def parser():
    parser=argparse.ArgumentParser(description=__doc__)
    modes=parser.add_subparsers(dest="mode",required=True)
    p=modes.add_parser("prepare",help="Write6fresh model declarations; never train")
    p.add_argument("--output",required=True,type=Path)
    p.add_argument("--profile",choices=PROFILES,default="adaptive_v1")
    p=modes.add_parser("check",help="Zero-learning schema/source checks; no env.step")
    p=modes.add_parser("train",help="Explicit bounded native C07 CUDA training")
    p.add_argument("--auv",required=True,type=int,choices=(2,3,4))
    p.add_argument("--sensors",type=int,default=30)
    p.add_argument("--method",required=True,choices=("full","usde_only"))
    p.add_argument("--profile",choices=PROFILES,default="adaptive_v1")
    p.add_argument("--fault",choices=("original_c07","reference","direct1_outage"),default="original_c07")
    p.add_argument("--steps",required=True,type=int)
    p.add_argument("--seed",type=int,default=7)
    p.add_argument("--device",default="cuda")
    p.add_argument("--output",required=True,type=Path)
    p.add_argument("--ledger",required=True,type=Path)
    p.add_argument("--budget-mode",choices=("aggregate","per_model"),default="per_model")
    p.add_argument("--candidate-id",default="initial")
    p.add_argument("--development-limit",type=int,default=100000,help="Declared exploratory endpoint, not a fixed human cap")
    p.add_argument("--milestones",nargs="*",type=int,default=[])
    p.add_argument("--stage",choices=("development","full"),default="development")
    p.add_argument("--confirm-full-training",default=None,help="Later explicit authorization: "+FULL_CONFIRMATION)
    p.add_argument("--attempt-id")
    p.add_argument("--resume",type=Path)
    p.add_argument("--resume-parent-attempt")
    p=modes.add_parser("evaluate",help="Frozen development evaluation; failures retained, no learning")
    p.add_argument("--checkpoint",required=True,type=Path)
    p.add_argument("--output",required=True,type=Path)
    p.add_argument("--seeds",required=True,type=int,nargs="+")
    p.add_argument("--device",default="cpu")
    p.add_argument("--fault",choices=("reference","direct1_outage","training"),default="reference")
    p.add_argument("--validation-contract",type=Path,help="Frozen five-model contract; opens all30held-out seeds once per arm")
    p=modes.add_parser("analyze",help="Read completed evaluations; never resimulate")
    p.add_argument("--inputs",required=True,type=Path,nargs="+")
    p.add_argument("--output",required=True,type=Path)
    p=modes.add_parser("budget",help="Read physicalwork ledger")
    p.add_argument("--ledger",required=True,type=Path)
    p.add_argument("--budget-mode",choices=("aggregate","per_model"),default="aggregate")
    return parser

def main():
    args=parser().parse_args()
    if args.mode=="prepare": result=prepare(args.output,args.profile)
    elif args.mode=="train": result=train_declared(args)
    elif args.mode=="budget": result=BudgetLedger(args.ledger,args.budget_mode).snapshot()
    elif args.mode=="check":
        rows=[]
        for n in (2,3,4):
            for method in ("full","usde_only"):
                for profile in PROFILES:
                    env=make_environment(n,30,method,profile)
                    rows.append(dict(auv=n,method=method,profile=profile,local_dim=env.observation_dim,
                        root_dim=env.slow_observation_dim,topology_actions=env.network.n_actions))
                    env.close()
        result=dict(status="passed_zero_learning_zero_steps",source_count=len(source_hashes()),schemas=rows)
    elif args.mode=="evaluate":
        from .evaluation import evaluate_checkpoint
        result=evaluate_checkpoint(args.checkpoint,args.output,args.seeds,args.device,args.fault,args.validation_contract)
    else:
        from .evaluation import analyze_evaluations
        result=analyze_evaluations(args.inputs,args.output)
    print(json.dumps(result,ensure_ascii=False,allow_nan=False),flush=True)

if __name__=="__main__": main()
