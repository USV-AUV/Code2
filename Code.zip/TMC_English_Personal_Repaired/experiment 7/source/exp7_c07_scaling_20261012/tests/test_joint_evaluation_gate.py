"""Pure contract validation only: no native imports, weights or opened markers.

_validate_contract reads only pinned reference JSON and this temporary empty
history directory. It does NOT call validate_evaluation_seeds' holdout opening.
"""
import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import tempfile
from types import MappingProxyType
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
CODE = Path(__file__).resolve().parents[2]
def historical_source(relative, *, directories=(), files=()):
    """Lazily locate a historical candidate; absent history alone is a skip.

    No folder basename is required. A present candidate with missing inputs is
    an error, and the caller's existing SHA/AST assertions remain unchanged.
    """
    relative=Path(relative)
    if relative.is_absolute() or len(relative.parts)<2 or ".." in relative.parts:
        raise ValueError("A relative historical candidate path is required")
    candidate=Path(*relative.parts[:2])
    for root in Path(__file__).resolve().parents:
        anchor=root/candidate
        if not anchor.exists():
            continue
        if not anchor.is_dir():
            raise AssertionError("Historical candidate is not a directory: "+str(anchor))
        result=root/relative
        expected_directory=bool(directories or files)
        if not (result.is_dir() if expected_directory else result.is_file()):
            raise AssertionError("Present historical candidate is incomplete: "+str(result))
        for name in directories:
            if not (result/name).is_dir():
                raise AssertionError("Historical directory is missing: "+str(result/name))
        for name in files:
            if not (result/name).is_file():
                raise AssertionError("Historical file is missing: "+str(result/name))
        return result
    raise unittest.SkipTest("Historical candidate tree absent: "+candidate.as_posix())
SPEC = importlib.util.spec_from_file_location("isolated_joint_record_gate", CODE/"exp7_c07_scaling_20261012/evaluation_gate.py")
gate = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(gate)


def restore_v28_gate_functions(functions):
    """Reverse enumerated V28-only pure ports; no ignored old function bodies."""
    functions=deepcopy(functions)
    dump=lambda node:ast.dump(node,include_attributes=False)
    for name in ("_require_joint_source_pins","_joint_v28_clock_queue_records"):
        if name not in functions:raise AssertionError("Missing V28 helper: "+name)
        functions.pop(name)
    def remove(fn,predicate):
        sites=[(parent,i) for parent in ast.walk(fn) if hasattr(parent,"body") and isinstance(parent.body,list)
               for i,node in enumerate(parent.body) if predicate(node)]
        if len(sites)!=1:raise AssertionError("Exactly one V28 statement required in "+fn.name)
        parent,index=sites[0];parent.body.pop(index)
    is_call=lambda node:isinstance(node,ast.Expr) and dump(node)==dump(ast.parse("_require_joint_source_pins()").body[0])
    remove(functions["_joint_reference_records"],is_call)
    for name in ("_validate_contract","validate_evaluation_seeds"):
        remove(functions[name],lambda node:isinstance(node,ast.If) and any(is_call(x) for x in node.body))
    expected=dump(ast.parse("n>2 and profile==JOINT_PHY_LOC_ROOT16_PROFILE",mode="eval").body)
    remove(functions["_joint_expected_records"],lambda node:isinstance(node,ast.If) and dump(node.test)==expected)
    expected=dump(ast.parse("profile==JOINT_PHY_LOC_ROOT16_PROFILE",mode="eval").body)
    remove(functions["_joint_contract_scope"],lambda node:isinstance(node,ast.If) and dump(node.test)==expected)
    result=functions["_joint_contract_scope"].body[-1]
    if not isinstance(result,ast.Return) or not isinstance(result.value,ast.IfExp) or dump(result.value.test)!=expected:
        raise AssertionError("Exactly the V28 closed cross-N exemption required")
    result.value=result.value.orelse
    return functions


def restore_v27_gate_functions(functions):
    """Undo exactly V27's STATE record, memberships and closed scope return."""
    functions=restore_v28_gate_functions(functions)
    dump=lambda node:ast.dump(node,include_attributes=False)
    fn=functions["_joint_expected_records"]
    statement=ast.parse('if n>2 and profile==N34_STATE8_11_PROFILE:\n    cfg["state_period"]={3:8.0,4:11.0}[n]').body[0]
    sites=[i for i,node in enumerate(fn.body) if dump(node)==dump(statement)]
    if len(sites)!=1:raise AssertionError("Exactly one V27 STATE record assignment required")
    fn.body.pop(sites[0])
    source=dump(ast.parse("profile in (N4_COORD8_PROFILE,N34_STATE8_11_PROFILE)",mode="eval").body)
    class Restore(ast.NodeTransformer):
        count=0
        def visit_Compare(self,node):
            if dump(node)==source:
                self.count+=1
                return ast.parse("profile==N4_COORD8_PROFILE",mode="eval").body
            return self.generic_visit(node)
        def visit_Tuple(self,node):
            node=self.generic_visit(node)
            node.elts=[x for x in node.elts if not isinstance(x,ast.Name) or x.id!="N34_STATE8_11_PROFILE"]
            return node
    restore=Restore();functions={name:restore.visit(node) for name,node in functions.items()}
    if restore.count!=1:raise AssertionError("Exactly one inherited V26 COORD membership required")
    fn=functions["_joint_contract_scope"]
    expected=ast.parse('return (frozenset(("tdma_sensors_per_group","hello_period","state_period")) if profile==N34_STATE8_11_PROFILE else frozenset(("tdma_sensors_per_group","hello_period")))').body[0]
    if dump(fn.body[-1])!=dump(expected):raise AssertionError("Only closed V27 STATE cross-N scope may differ")
    fn.body[-1]=ast.parse('return frozenset(("tdma_sensors_per_group","hello_period"))').body[0]
    return functions


class JointGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.history = Path(self.tmp.name)
        # TEST-ONLY text SHA patch. It is not independent ROOT binding/release
        # authority, and the production template remains None/fail-closed.
        pins={"adapter/"+name:hashlib.sha256((CODE/"exp7_c07_scaling_20261012"/name).read_bytes()).hexdigest()
              for name in ("joint_clocks.py","environment.py") if gate.JOINT_SOURCE_PINS.get("adapter/"+name) is None}
        self.pin_patch=patch.dict(gate.JOINT_SOURCE_PINS,pins)
        self.pin_patch.start();self.addCleanup(self.pin_patch.stop)
        self.refs = {key: json.loads((CODE/"reference"/relative).read_text(encoding="utf-8-sig"))
                     for key, (relative, _) in gate.JOINT_REFERENCES.items()}
        self.sources = {**gate.JOINT_SOURCE_PINS,
            **{key: pin for key, (_, pin) in gate.JOINT_REFERENCES.items()},
            **{"original/"+key: value for key, value in self.refs["reference/full"]["source_hashes"].items()}}
        self.contract_for(next(iter(gate.JOINT_HORIZONS)))

    def contract_for(self, profile):
        self.contract = dict(format=gate.CONTRACT_FORMAT, profile=profile, training_step=200000,
            training_seed=7, primary="collected_packets", fault_profile="reference",
            history_directory=str(self.history), confirmation_index=1, family_alpha=.025,
            seeds=list(gate.HOLDOUT_SEEDS), source_hashes=deepcopy(self.sources), models=[])
        mapping = {str(n): h for n, h in gate.JOINT_HORIZONS[profile].items()}
        for n, method in sorted(gate.REQUIRED_ARMS):
            cfg, mo, reference = gate._joint_expected_records(n, method, profile, self.refs)
            h = gate.JOINT_HORIZONS[profile][n]
            lead = 14.4 if n == 2 else float(h*gate.JOINT_FRAMES[profile][n]-12)
            port = method == "full_v6" and h == 2
            declaration = dict(version="MANUFACTURED_RECORD_ONLY", profile=profile, n_auv=n,
                n_sensors=30, method=method, config=cfg, method_options=mo,
                routing_options=deepcopy(reference["routing_options"]),
                learning=deepcopy(reference["learning_config"]),
                training_protocol=deepcopy(reference["training_protocol"]), old_weights_allowed=False,
                reward="original same team reward to every TD3 replay; original topology_reward",
                ending="original collision/boundary absorbing terminal; unfinished timeout macro discarded",
                scale_diagnostics=dict(joint_clock_adaptation=dict(registered_H3_H4=mapping,
                    selector=dict(profile=profile, n_auv=n, horizon=h, fixed_horizon_mapping=mapping,
                        minimum_command_lead_s=lead, installed_H2_hook=port,
                        selector_port=dict(source_sha256=gate.JOINT_SOURCE_PINS["original/v6_candidates/c04/environment.py"],
                            changed_AST_sites=1 if port else 0, MAX_delta="F -> 2*F" if port else "original F",
                            reverse_AST_identical=True)))))
            self.contract["models"].append(dict(n_auv=n, method=method, profile=profile,
                training_step=200000, seed=7, policy_sha=hashlib.sha256(f"{profile}/{n}/{method}".encode()).hexdigest(),
                environment_config=deepcopy(cfg), declaration=declaration,
                declaration_sha256=gate._record_digest(declaration)))
            if profile==gate.JOINT_PHY_LOC_ROOT16_PROFILE:
                clock,queue,owners,gap=gate._joint_v28_clock_queue_records(n,cfg)
                declaration["scale_diagnostics"]["clock"]=clock
                declaration["scale_diagnostics"]["joint_clock_adaptation"].update(
                    actual_slot_owners=owners,actual_slot_duration_s=cfg["slot_duration"],
                    actual_cooperative_gap_s=gap,actual_max_management_run=2)
                declaration["scale_diagnostics"]["joint_phy_localization_adaptation"]=dict(
                    expected_actual_queue_options=queue,coordination_service_interval=queue["coord_service_s"],
                    localization_service_interval=queue["localization_service_s"],
                    same_N_full_USDE_whole_config_and_queue_numerics_shared=True,
                    conditional_preparation_not_launch_authority=True)
                self.reseal(self.contract["models"][-1])
        self.saved_for()

    def saved_for(self, n=4, method="full_v6"):
        model = next(m for m in self.contract["models"] if m["n_auv"] == n and m["method"] == method)
        d = deepcopy(model["declaration"])
        self.policy_sha = model["policy_sha"]
        self.saved = dict(global_step=200000, seed=7, method_id=method, source_hashes=deepcopy(self.contract["source_hashes"]),
            environment_config=deepcopy(model["environment_config"]), method_options=d["method_options"],
            routing_options=d["routing_options"], learning_config=d["learning"], training_protocol=d["training_protocol"],
            scale_context=dict(stage="development", profile=model["profile"], declaration=d,
                               declaration_sha256=model["declaration_sha256"]))

    def check(self):
        with patch.object(gate, "_exclusive_json", side_effect=AssertionError("NO opening holdout")):
            result = gate._validate_contract(self.contract, self.saved, self.policy_sha,
                                             list(gate.HOLDOUT_SEEDS), "reference")
        self.assertEqual(list(self.history.iterdir()), [])
        return result

    def reseal(self, model):
        model["declaration_sha256"] = gate._record_digest(model["declaration"])

    def test_registry_matches_reviewed_source_AST_and_no_native_imports(self):
        path = CODE/"exp7_c07_scaling_20261012/joint_clocks.py"
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), gate.JOINT_SOURCE_PINS["adapter/joint_clocks.py"])
        self.assertEqual(hashlib.sha256((CODE/"exp7_c07_scaling_20261012/environment.py").read_bytes()).hexdigest(),
            gate.JOINT_SOURCE_PINS["adapter/environment.py"])
        source = ast.parse(path.read_text(encoding="utf-8"))
        nodes = [n for n in source.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
                 and n.targets[0].id in ("LEGACY_PROFILES", "HETEROGENEOUS_PROFILE", "HELLO48_PROFILE", "POOL12_PROFILE", "N4_COORD8_PROFILE", "N34_STATE8_11_PROFILE", "JOINT_PHY_LOC_ROOT16_PROFILE", "PROFILES", "HORIZONS", "FRAMES", "PROFILE_FRAMES", "MINIMUMS")]
        namespace = {"MappingProxyType": MappingProxyType}
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])),
                     "<pure fixed registry assignments only>", "exec"), namespace)
        self.assertEqual({p:dict(h) for p,h in namespace["HORIZONS"].items()}, gate.JOINT_HORIZONS)
        self.assertEqual({p:dict(h) for p,h in namespace["PROFILE_FRAMES"].items()},gate.JOINT_FRAMES)
        self.assertNotIn("torch", sys.modules)
        self.assertNotIn("usv_auv.environment", sys.modules)

    def test_all_registered_profiles_all_five_current_arms_pure_positive_no_markers(self):
        for profile in gate.JOINT_HORIZONS:
            self.contract_for(profile)
            for n, method in sorted(gate.REQUIRED_ARMS):
                self.saved_for(n, method)
                self.assertEqual(self.check()["arm"], (n, method))

    def test_heterogeneous_exact_scope_and_legacy_N2_N3_numeric_identity(self):
        profile=gate.HETEROGENEOUS_PROFILE
        old="adaptive_packet_grid_joint_h3_2_h4_2_v12"
        for n,method in sorted(gate.REQUIRED_ARMS):
            a=gate._joint_expected_records(n,method,old,self.refs)
            z=gate._joint_expected_records(n,method,profile,self.refs)
            changed=lambda x,y:{k for k,v in y.items() if not gate._typed_exact(v,x.get(k))}
            self.assertEqual(changed(a[0],z[0]),set() if n!=4 else {"tdma_sensors_per_group","service_ack_timeout","grant_ttl"})
            self.assertEqual(changed(a[1],z[1]),set() if n!=4 else {"mac_child_lead_s"})
            self.assertEqual(z[1]["mac_prepare_lead_frames"],3)
            if n==4:
                self.assertEqual((z[0]["tdma_sensors_per_group"],z[0]["hello_period"],z[0]["service_ack_timeout"],z[0]["grant_ttl"],z[1]["mac_child_lead_s"]),
                    (4,40.0,134.0,134.0,72.0))
        self.contract_for(profile)
        self.check()

    def test_heterogeneous_resealed_G_ACK_MIN_prepare_or_USDE_only_damage_rejected(self):
        self.contract_for(gate.HETEROGENEOUS_PROFILE);original=deepcopy(self.contract)
        for field,key,value in (("config","tdma_sensors_per_group",6),("config","tdma_sensors_per_group",4.0),
            ("config","service_ack_timeout",134),("config","grant_ttl",180.0),("config","hello_period",60.0),
            ("method_options","mac_child_lead_s",54.0),("method_options","mac_child_lead_s",72),
            ("method_options","mac_prepare_lead_frames",5)):
            self.contract=deepcopy(original)
            for model in self.contract["models"]:
                if model["n_auv"]==4:
                    model["declaration"][field][key]=value
                    if field=="config":model["environment_config"][key]=value
                    self.reseal(model)
            self.saved_for()
            with self.subTest(field=field,key=key,value=value),self.assertRaises(gate.EvaluationGateError):self.check()
        self.contract=deepcopy(original)
        model=next(m for m in self.contract["models"] if m["n_auv"]==4 and m["method"]=="usde_only_v6")
        model["environment_config"]["tdma_sensors_per_group"]=6;model["declaration"]["config"]["tdma_sensors_per_group"]=6
        self.reseal(model);self.saved_for()
        with self.assertRaises(gate.EvaluationGateError):self.check()

    def test_hello48_all_six_scientific_records_only_N4_float_CFG_delta(self):
        for n in (2,3,4):
            for method in ("full_v6","usde_only_v6"):
                a=gate._joint_expected_records(n,method,gate.HETEROGENEOUS_PROFILE,self.refs)
                z=gate._joint_expected_records(n,method,gate.HELLO48_PROFILE,self.refs)
                delta={k:{"old":a[0][k],"new":v} for k,v in z[0].items()
                    if not gate._typed_exact(v,a[0].get(k))}
                self.assertTrue(gate._typed_exact(delta,{} if n!=4 else {"hello_period":{"old":40.0,"new":48.0}}))
                self.assertTrue(gate._typed_exact(a[1],z[1]))
                self.assertTrue(gate._typed_exact(a[2],z[2]))
                self.assertIs(type(z[0]["hello_period"]),float)
                self.assertIs(type(z[1]["visit_packet_budget"]),float)
                self.assertEqual(z[1]["visit_packet_budget"],4.0)
                if n==4:
                    self.assertEqual((gate.JOINT_FRAMES[gate.HELLO48_PROFILE][n],z[0]["tdma_sensors_per_group"],
                        z[0]["hello_period"],z[0]["service_ack_timeout"],z[0]["grant_ttl"],z[1]["mac_child_lead_s"]),
                        (42.0,4,48.0,134.0,134.0,72.0))
        self.contract_for(gate.HELLO48_PROFILE)
        for n,method in sorted(gate.REQUIRED_ARMS):
            self.saved_for(n,method);self.assertEqual(self.check()["arm"],(n,method))

    def test_hello48_resealed_period_type_scope_cap_or_clock_damage_rejected(self):
        self.contract_for(gate.HELLO48_PROFILE);original=deepcopy(self.contract)
        for n,field,key,value in ((4,"config","hello_period",48),(4,"config","hello_period",True),
            (4,"config","hello_period",40.0),(4,"config","hello_period",49.0),
            (4,"config","hello_period",float("nan")),(4,"config","hello_period",float("inf")),
            (3,"config","hello_period",48.0),(2,"config","hello_period",48.0),
            (4,"config","service_ack_timeout",126.0),(4,"config","grant_ttl",150.0),
            (4,"config","tdma_sensors_per_group",6),(4,"method_options","mac_child_lead_s",54.0),
            (4,"method_options","visit_packet_budget",6.0)):
            self.contract=deepcopy(original)
            for model in self.contract["models"]:
                if model["n_auv"]==n:
                    model["declaration"][field][key]=value
                    if field=="config":model["environment_config"][key]=value
                    if type(value) is not float or math.isfinite(value):
                        self.reseal(model)
            self.saved_for()
            with self.subTest(n=n,field=field,key=key,value=value),self.assertRaises(gate.EvaluationGateError):self.check()
        self.contract=deepcopy(original)
        model=next(m for m in self.contract["models"] if m["n_auv"]==4 and m["method"]=="usde_only_v6")
        model["environment_config"]["hello_period"]=40.0;model["declaration"]["config"]["hello_period"]=40.0
        self.reseal(model);self.saved_for()
        with self.assertRaises(gate.EvaluationGateError):self.check()

    def test_hello48_old_profile_whole_scope_cannot_migrate_by_resealing(self):
        self.contract_for(gate.HETEROGENEOUS_PROFILE)
        for model in self.contract["models"]:
            if model["n_auv"]==4:
                model["environment_config"]["hello_period"]=48.0
                model["declaration"]["config"]["hello_period"]=48.0
                self.reseal(model)
        self.saved_for()
        with self.assertRaises(gate.EvaluationGateError):self.check()

    def test_pool12_all_six_scientific_records_only_N4_integer_MO_delta(self):
        for n in (2,3,4):
            for method in ("full_v6","usde_only_v6"):
                a=gate._joint_expected_records(n,method,gate.HETEROGENEOUS_PROFILE,self.refs)
                z=gate._joint_expected_records(n,method,gate.POOL12_PROFILE,self.refs)
                self.assertTrue(gate._typed_exact(a[0],z[0]))
                self.assertTrue(gate._typed_exact(a[2],z[2]))
                self.assertEqual(a[1].keys(),z[1].keys())
                delta={k:{"old":a[1][k],"new":v} for k,v in z[1].items() if not gate._typed_exact(v,a[1].get(k))}
                self.assertTrue(gate._typed_exact(delta,{} if n!=4 else {"mac_pool_slots":{"old":20,"new":12}}))
                if n==4:
                    self.assertIs(type(z[1]["mac_pool_slots"]),int)
                    self.assertEqual((z[0]["hello_period"],z[1]["visit_packet_budget"],z[0]["tdma_sensors_per_group"],
                        gate.JOINT_FRAMES[gate.POOL12_PROFILE][n],z[1]["mac_child_lead_s"],z[0]["service_ack_timeout"],z[0]["grant_ttl"]),
                        (40.0,4.0,4,42.0,72.0,134.0,134.0))
        self.contract_for(gate.POOL12_PROFILE)
        for n,method in sorted(gate.REQUIRED_ARMS):
            self.saved_for(n,method);self.assertEqual(self.check()["arm"],(n,method))

    def test_pool12_resealed_nonregistered_tuple_float_alias_and_old_scope_rejected(self):
        self.contract_for(gate.POOL12_PROFILE);original=deepcopy(self.contract)
        for key,value in (("mac_pool_slots",True),("mac_pool_slots",12.0),("mac_pool_slots",9),
            ("mac_pool_slots",11),("mac_pool_slots",13),("mac_pool_slots",16),("mac_pool_slots",20),
            ("mac_auv_slots",3),("mac_max_leases",20),("mac_child_max_active",7),
            ("mac_child_slots_per_sensor",1),("mac_coop_lease_frames",29),("mac_frame_stride",1),
            ("mac_child_lease_frames",2),("visit_packet_budget",6.0)):
            self.contract=deepcopy(original)
            for model in self.contract["models"]:
                if model["n_auv"]==4:
                    model["declaration"]["method_options"][key]=value;self.reseal(model)
            self.saved_for()
            with self.subTest(key=key,value=value),self.assertRaises(gate.EvaluationGateError):self.check()
        for profile in (gate.HETEROGENEOUS_PROFILE,gate.HELLO48_PROFILE):
            self.contract_for(profile)
            for model in self.contract["models"]:
                if model["n_auv"]==4:
                    model["declaration"]["method_options"]["mac_pool_slots"]=12;self.reseal(model)
            self.saved_for()
            with self.assertRaises(gate.EvaluationGateError):self.check()
        self.contract=deepcopy(original)
        model=next(m for m in self.contract["models"] if m["n_auv"]==4 and m["method"]=="usde_only_v6")
        model["declaration"]["method_options"]["mac_pool_slots"]=20;self.reseal(model);self.saved_for()
        with self.assertRaises(gate.EvaluationGateError):self.check()
        self.contract=deepcopy(original)
        for model in self.contract["models"]:
            if model["n_auv"]==4:
                model["environment_config"]["hello_period"]=48.0;model["declaration"]["config"]["hello_period"]=48.0
                self.reseal(model)
        self.saved_for()
        with self.assertRaises(gate.EvaluationGateError):self.check()

    def test_G_HELLO_ACK_grant_typed_alias_and_drift_resealed_rejected(self):
        original = deepcopy(self.contract)
        for key, value in (("tdma_sensors_per_group", 6.), ("hello_period", 30),
                           ("hello_period", 20.), ("service_ack_timeout", 106), ("grant_ttl", 117.)):
            self.contract = deepcopy(original)
            for model in self.contract["models"]:
                if model["n_auv"] == 3:
                    model["environment_config"][key] = value
                    model["declaration"]["config"][key] = value
                    self.reseal(model)
            with self.subTest(key=key, value=value), self.assertRaises(gate.EvaluationGateError):
                self.check()

    def test_v26_all_six_independent_records_only_N4_typed_coord8_CFG_delta(self):
        for n in (2,3,4):
            for method in ("full_v6","usde_only_v6"):
                a=gate._joint_expected_records(n,method,gate.POOL12_PROFILE,self.refs)
                z=gate._joint_expected_records(n,method,gate.N4_COORD8_PROFILE,self.refs)
                delta={key:{"old":a[0][key],"new":value} for key,value in z[0].items()
                    if not gate._typed_exact(value,a[0].get(key))}
                self.assertTrue(gate._typed_exact(delta,{} if n!=4 else {"coordination_service_interval":{"old":4.0,"new":8.0}}))
                self.assertTrue(gate._typed_exact(a[1],z[1]));self.assertTrue(gate._typed_exact(a[2],z[2]))
                if n==4:
                    self.assertIs(type(z[0]["coordination_service_interval"]),float)
                    self.assertTrue(gate._typed_exact(z[0]["coordination_service_interval"],8.0))
                    self.assertTrue(gate._typed_exact(z[0]["state_period"],5.0))
                    self.assertEqual((z[0]["tdma_sensors_per_group"],gate.JOINT_FRAMES[gate.N4_COORD8_PROFILE][n],
                        z[0]["hello_period"],z[0]["service_ack_timeout"],z[0]["grant_ttl"],z[1]["mac_child_lead_s"],z[1]["mac_pool_slots"]),
                        (4,42.0,40.0,134.0,134.0,72.0,12))
                    self.assertEqual((z[0]["state_ttl"],z[2]["routing_options"]["state_stale_s"]),(90.0,25.0))
        for n in (2,3,4):
            full=gate._joint_expected_records(n,"full_v6",gate.N4_COORD8_PROFILE,self.refs)[0]
            usde=gate._joint_expected_records(n,"usde_only_v6",gate.N4_COORD8_PROFILE,self.refs)[0]
            self.assertTrue(gate._typed_exact(full,usde))
        self.contract_for(gate.N4_COORD8_PROFILE)
        for n,method in sorted(gate.REQUIRED_ARMS):
            self.saved_for(n,method);self.assertEqual(self.check()["arm"],(n,method))

    def test_v26_resealed_priority_alias_wrong_scale_MO_RO_and_unchanged_clocks_rejected(self):
        self.contract_for(gate.N4_COORD8_PROFILE);original=deepcopy(self.contract)
        changes=((4,"config","coordination_service_interval",8),(4,"config","coordination_service_interval",True),(4,"config","coordination_service_interval","8.0"),
            (4,"config","coordination_service_interval",4.0),(4,"config","coordination_service_interval",12.0),(4,"config","coordination_service_interval",8.1),
            (4,"config","coordination_service_interval",float("nan")),(4,"config","coordination_service_interval",float("inf")),
            (2,"config","coordination_service_interval",8.0),(3,"config","coordination_service_interval",8.0),
            (4,"config","state_period",20.0),(4,"config","tdma_sensors_per_group",6),(4,"config","service_ack_timeout",126.0),
            (4,"config","grant_ttl",126.0),(4,"config","hello_period",48.0),(4,"config","state_ttl",120.0),
            (4,"config","gamma",.999),(4,"routing_options","state_stale_s",90.0),
            (4,"method_options","mac_child_lead_s",16.8),(4,"method_options","mac_pool_slots",20))
        for n,section,key,bad in changes:
            self.contract=deepcopy(original)
            for model in self.contract["models"]:
                if model["n_auv"]==n:
                    model["declaration"][section][key]=bad
                    if section=="config":model["environment_config"][key]=bad
                    if type(bad) is not float or math.isfinite(bad):self.reseal(model)
            self.saved_for()
            with self.subTest(n=n,section=section,key=key,bad=bad),self.assertRaises(gate.EvaluationGateError):self.check()

    def test_v26_old_profile_reseal_asymmetric_control_and_current_metadata_rejected(self):
        self.contract_for(gate.POOL12_PROFILE)
        for model in self.contract["models"]:
            if model["n_auv"]==4:
                model["environment_config"]["coordination_service_interval"]=8.0;model["declaration"]["config"]["coordination_service_interval"]=8.0
                self.reseal(model)
        self.saved_for()
        with self.assertRaises(gate.EvaluationGateError):self.check()
        self.contract_for(gate.N4_COORD8_PROFILE);original=deepcopy(self.contract)
        for method in ("full_v6","usde_only_v6"):
            self.contract=deepcopy(original)
            model=next(x for x in self.contract["models"] if x["n_auv"]==4 and x["method"]==method)
            model["environment_config"]["coordination_service_interval"]=4.0;model["declaration"]["config"]["coordination_service_interval"]=4.0
            self.reseal(model);self.saved_for()
            with self.subTest(method=method),self.assertRaises(gate.EvaluationGateError):self.check()
        for field,key,bad in (("environment_config","coordination_service_interval",8),
            ("method_options","mac_child_lead_s",16.8),("routing_options","state_stale_s",90.0)):
            self.contract=deepcopy(original);self.saved_for();self.saved[field][key]=bad
            with self.subTest(field=field),self.assertRaises(gate.EvaluationGateError):self.check()

    def test_v26_only_enumerated_pure_function_ports_reverse_whole_K16_gate_AST(self):
        old=historical_source("iterative_candidates_20261014/n4_root_pool12_v16_frozen/code/exp7_c07_scaling_20261012/evaluation_gate.py")
        dump=lambda node:ast.dump(node,include_attributes=False)
        before={node.name:node for node in ast.parse(old.read_text(encoding="utf-8")).body if isinstance(node,ast.FunctionDef)}
        after={node.name:deepcopy(node) for node in ast.parse(Path(gate.__file__).read_text(encoding="utf-8")).body if isinstance(node,ast.FunctionDef)}
        after=restore_v27_gate_functions(after)
        fn=after["_joint_expected_records"]
        statement=ast.parse('if n==4 and profile==N4_COORD8_PROFILE:\n    cfg["coordination_service_interval"]=8.0').body[0]
        matches=[i for i,node in enumerate(fn.body) if dump(node)==dump(statement)]
        self.assertEqual(len(matches),1);fn.body.pop(matches[0])
        signature=dump(ast.parse("profile in (POOL12_PROFILE,N4_COORD8_PROFILE)",mode="eval").body)
        class Restore(ast.NodeTransformer):
            count=0
            def visit_Compare(self,node):
                if dump(node)==signature:
                    self.count+=1;return ast.parse("profile==POOL12_PROFILE",mode="eval").body
                return self.generic_visit(node)
            def visit_Tuple(self,node):
                node=self.generic_visit(node)
                node.elts=[item for item in node.elts if not isinstance(item,ast.Name) or item.id!="N4_COORD8_PROFILE"]
                return node
        restore=Restore();after["_joint_expected_records"]=restore.visit(fn);self.assertEqual(restore.count,1)
        self.assertEqual(before.keys(),after.keys())
        for name,node in before.items():self.assertEqual(dump(node),dump(after[name]),name)

    def test_v27_all_six_independent_records_only_typed_N3_state8_N4_state11(self):
        p=gate.N34_STATE8_11_PROFILE
        for n in (2,3,4):
            for method in ("full_v6","usde_only_v6"):
                a=gate._joint_expected_records(n,method,gate.N4_COORD8_PROFILE,self.refs)
                z=gate._joint_expected_records(n,method,p,self.refs)
                delta={key:{"old":a[0][key],"new":value} for key,value in z[0].items()
                    if not gate._typed_exact(value,a[0].get(key))}
                wanted={} if n==2 else {"state_period":{"old":5.0,"new":{3:8.0,4:11.0}[n]}}
                self.assertTrue(gate._typed_exact(delta,wanted))
                self.assertIs(type(z[0]["state_period"]),float)
                back=deepcopy(z[0])
                if n>2:back["state_period"]=5.0
                self.assertTrue(gate._typed_exact(a[0],back))
                self.assertTrue(gate._typed_exact(a[1],z[1]));self.assertTrue(gate._typed_exact(a[2],z[2]))
                if n>2:self.assertTrue(gate._typed_exact(z[0]["coordination_service_interval"],16./3 if n==3 else 8.0))
                if n==4:
                    self.assertEqual((z[0]["tdma_sensors_per_group"],gate.JOINT_FRAMES[p][n],
                        z[0]["service_ack_timeout"],z[0]["grant_ttl"],z[1]["mac_child_lead_s"],z[1]["mac_pool_slots"]),
                        (4,42.0,134.0,134.0,72.0,12))
        for n in (2,3,4):
            f=gate._joint_expected_records(n,"full_v6",p,self.refs)[0]
            u=gate._joint_expected_records(n,"usde_only_v6",p,self.refs)[0]
            self.assertTrue(gate._typed_exact(f,u))
        self.contract_for(p)
        for n,method in sorted(gate.REQUIRED_ARMS):
            self.saved_for(n,method);self.assertEqual(self.check()["arm"],(n,method))

    def test_v27_resealed_aliases_nonfinite_nearby_and_wrong_N_rejected(self):
        self.contract_for(gate.N34_STATE8_11_PROFILE);original=deepcopy(self.contract)
        for n in (2,3,4):
            good={2:5.0,3:8.0,4:11.0}[n]
            wrong=(int(good),True,False,str(good),good+.001,0.0,-1.0,
                *(x for x in (5.0,8.0,11.0) if x!=good),float("nan"),float("inf"),float("-inf"))
            for bad in wrong:
                self.contract=deepcopy(original)
                for model in self.contract["models"]:
                    if model["n_auv"]==n:
                        model["environment_config"]["state_period"]=bad;model["declaration"]["config"]["state_period"]=bad
                        if type(bad) is not float or math.isfinite(bad):self.reseal(model)
                self.saved_for()
                with self.subTest(n=n,bad=bad),self.assertRaises(gate.EvaluationGateError):self.check()

    def test_v27_old_profiles_asymmetric_or_only_current_record_cannot_migrate(self):
        for p in (gate.POOL12_PROFILE,gate.N4_COORD8_PROFILE):
            self.contract_for(p)
            for model in self.contract["models"]:
                n=model["n_auv"]
                if n>2:
                    model["environment_config"]["state_period"]={3:8.0,4:11.0}[n]
                    model["declaration"]["config"]["state_period"]={3:8.0,4:11.0}[n];self.reseal(model)
            self.saved_for()
            with self.subTest(profile=p),self.assertRaises(gate.EvaluationGateError):self.check()
        self.contract_for(gate.N34_STATE8_11_PROFILE);original=deepcopy(self.contract)
        for n,method in ((3,"full_v6"),(3,"usde_only_v6"),(4,"full_v6"),(4,"usde_only_v6")):
            self.contract=deepcopy(original)
            model=next(x for x in self.contract["models"] if x["n_auv"]==n and x["method"]==method)
            model["environment_config"]["state_period"]=5.0;model["declaration"]["config"]["state_period"]=5.0
            self.reseal(model);self.saved_for()
            with self.subTest(n=n,method=method),self.assertRaises(gate.EvaluationGateError):self.check()
        for n,method in ((3,"full_v6"),(4,"full_v6")):
            self.contract=deepcopy(original);self.saved_for(n,method)
            self.saved["environment_config"]["state_period"]=5.0
            with self.assertRaises(gate.EvaluationGateError):self.check()
        self.contract=deepcopy(original);self.saved_for()
        self.saved["scale_context"]["declaration"]["config"]["state_period"]=5.0
        with self.assertRaises(gate.EvaluationGateError):self.check()

    def test_v27_unrelated_CFG_MO_RO_learning_or_protocol_reseal_rejected(self):
        self.contract_for(gate.N34_STATE8_11_PROFILE);original=deepcopy(self.contract)
        for n,section,key,bad in ((3,"config","coordination_service_interval",8.0),
            (4,"config","coordination_service_interval",4.0),(4,"config","gamma",.999),
            (4,"config","slow_period",10),(4,"config","state_ttl",120.0),
            (4,"method_options","mac_pool_slots",20),(3,"method_options","mac_child_lead_s",72.0),
            (4,"routing_options","state_stale_s",90.0),(4,"learning","hidden_dim",256),
            (4,"training_protocol","topology_warmup_steps",10000)):
            self.contract=deepcopy(original)
            for model in self.contract["models"]:
                if model["n_auv"]==n:
                    model["declaration"][section][key]=bad
                    if section=="config":model["environment_config"][key]=bad
                    self.reseal(model)
            self.saved_for()
            with self.subTest(n=n,section=section,key=key),self.assertRaises(gate.EvaluationGateError):self.check()
        self.assertNotIn("state_period",gate.SCALE_CONFIG_FIELDS)

    def test_v27_only_enumerated_ports_reverse_whole_pinned_K26_gate_functions(self):
        old=historical_source("iterative_candidates_20261017/n4_coord8_pool12_v26_frozen/code/exp7_c07_scaling_20261012/evaluation_gate.py")
        self.assertEqual(hashlib.sha256(old.read_bytes()).hexdigest(),"2cd9fefb128da8a6cb4ad9d80675924eb6ba9602567d7aa332b345f8d37f5920")
        dump=lambda node:ast.dump(node,include_attributes=False)
        before={node.name:node for node in ast.parse(old.read_text(encoding="utf-8")).body if isinstance(node,ast.FunctionDef)}
        after={node.name:deepcopy(node) for node in ast.parse(Path(gate.__file__).read_text(encoding="utf-8")).body if isinstance(node,ast.FunctionDef)}
        after=restore_v27_gate_functions(after)
        self.assertEqual(before.keys(),after.keys())
        for name,node in before.items():self.assertEqual(dump(node),dump(after[name]),name)

    def test_complete_CFG_MO_RO_learning_and_unknown_field_resealed_rejected(self):
        original = deepcopy(self.contract)
        for field, key, value in (("config", "exploration_noise", .05), ("config", "unknown", True),
                                 ("method_options", "mac_child_lease_frames", 5),
                                 ("routing_options", "unknown", True), ("learning", "policy_delay", 3)):
            self.contract = deepcopy(original)
            model = self.contract["models"][1]
            model["declaration"][field][key] = value
            if field == "config": model["environment_config"][key] = value
            self.reseal(model)
            with self.subTest(field=field), self.assertRaises(gate.EvaluationGateError): self.check()

    def test_fixed_MIN_H_and_USDE_nohook_resealed_rejected(self):
        original = deepcopy(self.contract)
        for field, key, value in (("method_options", "mac_child_lead_s", 48.),
                                 ("selector", "horizon", True), ("selector", "installed_H2_hook", True)):
            self.contract = deepcopy(original)
            model = next(m for m in self.contract["models"] if m["n_auv"] == 3 and m["method"] == "usde_only_v6")
            target = model["declaration"][field] if field == "method_options" else model["declaration"]["scale_diagnostics"]["joint_clock_adaptation"]["selector"]
            target[key] = value
            self.reseal(model)
            with self.subTest(field=field), self.assertRaises(gate.EvaluationGateError): self.check()

    def test_all_five_declaration_SHA_source_and_current_metadata_required(self):
        original = deepcopy(self.contract)
        for mode in ("missing_declaration", "wrong_sha", "source", "saved_MO", "saved_ctx"):
            self.contract = deepcopy(original); self.saved_for()
            if mode == "missing_declaration": self.contract["models"][0].pop("declaration")
            elif mode == "wrong_sha": self.contract["models"][0]["declaration_sha256"] = "0"*64
            elif mode == "source": self.contract["source_hashes"]["adapter/joint_clocks.py"] = "0"*64
            elif mode == "saved_MO": self.saved["method_options"]["mac_pool_slots"] = 20.
            else: self.saved["scale_context"]["declaration"]["profile"] = "other"
            with self.subTest(mode=mode), self.assertRaises(gate.EvaluationGateError): self.check()

    def test_fairness_sameN_USDE_damage_or_mixed_endpoint_and_missing_arm_rejected(self):
        original = deepcopy(self.contract)
        for mode in ("control_CFG", "control_MAC", "mixed_endpoint", "missing_arm", "duplicate_policy"):
            self.contract = deepcopy(original)
            model = next(m for m in self.contract["models"] if m["n_auv"] == 3 and m["method"] == "usde_only_v6")
            if mode == "control_CFG":
                model["environment_config"]["arrival_rate"] = .003
                model["declaration"]["config"]["arrival_rate"] = .003
                self.reseal(model)
            elif mode == "control_MAC":
                model["declaration"]["method_options"]["mac_enabled"] = True
                self.reseal(model)
            elif mode == "mixed_endpoint": model["training_step"] = 150000
            elif mode == "missing_arm": self.contract["models"].pop()
            else: model["policy_sha"] = self.contract["models"][0]["policy_sha"]
            with self.subTest(mode=mode), self.assertRaises(gate.EvaluationGateError): self.check()

    def test_all_old_gate_functions_except_explicit_contract_scope_are_AST_unchanged(self):
        old = historical_source("iterative_candidates_20261013/packet_grid_n4_child_h2_v11_preparation/code/exp7_c07_scaling_20261012/evaluation_gate.py")
        dump = lambda node: ast.dump(node, include_attributes=False)
        before = {n.name:n for n in ast.parse(old.read_text(encoding="utf-8")).body if isinstance(n, ast.FunctionDef)}
        after = {n.name:n for n in ast.parse(Path(gate.__file__).read_text(encoding="utf-8")).body if isinstance(n, ast.FunctionDef)}
        after=restore_v28_gate_functions(after)
        for name, node in before.items():
            if name != "_validate_contract":
                self.assertEqual(dump(node), dump(after[name]), name)
        self.assertEqual(gate.SCALE_CONFIG_FIELDS,
            frozenset(("n_auv", "declared_packet_bits", "deployment_layout", "coordination_service_interval",
                       "service_ack_timeout", "grant_ttl")))

    def test_v28_prepared_source_PINs_refuse_before_any_path_IO_or_markers(self):
        self.contract_for(gate.JOINT_PHY_LOC_ROOT16_PROFILE)
        with patch.dict(gate.JOINT_SOURCE_PINS,{"adapter/joint_clocks.py":None,"adapter/environment.py":None}),\
             patch.object(gate,"_read_json",side_effect=AssertionError("NO prepared read")),\
             patch.object(Path,"resolve",side_effect=AssertionError("NO prepared path IO")),\
             patch.object(gate,"_exclusive_json",side_effect=AssertionError("NO markers")):
            with self.assertRaisesRegex(gate.EvaluationGateError,"PREPARED"):
                gate._validate_contract(self.contract,self.saved,self.policy_sha,list(gate.HOLDOUT_SEEDS),"reference")
            with self.assertRaisesRegex(gate.EvaluationGateError,"PREPARED"):
                gate.validate_evaluation_seeds(self.saved,self.policy_sha,[10712000])
            with self.assertRaisesRegex(gate.EvaluationGateError,"PREPARED"):
                gate._joint_reference_records(self.sources)

    def test_v28_prepared_PIN_schema_none_empty_missing_extra_or_bool_refuses_before_IO(self):
        self.contract_for(gate.JOINT_PHY_LOC_ROOT16_PROFILE)
        valid=deepcopy(gate.JOINT_SOURCE_PINS)
        missing=deepcopy(valid);missing.pop("adapter/environment.py")
        malformed=(None,{},missing,{**valid,"extra":"0"*64},
            {**valid,"adapter/environment.py":True},True,{**valid,"adapter/environment.py":"A"*64})
        for pins in malformed:
            with self.subTest(pins=pins),patch.object(gate,"JOINT_SOURCE_PINS",pins),\
                 patch.object(gate,"_read_json",side_effect=AssertionError("NO malformed PIN read")),\
                 patch.object(Path,"resolve",side_effect=AssertionError("NO malformed PIN path IO")):
                with self.assertRaisesRegex(gate.EvaluationGateError,"PREPARED"):
                    gate._validate_contract(self.contract,self.saved,self.policy_sha,list(gate.HOLDOUT_SEEDS),"reference")
                with self.assertRaisesRegex(gate.EvaluationGateError,"PREPARED"):
                    gate._joint_reference_records(self.sources)
                with self.assertRaisesRegex(gate.EvaluationGateError,"PREPARED"):
                    gate.validate_evaluation_seeds(self.saved,self.policy_sha,[10712000])

    def test_v28_whole_six_records_exact_joint_deltas_and_N2_original_numerics(self):
        p=gate.JOINT_PHY_LOC_ROOT16_PROFILE
        for n in (2,3,4):
            for method in ("full_v6","usde_only_v6"):
                cfg,mo,ref=gate._joint_expected_records(n,method,p,self.refs)
                old,oldmo,oldref=gate._joint_expected_records(n,method,gate.N34_STATE8_11_PROFILE,self.refs)
                expected_cfg=deepcopy(old);expected_mo=deepcopy(oldmo)
                if n==3:
                    expected_cfg.update(slot_duration=0.5,hello_period=45.0,service_ack_timeout=88.0,
                        grant_ttl=100.0,localization_service_interval=8.0)
                    expected_mo["mac_child_lead_s"]=2*(50*0.5)-12.0
                if n==4:
                    expected_cfg.update(tdma_sensors_per_group=6,slot_duration=0.55,hello_period=80.0,
                        coordination_service_interval=4.0,localization_service_interval=6.0,
                        service_ack_timeout=116.0,grant_ttl=116.0)
                    expected_mo.update(mac_pool_slots=16,mac_child_max_active=4,mac_child_lead_s=2*(55*0.55)-12.0)
                self.assertTrue(gate._typed_exact(cfg,expected_cfg));self.assertTrue(gate._typed_exact(mo,expected_mo))
                self.assertTrue(gate._typed_exact(ref,oldref))
                if n==2:self.assertNotIn("localization_service_interval",cfg)
                clock,q,owners,gap=gate._joint_v28_clock_queue_records(n,cfg)
                self.assertEqual(len(owners),{2:60,3:50,4:55}[n])
                self.assertTrue(gate._typed_exact(clock["frame_s"],{2:36.0,3:50*0.5,4:55*0.55}[n]))
                self.assertTrue(gate._typed_exact(q["localization_service_s"],{2:12.0,3:8.0,4:6.0}[n]))
        self.contract_for(p)
        for arm in sorted(gate.REQUIRED_ARMS):self.saved_for(*arm);self.assertEqual(self.check()["arm"],arm)
        self.assertNotIn("slot_duration",gate.SCALE_CONFIG_FIELDS)
        self.assertNotIn("localization_service_interval",gate.SCALE_CONFIG_FIELDS)

    def test_v28_resealed_alias_missing_unknown_fields_or_wrong_parent_profile_refused(self):
        self.contract_for(gate.JOINT_PHY_LOC_ROOT16_PROFILE);original=deepcopy(self.contract)
        changes=((3,"slot_duration",0.6),(4,"slot_duration",0.5),(4,"tdma_sensors_per_group",4),
            (3,"hello_period",30.0),(4,"hello_period",80),(3,"localization_service_interval",8),
            (4,"localization_service_interval",True),(4,"localization_service_interval",12.0),
            (4,"coordination_service_interval",8.0),(3,"service_ack_timeout",88),
            (3,"grant_ttl",88.0),(4,"grant_ttl",116),(2,"localization_service_interval",12.0),
            (4,"unknown_CFG",1),(4,"state_ttl",120.0),(4,"gamma",.999))
        for n,key,value in changes:
            self.contract=deepcopy(original)
            for model in self.contract["models"]:
                if model["n_auv"]==n:
                    model["environment_config"][key]=value;model["declaration"]["config"][key]=value;self.reseal(model)
            self.saved_for()
            with self.subTest(n=n,key=key,value=value),self.assertRaises(gate.EvaluationGateError):self.check()
        for mode in ("missing","nan","inf","wrong_profile","asymmetric"):
            self.contract=deepcopy(original)
            model=next(m for m in self.contract["models"] if (m["n_auv"],m["method"])==(4,"usde_only_v6"))
            if mode=="missing":
                model["environment_config"].pop("localization_service_interval");model["declaration"]["config"].pop("localization_service_interval")
            elif mode=="wrong_profile":model["declaration"]["profile"]=gate.N34_STATE8_11_PROFILE
            else:
                value={"nan":float("nan"),"inf":float("inf"),"asymmetric":8.0}[mode]
                model["environment_config"]["localization_service_interval"]=value;model["declaration"]["config"]["localization_service_interval"]=value
            if mode not in ("nan","inf"):self.reseal(model)
            self.saved_for()
            with self.subTest(mode=mode),self.assertRaises(gate.EvaluationGateError):self.check()

    def test_v28_whole_clock_queue_MO_RO_and_learning_damage_cannot_reseal(self):
        self.contract_for(gate.JOINT_PHY_LOC_ROOT16_PROFILE);original=deepcopy(self.contract)
        paths=(("clock","frame_s"),("clock","service_retry_interval_s"),
            ("joint_phy_localization_adaptation","expected_actual_queue_options","localization_service_s"),
            ("joint_phy_localization_adaptation","expected_actual_queue_options","management_burst"),
            ("joint_phy_localization_adaptation","expected_actual_queue_options","extra"),
            ("joint_clock_adaptation","actual_slot_duration_s"),("joint_clock_adaptation","actual_max_management_run"))
        for keys in paths:
            self.contract=deepcopy(original);model=next(m for m in self.contract["models"] if m["n_auv"]==4)
            target=model["declaration"]["scale_diagnostics"]
            for key in keys[:-1]:target=target[key]
            target[keys[-1]]=True;self.reseal(model);self.saved_for()
            with self.subTest(keys=keys),self.assertRaises(gate.EvaluationGateError):self.check()
        for section,key,bad in (("method_options","mac_pool_slots",16.0),("method_options","mac_child_max_active",8),
            ("method_options","mac_auv_slots",3),("method_options","mac_child_lead_s",48.5),
            ("method_options","mac_max_leases",30),("routing_options","state_stale_s",90.0),
            ("learning","policy_delay",3),("training_protocol","topology_warmup_steps",1)):
            self.contract=deepcopy(original)
            for model in self.contract["models"]:
                if model["n_auv"]==4:model["declaration"][section][key]=bad;self.reseal(model)
            self.saved_for()
            with self.subTest(section=section,key=key),self.assertRaises(gate.EvaluationGateError):self.check()

    def test_v28_old_profiles_do_not_gain_LOC_or_short_slot_exemption(self):
        for p in (gate.POOL12_PROFILE,gate.N4_COORD8_PROFILE,gate.N34_STATE8_11_PROFILE):
            self.contract_for(p)
            for model in self.contract["models"]:
                if model["n_auv"]>2:
                    for target in (model["environment_config"],model["declaration"]["config"]):
                        target["localization_service_interval"]={3:8.0,4:6.0}[model["n_auv"]]
                    self.reseal(model)
            self.saved_for()
            with self.subTest(profile=p),self.assertRaises(gate.EvaluationGateError):self.check()

    def test_v28_explicit_ports_reverse_all_pinned_K27_gate_functions(self):
        old=historical_source("iterative_candidates_20261017/n34_state8_11_coord8_pool12_v27_frozen/code/exp7_c07_scaling_20261012/evaluation_gate.py")
        self.assertEqual(hashlib.sha256(old.read_bytes()).hexdigest(),"275906e94e0e75d80b77ab23eeba1b79baa433510bb4e3c96cf68ea557836873")
        definitions=lambda text:{node.name:node for node in ast.parse(text).body if isinstance(node,ast.FunctionDef)}
        before=definitions(old.read_text(encoding="utf-8"))
        after=restore_v28_gate_functions(definitions(Path(gate.__file__).read_text(encoding="utf-8")))
        self.assertEqual(before.keys(),after.keys())
        for name in before:self.assertEqual(ast.dump(before[name],include_attributes=False),ast.dump(after[name],include_attributes=False),name)

    def test_N2_original_and_old_scope_get_no_G_HELLO_exemption(self):
        model = self.contract["models"][0]
        model["environment_config"]["hello_period"] = 30.
        model["declaration"]["config"]["hello_period"] = 30.
        self.reseal(model)
        with self.assertRaises(gate.EvaluationGateError): self.check()
        self.contract_for(next(iter(gate.JOINT_HORIZONS)))
        self.contract["profile"] = "adaptive_packet_grid_joint_h3_3_h4_2_v12"
        for model in self.contract["models"]: model["profile"] = self.contract["profile"]
        self.saved["scale_context"]["profile"] = self.contract["profile"]
        with self.assertRaisesRegex(gate.EvaluationGateError, "common physical scope"): self.check()

    def test_legacy_contract_original_equal_G_HELLO_still_passes_without_new_records(self):
        profile = "adaptive_packet_grid_v3"
        self.contract["profile"] = profile
        for model in self.contract["models"]:
            model["profile"] = profile
            model["environment_config"] = deepcopy(self.refs["reference/config"])
            model["environment_config"]["n_auv"] = model["n_auv"]
            model.pop("declaration"); model.pop("declaration_sha256")
        model = self.contract["models"][0]
        self.policy_sha = model["policy_sha"]
        self.saved = dict(global_step=200000, seed=7, method_id=model["method"],
            source_hashes=deepcopy(self.contract["source_hashes"]), environment_config=deepcopy(model["environment_config"]),
            scale_context=dict(stage="development", profile=profile, declaration=dict(profile=profile,
                n_auv=2, n_sensors=30, method=model["method"], config=deepcopy(model["environment_config"]))))
        self.assertEqual(self.check()["arm"], (2, "full_v6"))


if __name__ == "__main__":
    unittest.main()
