"""Temp-file/simple-record/inert native fixtures only, zero physical advance."""
import copy
import gzip
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest import mock

EXPERIMENT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(EXPERIMENT))
from exp7_c07_scaling_20261012 import passive_journal_io as journal_io


class PassiveJournalIOTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.original = self.root/"evaluation/seed_10712000"
        self.original.mkdir(parents=True)
        for name in ("episode.json", "trace.jsonl.gz", "network_evidence.json.gz"):
            (self.original/name).write_bytes(b"untouched-original-fixture:"+name.encode())
        self.original_bytes = {p.name: p.read_bytes() for p in self.original.iterdir()}
        self.directory = self.root/"passive_sidecars/episode_10712000"
        self.env = NS(network=NS(mac_events=[]), mac_scheduler_events=[], c04_task_events=[],
                      c06_task_events=[], c07_task_events=[], service_end_events=[])
        self.header = dict(n_auv=3, n_sensors=30, slot_owners=tuple(range(34)), slot_duration=.6,
            source_hashes={"synthetic/source.py": "a"*64}, model_sha256="b"*64,
            profile="synthetic_static_profile", seed=10712000)

    def make(self, **kwargs):
        arguments = dict(enabled=True, header=self.header, episode_files_directory=self.original)
        arguments.update(kwargs)
        writer = journal_io.make_passive_journal_writer(self.env, self.directory, **arguments)
        self.addCleanup(lambda: writer._close() if not writer._completed and not writer._failed else None)
        return writer

    def rows(self):
        with gzip.open(self.directory/journal_io.EVENT_NAME, "rt", encoding="utf-8") as stream:
            return [json.loads(line) for line in stream]

    def assert_original_unchanged(self):
        self.assertEqual({p.name:p.read_bytes() for p in self.original.iterdir()}, self.original_bytes)

    def test_default_off_never_inspects_env_path_or_metadata_or_builds_directory(self):
        class Forbidden:
            def __getattribute__(self, name): raise AssertionError("OFF inspected object")
            def __fspath__(self): raise AssertionError("OFF resolved path")
        self.assertIsNone(journal_io.make_passive_journal_writer())
        self.assertIsNone(journal_io.make_passive_journal_writer(Forbidden(), Forbidden(),
            header=Forbidden(), episode_files_directory=Forbidden()))
        self.assertFalse(self.directory.exists())
        with self.assertRaises(ValueError): journal_io.make_passive_journal_writer(enabled=1)
        with self.assertRaises(ValueError): journal_io.PassiveJournalWriter(Forbidden(), Forbidden())

    def test_explicit_interval_and_final_drain_exactly_once_per_stream(self):
        writer = self.make()
        self.env.network.mac_events.append(dict(time=.2, event="MAC_A"))
        self.assertEqual(writer.drain(step_end=9,time_s=9.)["status"], "not_due")
        self.assertEqual(writer.drain(step_end=10,time_s=10.)["records_written"], 1)
        self.assertEqual(writer.drain(step_end=10,time_s=10.,force=True)["records_written"], 0)
        self.env.network.mac_events.append(dict(time=10.2,event="MAC_B"))
        self.env.c07_task_events.append(dict(time=10.2,event="task"))
        report = writer.finalize(step_end=11,time_s=11.)
        rows = self.rows()
        self.assertEqual([(r["stream"],r["stream_index"]) for r in rows],
            [("net.mac_events",0),("net.mac_events",1),("env.c07_task_events",0)])
        self.assertEqual([r["file_record_index"] for r in rows], [0,1,2])
        self.assertTrue(all(r["cross_stream_global_order"] == "unknown" for r in rows))
        self.assertEqual(report["records_written"],3)
        self.assert_original_unchanged()
        before = {p.name:p.read_bytes() for p in self.directory.iterdir()}
        with self.assertRaises(journal_io.PassiveJournalIOError): writer.finalize(step_end=11,time_s=11.)
        self.assertEqual({p.name:p.read_bytes() for p in self.directory.iterdir()},before)

    def test_complete_own_receipts_hash_exact_bytes_and_separate_logging_time(self):
        writer = self.make(); report = writer.finalize(step_end=0,time_s=0.)
        self.assertEqual(set(report["strict_receipts"]), {"header.json","passive_events.jsonl.gz","final_summary.json","receipt.json"})
        for name,receipt in report["strict_receipts"].items():
            raw=(self.directory/name).read_bytes()
            self.assertEqual(receipt,dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
        stored = json.loads((self.directory/"receipt.json").read_text())
        self.assertEqual(set(stored["artifacts"]), {"header.json","passive_events.jsonl.gz","final_summary.json"})
        self.assertGreaterEqual(report["logging_wall_time_s"], report["logging_wall_time_s_before_summary_and_receipt"])
        self.assertNotIn("inference_ms",report)
        self.assertFalse(report["native_ending_changed"])
        self.assert_original_unchanged()

    def test_header_preserves_provided_static_values_without_cfg_or_policy_reads(self):
        before = copy.deepcopy(self.header)
        self.env.cfg = NS(n_auv="FORBIDDEN uninspected cfg")
        self.env.policy = NS(model="FORBIDDEN uninspected policy")
        writer = self.make(); self.header["source_hashes"]["synthetic/source.py"]="c"*64
        report = writer.finalize(step_end=0,time_s=0.)
        expected = dict(before,slot_owners=list(before["slot_owners"]))
        self.assertEqual(report["metadata"],expected)

    def test_missing_stream_cursor_unavailable_not_observed_zero(self):
        self.env = NS(network=NS(mac_events=[]))
        writer = self.make(); report = writer.finalize(step_end=0,time_s=0.)
        self.assertIsNone(report["native_next_cursors"]["env.c07_task_events"])
        self.assertEqual(report["final_drain_statistics"]["streams"]["env.c07_task_events"]["availability"],"missing")
        self.assertEqual(report["writer_record_counts_by_stream"]["env.c07_task_events"],0)

    def test_disjoint_directory_guard_prevents_original_folder_parent_or_child(self):
        for folder in (self.original,self.original/"journal",self.original.parent):
            with self.subTest(folder=folder), self.assertRaises(ValueError):
                journal_io.make_passive_journal_writer(self.env,folder,enabled=True,header=self.header,
                                                       episode_files_directory=self.original)
            self.assert_original_unchanged()

    def test_preexisting_sidecar_is_not_overwritten_or_given_failure_file(self):
        self.directory.mkdir(parents=True)
        (self.directory/"user.txt").write_bytes(b"owned evidence")
        with self.assertRaises(FileExistsError):self.make()
        self.assertEqual({p.name:p.read_bytes() for p in self.directory.iterdir()}, {"user.txt":b"owned evidence"})
        self.assert_original_unchanged()

    def test_invalid_static_json_types_never_call_user_conversion_or_create_files(self):
        class ForbiddenConversion:
            def to_dict(self):raise AssertionError("No conversion callback")
            def tolist(self):raise AssertionError("No conversion callback")
        for key,value in (("n_auv",True),("slot_duration",float("inf")),("seed",True),
                          ("model_sha256","bad"),("extra",ForbiddenConversion())):
            header = dict(self.header);header[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):self.make(header=header)
            self.assertFalse(self.directory.exists())

    def test_source_invalid_preserves_prefix_and_blocks_retry_without_native_change(self):
        writer=self.make(); self.env.network.mac_events.append(dict(time=1.,event="good"))
        writer.drain(step_end=10,time_s=10.)
        invalid = dict(time=11.,event="bad",value=object())
        self.env.service_end_events.append(invalid)
        with self.assertRaises(journal_io.PassiveJournalIOError):writer.drain(step_end=20,time_s=20.)
        self.assertEqual(len(self.rows()),1)
        failed=json.loads((self.directory/"FAILED.json").read_text())
        self.assertEqual(failed["stage"],"drain")
        self.assertIn("env.service_end_events[0].value",failed["error"])
        self.assertIs(self.env.service_end_events[0],invalid)
        before={p.name:p.read_bytes() for p in self.directory.iterdir()}
        with self.assertRaises(journal_io.PassiveJournalIOError):writer.drain(step_end=21,time_s=21.)
        self.assertEqual({p.name:p.read_bytes() for p in self.directory.iterdir()},before)
        self.assert_original_unchanged()

    def test_disk_failure_preserves_written_prefix_and_is_terminal(self):
        writer=self.make()
        self.env.network.mac_events.extend([dict(time=1.,event="A"),dict(time=2.,event="B")])
        actual=writer._stream
        class FailingStream:
            def __init__(self):self.calls=0
            def write(self,line):
                self.calls+=1
                if self.calls==2:raise OSError("synthetic disk-full failure")
                return actual.write(line)
            def close(self):return actual.close()
        writer._stream=FailingStream()
        with self.assertRaises(journal_io.PassiveJournalIOError):writer.drain(step_end=10,time_s=10.)
        self.assertEqual(len(self.rows()),1)
        self.assertFalse((self.directory/"final_summary.json").exists())
        self.assertTrue((self.directory/"FAILED.json").exists())
        with self.assertRaises(journal_io.PassiveJournalIOError):writer.finalize(step_end=10,time_s=10.)
        self.assert_original_unchanged()

    def test_public_abort_preserves_evidence_and_callers_original_exception(self):
        writer=self.make(); original=RuntimeError("synthetic original evaluator error")
        self.env.network.mac_events.append(dict(time=1.,event="prefix"))
        writer.drain(step_end=10,time_s=10.)
        try:
            try:
                raise original
            except RuntimeError as error:
                result=writer.abort(stage="caller_evaluation_error",error=error)
                self.assertTrue(result["original_exception_untouched"])
                raise
        except RuntimeError as error:
            self.assertIs(error,original)
        self.assertEqual(len(self.rows()),1)
        failed=json.loads((self.directory/"FAILED.json").read_text())
        self.assertEqual(failed["error_type"],"RuntimeError")
        self.assertEqual(failed["stage"],"caller_evaluation_error")
        before={p.name:p.read_bytes() for p in self.directory.iterdir()}
        writer.abort(stage="second_abort",error=original)
        self.assertEqual({p.name:p.read_bytes() for p in self.directory.iterdir()},before)
        with self.assertRaises(journal_io.PassiveJournalIOError):writer.finalize(step_end=10,time_s=10.)
        self.assert_original_unchanged()

    def test_construction_drain_finalize_cancellations_preserve_same_objects_and_prefix(self):
        for kind in (KeyboardInterrupt,SystemExit,GeneratorExit):
            for stage in ("construction","drain","finalize"):
                with self.subTest(kind=kind.__name__,stage=stage),tempfile.TemporaryDirectory() as task_temp:
                    output=Path(task_temp)/"sidecar"; cancellation=kind("synthetic cancellation")
                    if stage=="construction":
                        original_write=journal_io._exclusive_json; calls=[0]
                        def interrupt_first(path,value):
                            calls[0]+=1
                            if calls[0]==1:raise cancellation
                            return original_write(path,value)
                        with mock.patch.object(journal_io,"_exclusive_json",side_effect=interrupt_first):
                            try:
                                journal_io.make_passive_journal_writer(self.env,output,enabled=True,header=self.header,
                                                                      episode_files_directory=self.original)
                            except BaseException as error:self.assertIs(error,cancellation)
                            else:self.fail("Construction swallowed cancellation")
                    else:
                        writer=journal_io.make_passive_journal_writer(self.env,output,enabled=True,header=self.header,
                                                                     episode_files_directory=self.original)
                        self.env.network.mac_events=[]
                        # Create a fresh binding for this subcase's stored list.
                        writer._journal=journal_io.make_passive_journal(self.env,enabled=True)
                        self.env.network.mac_events.append(dict(time=1.,event="safe_prefix"))
                        writer.drain(step_end=10,time_s=10.)
                        if stage=="drain":
                            patch=mock.patch.object(writer._journal,"drain",side_effect=cancellation)
                            operation=lambda:writer.drain(step_end=20,time_s=20.)
                        else:
                            patch=mock.patch.object(journal_io,"_receipt",side_effect=cancellation)
                            operation=lambda:writer.finalize(step_end=20,time_s=20.)
                        with patch:
                            try:operation()
                            except BaseException as error:self.assertIs(error,cancellation)
                            else:self.fail("Logging swallowed cancellation")
                        with gzip.open(output/"passive_events.jsonl.gz","rt") as stream:
                            self.assertEqual(len(stream.readlines()),1)
                        with self.assertRaises(journal_io.PassiveJournalIOError):writer.drain(step_end=21,time_s=21.)
                    failed=json.loads((output/"FAILED.json").read_text())
                    self.assertEqual(failed["cancellation_type"],kind.__name__)
                    self.assertFalse((output/"receipt.json").exists())
                    self.assert_original_unchanged()

    def test_cleanup_cancellation_not_hidden_behind_ordinary_write_error(self):
        writer=self.make(); actual=writer._stream; cancellation=KeyboardInterrupt("synthetic close cancel")
        class FailedWriteAndCancelledClose:
            def write(self,line):raise OSError("synthetic write failed")
            def close(self):actual.close();raise cancellation
        writer._stream=FailedWriteAndCancelledClose()
        self.env.network.mac_events.append(dict(time=1.,event="A"))
        try:writer.drain(step_end=10,time_s=10.)
        except BaseException as error:self.assertIs(error,cancellation)
        else:self.fail("Cleanup cancellation became tolerable logging error")
        self.assertIsNone(writer._raw)
        self.assertEqual(json.loads((self.directory/"FAILED.json").read_text())["cancellation_type"],"KeyboardInterrupt")
        self.assert_original_unchanged()

    def test_event_getters_hooks_rng_or_physical_calls_are_not_used(self):
        def forbidden(*args,**kwargs):raise AssertionError("Forbidden behavior/physics getter")
        self.env.step=self.env._mac_candidates=self.env._queue_forecast=forbidden
        self.env.network.advance=forbidden
        self.env.rng=NS(bit_generator=NS(state="unchanged synthetic RNG record"))
        before=copy.deepcopy(vars(self.env))
        writer=self.make(); writer.finalize(step_end=0,time_s=0.)
        self.assertEqual(self.env.rng.bit_generator.state,before["rng"].bit_generator.state)
        self.assert_original_unchanged()

    def test_bad_context_and_binding_change_are_logging_failures_only(self):
        for mode in ("backwards","network_reset","boolean"):
            with tempfile.TemporaryDirectory() as task_temp:
                output=Path(task_temp)/"sidecar"
                writer=journal_io.make_passive_journal_writer(self.env,output,enabled=True,header=self.header,
                    episode_files_directory=self.original)
                writer.drain(step_end=10,time_s=10.)
                if mode=="network_reset":self.env.network=NS(mac_events=[])
                with self.assertRaises(journal_io.PassiveJournalIOError):
                    writer.drain(step_end=True if mode=="boolean" else 9 if mode=="backwards" else 20,
                                 time_s=9. if mode=="backwards" else 20.)
                self.assertTrue((output/"FAILED.json").exists())
                self.assert_original_unchanged()

    def test_native_inert_permission_events_are_plain_json_compatible_without_advance(self):
        # Standalone-code-package compatible: no external verification script,
        # real model, ENV constructor or trial. Native protocol-state only.
        from exp7_c07_scaling_20261012 import paths
        from v6_candidates.c06.mac import DynamicMacNetwork
        net=DynamicMacNetwork(dict(n_auv=4,n_sensors=30,area_size=200.,sensor_depth=100.,
            tdma_sensors_per_group=3,slot_duration=.6,bit_rate=16000.,max_packet_bits=4096,
            discovery_enabled=False,faults=[]),seed=0)
        with mock.patch.object(type(net),"advance",side_effect=AssertionError("No native network advance")):
            ident=net.request_lease(5,0,start_frame=2,end_frame=32)
            prepare=next(q.packet for q in net._queues[0] if q.packet.kind=="MAC_PREPARE")
            net._receive(copy.deepcopy(prepare),5,0)  # synthetic already-arrived premise
            ack=next(q.packet for q in net._queues[5] if q.packet.kind=="MAC_ACK")
            net._receive(copy.deepcopy(ack),0,5)      # not a physical success
            p=net._root_requests[ident]
            net.propose_child(ident,6,p.start_frame,p.start_frame+3)
            self.env=NS(network=net,mac_scheduler_events=[],c04_task_events=[],
                        c06_task_events=[],c07_task_events=[],service_end_events=[])
            self.header=dict(self.header,n_auv=4,slot_owners=net.slot_owners,
                             profile="synthetic_V9_native_permission_state")
            writer=self.make(); report=writer.finalize(step_end=0,time_s=0.)
        self.assertGreater(report["records_written"],0)
        self.assertEqual(net.metrics["slots"],0)
        self.assertEqual(net.metrics["transmissions"],0)
        self.assertTrue(any(row["native_record"]["event"]=="child_silence_promised" for row in self.rows()))
        self.assert_original_unchanged()

    def test_numpy_scalar_is_rejected_not_silently_coerced(self):
        import numpy as np
        writer=self.make();self.env.network.mac_events.append(dict(time=1.,event="synthetic_np_scalar",x=np.int64(1)))
        with self.assertRaises(journal_io.PassiveJournalIOError):writer.finalize(step_end=1,time_s=1.)
        failed=json.loads((self.directory/"FAILED.json").read_text())
        self.assertIn("net.mac_events[0].x",failed["error"])
        self.assert_original_unchanged()


if __name__=="__main__":unittest.main()
