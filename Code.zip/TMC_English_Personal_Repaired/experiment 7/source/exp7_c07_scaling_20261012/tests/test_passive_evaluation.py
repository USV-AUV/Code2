"""Evaluator mocks/AST only: no real model, native ENV step or net advance."""
import ast
from contextlib import nullcontext
import copy
import gzip
import itertools
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest import mock

EXPERIMENT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(EXPERIMENT))
import numpy as np
from exp7_c07_scaling_20261012 import evaluation
from exp7_c07_scaling_20261012.root_budget import ROOT_BUDGET_PROFILE


BASE_METRICS=dict(collected_bits=0,initial_bits=100,arrival_bits=0,total_energy_j=10.)

class SyntheticConfig:
    def __init__(self,n):
        self.n_auv=n;self.n_sensors=30;self.episode_steps=2;self.slow_period=5
        self.dt=1.;self.substeps=1;self.data_packet_bits=2048;self.faults=[]
    def to_dict(self):return dict(vars(self))
    def validate(self):pass

class SyntheticEnv:
    """Preconstructed transition records; not a native simulation class."""
    def __init__(self,n,ending="time_limit",native_error=None,bad_event=False,cleanup_error=None):
        self.cfg=SyntheticConfig(n);self.ending=ending;self.native_error=native_error
        self.bad_event=bad_event;self.actions=[];self.slow_calls=0;self.closed=False
        self.cleanup_error=cleanup_error
        self.step_count=0;self.time=0.;self.reset_calls=0
    def reset(self,seed):
        self.reset_calls+=1;self.step_count=0;self.time=0.
        self.network=NS(active_parents=tuple(0 for _ in range(self.cfg.n_auv)),metrics={},
            slot_owners=tuple(range(self.cfg.n_auv+31)),slot_duration=.6,mac_events=[])
        self.mac_scheduler_events=[];self.c04_task_events=[];self.c06_task_events=[]
        self.c07_task_events=[];self.service_end_events=[]
        self.targets=np.zeros(self.cfg.n_auv,dtype=int)
        self.collected=set();self.acknowledged=set()
        return np.zeros((self.cfg.n_auv,2)),dict(metrics=dict(BASE_METRICS))
    def slow_state(self):
        self.slow_calls+=1
        return np.array([1.]),np.array([True])
    def step(self,actions,topology):
        # A mock producer returning fixed data, not ENV.step/network.advance.
        if self.native_error is not None and self.step_count==1:raise self.native_error
        self.actions.append((actions.copy(),topology));self.step_count+=1;self.time=float(self.step_count)
        event=dict(time=self.time,event="synthetic_native_record")
        if self.bad_event:event["bad_plain_json_value"]=object()
        self.network.mac_events.append(event)
        finished=self.step_count==self.cfg.episode_steps
        terminated=finished and self.ending!="time_limit"
        truncated=finished and not terminated
        return np.zeros((self.cfg.n_auv,2)),1.,terminated,truncated,dict(metrics=dict(BASE_METRICS),
            termination_reason=self.ending if finished else "running")
    def _positions_3d(self):return np.zeros((self.cfg.n_auv+1,3))
    def close(self):
        self.closed=True
        if self.cleanup_error is not None:raise self.cleanup_error

class SyntheticPhysical:
    def __init__(self,env,info,method):self.env=env;self.samples=[]
    def after_step(self,info):return dict(state_aoi_s=[0.]*self.env.cfg.n_auv)
    def finalize(self):return dict(collection=dict(distinct_served_sensors=0,collected_packets_per_sensor=[0]*30))

class SyntheticSafety:
    def __init__(self,env):self.samples=[dict(synthetic_substep=True)]*2
    def finalize(self):return dict(synthetic_safety_only=True)

class SyntheticNetworkObserver:
    def __init__(self,network):pass
    def finalize(self,time_s):return dict(core_counter_reconciliation=dict(all_observed_counters_match_core=True),
                                         logical=dict(DATA=dict(delivered_unique=0)))


class PassiveEvaluationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.checkpoint=self.root/"synthetic_identity_not_a_model.bin"
        self.checkpoint.write_bytes(b"synthetic identity bytes; no weight format")

    def evaluate(self,profile=ROOT_BUDGET_PROFILE,n=3,method="full_v6",ending="time_limit",native_error=None,
                 bad_event=False,off=False,factory_failure=False,seeds=(10712000,),cancellation=None,
                 cancel_stage=None,cleanup_error=None,aggregation_error=None,abort_error=None,episode_steps=2):
        env=SyntheticEnv(n,ending,native_error,bad_event,cleanup_error)
        env.cfg.episode_steps=episode_steps
        self.last_env=env
        policy=NS(topology=object() if method=="full_v6" else None,method=NS(method_id=method),
            make_environment=lambda:env,validate_environment=lambda env:None,
            act=lambda obs:np.tile(np.array([[.2,-.3]]),(n,1)),topology_action=lambda state,mask:0)
        saved=dict(environment_config=env.cfg.to_dict(),method_id=method,global_step=100000,seed=7,
            source_hashes={"synthetic/source.py":"a"*64},scale_context=dict(profile=profile,stage="development"))
        path=self.root/f"output_{len(list(self.root.glob('output_*')))}"
        clock=itertools.count()
        patches=[mock.patch.object(evaluation,"load_new_checkpoint",return_value=saved),
            mock.patch.object(evaluation,"source_hashes",return_value=saved["source_hashes"]),
            mock.patch.object(evaluation,"bindings",side_effect=lambda *args,**kwargs:nullcontext()),
            mock.patch.object(evaluation.native,"Policy",return_value=policy),
            mock.patch.object(evaluation.native,"make_environment_observer",side_effect=SyntheticPhysical),
            mock.patch.object(evaluation,"PhysicalAudit",side_effect=SyntheticSafety),
            mock.patch.object(evaluation,"NetworkObserver",side_effect=SyntheticNetworkObserver),
            mock.patch.object(evaluation,"usable_installed_path",return_value=True),
            mock.patch.object(evaluation,"seed_all"),mock.patch.object(evaluation.torch,"set_num_threads"),
            mock.patch.object(evaluation,"hop",return_value={}),
            mock.patch.object(evaluation,"selected_specs",return_value=[(f"metric{i}",f"metric{i}","unit","synthetic",lambda row:0.) for i in range(75)]),
            mock.patch.object(evaluation.time,"perf_counter",side_effect=lambda:float(next(clock)))]
        if off:patches.append(mock.patch.object(evaluation,"make_passive_journal_writer",return_value=None))
        if factory_failure:patches.append(mock.patch.object(evaluation,"make_passive_journal_writer",side_effect=OSError("synthetic observer construction failure")))
        if cancel_stage=="construction":patches.append(mock.patch.object(evaluation,"make_passive_journal_writer",side_effect=cancellation))
        if cancel_stage in ("drain","finalize") or abort_error is not None:
            actual_factory=evaluation.make_passive_journal_writer
            def writer_factory(*args,**kwargs):
                writer=actual_factory(*args,**kwargs)
                if cancel_stage=="drain":writer._journal.drain=mock.Mock(side_effect=cancellation)
                if cancel_stage=="finalize":
                    original_close=writer._close
                    def cancelled_close():original_close();raise cancellation
                    writer._close=cancelled_close
                if abort_error is not None:
                    original_abort=writer.abort
                    def failed_abort(**kwargs):original_abort(**kwargs);raise abort_error
                    writer.abort=failed_abort
                return writer
            patches.append(mock.patch.object(evaluation,"make_passive_journal_writer",side_effect=writer_factory))
        if aggregation_error is not None:patches.append(mock.patch.object(evaluation,"_write_passive_complete",side_effect=aggregation_error))
        for patch in patches:patch.start()
        try:
            result=evaluation.evaluate_checkpoint(self.checkpoint,path,seeds)
        finally:
            for patch in reversed(patches):patch.stop()
        return env,path,result

    def test_old_profiles_never_call_writer_or_create_sidecar(self):
        for profile in ("natural","adaptive_packet_grid_window_v5","adaptive_packet_grid_calendar_v8"):
            with mock.patch.object(evaluation,"make_passive_journal_writer",side_effect=AssertionError("Old profile called writer")):
                env,path,result=self.evaluate(profile=profile)
            self.assertNotIn("passive_journal",result)
            self.assertFalse((path/"passive_sidecars").exists())
            self.assertEqual(len(env.actions),2)

    def test_v9_all_scales_and_arms_same_sidecar_standard_and_original_three_files(self):
        for n,method in ((2,"full_v6"),(2,"usde_only_v6"),(3,"full_v6"),(4,"full_v6"),(3,"usde_only_v6"),(4,"usde_only_v6")):
            env,path,result=self.evaluate(n=n,method=method)
            folder=path/"seed_10712000"
            self.assertEqual({p.name for p in folder.iterdir()}, {"episode.json","trace.jsonl.gz","network_evidence.json.gz"})
            record=json.loads((folder/"episode.json").read_text())
            self.assertEqual(len(record["metrics75"]),75)
            self.assertFalse(any("journal" in key or "logging" in key for key in record["timing"]))
            sidecars=json.loads((path/"passive_sidecars/complete.json").read_text())
            self.assertEqual(sidecars["original_evaluation_status"],"completed")
            self.assertEqual(sidecars["observer_status"],"completed")
            header=json.loads((path/"passive_sidecars/seed_10712000/header.json").read_text())["metadata"]
            self.assertEqual((header["n_auv"],header["n_sensors"],header["method"]),(n,30,method))
            self.assertEqual(len(env.actions),2)
            self.assertEqual(result["passive_journal"]["observer_status"],"completed")

    def test_off_on_synthetic_raw_actions_updates_endings_metrics_and_original_cpu_equal(self):
        # The OFF factory is intentionally absent, not a production opt-out API.
        # These are fake transition records, not real transparency evidence.
        env_a,path_a,_=self.evaluate(off=True,ending="collision")
        env_b,path_b,_=self.evaluate(ending="collision")
        np.testing.assert_array_equal([a[0] for a in env_a.actions],[a[0] for a in env_b.actions])
        self.assertEqual(env_a.step_count,env_b.step_count)
        self.assertEqual(env_a.slow_calls,env_b.slow_calls)
        record_a=json.loads((path_a/"seed_10712000/episode.json").read_text())
        record_b=json.loads((path_b/"seed_10712000/episode.json").read_text())
        self.assertEqual(record_a,record_b)

    def test_logging_source_failure_does_not_drop_or_repeat_synthetic_native_steps(self):
        env,path,result=self.evaluate(bad_event=True,ending="boundary")
        original=json.loads((path/"complete.json").read_text())
        observer=json.loads((path/"passive_sidecars/complete.json").read_text())
        self.assertEqual(original["status"],"completed")
        self.assertEqual(original["rows"][0]["termination_reason"],"boundary")
        self.assertEqual(observer["observer_status"],"failed")
        self.assertEqual(observer["original_evaluation_status"],"completed")
        self.assertEqual(len(env.actions),2)
        self.assertTrue((path/"passive_sidecars/seed_10712000/FAILED.json").exists())
        with gzip.open(path/"seed_10712000/trace.jsonl.gz","rt") as stream:self.assertEqual(len(stream.readlines()),2)
        self.assertEqual(result["status"],"completed")

    def test_logging_construction_failure_continues_original_episode(self):
        env,path,result=self.evaluate(factory_failure=True)
        observer=json.loads((path/"passive_sidecars/complete.json").read_text())
        self.assertEqual(observer["observer_status"],"failed")
        self.assertEqual(observer["episode_reports"][0]["logging_error"]["stage"],"construction")
        self.assertEqual(len(env.actions),2)
        self.assertEqual(result["status"],"completed")

    def test_actual_caller_exception_identity_is_not_overridden_by_abort(self):
        original=RuntimeError("synthetic native evaluator failure")
        with self.assertRaises(RuntimeError) as seen:self.evaluate(native_error=original)
        self.assertIs(seen.exception,original)
        path=next(self.root.glob("output_*"))
        self.assertFalse((path/"complete.json").exists())
        self.assertTrue((path/"passive_sidecars/FAILED.json").exists())
        self.assertTrue((path/"passive_sidecars/seed_10712000/FAILED.json").exists())
        with gzip.open(path/"seed_10712000/trace.jsonl.gz","rt") as stream:self.assertEqual(len(stream.readlines()),1)

    def test_observer_cancellations_stop_before_further_transitions_and_keep_original_object(self):
        for kind in (KeyboardInterrupt,SystemExit,GeneratorExit):
            for stage in ("construction","drain","finalize"):
                with self.subTest(kind=kind.__name__,stage=stage):
                    cancellation=kind("synthetic observer cancel")
                    steps=12 if stage=="drain" else 2
                    try:self.evaluate(cancellation=cancellation,cancel_stage=stage,episode_steps=steps,seeds=(10712000,10712001))
                    except BaseException as error:self.assertIs(error,cancellation)
                    else:self.fail("Evaluator continued after cancellation")
                    self.assertEqual(len(self.last_env.actions),0 if stage=="construction" else 10 if stage=="drain" else 2)
                    self.assertEqual(self.last_env.reset_calls,1)
                    self.assertTrue(self.last_env.closed)

    def test_native_exception_cleanup_and_aggregation_cannot_mask_original(self):
        for cleanup in (OSError("synthetic env close failed"),KeyboardInterrupt("synthetic cleanup cancel")):
            for abort_error in (OSError("synthetic abort failed"),SystemExit("synthetic abort cancel")):
                with self.subTest(cleanup=type(cleanup).__name__,abort=type(abort_error).__name__):
                    original=RuntimeError("synthetic original native failure")
                    try:self.evaluate(native_error=original,cleanup_error=cleanup,abort_error=abort_error,
                        aggregation_error=GeneratorExit("synthetic aggregation cancel"))
                    except BaseException as error:self.assertIs(error,original)
                    else:self.fail("Original caller exception was suppressed")
                    self.assertEqual(len(self.last_env.actions),1)
                    self.assertTrue(self.last_env.closed)

    def test_native_cancellation_object_survives_other_cleanup_cancellations(self):
        for kind in (KeyboardInterrupt,SystemExit,GeneratorExit):
            cancellation=kind("synthetic original native cancellation")
            try:self.evaluate(native_error=cancellation,cleanup_error=OSError("synthetic close error"),
                abort_error=KeyboardInterrupt("secondary cleanup cancellation"),
                aggregation_error=SystemExit("secondary aggregate cancellation"))
            except BaseException as error:self.assertIs(error,cancellation)
            else:self.fail("Original native cancellation was overridden")
            self.assertEqual(len(self.last_env.actions),1)
            self.assertTrue(self.last_env.closed)

    def test_new_episode_gets_new_writer_after_reset(self):
        env,path,_=self.evaluate(seeds=(10712000,10712001))
        reports=json.loads((path/"passive_sidecars/complete.json").read_text())["episode_reports"]
        self.assertEqual([report["seed"] for report in reports],[10712000,10712001])
        self.assertEqual([report["logging_report"]["records_written"] for report in reports],[2,2])
        self.assertEqual(env.reset_calls,2)

    def test_ast_one_native_action_step_and_slow_request_drains_after_method_timer_trace(self):
        tree=ast.parse((EXPERIMENT/"exp7_c07_scaling_20261012/evaluation.py").read_text())
        function=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=="evaluate_checkpoint")
        calls=[node for node in ast.walk(function) if isinstance(node,ast.Call)]
        native=lambda name:[node for node in calls if isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name)
                            and node.func.value.id=="env" and node.func.attr==name]
        self.assertEqual(len(native("step")),1);self.assertEqual(len(native("slow_state")),1)
        self.assertFalse(native("_mac_candidates"));self.assertFalse(native("_conflict_keys"));self.assertFalse(native("_peer_reservations"))
        trace=next(node for node in calls if isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name)
                   and node.func.value.id=="stream" and node.func.attr=="write")
        drains=[node for node in calls if isinstance(node.func,ast.Name) and node.func.id=="_drain_passive"]
        self.assertTrue(all(node.lineno>trace.lineno for node in drains))
        helper=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=="_open_passive")
        self.assertFalse(any(isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in
            {"step","advance","act","slow_state","_mac_candidates","_conflict_keys"} for node in ast.walk(helper)))


if __name__=="__main__":unittest.main()
