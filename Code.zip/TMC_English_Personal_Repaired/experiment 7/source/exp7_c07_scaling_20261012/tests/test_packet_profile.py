"""Packet objective adaptation uses native C07 mechanisms and charged slots."""
import json
from dataclasses import asdict
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012.environment import build_settings,make_environment
from exp7_c07_scaling_20261012.budget import BudgetLedger,BudgetError
from exp7_c07_scaling_20261012.paths import reference_metadata,reference_config

class PacketCandidateTests(unittest.TestCase):
    def test_original_two_auv_settings_unchanged(self):
        for method in ("full_v6","usde_only_v6"):
            cfg,options,routing,diagnostic=build_settings(2,30,method,"adaptive_packet_v2")
            metadata=json.loads(reference_metadata(method).read_text(encoding="utf-8-sig"))
            self.assertEqual(cfg.to_dict(),json.loads(reference_config().read_text(encoding="utf-8-sig")))
            self.assertEqual(asdict(options),metadata["method_options"])
            self.assertEqual(asdict(routing),metadata["routing_options"])
    def test_native_paid_packet_quota_and_common_baseline(self):
        for n,pool,children,total in ((3,12,6,21),(4,14,8,26)):
            settings=[build_settings(n,30,method,"adaptive_packet_v2") for method in ("full","usde_only")]
            self.assertEqual(settings[0][0].to_dict(),settings[1][0].to_dict())
            for cfg,options,routing,diagnostic in settings:
                self.assertEqual(options.mac_pool_slots,pool)
                self.assertEqual(options.mac_child_max_active,children)
                self.assertEqual(options.mac_child_slots_per_sensor,2)
                self.assertEqual(options.mac_max_leases,total)
                self.assertEqual(options.mac_coop_lease_frames,30)
                self.assertEqual(options.mac_frame_stride,2)
                self.assertEqual(diagnostic["nominal_root_pool_remainder_if_all_installed"],6)
                self.assertEqual((cfg.slot_duration,cfg.bit_rate),(.6,16000))
            env=make_environment(n,30,"full","adaptive_packet_v2")
            self.addCleanup(env.close)
            self.assertEqual(len(env.network.slot_owners),70 if n==3 else 80)
    def test_extended_configured_limit_is_explicit_and_immutable(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/"ledger.json"
            with self.assertRaises(BudgetError): BudgetLedger(path,"per_model",200000)
            ledger=BudgetLedger(path,"per_model",200000,allow_extended_development=True)
            self.assertEqual(ledger.snapshot()["development_limit"],200000)
            with self.assertRaises(BudgetError): BudgetLedger(path,"per_model",100000)

if __name__=="__main__": unittest.main()
