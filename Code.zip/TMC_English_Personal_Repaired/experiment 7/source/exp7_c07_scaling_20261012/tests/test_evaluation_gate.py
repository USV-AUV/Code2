"""Synthetic record fixtures only; no actual models, evaluation or simulator."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


PATH = Path(__file__).resolve().parents[1] / "evaluation_gate.py"
SPEC = importlib.util.spec_from_file_location("isolated_evaluation_gate", PATH)
gate = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(gate)


def sha(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def config(n):
    value = {name: 1 for name in gate.REQUIRED_PHYSICAL_FIELDS}
    value.update(seed=7, n_auv=n, n_sensors=30, episode_steps=1200,
        area_size=200., auv_depth=70., sensor_depth=100., dt=1., substeps=10,
        slow_period=5, max_speed=2.2, min_separation=3., collection_radius=6.,
        data_packet_bits=2048, data_header_bits=256, initial_packets=4, arrival_rate=.002,
        slot_duration=.6, tdma_sensors_per_group=3, sound_speed=1500., guard_time=.04,
        processing_delay=.02, bit_rate=16000., bandwidth_hz=8000., faults=[],
        service_ack_timeout=80. if n == 2 else 100. + n,
        grant_ttl=100. if n == 2 else 100. + n,
        reward_data_weight=5., warmup_steps=1000)
    if n > 2:
        value.update(declared_packet_bits=3200 if n == 3 else 4096, deployment_layout="scale_grid")
    return value


class EvaluationGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / "VALIDATION_CONTRACT.json"
        self.history = self.root / "persistent_history"
        self.history.mkdir()
        self.contract = dict(format=gate.CONTRACT_FORMAT, profile="adaptive_packet_grid_v3",
            training_step=100000, training_seed=7, primary="collected_packets",
            fault_profile="reference", history_directory=str(self.history.resolve()),
            confirmation_index=1, family_alpha=.025, seeds=list(gate.HOLDOUT_SEEDS),
            source_hashes={"adapter/source.py": sha("synthetic frozen source")}, models=[])
        for n, method in sorted(gate.REQUIRED_ARMS):
            self.contract["models"].append(dict(n_auv=n, method=method, seed=7,
                profile=self.contract["profile"], training_step=100000,
                environment_config=config(n), policy_sha=sha(f"synthetic {n}/{method}")))
        self.write_contract()

    def write_contract(self):
        self.path.write_text(json.dumps(self.contract, allow_nan=False), encoding="utf-8")

    def saved(self, n=2, method="full_v6"):
        entry = next(model for model in self.contract["models"]
                     if model["n_auv"] == n and model["method"] == method)
        return dict(seed=7, global_step=entry["training_step"], method_id=method,
            source_hashes=copy.deepcopy(self.contract["source_hashes"]),
            environment_config=copy.deepcopy(entry["environment_config"]),
            scale_context=dict(stage="development", profile=entry["profile"],
                declaration=dict(profile=entry["profile"], n_auv=n, n_sensors=30,
                    method=method, config=copy.deepcopy(entry["environment_config"]))))

    def open(self, n=2, method="full_v6", saved=None, policy_sha=None, seeds=None,
             fault_profile="reference", contract_path=None):
        entry = next(model for model in self.contract["models"]
                     if model["n_auv"] == n and model["method"] == method)
        return gate.validate_evaluation_seeds(saved or self.saved(n, method), policy_sha or entry["policy_sha"],
            list(self.contract["seeds"]) if seeds is None else seeds, self.path if contract_path is None else contract_path,
            fault_profile=fault_profile)

    def no_markers(self):
        self.assertEqual(list(self.root.rglob("*.started.json")), [])

    def test_development_pool_is_repeatable_and_has_no_side_effect(self):
        saved = {"global_step": 50000, "scale_context": {"stage": "development"}}
        for seeds in ([10712000], [10712000, 10712029]):
            for _ in range(2):
                metadata = gate.validate_evaluation_seeds(saved, sha("dev"), seeds)
                self.assertEqual(metadata["phase"], "development")
                self.assertFalse(metadata["holdout_opened"])
                self.assertIsNone(metadata["family_alpha"])
                self.assertEqual(metadata["fault_profile"], "reference")
                self.assertEqual(metadata["evaluation_fault"], "reference")
        self.no_markers()

    def test_development_cannot_be_relabelled_by_contract(self):
        with self.assertRaises(gate.EvaluationGateError):
            gate.validate_evaluation_seeds(self.saved(), sha("dev"), [10712000], self.path)
        self.no_markers()

    def test_invalid_seed_sets_are_rejected_without_markers(self):
        for seeds in ([], [10712000, 10712000], [True], [10712000.], [10711000],
                      [10712000, 10713000], list(gate.HOLDOUT_SEEDS)[:-1], list(reversed(gate.HOLDOUT_SEEDS))):
            with self.subTest(seeds=seeds), self.assertRaises(gate.EvaluationGateError):
                gate.validate_evaluation_seeds(self.saved(), sha("unused"), seeds, self.path)
            self.no_markers()

    def test_holdout_needs_a_contract(self):
        with self.assertRaises(gate.EvaluationGateError):
            gate.validate_evaluation_seeds(self.saved(), sha("unused"), list(gate.HOLDOUT_SEEDS))
        self.no_markers()

    def test_valid_first_open_has_complete_phase_and_exclusive_marker(self):
        metadata = self.open()
        self.assertEqual(metadata["phase"], "holdout_validation")
        self.assertEqual(metadata["confirmation_index"], 1)
        self.assertEqual(metadata["family_alpha"], .025)
        self.assertEqual(metadata["primary"], "collected_packets")
        self.assertEqual(metadata["seeds"], list(gate.HOLDOUT_SEEDS))
        self.assertEqual(metadata["checkpoint_stage"], "development")
        self.assertEqual(metadata["fault_profile"], "reference")
        self.assertEqual(metadata["evaluation_fault"], "reference")
        self.assertEqual(metadata["history_directory"], str(self.history.resolve()))
        self.assertEqual(Path(metadata["started_marker"]).parent, self.history)
        self.assertEqual(Path(metadata["seed_set_marker"]).parent, self.history)
        self.assertTrue(metadata["holdout_opened"])
        self.assertFalse(metadata["already_opened"])
        self.assertEqual(json.loads(Path(metadata["started_marker"]).read_text(encoding="utf-8")), metadata)
        self.assertEqual(metadata["validation_contract_sha256"], hashlib.sha256(self.path.read_bytes()).hexdigest())

    def test_all_five_arms_share_one_contract_without_opening_models(self):
        values = [self.open(n, method) for n, method in sorted(gate.REQUIRED_ARMS)]
        self.assertEqual(len(list(self.history.glob("holdout_*.started.json"))), 6)
        self.assertEqual(list(self.root.glob("*.started.json")), [])
        self.assertEqual(len({value["validation_contract_sha256"] for value in values}), 1)

    def test_failure_or_success_cannot_retry_and_does_not_overwrite(self):
        metadata = self.open()
        marker = Path(metadata["started_marker"])
        before = marker.read_bytes()
        with self.assertRaisesRegex(gate.EvaluationGateError, "already opened"):
            self.open()
        self.assertEqual(marker.read_bytes(), before)

    def test_global_marker_binds_exact_immutable_contract_bytes(self):
        self.open()
        self.path.write_text(self.path.read_text(encoding="utf-8") + "\n", encoding="utf-8")
        with self.assertRaisesRegex(gate.EvaluationGateError, "another immutable contract"):
            self.open(3)
        self.assertFalse((self.history / "holdout_10713000_10713029_3_full_v6.started.json").exists())

    def test_corrupt_global_marker_remains_blocking(self):
        marker = self.history / gate.SEED_HISTORY_NAME
        marker.write_text("{partial", encoding="utf-8")
        with self.assertRaises(gate.EvaluationGateError):
            self.open()
        self.assertEqual(marker.read_text(encoding="utf-8"), "{partial")

    def test_confirmation_alpha_spending_uses_declared_index(self):
        self.contract.update(confirmation_index=2, family_alpha=.0125, seeds=list(gate.confirmation_seeds(2)))
        self.write_contract()
        self.assertEqual(self.open()["family_alpha"], .0125)

    def test_copying_contract_directory_cannot_reopen_model(self):
        opened = self.open()
        copied_folder = self.root / "copied_contract_folder"
        copied_folder.mkdir()
        copied_path = copied_folder / self.path.name
        copied_path.write_bytes(self.path.read_bytes())
        marker = Path(opened["started_marker"])
        before = marker.read_bytes()
        with self.assertRaisesRegex(gate.EvaluationGateError, "already opened"):
            self.open(contract_path=copied_path)
        self.assertEqual(marker.read_bytes(), before)
        self.assertEqual(list(copied_folder.glob("*.started.json")), [])

    def test_copied_contract_can_open_an_unopened_arm_under_same_binding(self):
        original = self.open()
        copied_folder = self.root / "copied_contract_folder"
        copied_folder.mkdir()
        copied_path = copied_folder / self.path.name
        copied_path.write_bytes(self.path.read_bytes())
        metadata = self.open(3, contract_path=copied_path)
        self.assertEqual(metadata["validation_contract_sha256"], original["validation_contract_sha256"])
        self.assertEqual(Path(metadata["started_marker"]).parent, self.history)
        self.assertEqual(list(copied_folder.glob("*.started.json")), [])

    def test_fault_contract_missing_mismatch_and_unknown_rejected_before_open(self):
        original = copy.deepcopy(self.contract)
        for mutation in ("missing", "mismatch", "unknown"):
            with self.subTest(mutation=mutation):
                self.contract = copy.deepcopy(original)
                if mutation == "missing": self.contract.pop("fault_profile")
                elif mutation == "mismatch": self.contract["fault_profile"] = "direct1_outage"
                self.write_contract()
                with self.assertRaises(gate.EvaluationGateError):
                    self.open(fault_profile="unknown" if mutation == "unknown" else "reference")
                self.no_markers()

    def test_reference_and_outage_cannot_bypass_shared_seed_history(self):
        self.open()
        self.contract["fault_profile"] = "direct1_outage"
        self.write_contract()
        with self.assertRaisesRegex(gate.EvaluationGateError, "another immutable contract/index/fault"):
            self.open(3, fault_profile="direct1_outage")
        self.assertFalse((self.history / "holdout_10713000_10713029_3_full_v6.started.json").exists())

    def test_confirmation_index_cannot_reset_shared_seed_history(self):
        self.open()
        self.contract.update(confirmation_index=2, family_alpha=.0125)
        self.write_contract()
        with self.assertRaisesRegex(gate.EvaluationGateError, "seeds for its confirmation_index"):
            self.open(3)
        self.assertFalse((self.history / "holdout_10713000_10713029_3_full_v6.started.json").exists())

    def test_confirmation_seeds_are_finite_disjoint_ordered_blocks(self):
        self.assertEqual(gate.confirmation_seeds(1), tuple(range(10919000,10919030)))
        self.assertEqual(gate.confirmation_seeds(2), tuple(range(10920000,10920030)))
        self.assertFalse(set(gate.confirmation_seeds(1)) & set(gate.confirmation_seeds(2)))
        self.assertEqual(len(gate.confirmation_seeds(gate.MAX_CONFIRMATION_INDEX)),30)
        for index in (0,-1,True,1.,None,gate.MAX_CONFIRMATION_INDEX+1,10**100):
            with self.subTest(index=index), self.assertRaises(gate.EvaluationGateError):
                gate.confirmation_seeds(index)
        self.no_markers()

    def test_block2_can_be_preregistered_after_block1_but_not_reopened(self):
        first = self.open()
        first_marker = Path(first["started_marker"])
        first_bytes = first_marker.read_bytes()
        self.contract.update(confirmation_index=2,family_alpha=.0125,seeds=list(gate.confirmation_seeds(2)))
        self.write_contract()
        second = self.open()
        self.assertEqual(second["seeds"],list(range(10920000,10920030)))
        self.assertEqual(second["family_alpha"],.0125)
        self.assertNotEqual(second["started_marker"],first["started_marker"])
        self.assertNotEqual(second["seed_set_marker"],first["seed_set_marker"])
        self.assertEqual(first_marker.read_bytes(),first_bytes)
        self.assertEqual(len(list(self.history.glob("holdout_*.started.json"))),4)
        with self.assertRaisesRegex(gate.EvaluationGateError,"already opened"):
            self.open()

    def test_block2_contract_copy_reuses_same_history_and_cannot_reopen(self):
        self.contract.update(confirmation_index=2,family_alpha=.0125,seeds=list(gate.confirmation_seeds(2)))
        self.write_contract()
        self.open()
        copied = self.root/"copy_block2"
        copied.mkdir()
        path = copied/self.path.name
        path.write_bytes(self.path.read_bytes())
        with self.assertRaisesRegex(gate.EvaluationGateError,"already opened"):
            self.open(contract_path=path)
        self.assertEqual(list(copied.glob("*.started.json")),[])

    def test_wrong_block_index_partial_or_arbitrary_block_is_rejected(self):
        for seeds in (list(gate.confirmation_seeds(2)),list(gate.confirmation_seeds(1))[:-1],list(range(10714001,10714031))):
            with self.subTest(seeds=seeds), self.assertRaisesRegex(gate.EvaluationGateError,"confirmation_index"):
                self.open(seeds=seeds)
            self.no_markers()

    def test_history_must_be_explicit_absolute_existing_directory(self):
        original = copy.deepcopy(self.contract)
        for history in (None, "relative_history", "", str(self.root / "absent"), str(self.path)):
            with self.subTest(history=history):
                self.contract = copy.deepcopy(original)
                if history is None: self.contract.pop("history_directory")
                else: self.contract["history_directory"] = history
                self.write_contract()
                with self.assertRaises(gate.EvaluationGateError): self.open()
                self.no_markers()

    def test_development_faults_are_repeatable_and_never_touch_history(self):
        saved = {"global_step": 50000, "scale_context": {"stage": "development"}}
        for fault_profile in sorted(gate.FAULT_PROFILES):
            for _ in range(2):
                metadata = gate.validate_evaluation_seeds(saved, sha("dev"), [10712000],
                    fault_profile=fault_profile)
                self.assertEqual(metadata["fault_profile"], fault_profile)
                self.assertEqual(metadata["evaluation_fault"], fault_profile)
                self.assertEqual(metadata["phase"], "development")
        self.no_markers()

    def test_outage_contract_preserves_fault_in_both_markers_and_phase(self):
        self.contract["fault_profile"] = "direct1_outage"
        self.write_contract()
        metadata = self.open(fault_profile="direct1_outage")
        global_marker = json.loads((self.history / gate.SEED_HISTORY_NAME).read_text(encoding="utf-8"))
        model_marker = json.loads(Path(metadata["started_marker"]).read_text(encoding="utf-8"))
        for record in (metadata, global_marker, model_marker):
            self.assertEqual(record["fault_profile"], "direct1_outage")
            self.assertEqual(record["evaluation_fault"], "direct1_outage")
            self.assertEqual(record["confirmation_index"], 1)
            self.assertEqual(record["validation_contract_sha256"], hashlib.sha256(self.path.read_bytes()).hexdigest())

    def test_wrong_confirmation_spending_rejected_before_open(self):
        for index, alpha in ((0, .05), (1, .05), (2, .025), (True, .025), (1, True), (100000, .0)):
            with self.subTest(index=index, alpha=alpha):
                self.contract.update(confirmation_index=index, family_alpha=alpha)
                self.write_contract()
                with self.assertRaises(gate.EvaluationGateError):
                    self.open()
                self.no_markers()

    def test_primary_contract_and_seed_changes_rejected(self):
        mutations = (("primary", "distinct_sensors"), ("training_seed", 11),
                     ("seeds", list(gate.HOLDOUT_SEEDS)[:-1]), ("format", "unknown"), ("profile", ""))
        original = copy.deepcopy(self.contract)
        for key, value in mutations:
            with self.subTest(key=key):
                self.contract = copy.deepcopy(original)
                self.contract[key] = value
                self.write_contract()
                with self.assertRaises(gate.EvaluationGateError):
                    self.open()
                self.no_markers()

    def test_missing_duplicate_extra_and_duplicate_digest_arms_rejected(self):
        original = copy.deepcopy(self.contract)
        for mutation in ("missing", "duplicate", "extra", "sha"):
            with self.subTest(mutation=mutation):
                self.contract = copy.deepcopy(original)
                models = self.contract["models"]
                if mutation == "missing": models.pop()
                elif mutation == "duplicate": models[-1] = copy.deepcopy(models[0])
                elif mutation == "extra": models[-1]["n_auv"] = 2; models[-1]["method"] = "usde_only_v6"
                else: models[-1]["policy_sha"] = models[0]["policy_sha"]
                self.write_contract()
                with self.assertRaises(gate.EvaluationGateError): self.open()
                self.no_markers()

    def test_all_model_budget_seed_and_profile_checked(self):
        original = copy.deepcopy(self.contract)
        for key, value in (("training_step", 50000), ("seed", 11), ("profile", "other")):
            with self.subTest(key=key):
                self.contract = copy.deepcopy(original)
                self.contract["models"][-1][key] = value
                self.write_contract()
                with self.assertRaises(gate.EvaluationGateError): self.open()
                self.no_markers()

    def test_common_physics_and_same_scale_config_required(self):
        original = copy.deepcopy(self.contract)
        for key, value in (("area_size", 300.), ("bit_rate", 32000.), ("n_sensors", 60),
                           ("seed", 11), ("episode_steps", 3), ("service_ack_timeout", 999.)):
            with self.subTest(key=key):
                self.contract = copy.deepcopy(original)
                self.contract["models"][-1]["environment_config"][key] = value
                self.write_contract()
                with self.assertRaises(gate.EvaluationGateError): self.open()
                self.no_markers()

    def test_current_actual_model_must_match_each_frozen_field(self):
        for field in ("policy_sha", "seed", "global_step", "profile", "source_hashes", "config", "method", "declaration"):
            with self.subTest(field=field):
                saved = self.saved()
                policy_sha = None
                if field == "policy_sha": policy_sha = sha("another artifact")
                elif field == "seed": saved["seed"] = 11
                elif field == "global_step": saved["global_step"] = 50000
                elif field == "profile": saved["scale_context"]["profile"] = "other"
                elif field == "source_hashes": saved["source_hashes"]["adapter/source.py"] = sha("modified")
                elif field == "config": saved["environment_config"]["bit_rate"] = 32000
                elif field == "method": saved["method_id"] = "usde_only_v6"
                else: saved["scale_context"]["declaration"]["config"]["bit_rate"] = 32000
                with self.assertRaises(gate.EvaluationGateError): self.open(saved=saved, policy_sha=policy_sha)
                self.no_markers()

    def test_method_aliases_are_unambiguous(self):
        for item in self.contract["models"]:
            item["method"] = "full" if item["method"] == "full_v6" else "usde_only"
        self.write_contract()
        saved = self.saved(method="full")
        saved["method_id"] = "full_v6"
        metadata = self.open(method="full", saved=saved)
        self.assertEqual(metadata["method"], "full_v6")

    def test_json_duplicates_nonfinite_and_missing_scope_rejected(self):
        self.path.write_text('{"format":"a","format":"b"}', encoding="utf-8")
        with self.assertRaises(gate.EvaluationGateError): self.open()
        self.no_markers()
        self.path.write_text('{"family_alpha":NaN}', encoding="utf-8")
        with self.assertRaises(gate.EvaluationGateError): self.open()
        self.no_markers()
        self.contract["models"][0]["environment_config"].pop("area_size")
        self.write_contract()
        with self.assertRaises(gate.EvaluationGateError): self.open()
        self.no_markers()


if __name__ == "__main__":
    unittest.main()
