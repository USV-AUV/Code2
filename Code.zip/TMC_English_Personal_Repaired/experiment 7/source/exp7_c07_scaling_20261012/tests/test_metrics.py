"""Synthetic-only arithmetic tests; no simulator or model imports."""
import copy
import importlib.util
from pathlib import Path
import unittest


spec = importlib.util.spec_from_file_location("isolated_scale_metrics", Path(__file__).parents[1] / "metrics.py")
metrics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metrics)


def row(n=3, method="full", seed=1, distinct=2, packets=3, duration=10):
    return dict(n_auv=n, method=method, seed=seed, n_sensors=4, distinct_sensors=distinct,
                collected_packets=packets, duration_s=duration, terminated=True, truncated=False,
                safety={}, metrics75={}, network_summary={})


def five_arms():
    rows = []
    for seed in range(8):
        for n, method, offset in ((2,"full",0), (3,"full",2), (4,"full",5),
                                  (3,"usde_only",1), (4,"usde_only",3)):
            value = offset + seed % 3
            sample = row(n, method, seed, value, value*2)
            sample["n_sensors"] = 30
            sample["terminated"] = seed % 2 == 0
            sample["truncated"] = not sample["terminated"]
            rows.append(sample)
    return rows


class MetricsTests(unittest.TestCase):
    def test_unique_sensors_not_packets_and_duplicate_receipts(self):
        audit = metrics.audit_unique_data([(0,1),(0,1),(0,2),(2,1)], 4, 3)
        self.assertEqual(audit["distinct_sensors"], 2)
        self.assertEqual(audit["collected_packets"], 3)
        self.assertEqual(audit["coverage_fraction"], .5)
        self.assertEqual(audit["per_sensor_packets"], [2,0,1,0])
        self.assertEqual(audit["duplicate_receipts"], 1)
        self.assertAlmostEqual(audit["jain_packets_all_sensors"], 9/20)
        self.assertIsNone(metrics.audit_unique_data([],4)["jain_packets_all_sensors"])
        with self.assertRaises(ValueError):
            metrics.audit_unique_data([(4,1)],4)
        with self.assertRaises(ValueError):
            metrics.audit_unique_data([(0,1)],4,2)

    def test_failures_durations_actual_denominators_and_no_mutation(self):
        a = row(seed=1)
        a.update(per_sensor_packets=[2,1,0,0], energy_j=100, aoi_sum_s=30, aoi_auv_seconds=30,
                 connectivity_usable_auv_seconds=15, connectivity_observation_auv_seconds=30,
                 recovery=dict(affected=True,censored=True,recovery_s=None,censor_followup_s=5))
        a["safety"] = dict(had_collision=True,had_boundary=False,had_any_violation=True,
                           collision_pair_s=.5,observation_pair_s=30,boundary_auv_s=0,observation_auv_s=30)
        a["network_summary"] = dict(by_kind=dict(DATA=dict(hop_delivery=dict(
            completion_window=dict(resolved_failures=1,resolved_trials=2)))))
        b = row(seed=2, duration=20, distinct=1, packets=1)
        b.update(terminated=False,truncated=True,per_sensor_packets=[1,0,0,0],data_resolved_failures=0,
                 data_resolved_trials=8,energy_j=200,recovery=dict(affected=True,censored=False,recovery_s=4))
        b["safety"] = dict(had_collision=False,had_boundary=False,had_any_violation=False,
                           collision_pair_s=0,observation_pair_s=60,boundary_auv_s=0,observation_auv_s=60)
        before = copy.deepcopy([a,b])
        group = metrics.summarize_groups([a,b])["auv3/full"]
        self.assertEqual([a,b],before)
        self.assertEqual(group["episodes"],2)
        self.assertEqual(group["terminated_episodes"],1)
        self.assertEqual(group["duration_s"]["sum"],30)
        self.assertEqual(group["distinct_sensors"]["mean"],1.5)
        self.assertEqual(group["coverage_pooled"]["denominator"],8)
        self.assertEqual(group["data_nondelivery"]["ratio"],.1)
        self.assertEqual(group["data_nondelivery"]["denominator"],10)
        self.assertAlmostEqual(group["safety"]["collision_pair_s"]["ratio"],.5/90)
        self.assertEqual(group["energy_j_per_unique_packet"]["ratio"],75)
        self.assertEqual(group["recovery"]["right_censored_episodes"],1)
        self.assertEqual(group["recovery"]["recovered_delay_s"]["mean"],4)
        self.assertEqual(group["state_aoi_pooled"]["n_available"],1)

    def test_missing_values_are_null_and_zero_denominator_is_undefined(self):
        a = row(distinct=0,packets=0)
        del a["n_sensors"]
        group = metrics.summarize_groups([a])["auv3/full"]
        self.assertIsNone(group["energy_j"]["sum"])
        self.assertIsNone(group["coverage_pooled"]["denominator"])
        self.assertIsNone(group["coverage_fraction"]["mean"])
        self.assertIsNone(group["data_nondelivery"]["ratio"])
        self.assertIsNone(group["packet_depth"]["pooled_packets_per_served_sensor"]["ratio"])
        self.assertIsNone(group["recovery"]["affected_episodes"])
        a["recovery"] = dict(affected=True,censored=None,recovery_s=None)
        recovery = metrics.summarize_groups([a])["auv3/full"]["recovery"]
        self.assertIsNone(recovery["recovered_episodes"])
        self.assertIsNone(recovery["right_censored_episodes"])
        self.assertIsNone(recovery["recovered_fraction"]["ratio"])
        self.assertEqual(recovery["unresolved_affected_episodes"],1)

    def test_paired_sign_family_determinism_and_failures_retained(self):
        rows = five_arms()
        before = copy.deepcopy(rows)
        result = metrics.paired_contrasts(rows,repetitions=300,seed=9)
        self.assertEqual(result,metrics.paired_contrasts(rows,repetitions=300,seed=9))
        self.assertEqual(rows,before)
        self.assertEqual(result["family_size"],8)
        for name, expected in (("full4-full3",3),("full3-full2",2),
                               ("full3-usde3",1),("full4-usde4",2)):
            entry = result["contrasts"][name]["metrics"]["distinct_sensors"]
            self.assertEqual(entry["paired_seed_denominator"],8)
            self.assertEqual(entry["mean_difference"],expected)
            self.assertEqual(entry["ci_familywise"],[expected,expected])
            self.assertEqual(entry["marginal_alpha_bonferroni"],.05/8)
        rows[0]["distinct_sensors"] = None
        entry = metrics.paired_contrasts(rows,repetitions=20)["contrasts"]["full3-full2"]["metrics"]["distinct_sensors"]
        self.assertEqual(entry["n_missing_pairs"],1)
        self.assertIsNone(entry["ci_familywise"])

    def test_bonferroni_interval_encloses_uncorrected_and_strict_seed_sets(self):
        rows = five_arms()
        rows[6]["distinct_sensors"] += 1
        result = metrics.paired_contrasts(rows,repetitions=500)
        entry = result["contrasts"]["full3-full2"]["metrics"]["distinct_sensors"]
        self.assertLessEqual(entry["ci_familywise"][0],entry["ci95_uncorrected"][0])
        self.assertGreaterEqual(entry["ci_familywise"][1],entry["ci95_uncorrected"][1])
        with self.assertRaises(ValueError):
            metrics.paired_contrasts(rows[:-1],repetitions=20)
        with self.assertRaises(ValueError):
            metrics.summarize_groups(rows+[rows[0]])

    def test_reject_inconsistent_sensor_depth_and_false_data_denominators(self):
        a = row()
        a["per_sensor_packets"]=[3,0,0,0]
        with self.assertRaises(ValueError):
            metrics.summarize_groups([a])
        a = row()
        a.update(data_resolved_failures=3,data_resolved_trials=2)
        with self.assertRaises(ValueError):
            metrics.summarize_groups([a])


if __name__ == "__main__":
    unittest.main()
