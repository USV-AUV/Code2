"""Random untrained inference modules only; never create optimizers or step."""
from dataclasses import asdict
from pathlib import Path
import sys
import unittest
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012.workflow import native,bindings,declaration,digest_json,source_hashes,INFERENCE_FORMAT,VERSION
from exp7_c07_scaling_20261012.environment import make_environment
from usv_auv.deploy import environment_schema
from usv_auv.learning import mlp
from v6_candidates.c07.methods import get_method

class NativeInferenceTests(unittest.TestCase):
    def test_real_native_policy_uses_full_scale_schema_without_learning(self):
        for n in (2,3,4):
            for method in ("full","usde_only"):
                declared=declaration(n,30,method,"adaptive_v1",faults=[])
                env=make_environment(n,30,method,"adaptive_v1",faults=[])
                self.addCleanup(env.close)
                cfg=env.cfg
                spec=get_method(declared["method"])
                schema=environment_schema(env)
                context=dict(version=VERSION,profile="adaptive_v1",stage="development",declaration=declared,
                    declaration_sha256=digest_json(declared))
                checkpoint=dict(format=INFERENCE_FORMAT,scale_context=context,global_step=0,
                    method_id=spec.method_id,method_spec=spec.to_dict(),method_fingerprint=spec.fingerprint,
                    environment_config=cfg.to_dict(),config_fingerprint=cfg.fingerprint,learning_config=declared["learning"],
                    revision_learning_options=asdict(native.RevisionLearningOptions(area_size=cfg.area_size,max_speed=cfg.max_speed,
                        dt=cfg.dt,action_frame=cfg.action_frame)),training_protocol=declared["training_protocol"],
                    method_options=declared["method_options"],routing_options=declared["routing_options"],
                    source_hashes=source_hashes(),observation_schema=schema,
                    agents=[{"actor":mlp(env.observation_dim,2,cfg.hidden_dim,True).state_dict()} for _ in range(n)],
                    topology={"online":mlp(env.slow_observation_dim,env.network.n_actions,cfg.hidden_dim).state_dict()} if spec.use_topology else None)
                with bindings(context):
                    policy=native.Policy(checkpoint,"cpu")
                    actual=policy.make_environment()
                    self.addCleanup(actual.close)
                    obs,_=actual.reset(42)
                    actions=policy.act(obs)
                    self.assertEqual(actions.shape,(n,2))
                    self.assertTrue(np.isfinite(actions).all())
                    self.assertTrue(np.all(np.abs(actions)<=1))
                    slow,mask=actual.slow_state()
                    self.assertEqual(policy.topology_action(slow,mask),0 if spec.use_topology else None)
                    self.assertTrue(all(not param.requires_grad for actor in policy.actors for param in actor.parameters()))
                    self.assertFalse(any("optimizer" in key for key in vars(policy)))

if __name__=="__main__": unittest.main()
