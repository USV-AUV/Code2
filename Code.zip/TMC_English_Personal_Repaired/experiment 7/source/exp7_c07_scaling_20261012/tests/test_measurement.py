"""PhysicalAudit must observe native transitions without changing them."""
from itertools import product
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012.environment import make_environment
from exp7_c07_scaling_20261012.measurement import PhysicalAudit, usable_installed_path


class PassiveMeasurementContracts(unittest.TestCase):
    def make(self, n, method="full_v6", profile="natural"):
        env = make_environment(n, 30, method, profile=profile)
        self.addCleanup(env.close)
        env.reset(seed=42)
        return env

    def assert_native_state_equal(self, plain, measured):
        for field in ("auv_positions", "usv_position", "targets", "last_actions", "executed_velocities"):
            np.testing.assert_array_equal(getattr(plain, field), getattr(measured, field))
        np.testing.assert_array_equal(plain.network.energy_j, measured.network.energy_j)
        self.assertEqual(plain.metrics, measured.metrics)
        self.assertEqual(plain.network.metrics, measured.network.metrics)
        self.assertEqual(plain.collected, measured.collected)
        self.assertEqual(plain.acknowledged, measured.acknowledged)
        self.assertEqual(plain.network.local_versions, measured.network.local_versions)
        self.assertEqual(plain.done, measured.done)

    def test_native_thirty_step_transitions_and_substep_cadence_are_unchanged(self):
        for n, method, profile in product((3, 4), ("full_v6", "usde_only_v6"), ("natural", "adaptive_v1")):
            with self.subTest(n=n, method=method, profile=profile):
                plain, measured = self.make(n, method, profile), self.make(n, method, profile)
                audit = PhysicalAudit(measured)
                for step in range(30):
                    action = np.tile(np.array([-.97, .12 * np.sin(step / 7)], dtype=np.float32), (n, 1))
                    route = 0 if step % plain.cfg.slow_period == 0 else None
                    expected = plain.step(action.copy(), route)
                    observed = measured.step(action.copy(), route)
                    np.testing.assert_array_equal(expected[0], observed[0])
                    self.assertEqual(expected[1:], observed[1:])
                    self.assert_native_state_equal(plain, measured)
                    np.testing.assert_array_equal(measured.last_actions, action)
                    self.assertEqual(len(audit.samples), measured.step_count * measured.cfg.substeps)
                    self.assertFalse(expected[2] or expected[3], "Fixture must exercise all thirty steps")
                metrics_before = dict(measured.network.metrics)
                report = audit.finalize()
                self.assertEqual(metrics_before, measured.network.metrics)
                self.assert_native_state_equal(plain, measured)
                self.assertEqual(report["physical_substeps"], 30 * measured.cfg.substeps)
                self.assertEqual(report["observation_auv_s"], 30 * measured.cfg.dt * n)
                self.assertEqual(report["observation_pair_s"], 30 * measured.cfg.dt * n * (n - 1) / 2)
                self.assertFalse(report["had_any_violation"])
                expected_times = np.arange(1, 30 * measured.cfg.substeps + 1) * measured.cfg.dt / measured.cfg.substeps
                np.testing.assert_allclose([sample["time_s"] for sample in audit.samples], expected_times, rtol=0, atol=1e-12)

    def test_audit_preserves_native_absorbing_failure_and_its_full_final_substeps(self):
        for n in (3, 4):
            with self.subTest(n=n):
                plain, measured = self.make(n), self.make(n)
                plain.auv_positions[0, 0] = measured.auv_positions[0, 0] = plain.cfg.area_size + 5
                audit = PhysicalAudit(measured)
                action = np.tile([-1., 0.], (n, 1))
                expected, observed = plain.step(action.copy(), 0), measured.step(action.copy(), 0)
                np.testing.assert_array_equal(expected[0], observed[0])
                self.assertEqual(expected[1:], observed[1:])
                self.assertTrue(observed[2])
                self.assertFalse(observed[3])
                self.assertEqual(observed[4]["termination_reason"], "boundary")
                self.assert_native_state_equal(plain, measured)
                report = audit.finalize()
                self.assertEqual(report["physical_substeps"], measured.cfg.substeps)
                self.assertTrue(report["had_boundary"])
                self.assertEqual(report["boundary_onsets"], 1)
                self.assertEqual(report["boundary_auv_s"], measured.cfg.dt)
                with self.assertRaisesRegex(RuntimeError, "reset"):
                    measured.step(action)

    def test_installed_path_uses_actual_network_range_inclusive_and_bidirectional_faults(self):
        for n in (3, 4):
            with self.subTest(n=n):
                env = self.make(n)
                net = env.network
                self.assertEqual(env.cfg.link_range, 350.)
                net.max_range = 10.
                positions = np.zeros((net.n_nodes, 3))
                positions[1, 0] = 11.
                self.assertFalse(usable_installed_path(net, 1, positions, 0.))
                positions[1, 0] = 10.
                self.assertTrue(usable_installed_path(net, 1, positions, 0.))
                # An outage only in the reverse direction still makes a
                # bidirectional installed path unusable; no stochastic claim.
                net.add_fault(0, 1, 0., 1., bidirectional=False)
                self.assertFalse(usable_installed_path(net, 1, positions, 0.))
                self.assertTrue(usable_installed_path(net, 1, positions, 2.))

    def test_real_two_hop_installation_and_each_hop_lease_are_required(self):
        for n in (3, 4):
            with self.subTest(n=n):
                env = self.make(n)
                net = env.network
                net.max_range = 10.
                positions = np.zeros((net.n_nodes, 3))
                positions[1, 0], positions[2, 0] = 14., 7.
                # Before a locally installed detour, the direct 14m route fails.
                self.assertFalse(usable_installed_path(net, 1, positions, 0.))
                route = (2, 0) + (0,) * (n - 2)
                self.assertIn(route, net.candidates)
                net.installed_routes[1][1] = (route, 5.)
                net.active_version[1] = 1
                self.assertFalse(usable_installed_path(net, 1, positions, 0.))
                net.installed_routes[2][1] = (route, 5.)
                self.assertTrue(usable_installed_path(net, 1, positions, 0.))
                # Native _next_hop validates local leases at network.time;
                # audit time and that current network clock must agree.
                net.time = 5.01
                self.assertFalse(usable_installed_path(net, 1, positions, 5.01))
                net.time = 0.
                positions[2, 0] = 11.
                self.assertFalse(usable_installed_path(net, 1, positions, 0.))
                positions[2, 0] = 7.
                net.installed_routes[1][1] = (route, 10.)
                net.time = 6.
                self.assertFalse(usable_installed_path(net, 1, positions, 6.), "A live source lease cannot create an expired relay lease")


if __name__ == "__main__":
    unittest.main()
