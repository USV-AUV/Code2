"""Prepared native-capacity profile contracts; zero step and zero learning."""
from dataclasses import asdict, replace
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012.environment import (PROFILES,build_settings,make_environment,
                                                validate_scale_mac_budget,MethodOptions)
from exp7_c07_scaling_20261012.paths import EXPERIMENT,reference_config,reference_metadata
from exp7_c07_scaling_20261012.workflow import declaration,source_hashes
from v6_candidates.c07.environment import TaskV4Env as OriginalC07
from v6_candidates.c04.environment import TaskV4Env as IntentEnv
from usv_auv.config import Config as OriginalConfig

V5="adaptive_packet_grid_window_v5"
V6="adaptive_packet_grid_pool_v6"


class PoolCandidateContracts(unittest.TestCase):
    def test_profile_registered_but_not_default(self):
        self.assertIn(V6,PROFILES)
        self.assertEqual(build_settings.__defaults__[0],"adaptive_v1")

    def test_only_intended_native_options_change_against_V5(self):
        for n,expected in ((3,{"mac_pool_slots":14,"mac_child_max_active":8,"mac_max_leases":23}),
                           (4,{"mac_pool_slots":16,"mac_child_max_active":8,"mac_max_leases":28})):
            for method in ("full","usde_only"):
                with self.subTest(n=n,method=method):
                    before=build_settings(n,30,method,V5)
                    after=build_settings(n,30,method,V6)
                    self.assertEqual(before[0].to_dict(),after[0].to_dict())
                    self.assertEqual(asdict(before[2]),asdict(after[2]))
                    left,right=asdict(before[1]),asdict(after[1])
                    changed={key for key in left if left[key]!=right[key]}
                    self.assertEqual(changed,{"mac_pool_slots","mac_child_max_active","mac_max_leases"}
                                     if n==3 else {"mac_pool_slots","mac_max_leases"})
                    self.assertEqual({key:right[key]for key in expected},expected)
                    self.assertEqual((right["mac_auv_slots"],right["mac_child_slots_per_sensor"],right["mac_child_lease_frames"]),(3,2,3))
                    self.assertEqual(right["mac_child_lead_s"],30. if n==3 else 36.)

    def test_two_AUV_cfg_options_routing_are_exact_original(self):
        frozen=json.loads(reference_config().read_text(encoding="utf-8-sig"))
        for method in ("full_v6","usde_only_v6"):
            with self.subTest(method=method):
                cfg,mo,ro,diagnostic=build_settings(2,30,method,V6)
                old=build_settings(2,30,method,V5)
                metadata=json.loads(reference_metadata(method).read_text(encoding="utf-8-sig"))
                self.assertIs(type(cfg),OriginalConfig)
                self.assertEqual(cfg.to_dict(),frozen)
                self.assertEqual(asdict(mo),metadata["method_options"])
                self.assertEqual(asdict(ro),metadata["routing_options"])
                self.assertEqual((cfg.to_dict(),asdict(mo),asdict(ro)),(old[0].to_dict(),asdict(old[1]),asdict(old[2])))
                self.assertNotIn("pool_capacity_adaptation",diagnostic)

    def test_full_USDE_common_settings_only_bundle_flag_differs(self):
        for n,sensors in ((3,30),(4,30),(3,45),(4,60)):
            with self.subTest(n=n,sensors=sensors):
                full=build_settings(n,sensors,"full",V6)
                usde=build_settings(n,sensors,"usde_only",V6)
                self.assertEqual(full[0].to_dict(),usde[0].to_dict())
                self.assertEqual(asdict(full[2]),asdict(usde[2]))
                a,b=asdict(full[1]),asdict(usde[1])
                self.assertTrue(a.pop("mac_enabled"));self.assertFalse(b.pop("mac_enabled"))
                self.assertEqual(a,b)
                self.assertEqual((full[0].bit_rate,full[0].slot_duration),(16000.,.6))

    def test_same_learning_reward_and_ending_declaration(self):
        for n in (2,3,4):
            for method in ("full","usde_only"):
                old=declaration(n,30,method,V5)
                new=declaration(n,30,method,V6)
                for key in ("config","learning","training_protocol","routing_options","reward","ending","old_weights_allowed"):
                    self.assertEqual(new[key],old[key])

    def test_scale_budget_check_uses_actual_n_not_historical_two(self):
        for n,lower_global in ((3,22),(4,27)):
            options=build_settings(n,30,"full",V6)[1]
            wrong=replace(options,mac_max_leases=lower_global)
            # The unchanged native ancestor's 2-AUV budget guard accepts this;
            # the new explicitly scoped scale guard must not.
            self.assertIsInstance(wrong,MethodOptions)
            with self.assertRaisesRegex(ValueError,"n_auv"):
                validate_scale_mac_budget(n,wrong)

    def test_native_caps_and_bool_coercion_stay_rejected(self):
        good=asdict(build_settings(4,30,"full",V6)[1])
        invalid={"mac_pool_slots":[1,17,True],"mac_auv_slots":[0,9,True],"mac_max_leases":[0,31,True],
                 "mac_child_max_active":[0,9,True],"mac_child_slots_per_sensor":[0,5,True],"mac_child_lease_frames":[0,4,True]}
        for field,values in invalid.items():
            for value in values:
                with self.subTest(field=field,value=value):
                    with self.assertRaisesRegex(ValueError,"Native C07"):
                        validate_scale_mac_budget(4,{**good,field:value})
                    with self.assertRaises(ValueError):
                        MethodOptions(**{**good,field:value})

    def test_root_control_rights_cannot_be_all_nominally_delegated(self):
        good=asdict(build_settings(3,30,"full",V6)[1])
        with self.assertRaisesRegex(ValueError,"root control"):
            validate_scale_mac_budget(3,{**good,"mac_pool_slots":8,"mac_child_max_active":8})

    def test_old_natural_profile_keeps_original_global_clipping_semantics(self):
        for n in (3,4):
            cfg,mo,_,_=build_settings(n,30,"full","natural")
            self.assertEqual((mo.mac_pool_slots,mo.mac_auv_slots,mo.mac_max_leases),(10,3,16))
            self.assertGreater(mo.mac_pool_slots+n*mo.mac_auv_slots,mo.mac_max_leases)
        for profile in PROFILES:
            for n in (2,3,4):
                for method in ("full","usde_only"):
                    build_settings(n,30,method,profile)

    def test_diagnostics_distinguish_nominal_future_caps_from_real_capacity(self):
        for n,headroom,remainder in ((3,2,6),(4,0,8)):
            diagnostic=build_settings(n,30,"full",V6)[3]["pool_capacity_adaptation"]
            self.assertEqual(diagnostic["child_cap_headroom_for_old_or_future_windows"],headroom)
            self.assertEqual(diagnostic["nominal_root_pool_remainder_if_child_cap_fully_occupied"],remainder)
            self.assertFalse(diagnostic["physical_slots_or_bitrate_added"])
            self.assertFalse(diagnostic["new_scheduler_or_information"])
            self.assertIn("old irrevocable",diagnostic["tradeoff"])
            self.assertIn("does not select",diagnostic["selection_status"])

    def test_declaration_diagnostics_are_exact_JSON_roundtrip_for_ledger_binding(self):
        for n in (2,3,4):
            for method in ("full","usde_only"):
                value=declaration(n,30,method,V6)
                self.assertEqual(json.loads(json.dumps(value,sort_keys=True,allow_nan=False)),value)

    def test_zero_step_environment_keeps_native_controllers_and_no_USDE_DDQN(self):
        for n in (2,3,4):
            for method in ("full","usde_only"):
                env=make_environment(n,30,method,V6)
                self.addCleanup(env.close)
                self.assertEqual(env.step_count,0)
                self.assertIs(env.step.__func__,OriginalC07.step)
                self.assertIs(env._select_targets.__func__,OriginalC07._select_targets)
                if n>2:self.assertIs(env._child_tick.__func__,IntentEnv._child_tick)
                self.assertEqual(env.method.use_topology,method=="full")
                self.assertEqual(env.method_options.mac_enabled,method=="full")
                self.assertEqual(env.network.n_actions,{2:4,3:11,4:42}[n] if method=="full" else 2)
                self.assertFalse(env.network.root_records)

    def test_original_110_scientific_reference_identities_remain_exact(self):
        frozen=EXPERIMENT/"iterative_candidates_20261012"/"packet_grid_window_v5"/"code"/"PACKAGE_MANIFEST.json"
        if not frozen.is_file():self.skipTest("Historical frozen V5 evidence is not included in standalone code package")
        expected=json.loads(frozen.read_text(encoding="utf-8"))["source_hashes"]
        keys={key for key in expected if key.startswith(("original/","reference/"))}
        self.assertEqual(len(keys),110)
        current=source_hashes()
        self.assertEqual({key:current[key]for key in keys},{key:expected[key]for key in keys})


if __name__=="__main__":
    unittest.main(verbosity=2)
