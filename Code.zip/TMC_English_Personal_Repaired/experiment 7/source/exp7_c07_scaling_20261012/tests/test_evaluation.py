"""Short evaluator integration fixture, never a trained performance claim."""
import importlib
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
evaluation=importlib.import_module("exp7_c07_scaling_20261012.evaluation")
from exp7_c07_scaling_20261012.environment import make_environment
from exp7_c07_scaling_20261012.evaluation_gate import confirmation_seeds
from v6_candidates.c07.methods import get_method

class ShortUntrainedPolicy:
    # No torch model, optimizer, replay or RNG learner; prescribed actions only.
    method=get_method("usde_only_v6")
    topology=None
    def __init__(self,*args,**kwargs): pass
    def make_environment(self):
        env=make_environment(3,30,"usde_only",faults=[])
        env.cfg.episode_steps=3  # Explicit test fixture only, not CLI option.
        return env
    def validate_environment(self,env): pass
    def act(self,obs): return np.zeros((3,2),np.float32)

class EvaluationIntegrationTests(unittest.TestCase):
    def test_actual_three_step_observers_emit75_metrics_and_evidence(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            checkpoint=root/"dummy.json"
            checkpoint.write_text("{}",encoding="utf-8")
            context={"profile":"adaptive_v1","stage":"development"}
            saved={"scale_context":context,"global_step":0,"source_hashes":{"test": "fixture"}}
            with mock.patch.object(evaluation,"load_new_checkpoint",return_value=saved), \
                 mock.patch.object(evaluation,"source_hashes",return_value=saved["source_hashes"]), \
                 mock.patch.object(evaluation.native,"Policy",ShortUntrainedPolicy):
                result=evaluation.evaluate_checkpoint(checkpoint,root/"evaluation",[10712000])
            self.assertEqual(result["episodes"],1)
            row=json.loads((root/"evaluation"/"complete.json").read_text(encoding="utf-8"))["rows"][0]
            self.assertEqual(len(row["metrics75"]),75)
            self.assertEqual(row["safety"]["physical_substeps"],30)
            self.assertEqual(row["steps"],3)
            self.assertEqual(row["aoi_auv_seconds"],9)
            self.assertEqual(row["data_resolved_trials"],0)
            self.assertTrue((root/"evaluation"/"seed_10712000"/"network_evidence.json.gz").is_file())
            self.assertTrue((root/"evaluation"/"seed_10712000"/"trace.jsonl.gz").is_file())
    def test_holdout_and_duplicate_seeds_are_rejected_before_loading(self):
        for seeds in ([10713000],[10712000,10712000]):
            with mock.patch.object(evaluation,"load_new_checkpoint") as loader:
                with self.assertRaises(ValueError):
                    evaluation.evaluate_checkpoint("missing.pt","uncreated_eval_test",seeds)
                loader.assert_not_called()

class AnalysisPhaseTests(unittest.TestCase):
    def record(self,confirmation=False,index=1):
        seeds=list(confirmation_seeds(index)) if confirmation else [10712000,10712001]
        digest="a"*64
        rows=[dict(seed=seed,evaluation_fault="reference",model_sha256=digest,
                   model_training_step=50000) for seed in seeds]
        phase=dict(phase="holdout_validation" if confirmation else "development",seeds=seeds,
            primary="collected_packets",evaluation_fault="reference",holdout_opened=confirmation,
            already_opened=False,checkpoint_sha256=digest,model_training_step=50000,
            validation_contract_sha256="b"*64 if confirmation else None,
            confirmation_index=index if confirmation else None,family_alpha=.05/(2**index) if confirmation else None)
        return dict(rows=rows,seeds=seeds,evaluation_phase=phase,model_sha256=digest)

    def test_development_is_descriptive_and_legacy_cannot_be_confirmation(self):
        value=self.record()
        scope=evaluation.analysis_scope([value,copy.deepcopy(value)])
        self.assertEqual(scope["phase"],"development")
        self.assertEqual(scope["family_alpha"],.05)
        value.pop("evaluation_phase")
        self.assertEqual(evaluation.analysis_scope([value])["phase"],"development")
        held=self.record(True);held.pop("evaluation_phase")
        with self.assertRaises(ValueError): evaluation.analysis_scope([held])

    def test_confirmation_uses_frozen_sequential_alpha(self):
        for index,alpha in ((1,.025),(2,.0125)):
            scope=evaluation.analysis_scope([self.record(True,index),self.record(True,index)])
            self.assertEqual(scope["family_alpha"],alpha)
            self.assertEqual(scope["confirmation_index"],index)

    def test_mixed_phase_or_contract_is_rejected(self):
        with self.assertRaises(ValueError):
            evaluation.analysis_scope([self.record(),self.record(True)])
        changed=self.record(True)
        changed["evaluation_phase"]["validation_contract_sha256"]="c"*64
        with self.assertRaises(ValueError):
            evaluation.analysis_scope([self.record(True),changed])

    def test_confirmation_tampering_is_rejected(self):
        for key,value in (("family_alpha",.05),("evaluation_fault","training"),
                          ("checkpoint_sha256","c"*64),("holdout_opened",False),
                          ("confirmation_index",True),("model_training_step",100000)):
            changed=self.record(True);changed["evaluation_phase"][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError): evaluation.analysis_scope([changed])

    def test_next_confirmation_cannot_relabel_previously_seen_block(self):
        changed=self.record(True,2)
        old_seeds=list(confirmation_seeds(1))
        changed["seeds"]=old_seeds
        changed["evaluation_phase"]["seeds"]=old_seeds
        for row,seed in zip(changed["rows"],old_seeds): row["seed"]=seed
        with self.assertRaises(ValueError): evaluation.analysis_scope([changed])

    def test_missing_or_reordered_rows_are_rejected(self):
        for changed in (self.record(),self.record(True)):
            changed["rows"].reverse()
            with self.assertRaises(ValueError): evaluation.analysis_scope([changed])

if __name__=="__main__": unittest.main()
