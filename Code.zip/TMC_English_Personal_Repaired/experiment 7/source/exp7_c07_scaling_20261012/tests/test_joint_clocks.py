"""Prepared joint/V13/V15/V16/V26/V27/V28 declarations and inert lifecycle only.

Native libraries/config/options/calendar constructors import, but no ENV
constructor/reset/step, network.advance, Torch model/optimizer, real checkpoint,
probe, development seed or holdout is executed. object.__new__ fixtures below
are explicitly manufactured state, not a trial environment or performance.
"""
from copy import deepcopy
from dataclasses import asdict,fields
import ast
import inspect
import json
from itertools import product
import math
from pathlib import Path
import pickle
import sys
import tempfile
from types import MethodType,SimpleNamespace
import unittest
from unittest.mock import patch

sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012 import environment as e,workflow as w,root_budget as b,joint_clocks as j,child_deadline
from usv_auv.deploy import environment_schema
from v6_candidates.c03.mac import DynamicMacNetwork
from v6_candidates.c06.mac import DynamicMacNetwork as C06Net
from v4_task_20260917_r2.routing import QueueOptions


def historical_source(relative, *, directories=(), files=()):
    """Lazily locate a historical candidate; absent history alone is a skip.

    No folder basename is required. A present candidate with missing inputs is
    an error, and the caller's existing SHA/AST assertions remain unchanged.
    """
    relative=Path(relative)
    if relative.is_absolute() or len(relative.parts)<2 or ".." in relative.parts:
        raise ValueError("A relative historical candidate path is required")
    candidate=Path(*relative.parts[:2])
    for root in Path(__file__).resolve().parents:
        anchor=root/candidate
        if not anchor.exists():
            continue
        if not anchor.is_dir():
            raise AssertionError("Historical candidate is not a directory: "+str(anchor))
        result=root/relative
        expected_directory=bool(directories or files)
        if not (result.is_dir() if expected_directory else result.is_file()):
            raise AssertionError("Present historical candidate is incomplete: "+str(result))
        for name in directories:
            if not (result/name).is_dir():
                raise AssertionError("Historical directory is missing: "+str(result/name))
        for name in files:
            if not (result/name).is_file():
                raise AssertionError("Historical file is missing: "+str(result/name))
        return result
    raise unittest.SkipTest("Historical candidate tree absent: "+candidate.as_posix())


def _remove_exact_statement(function,source):
    wanted=ast.dump(ast.parse(source).body[0],include_attributes=False)
    sites=[(node,i) for node in ast.walk(function) if hasattr(node,"body") and isinstance(node.body,list)
           for i,statement in enumerate(node.body) if ast.dump(statement,include_attributes=False)==wanted]
    if len(sites)!=1:raise AssertionError("Exactly one reversible statement required in "+function.name+": "+source)
    parent,index=sites[0];parent.body.pop(index)


def restore_v28_scope_functions(functions):
    functions=deepcopy(functions)
    for name in ("_native_root16_child4_scope_check","NativeRoot16Child4N4Options",
                 "_check_native_root16_child4_shape","native_root16_child4_validation_proof"):
        if name not in functions:raise AssertionError("Missing V28 definition: "+name)
        functions.pop(name)
    _remove_exact_statement(functions["fast_runtime_check"],"_check_native_root16_child4_shape()")
    _remove_exact_statement(functions["expected_options"],
        'if n == 4 and profile==JOINT_PHY_LOC_ROOT16_PROFILE:\n    value.update(dict(zip(root_budget.BUDGET_FIELDS,ROOT16_CHILD4_TUPLE)))')
    dump=lambda node:ast.dump(node,include_attributes=False)
    expected=dump(ast.parse("profile==JOINT_PHY_LOC_ROOT16_PROFILE",mode="eval").body)
    class Restore(ast.NodeTransformer):
        count=0
        def visit_Tuple(self,node):
            node=self.generic_visit(node)
            node.elts=[x for x in node.elts if not isinstance(x,ast.Name) or x.id!="JOINT_PHY_LOC_ROOT16_PROFILE"]
            return node
        def visit_IfExp(self,node):
            if dump(node.test)==expected:
                self.count+=1;return self.visit(node.orelse)
            return self.generic_visit(node)
        def visit_Constant(self,node):
            if node.value=="Native pool12/root16 must not use the historical pool20 validator insertion":
                return ast.Constant(value="Native pool12 must not use the historical pool20 validator insertion")
            return node
    restore=Restore();result={name:restore.visit(node) for name,node in functions.items()}
    if restore.count!=2:raise AssertionError("Exactly V28 selector text and constructor dispatch expressions required")
    return result


def restore_v28_factory(function):
    function=deepcopy(function);branch=function.body[0]
    if (not isinstance(branch,ast.If) or branch.orelse or
            ast.dump(branch.test,include_attributes=False)!=ast.dump(ast.parse(
                "profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE",mode="eval").body,include_attributes=False)):
        raise AssertionError("Exactly first V28 isolated factory branch required")
    function.body.pop(0);return function


def restore_v28_environment_functions(functions):
    functions=deepcopy(functions)
    for name in ("_expected_joint_queue_options","DeclaredJointPHYLOCRoot16C07Env"):
        if name not in functions:raise AssertionError("Missing V28 environment definition: "+name)
        functions.pop(name)
    functions["build_settings"]=restore_v28_factory(functions["build_settings"])
    cfg=functions["ScaleConfig"]
    annotation=ast.dump(ast.parse("localization_service_interval: float = 12.").body[0],include_attributes=False)
    sites=[i for i,node in enumerate(cfg.body) if ast.dump(node,include_attributes=False)==annotation]
    if len(sites)!=1:raise AssertionError("Exactly one LOC ScaleConfig field required")
    cfg.body.pop(sites[0]);methods={node.name:node for node in cfg.body if isinstance(node,ast.FunctionDef)}
    _remove_exact_statement(methods["to_dict"],
        'if value["localization_service_interval"]==12. and not getattr(self,"_explicit_localization_service_interval",False):\n    value.pop("localization_service_interval")')
    _remove_exact_statement(methods["validate"],
        'if (type(self.localization_service_interval) is not float or not math.isfinite(self.localization_service_interval) or self.localization_service_interval<=0):\n    raise ValueError("LOC priority service interval must be a positive finite float")')
    _remove_exact_statement(methods["from_dict"],
        'if "localization_service_interval" in data:\n    value._explicit_localization_service_interval=True')
    reset=next(node for node in functions["ScaledC07Env"].body if isinstance(node,ast.FunctionDef) and node.name=="reset")
    _remove_exact_statement(reset,'localization=getattr(self.cfg,"localization_service_interval",12.)')
    _remove_exact_statement(reset,'if localization!=12.:\n    self.network.queue_options=replace(self.network.queue_options,localization_service_s=localization)')
    fn=functions["validate_joint_settings"]
    assignment,branch,result=fn.body[-3:]
    if (not isinstance(assignment,ast.Assign) or ast.dump(assignment.targets[0])!=ast.dump(ast.Name(id="result",ctx=ast.Store())) or
            not isinstance(branch,ast.If) or not isinstance(result,ast.Return) or not isinstance(result.value,ast.Name) or result.value.id!="result"):
        raise AssertionError("Exactly private expected_queue_options result port required")
    expected=ast.parse('if profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE:\n    result["expected_queue_options"]=_expected_joint_queue_options(expected[0])').body[0]
    if ast.dump(branch,include_attributes=False)!=ast.dump(expected,include_attributes=False):raise AssertionError("Wrong queue DTO factory branch")
    fn.body[-3:]=[ast.Return(value=assignment.value)]
    methods={node.name:node for node in functions["DeclaredJointC07Env"].body if isinstance(node,ast.FunctionDef)}
    _remove_exact_statement(methods["__init__"],
        'if profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE:\n    self._joint_expected_queue_type=_NATIVE_QUEUE_OPTIONS_CLASS')
    _remove_exact_statement(methods["validate_selector_identity"],
        'if self._joint_profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE:\n    if (type(net.queue_options) is not self._joint_expected_queue_type or not joint_clocks.exact(asdict(net.queue_options),expected["expected_queue_options"])):\n        raise ValueError("V28 actual whole original QueueOptions differs from fixed declared queue DTO")')
    _remove_exact_statement(methods["_full_selector_identity"],
        'if (self._joint_profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE and not joint_clocks.exact(self._joint_expected_DTO["expected_queue_options"],expected["expected_queue_options"])):\n    raise ValueError("V28 fixed expected whole QueueOptions cannot change at reset or recache")')
    return functions


def restore_v27_scope_functions(functions):
    """Reverse only the V27 registry memberships and selector diagnostic arm."""
    functions=restore_v28_scope_functions(functions)
    dump=lambda node:ast.dump(node,include_attributes=False)
    signature=dump(ast.parse("profile==N34_STATE8_11_PROFILE",mode="eval").body)
    class Restore(ast.NodeTransformer):
        count=0
        def visit_Tuple(self,node):
            node=self.generic_visit(node)
            node.elts=[x for x in node.elts if not isinstance(x,ast.Name) or x.id!="N34_STATE8_11_PROFILE"]
            return node
        def visit_IfExp(self,node):
            if dump(node.test)==signature:
                self.count+=1
                return self.visit(node.orelse)
            return self.generic_visit(node)
    restore=Restore()
    result={name:restore.visit(node) for name,node in functions.items()}
    if restore.count!=1:raise AssertionError("Exactly the V27 selector diagnostic arm required")
    return result


def restore_v27_factory(function):
    function=deepcopy(function)
    branch=function.body[0]
    dump=lambda node:ast.dump(node,include_attributes=False)
    if (not isinstance(branch,ast.If) or branch.orelse or
            dump(branch.test)!=dump(ast.parse("profile==joint_clocks.N34_STATE8_11_PROFILE",mode="eval").body)):
        raise AssertionError("Exactly the first V27 isolated factory branch required")
    function.body.pop(0)
    return function


def restore_v26_scope_functions(functions):
    """Undo only the enumerated V26 registry/scope ports for whole-AST tests."""
    functions=restore_v27_scope_functions(functions)
    dump=lambda node:ast.dump(node,include_attributes=False)
    replacements={dump(ast.parse(source,mode="eval").body):ast.parse(target,mode="eval").body
        for source,target in (("profile in (POOL12_PROFILE,N4_COORD8_PROFILE)","profile==POOL12_PROFILE"),
            ('scope["profile"] not in (POOL12_PROFILE,N4_COORD8_PROFILE)','scope["profile"] != POOL12_PROFILE'))}
    class Restore(ast.NodeTransformer):
        def visit_Compare(self,node):
            if dump(node) in replacements:return deepcopy(replacements[dump(node)])
            return self.generic_visit(node)
        def visit_Tuple(self,node):
            node=self.generic_visit(node)
            node.elts=[x for x in node.elts if not isinstance(x,ast.Name) or x.id!="N4_COORD8_PROFILE"]
            return node
        def visit_IfExp(self,node):
            if dump(node.test)==dump(ast.parse("profile==N4_COORD8_PROFILE",mode="eval").body):
                return self.visit(node.orelse)
            return self.generic_visit(node)
    # Preserve the original V16 native-scope predicate, not a weakened dict or
    # truthiness surrogate. Its two explicit new profile clauses undo to one.
    fn=functions["_native_pool12_scope_check"]
    condition=fn.body[1].value.args[0]
    expected=[ast.parse('type(scope.get("profile")) is str',mode="eval").body,
        ast.parse('scope["profile"] in (POOL12_PROFILE,N4_COORD8_PROFILE)',mode="eval").body]
    if [dump(node) for node in condition.values[1:3]]!=[dump(node) for node in expected]:
        raise AssertionError("Exactly the V26 native profile predicate ports required")
    condition.values[1:3]=[ast.parse('exact(scope.get("profile"),POOL12_PROFILE)',mode="eval").body]
    calls=[node for node in ast.walk(fn) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name)
        and node.func.id=="expected_options"]
    if len(calls)!=1 or dump(calls[0].args[2])!=dump(ast.parse('scope["profile"]',mode="eval").body):
        raise AssertionError("Exactly the V26 native expected-options profile port required")
    calls[0].args[2]=ast.Name(id="POOL12_PROFILE",ctx=ast.Load())
    return {name:Restore().visit(node) for name,node in functions.items()}


def context(n=4,method="full",profile=j.PROFILES[0]):
    d=w.declaration(n,30,method,profile,[])
    return dict(version=w.VERSION,profile=profile,declaration=d,declaration_sha256=w.digest_json(d),
        stage="development",development_model_limit=200000,candidate_id="UNSELECTED_MANUFACTURED_ONLY",
        attempt_id="manufactured",budget_mode="per_model")


def saved(c):
    d=c["declaration"];cfg=e.ScaleConfig.from_dict(d["config"]);spec=w.native.get_method(d["method"])
    return dict(format=w.INFERENCE_FORMAT,scale_context=deepcopy(c),global_step=0,seed=7,
        method_id=spec.method_id,method_spec=spec.to_dict(),method_fingerprint=spec.fingerprint,
        environment_config=cfg.to_dict(),config_fingerprint=cfg.fingerprint,
        method_options=deepcopy(d["method_options"]),routing_options=deepcopy(d["routing_options"]),
        learning_config=deepcopy(d["learning"]),training_protocol=deepcopy(d["training_protocol"]),
        revision_learning_options=asdict(w.native.RevisionLearningOptions(area_size=cfg.area_size,
            max_speed=cfg.max_speed,dt=cfg.dt,action_frame=cfg.action_frame)),
        source_hashes=w.source_hashes(),agents=[{"actor":{}} for _ in range(cfg.n_auv)],
        topology={"online":{}} if spec.use_topology else None)


def fixture(n=4,method="full",profile=j.PROFILES[0],target=None):
    cfg,mo,ro,d=e.build_settings(n,30,method,profile,[])
    value=target if target is not None else object.__new__(e.environment_class(profile))
    value._joint_profile=profile
    value._joint_expected_DTO=e.validate_joint_settings(cfg,method,mo,ro,profile)
    value._joint_expected_types=(type(cfg),type(mo),type(ro))
    value._joint_declared_n_auv=n;value._joint_expected=(cfg,method,mo,ro)
    value._joint_initialized=True;value._joint_close_attempted=False;value._joint_close_error=None
    value.cfg=cfg;value.method_options=mo;value.routing_options=ro
    value.method=w.native.get_method(e.canonical_method(method))
    value.observation_schema=list(e.local_fields(n));value.slow_observation_schema=list(e.slow_fields(n))
    value.observation_dim=len(value.observation_schema);value.slow_observation_dim=len(value.slow_observation_schema)
    candidates=([tuple(p) for p in product(range(n+1),repeat=n) if all(e.AcousticNetwork._valid_path(i,p) for i in range(1,n+1))]
        if value.method.use_topology else [tuple(0 for _ in range(n))])
    value._joint_expected_schema=dict(local_fields=value.observation_schema.copy(),slow_fields=value.slow_observation_schema.copy(),
        version=e.OriginalC07.observation_schema_version,topology_actions=len(candidates)+1,
        topology_candidates=[list(x) for x in candidates])
    # No network __init__/advance: fill only the already declared static facts.
    net=object.__new__(C06Net if profile == child_deadline.PROFILE else DynamicMacNetwork);cal=d["joint_clock_adaptation"]
    net.topologies=candidates;net.candidates=candidates;net.slot_owners=cal["actual_slot_owners"].copy()
    net.slot_duration=cal["actual_slot_duration_s"];net.cooperative_slot_gap=cal["actual_cooperative_gap_s"]
    net.max_management_run=cal["actual_max_management_run"];net.time=0.
    net.probe_timeout=value._joint_expected_DTO["native_probe_timeout_s"]
    if profile==j.JOINT_PHY_LOC_ROOT16_PROFILE:
        value._joint_expected_queue_type=QueueOptions
        net.queue_options=QueueOptions(**deepcopy(value._joint_expected_DTO["expected_queue_options"]))
    value.network=net;value.step_count=0;value.time=0.
    value.service_retry_interval=value._joint_expected_DTO["clock"]["service_retry_interval_s"]
    value.service_renew_lead=value._joint_expected_DTO["clock"]["service_renew_lead_s"]
    value._joint_selector_handle=(j.SelectorHandle(value) if j.HORIZONS[profile][n]==2 and value.method.use_resource_mac else None)
    value._child_delivery_handle=None  # Mirror the real constructor's cleanup lifecycle state.
    if profile == child_deadline.PROFILE and n in (3, 4) and value.method.use_resource_mac:
        net.n_auvs=n
        net.intent_enabled=True
        value._child_delivery_handle=child_deadline.RankHandle(net)
    value.validate_selector_identity()
    return value


class NoPhysics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.guards=[patch.object(e.OriginalC07,name,side_effect=AssertionError("NO actual ENV "+name))
            for name in ("__init__","reset","step")]
        cls.guards += [patch.object(e.AcousticNetwork,"advance",side_effect=AssertionError("NO network advance")),
            patch.object(DynamicMacNetwork,"advance",side_effect=AssertionError("NO native MAC advance"))]
        for guard in cls.guards:guard.start()
    @classmethod
    def tearDownClass(cls):
        for guard in reversed(cls.guards):guard.stop()


class DeclarationTests(NoPhysics):
    def test_exact_registered_profiles_no_free_horizon_and_original_defaults(self):
        self.assertEqual(len(j.LEGACY_PROFILES),4);self.assertEqual(len(j.PROFILES),10)
        self.assertEqual([dict(j.HORIZONS[p]) for p in j.PROFILES],
            [{2:1,3:1,4:1},{2:1,3:1,4:2},{2:1,3:2,4:1},{2:1,3:2,4:2},{2:1,3:2,4:2},{2:1,3:2,4:2},{2:1,3:2,4:2},{2:1,3:2,4:2},{2:1,3:2,4:2},{2:1,3:2,4:2}])
        self.assertEqual(j.PROFILES[-6],j.HETEROGENEOUS_PROFILE)
        self.assertEqual(j.PROFILES[-5],j.HELLO48_PROFILE)
        self.assertEqual(j.PROFILES[-4],j.POOL12_PROFILE)
        self.assertEqual(j.PROFILES[-3],j.N4_COORD8_PROFILE)
        self.assertEqual(j.PROFILES[-2],j.N34_STATE8_11_PROFILE)
        self.assertEqual(j.PROFILES[-1],j.JOINT_PHY_LOC_ROOT16_PROFILE)
        self.assertEqual(dict(j.FRAMES),{2:36.0,3:30.0,4:33.0})
        for p in j.PROFILES:
            for n in (2,3,4):self.assertEqual(j.registered(p,n)[0],j.HORIZONS[p][n])
        for p,n in ((b.ROOT_BUDGET_PROFILE,4),(j.PROFILES[0],True),(j.PROFILES[0],4.0)):
            with self.assertRaises(ValueError):j.registered(p,n)
        self.assertEqual(e.build_settings.__defaults__[0],"adaptive_v1")
        self.assertEqual(e.make_environment.__defaults__[0],"adaptive_v1")
        self.assertEqual(e.PROFILES[-len(j.PROFILES):],j.PROFILES)

    def test_common30_only_typed_and_no_arbitrary_profile(self):
        for p in j.PROFILES:
            for n,s in ((True,30),(3.0,30),(3,30.0),(3,45),(4,60)):
                with self.subTest(p=p,n=n,s=s),self.assertRaises(ValueError):e.build_settings(n,s,"full",p,[])
        with self.assertRaises(ValueError):e.build_settings(4,30,"full","adaptive_packet_grid_joint_h3_3_h4_2_v12",[])

    def test_all24_cfg_mo_ro_exact_v9_delta_and_noise_learning_preserved(self):
        for p in j.LEGACY_PROFILES:
            for n in (2,3,4):
                for m in ("full","usde_only"):
                    old=e.build_settings(n,30,m,b.ROOT_BUDGET_PROFILE,[]);new=e.build_settings(n,30,m,p,[])
                    oc,nc=old[0].to_dict(),new[0].to_dict();om,nm=asdict(old[1]),asdict(new[1])
                    cd={k for k in nc if not j.exact(nc[k],oc.get(k))};md={k for k in nm if not j.exact(nm[k],om.get(k))}
                    self.assertEqual(cd,set() if n==2 else {"tdma_sensors_per_group","hello_period","service_ack_timeout","grant_ttl"})
                    self.assertEqual(md,set() if n==2 else {"mac_child_lead_s"})
                    self.assertTrue(j.exact(asdict(old[2]),asdict(new[2])))
                    self.assertEqual(new[0].exploration_noise,.15)
                    self.assertEqual(new[0].episode_steps,1200)
                    self.assertEqual(tuple(fields(new[1])),tuple(fields(b.OriginalC07Options)))
                    if n>2:
                        self.assertEqual((nc["tdma_sensors_per_group"],nc["hello_period"],nc["service_ack_timeout"],nc["grant_ttl"]),
                            (6,30. if n==3 else 40.,106. if n==3 else 126.,106. if n==3 else 126.))
                    dnew=w.declaration(n,30,m,p,[]);dold=w.declaration(n,30,m,b.ROOT_BUDGET_PROFILE,[])
                    for key in ("learning","training_protocol","reward","ending"):
                        self.assertTrue(j.exact(dnew[key],dold[key]))

    def test_full_usde_whole_sameN_cfg_ro_and_only_mac_enabled_MO(self):
        for p in j.PROFILES:
            for n in (2,3,4):
                full=e.build_settings(n,30,"full",p,[]);usde=e.build_settings(n,30,"usde_only",p,[])
                self.assertTrue(j.exact(full[0].to_dict(),usde[0].to_dict()))
                self.assertTrue(j.exact(asdict(full[2]),asdict(usde[2])))
                f,u=asdict(full[1]),asdict(usde[1]);f["mac_enabled"]=False
                self.assertTrue(j.exact(f,u))
                self.assertFalse(usde[3]["joint_clock_adaptation"]["selector"]["installed_H2_hook"])
                self.assertEqual(usde[3]["joint_clock_adaptation"]["selector"]["selector_port"]["changed_AST_sites"],0)

    def test_complete_diagnostic_differences_against_actual_oracle_not_summary_selfassertion(self):
        diff=lambda a,z:{k:{"old":a.get(k),"new":v} for k,v in z.items() if not j.exact(a.get(k),v)}
        for p in j.PROFILES:
            for n in (2,3,4):
                cfg,mo,ro,d=e.build_settings(n,30,"full",p,[]);basecfg,basemo,_=e._reference("full_v6")
                self.assertTrue(j.exact(d["config_changes"],diff(basecfg,cfg.to_dict())))
                self.assertTrue(j.exact(d["option_changes"],diff(basemo,asdict(mo))))
                if n>2 and p!=j.JOINT_PHY_LOC_ROOT16_PROFILE:
                    v5=e.build_settings(n,30,"full","adaptive_packet_grid_window_v5",[])
                    self.assertTrue(j.exact(d["root_budget_adaptation"]["declared_config_diff_from_v5"],diff(v5[0].to_dict(),cfg.to_dict())))
                    self.assertTrue(j.exact(d["root_budget_adaptation"]["declared_option_diff_from_v5"],diff(asdict(v5[1]),asdict(mo))))
                    self.assertFalse(d["root_budget_adaptation"]["physical_calendar_unchanged_from_v5"])
                self.assertEqual(d["clock"]["frame_s"],j.registered_frame(p,n))
                self.assertEqual(mo.mac_child_lead_s,j.MINIMUMS[p][n])

    def test_legacy_builder_AST_oracle_all_original_profiles_preserved(self):
        root=Path(e.__file__).resolve().parents[1]
        path=historical_source("iterative_candidates_20261013/packet_grid_n4_child_h2_v11_preparation/code/exp7_c07_scaling_20261012/environment.py")
        self.assertEqual(j.digest(path),"6b75d3d65e50719d6cd5ee3e9d1e0c3c6862c26ab78a9739056f99c905a167ac")
        tree=ast.parse(path.read_text(encoding="utf-8-sig"))
        f=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=="build_settings")
        ns=dict(vars(e));exec(compile(ast.fix_missing_locations(ast.Module(body=[deepcopy(f)],type_ignores=[])),
            "<PIN V11 builder AST only>","exec",dont_inherit=True),ns)
        for p in e.PROFILES[:-len(j.PROFILES)]:
            for n in (2,3,4):
                for m in ("full","usde_only"):
                    old=ns["build_settings"](n,30,m,p,[]);new=e.build_settings(n,30,m,p,[])
                    for a,z in zip((old[0].to_dict(),asdict(old[1]),asdict(old[2]),old[3]),
                                   (new[0].to_dict(),asdict(new[1]),asdict(new[2]),new[3])):self.assertTrue(j.exact(a,z))

    def test_legacy_four_complete_settings_against_frozen_V12_builder_AST(self):
        root=Path(e.__file__).resolve().parents[1]
        path=historical_source("iterative_candidates_20261013/packet_grid_joint_h2_v12/code/exp7_c07_scaling_20261012/environment.py")
        self.assertEqual(j.digest(path),"0ea426e2c2bf517a1668a8cc327cfe0fff2aba72cad7e3ca17b194ad91b0f7ed")
        tree=ast.parse(path.read_text(encoding="utf-8-sig"))
        original=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=="build_settings")
        ns=dict(vars(e));exec(compile(ast.fix_missing_locations(ast.Module(body=[deepcopy(original)],type_ignores=[])),
            "<PIN V12 builder AST only>","exec",dont_inherit=True),ns)
        for p in j.LEGACY_PROFILES:
            for n in (2,3,4):
                for method in ("full","usde_only"):
                    old=ns["build_settings"](n,30,method,p,[]);new=e.build_settings(n,30,method,p,[])
                    for a,z in zip((old[0].to_dict(),asdict(old[1]),asdict(old[2]),old[3]),
                        (new[0].to_dict(),asdict(new[1]),asdict(new[2]),new[3])):self.assertTrue(j.exact(a,z))

    def test_heterogeneous_only_N4_three_CFG_and_one_MIN_no_other_numeric_deltas(self):
        p=j.HETEROGENEOUS_PROFILE
        for n in (2,3,4):
            for method in ("full","usde_only"):
                old=e.build_settings(n,30,method,j.LEGACY_PROFILES[-1],[]);new=e.build_settings(n,30,method,p,[])
                delta=lambda a,z:{k for k,v in z.items() if not j.exact(v,a.get(k))}
                self.assertEqual(delta(old[0].to_dict(),new[0].to_dict()),set() if n!=4 else {"tdma_sensors_per_group","service_ack_timeout","grant_ttl"})
                self.assertEqual(delta(asdict(old[1]),asdict(new[1])),set() if n!=4 else {"mac_child_lead_s"})
                self.assertTrue(j.exact(asdict(old[2]),asdict(new[2])))
                self.assertEqual(new[1].mac_prepare_lead_frames,3)
                self.assertEqual(new[1].mac_coop_lease_frames,30);self.assertEqual(new[1].mac_frame_stride,2)
                adaptation=new[3]["joint_clock_adaptation"]
                self.assertNotIn("selected",adaptation);self.assertNotIn("trained",adaptation)
                self.assertIs(adaptation["constructor_selects_or_trains"],False)
                self.assertIs(new[3]["heterogeneous_calendar_adaptation"]["physical_bandwidth_or_slot_rate_increased"],False)
                if n==4:
                    self.assertEqual((new[0].tdma_sensors_per_group,new[0].hello_period,new[0].service_ack_timeout,new[0].grant_ttl,new[1].mac_child_lead_s),
                        (4,40.0,134.0,134.0,72.0))
                    for key in ("hello_period","service_ack_timeout","grant_ttl"):
                        self.assertIs(type(new[0].to_dict()[key]),float)
                    self.assertIs(type(new[0].tdma_sensors_per_group),int)
                for key in ("learning","training_protocol","reward","ending"):
                    self.assertTrue(j.exact(w.declaration(n,30,method,p,[])[key],w.declaration(n,30,method,j.LEGACY_PROFILES[-1],[])[key]))

    def test_heterogeneous_actual_calendar_clocks_group_helpers_and_typed_scope(self):
        p=j.HETEROGENEOUS_PROFILE;cfg,mo,_,d=e.build_settings(4,30,"full",p,[])
        owners=d["joint_clock_adaptation"]["actual_slot_owners"]
        self.assertEqual((len(owners),d["clock"]["frame_s"]),(70,42.0))
        self.assertEqual(owners.count(0),8)
        for node in range(1,5):self.assertEqual(owners.count(node),8)
        for node in range(5,35):self.assertEqual(owners.count(node),1)
        self.assertAlmostEqual(d["joint_clock_adaptation"]["actual_cooperative_gap_s"],5.4)
        self.assertAlmostEqual(d["clock"]["service_retry_interval_s"],133.2)
        self.assertAlmostEqual(d["clock"]["service_renew_lead_s"],91.2)
        self.assertEqual(j.registered(p,4),(2,72.0));self.assertEqual(j.registered_group(p,4),4)
        for n in (True,4.0):
            with self.assertRaises(ValueError):j.registered_frame(p,n)
            with self.assertRaises(ValueError):j.registered_group(p,n)
        self.assertEqual((mo.mac_pool_slots,mo.mac_child_max_active,mo.mac_auv_slots,mo.mac_max_leases),(20,8,2,28))

    def test_heterogeneous_all30_donor_phases_have_a_12s_integer_lead_band(self):
        # Integer slot arithmetic of the existing C04 align/one-stride advance:
        # not a received parent/child, demand/overlap/cap or paid TX/RX proof.
        for n in (3,4):
            cfg,mo,_,d=e.build_settings(n,30,"full",j.HETEROGENEOUS_PROFILE,[])
            owners=d["joint_clock_adaptation"]["actual_slot_owners"]
            frame=len(owners);period=2*frame;tick=20  # .6s slots, native12s tick
            lower=int(round(mo.mac_child_lead_s/cfg.slot_duration))
            upper=2*frame
            gap=int(round(d["joint_clock_adaptation"]["actual_cooperative_gap_s"]/cfg.slot_duration))
            self.assertEqual((upper-lower)*cfg.slot_duration,12.0)
            self.assertEqual(period%tick,0)
            for parent_phase in (0,1):
                for donor in range(n+1,n+31):
                    offset=owners.index(donor);eligible=[]
                    for now in range(0,period,tick):
                        start=max(now//frame,parent_phase)
                        start+=(parent_phase-start)%mo.mac_frame_stride
                        first=start*frame+offset
                        if first<=now+2*gap:
                            start+=mo.mac_frame_stride;first=start*frame+offset
                        lead=first-now
                        if lower<lead<=upper:eligible.append((now,start,lead))
                    with self.subTest(n=n,parent_phase=parent_phase,donor=donor):
                        self.assertEqual(len(eligible),1)
                        _,start,_=eligible[0]
                        self.assertEqual((start-parent_phase)%mo.mac_frame_stride,0)
                        self.assertLess(start+mo.mac_child_lease_frames,parent_phase+mo.mac_coop_lease_frames)

    def test_all_V13_profiles_entire_settings_equal_frozen_V13_builder_AST(self):
        root=Path(e.__file__).resolve().parents[1]
        path=historical_source("iterative_candidates_20261013/packet_grid_heterogeneous_g4_h2_v13_frozen/code/exp7_c07_scaling_20261012/environment.py")
        self.assertEqual(j.digest(path),"119ef60e8be8e8c21ea56778b6f083335903cd4011c152335d97a1537355c4b7")
        original=next(x for x in ast.parse(path.read_text(encoding="utf-8-sig")).body
            if isinstance(x,ast.FunctionDef) and x.name=="build_settings")
        ns=dict(vars(e));exec(compile(ast.fix_missing_locations(ast.Module(body=[deepcopy(original)],type_ignores=[])),
            "<PIN frozen V13 builder AST only>","exec",dont_inherit=True),ns)
        for p in (*e.PROFILES[:-len(j.PROFILES)],*j.LEGACY_PROFILES,j.HETEROGENEOUS_PROFILE):
            for n,method,faults in product((2,3,4),("full","usde_only"),(None,[])):
                old=ns["build_settings"](n,30,method,p,faults);new=e.build_settings(n,30,method,p,faults)
                for a,z in zip((old[0].to_dict(),asdict(old[1]),asdict(old[2]),old[3]),
                    (new[0].to_dict(),asdict(new[1]),asdict(new[2]),new[3])):self.assertTrue(j.exact(a,z),(p,n,method))

    def test_hello48_whole_scientific_fieldsets_only_N4_one_typed_CFG_delta(self):
        for n,method,faults in product((2,3,4),("full","usde_only"),(None,[])):
            old=e.build_settings(n,30,method,j.HETEROGENEOUS_PROFILE,faults)
            new=e.build_settings(n,30,method,j.HELLO48_PROFILE,faults)
            before,after=old[0].to_dict(),new[0].to_dict()
            self.assertEqual(before.keys(),after.keys())
            delta={k:{"old":before[k],"new":v} for k,v in after.items() if not j.exact(before[k],v)}
            self.assertTrue(j.exact(delta,{} if n!=4 else {"hello_period":{"old":40.0,"new":48.0}}))
            self.assertTrue(j.exact(asdict(old[1]),asdict(new[1])))
            self.assertTrue(j.exact(asdict(old[2]),asdict(new[2])))
            self.assertIs(type(new[0].hello_period),float)
            self.assertIs(type(new[1].visit_packet_budget),float);self.assertEqual(new[1].visit_packet_budget,4.0)
            self.assertTrue(j.exact(old[3]["clock"],new[3]["clock"]))
            self.assertTrue(j.exact(old[3]["joint_clock_adaptation"]["actual_slot_owners"],
                new[3]["joint_clock_adaptation"]["actual_slot_owners"]))
            self.assertTrue(j.exact(old[3]["joint_clock_adaptation"]["selector"]["selector_port"],
                new[3]["joint_clock_adaptation"]["selector"]["selector_port"]))
            a=w.declaration(n,30,method,j.HETEROGENEOUS_PROFILE,faults)
            z=w.declaration(n,30,method,j.HELLO48_PROFILE,faults)
            self.assertEqual(a.keys(),z.keys())
            # Restore only the sole native CFG delta; ALL other scientific
            # declaration fields remain typed-exact, not a selected subset.
            z=deepcopy(z);z["config"]["hello_period"]=a["config"]["hello_period"]
            self.assertTrue(j.exact({k:v for k,v in a.items() if k not in ("profile","scale_diagnostics")},
                {k:v for k,v in z.items() if k not in ("profile","scale_diagnostics")}))
            adaptation=new[3]["hello_period_adaptation"]
            self.assertTrue(j.exact(adaptation["declared_config_diff_from_v13"],delta))
            self.assertTrue(j.exact(adaptation["declared_option_diff_from_v13"],{}))
            self.assertFalse(adaptation["physical_capacity_added"])
            self.assertFalse(adaptation["constructor_selects_or_trains"])
            self.assertIs(adaptation["visit_packet_budget_unchanged"],True)
            self.assertTrue(j.exact(adaptation["nominal_visit_packet_budget"],4.0))

    def test_hello48_actual_native_clocks_G4_H2_and_probe_rescue_unchanged(self):
        p=j.HELLO48_PROFILE
        for method in ("full","usde_only"):
            cfg,mo,_,d=e.build_settings(4,30,method,p,[])
            old=e.build_settings(4,30,method,j.HETEROGENEOUS_PROFILE,[])
            self.assertEqual((cfg.hello_period,cfg.tdma_sensors_per_group,d["clock"]["frame_s"],mo.mac_child_lead_s),
                (48.0,4,42.0,72.0))
            self.assertEqual((cfg.service_ack_timeout,cfg.grant_ttl,mo.mac_prepare_lead_frames,mo.visit_packet_budget),
                (134.0,134.0,3,4.0))
            self.assertEqual((j.registered_group(p,4),j.registered_frame(p,4),j.registered(p,4)),(4,42.0,(2,72.0)))
            net=e.AcousticNetwork(cfg,cfg.seed);prior=e.AcousticNetwork(old[0],old[0].seed)
            self.assertTrue(j.exact(list(net.slot_owners),list(prior.slot_owners)))
            self.assertTrue(j.exact(net.probe_timeout,prior.probe_timeout))
            self.assertAlmostEqual(net.cooperative_slot_gap,5.4)
            self.assertAlmostEqual(d["clock"]["cooperative_turn_s"],48.6)
            self.assertAlmostEqual(net.probe_timeout,49.2)
            self.assertAlmostEqual(.5*net.probe_timeout,24.6)
            self.assertAlmostEqual(d["clock"]["service_retry_interval_s"],133.2)
            self.assertAlmostEqual(d["clock"]["service_renew_lead_s"],91.2)
            adaptation=d["hello_period_adaptation"]
            self.assertTrue(j.exact(adaptation["old_native_probe_timeout_s"],adaptation["new_native_probe_timeout_s"]))
            self.assertTrue(j.exact(adaptation["old_native_ACK_rescue_threshold_s"],adaptation["new_native_ACK_rescue_threshold_s"]))

    def test_hello48_typed_saved_context_and_wrong_scope_rejected(self):
        p=j.HELLO48_PROFILE
        for n,method in product((2,3,4),("full","usde_only")):
            c=context(n,method,p);value=saved(c)
            self.assertIs(w.validate_checkpoint_metadata(value),value)
            for cap in (6.0,6,True):
                wrong=deepcopy(c);wrong["declaration"]["method_options"]["visit_packet_budget"]=cap
                wrong["declaration_sha256"]=w.digest_json(wrong["declaration"])
                with self.assertRaises(ValueError):w._authenticate_joint_context(wrong)
            if n!=4:continue
            for period in (48,True,"48.0",float("nan"),float("inf"),40.0,60.0):
                wrong=deepcopy(c);wrong["declaration"]["config"]["hello_period"]=period
                # Nonfinite values cannot even be sealed as JSON evidence.
                if type(period) is float and not math.isfinite(period):
                    with self.assertRaises(ValueError):w.digest_json(wrong["declaration"])
                else:
                    wrong["declaration_sha256"]=w.digest_json(wrong["declaration"])
                    with self.assertRaises(ValueError):w._authenticate_joint_context(wrong)
            wrong=deepcopy(c);wrong["profile"]=j.HETEROGENEOUS_PROFILE
            with self.assertRaises(ValueError):w._authenticate_joint_context(wrong)

    def test_hello48_cached_runtime_CFG_rejects_old_period_before_behavior(self):
        for method in ("full","usde_only"):
            env=fixture(4,method,j.HELLO48_PROFILE)
            try:
                old=env.cfg.hello_period
                for period in (40.0,48,True,float("nan"),49.0):
                    env.cfg.hello_period=period
                    with self.assertRaisesRegex(ValueError,"cached full typed runtime"):
                        env.validate_selector_identity()
                env.cfg.hello_period=old;env.validate_selector_identity()
            finally:env.close()

    def test_hello48_all_native_reference_workflow_and_selector_bodies_unchanged(self):
        code=Path(e.__file__).resolve().parents[1]
        old=historical_source("iterative_candidates_20261013/packet_grid_heterogeneous_g4_h2_v13_frozen/code",directories=("c07_source","reference"),files=tuple("exp7_c07_scaling_20261012/"+name for name in ("workflow.py","n4_child_h2.py","root_budget.py","evaluation.py","joint_clocks.py")))
        for folder in ("c07_source","reference"):
            before={p.relative_to(old/folder).as_posix():p for p in (old/folder).rglob("*") if p.is_file()}
            after={p.relative_to(code/folder).as_posix():p for p in (code/folder).rglob("*") if p.is_file()}
            self.assertEqual(before.keys(),after.keys())
            for key,path in before.items():self.assertEqual(j.digest(path),j.digest(after[key]),key)
        for name in ("workflow.py","n4_child_h2.py","root_budget.py","evaluation.py"):
            self.assertEqual(j.digest(old/"exp7_c07_scaling_20261012"/name),j.digest(code/"exp7_c07_scaling_20261012"/name),name)
        dump=lambda node:ast.dump(node,include_attributes=False)
        before={x.name:x for x in ast.parse((old/"exp7_c07_scaling_20261012/joint_clocks.py").read_text(encoding="utf-8")).body
            if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
        after={x.name:x for x in ast.parse(Path(j.__file__).read_text(encoding="utf-8")).body
            if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
        after=restore_v28_scope_functions(after)
        for name,node in before.items():
            if name not in ("registered_group","selector_proof","expected_options","_scope_check","build_options","fast_runtime_check"):
                self.assertEqual(dump(node),dump(after[name]),name)

    def test_all_prior_profiles_entire_settings_equal_stable_V15_builder_AST(self):
        code=Path(e.__file__).resolve().parents[1]
        path=historical_source("iterative_candidates_20261014/n4_hello48_v15_preparation/code/exp7_c07_scaling_20261012/environment.py")
        self.assertEqual(j.digest(path),"d2e097d195441d4dc82ffb8769725e76f27e417d86defee3e1b93ad9790a5cf5")
        original=next(x for x in ast.parse(path.read_text(encoding="utf-8-sig")).body
            if isinstance(x,ast.FunctionDef) and x.name=="build_settings")
        ns=dict(vars(e));exec(compile(ast.fix_missing_locations(ast.Module(body=[deepcopy(original)],type_ignores=[])),
            "<PIN stable V15 builder AST only>","exec",dont_inherit=True),ns)
        for p in (profile for profile in e.PROFILES if profile not in (j.POOL12_PROFILE,j.N4_COORD8_PROFILE,j.N34_STATE8_11_PROFILE,j.JOINT_PHY_LOC_ROOT16_PROFILE)):
            for n,method,faults in product((2,3,4),("full","usde_only"),(None,[])):
                old=ns["build_settings"](n,30,method,p,faults);new=e.build_settings(n,30,method,p,faults)
                for a,z in zip((old[0].to_dict(),asdict(old[1]),asdict(old[2]),old[3]),
                    (new[0].to_dict(),asdict(new[1]),asdict(new[2]),new[3])):self.assertTrue(j.exact(a,z),(p,n,method))

    def test_pool12_whole_scientific_fieldsets_only_N4_one_strict_integer_MO_delta(self):
        for n,method,faults in product((2,3,4),("full","usde_only"),(None,[])):
            old=e.build_settings(n,30,method,j.HETEROGENEOUS_PROFILE,faults)
            new=e.build_settings(n,30,method,j.POOL12_PROFILE,faults)
            self.assertTrue(j.exact(old[0].to_dict(),new[0].to_dict()))
            self.assertTrue(j.exact(asdict(old[2]),asdict(new[2])))
            a,z=asdict(old[1]),asdict(new[1]);self.assertEqual(a.keys(),z.keys())
            delta={k:{"old":a[k],"new":v} for k,v in z.items() if not j.exact(a[k],v)}
            self.assertTrue(j.exact(delta,{} if n!=4 else {"mac_pool_slots":{"old":20,"new":12}}))
            self.assertTrue(j.exact(old[3]["clock"],new[3]["clock"]))
            self.assertTrue(j.exact(old[3]["joint_clock_adaptation"]["actual_slot_owners"],
                new[3]["joint_clock_adaptation"]["actual_slot_owners"]))
            self.assertTrue(j.exact(old[3]["joint_clock_adaptation"]["selector"]["selector_port"],
                new[3]["joint_clock_adaptation"]["selector"]["selector_port"]))
            before=w.declaration(n,30,method,j.HETEROGENEOUS_PROFILE,faults)
            after=w.declaration(n,30,method,j.POOL12_PROFILE,faults)
            self.assertEqual(before.keys(),after.keys());after=deepcopy(after)
            after["method_options"]["mac_pool_slots"]=before["method_options"]["mac_pool_slots"]
            self.assertTrue(j.exact({k:v for k,v in before.items() if k not in ("profile","scale_diagnostics")},
                {k:v for k,v in after.items() if k not in ("profile","scale_diagnostics")}))
            if n==4:
                self.assertIs(type(new[1]),j.NativePool12N4Options)
                self.assertIs(type(new[1].mac_pool_slots),int)
                self.assertEqual(tuple(z[k] for k in b.BUDGET_FIELDS),(12,2,28,8,2,30,2,3))
                self.assertEqual((new[0].hello_period,new[1].visit_packet_budget,new[1].mac_child_lead_s),
                    (40.0,4.0,72.0))
                self.assertEqual((new[0].service_ack_timeout,new[0].grant_ttl),(134.0,134.0))
                budget=new[3]["root_budget_adaptation"]
                self.assertIs(budget["validation_domain_scale_port"],False)
                self.assertIs(budget["originally_validated_pool_configuration"],True)
                self.assertEqual((budget["nominal_global_parent_rights"],budget["nominal_root_remainder_if_child_cap_fully_occupied"]),(20,4))
            else:self.assertIs(type(new[1]),b.OriginalC07Options)

    def test_pool12_original_C03_constructor_call_and_no_ported_validator_even_in_builder(self):
        native_code=b.OriginalC03Options.__dict__["__post_init__"].__code__
        before=sys.getprofile();calls=[]
        def profile(frame,event,arg):
            if event!="call":return
            if frame.f_code.co_name=="__post_init__" and j.code_signature(frame.f_code)==j._PRIMITIVE_CODE:
                raise AssertionError("Native P12 path MUST NOT invoke any upper20 primitive")
            if frame.f_code is native_code:
                calls.append((type(frame.f_locals["self"]),frame.f_locals["self"].mac_pool_slots))
        for method in ("full_v6","usde_only_v6"):
            calls.clear();sys.setprofile(profile)
            try:
                cfg,mo,_,_=e.build_settings(4,30,method,j.POOL12_PROFILE,[])
                self.assertEqual([pool for _,pool in calls],[14,12])  # lawful V5 baseline + native returnedP12
                calls.clear();j.build_options(4,30,j.POOL12_PROFILE,method,asdict(mo))
                self.assertEqual(calls,[(j.NativePool12N4Options,12)])
            finally:sys.setprofile(before)
        self.assertIs(sys.getprofile(),before)
        self.assertEqual(j.NativePool12N4Options.__mro__,(j.NativePool12N4Options,*b.OriginalC07Options.__mro__))
        self.assertNotIn(j._JointC03Insertion,j.NativePool12N4Options.__mro__)
        self.assertNotIn(b._C03RootBudgetValidation,j.NativePool12N4Options.__mro__)
        self.assertEqual(tuple(fields(j.NativePool12N4Options)),tuple(fields(b.OriginalC07Options)))

    def test_pool12_exact_tuple_scope_type_and_historical_pickle_class_rejected(self):
        p=j.POOL12_PROFILE
        for method in ("full_v6","usde_only_v6"):
            values=j.expected_options(4,method,p)
            for pool in (True,12.0,"12",9,11,13,16,20):
                with self.subTest(pool=pool),self.assertRaises(ValueError):
                    j.build_options(4,30,p,method,{**values,"mac_pool_slots":pool})
            for key,value in (("mac_auv_slots",3),("mac_max_leases",20),("mac_child_max_active",7),
                ("mac_child_slots_per_sensor",1),("mac_coop_lease_frames",29),
                ("mac_frame_stride",1),("mac_child_lease_frames",2),("visit_packet_budget",6.0)):
                with self.subTest(key=key),self.assertRaises(ValueError):j.build_options(4,30,p,method,{**values,key:value})
            for n,s in ((4.0,30),(True,30),(4,30.0),(4,29),(3,30)):
                with self.assertRaises(ValueError):j.build_options(n,s,p,method,values)
            with self.assertRaises(ValueError):j.NativePool12N4Options(**values)
            token=j._SCOPE.set(dict(profile=p,n_auv=4,n_sensors=30,method=method,method_options=deepcopy(values)))
            try:
                with self.assertRaises(ValueError):j.JointN4Options(**values)
            finally:j._SCOPE.reset(token)
            for old in (j.HETEROGENEOUS_PROFILE,j.HELLO48_PROFILE,b.ROOT_BUDGET_PROFILE,"unregistered"):
                with self.assertRaises(ValueError):j._restore_options(old,values)
            for old in (j.HETEROGENEOUS_PROFILE,j.HELLO48_PROFILE):
                with self.assertRaises(ValueError):j._restore_options(p,j.expected_options(4,method,old))
            value=j.build_options(4,30,p,method,values);restored=pickle.loads(pickle.dumps(value))
            self.assertIs(type(restored),j.NativePool12N4Options);self.assertEqual(restored._joint_profile,p)
            self.assertTrue(j.exact(asdict(restored),values))
            original=b.OriginalC07Options(**values)  # valid generic native config is NOT this registered class/token
            cfg,_,ro,_=e.build_settings(4,30,method,p,[])
            with self.assertRaises(ValueError):e.validate_joint_settings(cfg,method,original,ro,p)
        self.assertIsNone(j._SCOPE.get());self.assertIsNone(b._CONSTRUCTION_SCOPE.get())

    def test_pool12_metadata_Policy_reconstruction_runtime_and_cancel_same_object(self):
        for method in ("full","usde_only"):
            p=j.POOL12_PROFILE;c=context(4,method,p);value=saved(c)
            self.assertIs(w.validate_checkpoint_metadata(value),value)
            with w.bindings(c) as executor:
                mo=executor.MethodOptions(**c["declaration"]["method_options"])
                self.assertIs(type(mo),j.NativePool12N4Options)
                self.assertTrue(j.exact(asdict(mo),c["declaration"]["method_options"]))
            env=fixture(4,method,p)
            try:
                policy=object.__new__(w._ORIGINAL_POLICY);policy.cfg=deepcopy(env.cfg);policy.method=env.method
                policy.schema=environment_schema(env);policy.checkpoint=dict(method_options=asdict(env.method_options),routing_options=asdict(env.routing_options))
                w._ORIGINAL_POLICY_VALIDATE(policy,env)
                object.__setattr__(env.method_options,"mac_pool_slots",20)
                with self.assertRaises(ValueError):env.validate_selector_identity()
                object.__setattr__(env.method_options,"mac_pool_slots",12);env.validate_selector_identity()
            finally:env.close()
            for key,wrong in (("mac_pool_slots",12.0),("mac_pool_slots",20),("visit_packet_budget",6.0)):
                damaged=deepcopy(c);damaged["declaration"]["method_options"][key]=wrong
                damaged["declaration_sha256"]=w.digest_json(damaged["declaration"])
                with self.assertRaises(ValueError):w._authenticate_joint_context(damaged)
            for error in (ValueError("native constructor"),KeyboardInterrupt("native cancel"),SystemExit("native exit")):
                with patch.object(j,"NativePool12N4Options",side_effect=error):
                    try:j.build_options(4,30,p,e.canonical_method(method),j.expected_options(4,e.canonical_method(method),p))
                    except BaseException as caught:self.assertIs(caught,error)
                    else:self.fail("must preserve same constructor error")
                self.assertIsNone(j._SCOPE.get())

    def test_pool12_scope_ports_reverse_entire_old_V15_helper_functions_AST(self):
        code=Path(e.__file__).resolve().parents[1]
        old=historical_source("iterative_candidates_20261014/n4_hello48_v15_preparation/code/exp7_c07_scaling_20261012/joint_clocks.py")
        self.assertEqual(j.digest(old),"e807585f171396ad12a800dd4a7dad705829a07a8d3c143f26aebcb0104d86e8")
        dump=lambda node:ast.dump(node,include_attributes=False)
        before={x.name:x for x in ast.parse(old.read_text(encoding="utf-8")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
        after={x.name:deepcopy(x) for x in ast.parse(Path(j.__file__).read_text(encoding="utf-8")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
        after=restore_v26_scope_functions(after)
        def remove_statement(fn,source):
            signature=dump(ast.parse(source).body[0]);sites=[i for i,node in enumerate(fn.body) if dump(node)==signature]
            self.assertEqual(len(sites),1);fn.body.pop(sites[0])
        remove_statement(after["fast_runtime_check"],"_check_native_pool12_shape()")
        remove_statement(after["expected_options"],"if n == 4 and profile == POOL12_PROFILE:\n    value[\"mac_pool_slots\"] = 12")
        remove_statement(after["_scope_check"],'require(scope["profile"] != POOL12_PROFILE, "Native pool12 must not use the historical pool20 validator insertion")')
        group=after["registered_group"];sites=[node for node in ast.walk(group) if isinstance(node,ast.Tuple) and any(isinstance(x,ast.Name) and x.id=="POOL12_PROFILE" for x in node.elts)]
        self.assertEqual(len(sites),1);sites[0].elts=[x for x in sites[0].elts if not isinstance(x,ast.Name) or x.id!="POOL12_PROFILE"]
        signature=dump(ast.parse("profile==POOL12_PROFILE",mode="eval").body)
        class RestoreSelector(ast.NodeTransformer):
            count=0
            def visit_IfExp(self,node):
                if dump(node.test)==signature:
                    self.count+=1;return deepcopy(node.orelse)
                return self.generic_visit(node)
        restore=RestoreSelector();after["selector_proof"]=restore.visit(after["selector_proof"]);self.assertEqual(restore.count,1)
        fn=after["build_options"];tries=[node for node in fn.body if isinstance(node,ast.Try)];self.assertEqual(len(tries),1)
        body=tries[0].body;assignment=dump(ast.parse("constructor=NativePool12N4Options if profile==POOL12_PROFILE else JointN4Options").body[0])
        sites=[i for i,node in enumerate(body) if dump(node)==assignment];self.assertEqual(len(sites),1);body.pop(sites[0])
        calls=[node for node in ast.walk(fn) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=="constructor"]
        self.assertEqual(len(calls),1);calls[0].func=ast.Name(id="JointN4Options",ctx=ast.Load())
        for name,node in before.items():self.assertEqual(dump(node),dump(after[name]),name)

    def test_independent_options_tokens_domain_and_pickle_profile(self):
        for p in j.PROFILES:
            for m in ("full_v6","usde_only_v6"):
                values=j.expected_options(4,m,p)
                with self.assertRaises(ValueError):j.JointN4Options(**values)
                with self.assertRaises(ValueError):b._RegisteredN4RootBudgetOptions(**values)
                value=j.build_options(4,30,p,m,values);restored=pickle.loads(pickle.dumps(value))
                self.assertIs(type(restored),j.NativeRoot16Child4N4Options if p==j.JOINT_PHY_LOC_ROOT16_PROFILE else j.NativePool12N4Options if p in (j.POOL12_PROFILE,j.N4_COORD8_PROFILE,j.N34_STATE8_11_PROFILE) else j.JointN4Options);self.assertEqual(restored._joint_profile,p)
                self.assertTrue(j.exact(asdict(value),asdict(restored)))
                for key,v in (("mac_pool_slots",20.),("mac_enabled",1),("mac_child_lead_s",84.)):
                    with self.assertRaises(ValueError):j.build_options(4,30,p,m,{**values,key:v})
                with self.assertRaises(ValueError):j.build_options(4,30,b.ROOT_BUDGET_PROFILE,m,values)
        self.assertIsNone(j._SCOPE.get());self.assertIsNone(b._CONSTRUCTION_SCOPE.get())

    def test_options_cancel_same_object_restores_scope(self):
        p=j.PROFILES[0];values=j.expected_options(4,"full_v6",p)
        for error in (ValueError("ordinary"),KeyboardInterrupt("cancel"),SystemExit("exit")):
            with patch.object(j,"JointN4Options",side_effect=error):
                try:j.build_options(4,30,p,"full_v6",values)
                except BaseException as caught:self.assertIs(caught,error)
                else:self.fail("must preserve error")
            self.assertIsNone(j._SCOPE.get())

    def test_whole_saved_context_source_cfg_options_and_typed_alias_guards(self):
        for p in j.PROFILES:
            c=context(profile=p);value=saved(c);self.assertIs(w.validate_checkpoint_metadata(value),value)
            for delta in (lambda x:x["environment_config"].update(hello_period=20.),
                lambda x:x["method_options"].update(mac_child_lead_s=84.),
                lambda x:x["scale_context"].update(profile=b.ROOT_BUDGET_PROFILE),
                lambda x:x["source_hashes"].update(extra="0"*64)):
                wrong=deepcopy(value);delta(wrong)
                with self.assertRaises(ValueError):w.validate_checkpoint_metadata(wrong)
            wrong=deepcopy(c);wrong["declaration"]["config"]["tdma_sensors_per_group"]=6.
            wrong["declaration_sha256"]=w.digest_json(wrong["declaration"])
            with self.assertRaises(ValueError):w._authenticate_joint_context(wrong)

    def test_original_policy_validator_actual_function_accepts_matching_new_declared_facts(self):
        for p in j.PROFILES:
            for n,m in ((2,"full"),(3,"full"),(4,"full"),(3,"usde_only"),(4,"usde_only")):
                env=fixture(n,m,p)
                try:
                    policy=object.__new__(w._ORIGINAL_POLICY);policy.cfg=deepcopy(env.cfg);policy.method=env.method
                    policy.schema=environment_schema(env);policy.checkpoint=dict(method_options=asdict(env.method_options),
                        routing_options=asdict(env.routing_options))
                    w._ORIGINAL_POLICY_VALIDATE(policy,env)  # Actual native function, no __init__/actors.
                    env.cfg.hello_period+=1.
                    with self.assertRaisesRegex(ValueError,"V6 C07 environment config/schema mismatch"):w._ORIGINAL_POLICY_VALIDATE(policy,env)
                finally:env.close()
    def test_constructor_whole_cfg_mo_ro_class_profile_tokens_checked_before_native(self):
        p=j.PROFILES[1];cfg,mo,ro,_=e.build_settings(4,30,"full",p,[])
        e.validate_joint_settings(cfg,"full",mo,ro,p)
        for key,value in (("hello_period",20.),("tdma_sensors_per_group",6.),("exploration_noise",.05)):
            wrong=deepcopy(cfg);setattr(wrong,key,value)
            with self.assertRaises(ValueError):e.validate_joint_settings(wrong,"full",mo,ro,p)
        wrong=deepcopy(mo);object.__setattr__(wrong,"_joint_profile",j.PROFILES[0])
        with self.assertRaises(ValueError):e.validate_joint_settings(cfg,"full",wrong,ro,p)
        wrong=object.__new__(b.OriginalC07Options)
        for key,value in asdict(mo).items():object.__setattr__(wrong,key,value)
        with self.assertRaises(ValueError):e.validate_joint_settings(cfg,"full",wrong,ro,p)


class Coord8DeclarationTests(NoPhysics):
    def test_v26_all_six_whole_records_only_N4_float_coord_delta_and_exact_rollback(self):
        for n,method,faults in product((2,3,4),("full","usde_only"),(None,[])):
            before=e.build_settings(n,30,method,j.POOL12_PROFILE,faults)
            after=e.build_settings(n,30,method,j.N4_COORD8_PROFILE,faults)
            a,z=before[0].to_dict(),after[0].to_dict()
            self.assertEqual(a.keys(),z.keys())
            delta={k:{"old":a[k],"new":v} for k,v in z.items() if not j.exact(a[k],v)}
            wanted={} if n!=4 else {"coordination_service_interval":{"old":4.0,"new":8.0}}
            self.assertTrue(j.exact(delta,wanted))
            self.assertTrue(j.exact(asdict(before[1]),asdict(after[1])))
            self.assertTrue(j.exact(asdict(before[2]),asdict(after[2])))
            self.assertTrue(j.exact(before[3]["clock"],after[3]["clock"]))
            self.assertTrue(j.exact(before[3]["joint_clock_adaptation"]["actual_slot_owners"],
                after[3]["joint_clock_adaptation"]["actual_slot_owners"]))
            a=w.declaration(n,30,method,j.POOL12_PROFILE,faults)
            z=w.declaration(n,30,method,j.N4_COORD8_PROFILE,faults)
            if n==4:z["config"]["coordination_service_interval"]=a["config"]["coordination_service_interval"]
            self.assertTrue(j.exact({k:v for k,v in a.items() if k not in ("profile","scale_diagnostics")},
                {k:v for k,v in z.items() if k not in ("profile","scale_diagnostics")}))
            adaptation=after[3]["coordination_priority_adaptation"]
            self.assertTrue(j.exact(adaptation["declared_config_diff_from_v16"],wanted))
            self.assertTrue(j.exact(adaptation["declared_option_diff_from_v16"],{}))
            self.assertFalse(adaptation["physical_capacity_added"]);self.assertFalse(adaptation["constructor_selects_or_trains"])
            if n==4:
                self.assertIs(type(after[0].coordination_service_interval),float)
                self.assertEqual((after[0].coordination_service_interval,after[0].state_period,
                    after[0].tdma_sensors_per_group,after[3]["clock"]["frame_s"],after[0].hello_period,
                    after[0].service_ack_timeout,after[0].grant_ttl,after[1].mac_child_lead_s),
                    (8.0,5.0,4,42.0,40.0,134.0,134.0,72.0))
                self.assertEqual((after[0].slow_period,after[0].state_ttl,after[2].state_stale_s),(5,90.0,25.0))
                self.assertEqual(max(after[0].state_period,2*(1+n+30)*after[0].slot_duration),42.0)
                self.assertEqual(tuple(asdict(after[1])[key] for key in b.BUDGET_FIELDS),j.POOL12_TUPLE)
            else:
                self.assertTrue(j.exact(before[0].to_dict(),after[0].to_dict()))
                if n==2:self.assertNotIn("coordination_service_interval",after[0].to_dict())
                else:self.assertTrue(j.exact(after[0].coordination_service_interval,16./3))
        for n,faults in product((2,3,4),(None,[])):
            full=e.build_settings(n,30,"full",j.N4_COORD8_PROFILE,faults)[0]
            usde=e.build_settings(n,30,"usde_only",j.N4_COORD8_PROFILE,faults)[0]
            self.assertTrue(j.exact(full.to_dict(),usde.to_dict()))

    def test_v26_native_C03_chain_no_pool20_pickle_MO_is_not_CFG_authority(self):
        native_code=b.OriginalC03Options.__dict__["__post_init__"].__code__
        calls=[];previous=sys.getprofile()
        def profile(frame,event,arg):
            if event!="call":return
            if frame.f_code.co_name=="__post_init__" and j.code_signature(frame.f_code)==j._PRIMITIVE_CODE:
                raise AssertionError("V26 may not invoke the historical upper20 validator")
            if frame.f_code is native_code:calls.append(frame.f_locals["self"].mac_pool_slots)
        for method in ("full_v6","usde_only_v6"):
            calls.clear();sys.setprofile(profile)
            try:
                cfg,mo,ro,_=e.build_settings(4,30,method,j.N4_COORD8_PROFILE,[])
                self.assertTrue(calls);self.assertTrue(all(type(x) is int and x in (12,14) for x in calls))
                calls.clear();j.build_options(4,30,j.N4_COORD8_PROFILE,method,asdict(mo));self.assertEqual(calls,[12])
            finally:sys.setprofile(previous)
            restored=pickle.loads(pickle.dumps(mo))
            self.assertIs(type(restored),j.NativePool12N4Options);self.assertEqual(restored._joint_profile,j.N4_COORD8_PROFILE)
            self.assertTrue(j.exact(asdict(restored),j.expected_options(4,method,j.POOL12_PROFILE)))
            old_cfg,old_mo,old_ro,_=e.build_settings(4,30,method,j.POOL12_PROFILE,[])
            with self.assertRaises(ValueError):e.validate_joint_settings(cfg,method,old_mo,ro,j.N4_COORD8_PROFILE)
            with self.assertRaises(ValueError):e.validate_joint_settings(old_cfg,method,restored,old_ro,j.N4_COORD8_PROFILE)
            proof=j.native_pool12_validation_proof()
            self.assertTrue(proof["original_C03_validator_used"]);self.assertFalse(proof["pool20_validator_insertion_used"])
            self.assertEqual(j.NativePool12N4Options.__mro__,(j.NativePool12N4Options,*b.OriginalC07Options.__mro__))
            for key,bad in (("mac_pool_slots",12.0),("mac_enabled",1),("mac_child_lead_s",72),
                ("mac_child_lead_s",16.8),("visit_packet_budget",6.0)):
                with self.subTest(key=key,bad=bad),self.assertRaises(ValueError):
                    j._restore_options(j.N4_COORD8_PROFILE,{**asdict(mo),key:bad})
        self.assertIs(sys.getprofile(),previous);self.assertIsNone(j._SCOPE.get())

    def test_v26_explicit_default_roundtrip_train_load_policy_rebuild_deepcopy_and_real_queue_replace(self):
        from v4_task_20260917_r2.routing import QueueOptions
        for method in ("full","usde_only"):
            c=context(4,method,j.N4_COORD8_PROFILE);raw=c["declaration"]["config"]
            cfg=e.ScaleConfig.from_dict(deepcopy(raw))
            self.assertIs(type(cfg.to_dict()["coordination_service_interval"]),float)
            self.assertTrue(j.exact(cfg.to_dict(),raw))
            self.assertNotIn("_explicit_coordination_service_interval",asdict(cfg))
            for value in (e.ScaleConfig.from_dict(cfg.to_dict()),deepcopy(cfg),pickle.loads(pickle.dumps(cfg))):
                self.assertTrue(j.exact(value.to_dict(),raw))
                self.assertTrue(j.exact(value.coordination_service_interval,8.0))
            # Metadata-only reproduction of the ACTUAL Config route: native train
            # Config.load -> cls.from_dict; native Policy Config.from_dict. No
            # native train/Policy constructor, model, ENV or network is invoked.
            with tempfile.TemporaryDirectory() as folder:
                path=Path(folder)/"manufactured_config.json";path.write_text(json.dumps(raw),encoding="utf-8")
                with w.bindings(c) as executor:
                    self.assertIs(executor.Config,e.ScaleConfig)
                    loaded=executor.Config.load(path)
                    rebuilt=executor.Config.from_dict(deepcopy(saved(c)["environment_config"]))
                    self.assertTrue(j.exact(loaded.to_dict(),raw));self.assertTrue(j.exact(rebuilt.to_dict(),raw))
                    self.assertEqual(loaded.fingerprint,rebuilt.fingerprint)
            eval_cfg=deepcopy(cfg);eval_cfg.faults=[];eval_cfg.validate()
            self.assertTrue(j.exact({k:v for k,v in eval_cfg.to_dict().items() if k!="faults"},
                {k:v for k,v in raw.items() if k!="faults"}))
            q4=e.replace(QueueOptions(),coord_service_s=4.0);q8=e.replace(q4,coord_service_s=8.0)
            self.assertTrue(j.exact(asdict(q8),{**asdict(q4),"coord_service_s":8.0}))
            self.assertTrue(j.exact(cfg.to_dict(),raw))
            # Explicit8int must remain an int, NEVER normalized/cast or elided.
            bad=e.ScaleConfig.from_dict({**raw,"coordination_service_interval":8})
            self.assertIs(type(bad.to_dict()["coordination_service_interval"]),int)
            mo=e.build_settings(4,30,method,j.N4_COORD8_PROFILE,[])[1]
            ro=e.build_settings(4,30,method,j.N4_COORD8_PROFILE,[])[2]
            with self.assertRaises(ValueError):e.validate_joint_settings(bad,method,mo,ro,j.N4_COORD8_PROFILE)
        for n,method,p in product((2,3,4),("full","usde_only"),e.PROFILES[:-1]):
            cfg=e.build_settings(n,30,method,p,[])[0];raw=cfg.to_dict()
            self.assertTrue(j.exact(e.ScaleConfig.from_dict(raw).to_dict(),raw),(n,method,p))
            if n==2:self.assertIs(type(e.ScaleConfig.from_dict(raw)),e.OriginalConfig)

    def test_v26_resealed_CFG_RO_MO_aliases_scope_and_cached_runtime_rejected(self):
        p=j.N4_COORD8_PROFILE
        for n,method in product((2,3,4),("full","usde_only")):
            c=context(n,method,p);record=saved(c);self.assertIs(w.validate_checkpoint_metadata(record),record)
            with w.bindings(c) as executor:
                mo=executor.MethodOptions(**c["declaration"]["method_options"])
                self.assertIs(type(mo),j.NativePool12N4Options if n==4 else b.OriginalC07Options)
            if n!=4:
                wrong=deepcopy(c);wrong["declaration"]["config"]["coordination_service_interval"]=8.0
                wrong["declaration_sha256"]=w.digest_json(wrong["declaration"])
                with self.assertRaises(ValueError):w._authenticate_joint_context(wrong)
                continue
            changes=(("config","coordination_service_interval",8),("config","coordination_service_interval",True),
                ("config","coordination_service_interval","8.0"),("config","coordination_service_interval",4.0),
                ("config","coordination_service_interval",12.0),("config","coordination_service_interval",8.1),
                ("config","state_period",20.0),("config","tdma_sensors_per_group",6),
                ("config","service_ack_timeout",126.0),("config","grant_ttl",126.0),("config","hello_period",48.0),
                ("config","state_ttl",120.0),("config","gamma",.999),("routing_options","state_stale_s",90.0),
                ("method_options","mac_child_lead_s",16.8),("method_options","mac_pool_slots",20))
            for section,key,bad in changes:
                wrong=deepcopy(c);wrong["declaration"][section][key]=bad
                wrong["declaration_sha256"]=w.digest_json(wrong["declaration"])
                with self.subTest(section=section,key=key,bad=bad),self.assertRaises(ValueError):w._authenticate_joint_context(wrong)
            for bad in (float("nan"),float("inf")):
                wrong=deepcopy(c);wrong["declaration"]["config"]["coordination_service_interval"]=bad
                with self.assertRaises(ValueError):w.digest_json(wrong["declaration"])
            env=fixture(n,method,p)
            try:
                for bad in (8,True,4.0,12.0,8.1,float("nan")):
                    env.cfg.coordination_service_interval=bad
                    with self.assertRaisesRegex(ValueError,"cached full typed runtime"):env.validate_selector_identity()
                env.cfg.coordination_service_interval=8.0;env.validate_selector_identity()
                env.cfg._explicit_coordination_service_interval=False
                with self.assertRaisesRegex(ValueError,"cached full typed runtime"):env.validate_selector_identity()
                env.cfg._explicit_coordination_service_interval=True;env.validate_selector_identity()
                env.cfg.faults=deepcopy(e._reference(e.canonical_method(method))[0]["faults"])
                env._full_selector_identity(recache=True)
            finally:
                env.cfg.coordination_service_interval=8.0;env.cfg._explicit_coordination_service_interval=True;env.close()

    def test_v26_complete_factory_and_helper_AST_reverse_to_pinned_K16(self):
        old=historical_source("iterative_candidates_20261014/n4_root_pool12_v16_frozen/code/exp7_c07_scaling_20261012",files=("environment.py","joint_clocks.py"))
        self.assertEqual(j.digest(old/"environment.py"),"8d307b6f58ce94194dbe93e58905a9dca3e2a4f93c5b7091590cb3a611c99e3c")
        self.assertEqual(j.digest(old/"joint_clocks.py"),"2fd4408e5f3caeb98d80060301c43764b491a28cdb069ab2928c66cd2c82ea3a")
        dump=lambda node:ast.dump(node,include_attributes=False)
        before={x.name:x for x in ast.parse((old/"environment.py").read_text(encoding="utf-8-sig")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
        after={x.name:deepcopy(x) for x in ast.parse(Path(e.__file__).read_text(encoding="utf-8-sig")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
        after=restore_v28_environment_functions(after)
        after["build_settings"]=restore_v27_factory(after["build_settings"])
        branch=after["build_settings"].body.pop(0)
        self.assertEqual(dump(branch.test),dump(ast.parse("profile==joint_clocks.N4_COORD8_PROFILE",mode="eval").body))
        # Exactly two metadata serialization-method edits, not a hidden scientific
        # Config field, constructor override or whole-profile relaxation.
        methods={x.name:x for x in after["ScaleConfig"].body if isinstance(x,ast.FunctionDef)}
        old_methods={x.name:x for x in before["ScaleConfig"].body if isinstance(x,ast.FunctionDef)}
        signature=dump(ast.parse('value["coordination_service_interval"]==8. and not getattr(self,"_explicit_coordination_service_interval",False)',mode="eval").body)
        sites=[node for node in ast.walk(methods["to_dict"]) if isinstance(node,ast.If) and dump(node.test)==signature]
        self.assertEqual(len(sites),1);sites[0].test=ast.parse('value["coordination_service_interval"]==8.',mode="eval").body
        expected=ast.parse('value=super().from_dict(data)\nif "coordination_service_interval" in data:\n    value._explicit_coordination_service_interval=True\nreturn value').body
        self.assertEqual([dump(x) for x in methods["from_dict"].body[-3:]],[dump(x) for x in expected])
        methods["from_dict"].body[-3:]=[deepcopy(old_methods["from_dict"].body[-1])]
        self.assertEqual(before.keys(),after.keys())
        for name,node in before.items():self.assertEqual(dump(node),dump(after[name]),name)
        ns=dict(vars(e));exec(compile(ast.fix_missing_locations(ast.Module(body=[deepcopy(before["build_settings"])],type_ignores=[])),
            "<PIN complete K16 builder only>","exec",dont_inherit=True),ns)
        for p,n,method,faults in product(tuple(p for p in e.PROFILES if p not in (j.N4_COORD8_PROFILE,j.N34_STATE8_11_PROFILE,j.JOINT_PHY_LOC_ROOT16_PROFILE)),(2,3,4),("full","usde_only"),(None,[])):
            a=ns["build_settings"](n,30,method,p,faults);z=e.build_settings(n,30,method,p,faults)
            self.assertTrue(j.exact((a[0].to_dict(),asdict(a[1]),asdict(a[2]),a[3]),(z[0].to_dict(),asdict(z[1]),asdict(z[2]),z[3])),(p,n,method))
        before={x.name:x for x in ast.parse((old/"joint_clocks.py").read_text(encoding="utf-8")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
        after={x.name:deepcopy(x) for x in ast.parse(Path(j.__file__).read_text(encoding="utf-8")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
        after=restore_v26_scope_functions(after)
        self.assertEqual(before.keys(),after.keys())
        for name,node in before.items():self.assertEqual(dump(node),dump(after[name]),name)


class State8And11DeclarationTests(NoPhysics):
    def test_v27_exact_typed_N_mapping_whole_K26_reverse_and_sameN_fairness(self):
        p=j.N34_STATE8_11_PROFILE
        self.assertEqual(dict(j.N34_STATE_PERIODS),{2:5.0,3:8.0,4:11.0})
        self.assertTrue(all(type(n) is int and type(value) is float for n,value in j.N34_STATE_PERIODS.items()))
        for n,method,faults in product((2,3,4),("full","usde_only"),(None,[])):
            before=e.build_settings(n,30,method,j.N4_COORD8_PROFILE,faults)
            after=e.build_settings(n,30,method,p,faults)
            a,z=before[0].to_dict(),after[0].to_dict()
            self.assertEqual(a.keys(),z.keys())
            delta={k:{"old":a[k],"new":v} for k,v in z.items() if not j.exact(a[k],v)}
            wanted={} if n==2 else {"state_period":{"old":5.0,"new":{3:8.0,4:11.0}[n]}}
            self.assertTrue(j.exact(delta,wanted),(n,method))
            self.assertIs(type(z["state_period"]),float)
            restored=deepcopy(z)
            if n>2:restored["state_period"]=5.0
            self.assertTrue(j.exact(restored,a))
            self.assertTrue(j.exact(asdict(before[1]),asdict(after[1])))
            self.assertTrue(j.exact(asdict(before[2]),asdict(after[2])))
            self.assertTrue(j.exact(before[3]["clock"],after[3]["clock"]))
            da=w.declaration(n,30,method,j.N4_COORD8_PROFILE,faults)
            dz=w.declaration(n,30,method,p,faults)
            if n>2:dz["config"]["state_period"]=5.0
            self.assertTrue(j.exact({k:v for k,v in da.items() if k not in ("profile","scale_diagnostics")},
                {k:v for k,v in dz.items() if k not in ("profile","scale_diagnostics")}))
            adaptation=after[3]["state_period_adaptation"]
            self.assertTrue(j.exact(adaptation["declared_config_diff_from_K26"],wanted))
            self.assertTrue(j.exact(adaptation["declared_option_diff_from_K26"],{}))
            self.assertFalse(adaptation["physical_capacity_added"])
            self.assertFalse(adaptation["constructor_selects_or_trains"])
            self.assertEqual((after[0].slow_period,after[0].state_ttl,after[2].state_stale_s),(5,90.0,25.0))
            if n==2:self.assertIs(type(after[0]),e.OriginalConfig)
            else:
                self.assertTrue(j.exact(after[0].coordination_service_interval,16./3 if n==3 else 8.0))
                self.assertEqual((after[0].tdma_sensors_per_group,after[3]["clock"]["frame_s"],
                    after[0].service_ack_timeout,after[0].grant_ttl,after[1].mac_child_lead_s),
                    (6,30.0,106.0,106.0,48.0) if n==3 else (4,42.0,134.0,134.0,72.0))
        for n,faults in product((2,3,4),(None,[])):
            f=e.build_settings(n,30,"full",p,faults)
            u=e.build_settings(n,30,"usde_only",p,faults)
            self.assertTrue(j.exact(f[0].to_dict(),u[0].to_dict()))
            self.assertTrue(j.exact(asdict(f[2]),asdict(u[2])))
            a,z=w.declaration(n,30,"full",p,faults),w.declaration(n,30,"usde_only",p,faults)
            for key in ("learning","training_protocol","reward","ending"):self.assertTrue(j.exact(a[key],z[key]))
        for n,sensors in ((True,30),(3.0,30),(4.0,30),(3,30.0),(3,True),(5,30)):
            with self.subTest(n=n,sensors=sensors),self.assertRaises(ValueError):e.build_settings(n,sensors,"full",p,[])

    def test_v27_declared_clock_arithmetic_only_not_a_network_trial(self):
        for n,period,state,coord,loc in ((2,5.0,5.0,5.0,40),(3,8.0,8.0,10.0,41),(4,11.0,11.0,15.0,42)):
            cfg,_,_,diagnostics=e.build_settings(n,30,"full",j.N34_STATE8_11_PROFILE,[])
            self.assertTrue(j.exact(cfg.state_period,period))
            a=diagnostics["state_period_adaptation"]
            self.assertTrue(j.exact((a["ordinary_STATE_interval_s"],a["ordinary_COORD_interval_s"]),(state,coord)))
            self.assertEqual(math.ceil(max(period,2*(1+n+30)*cfg.slot_duration)),loc)
            self.assertTrue(a["ordinary_intervals_are_nominal_no_dirty_not_delivery_guarantees"])
            self.assertTrue(a["dirty_event_rules_unchanged"]);self.assertTrue(a["localization_polling_cadence_unchanged"])

    def test_v27_Config_roundtrip_deepcopy_pickle_train_load_and_Policy_rebuild_route(self):
        for n,method in product((2,3,4),("full","usde_only")):
            c=context(n,method,j.N34_STATE8_11_PROFILE);raw=c["declaration"]["config"]
            cfg=e.ScaleConfig.from_dict(deepcopy(raw))
            values=(e.ScaleConfig.from_dict(cfg.to_dict()),deepcopy(cfg),pickle.loads(pickle.dumps(cfg)))
            for value in values:
                self.assertTrue(j.exact(value.to_dict(),raw));self.assertIs(type(value.state_period),float)
                if n==4:
                    self.assertIs(type(value.to_dict()["coordination_service_interval"]),float)
                    self.assertTrue(j.exact(value.to_dict()["coordination_service_interval"],8.0))
            record=saved(c);self.assertIs(w.validate_checkpoint_metadata(record),record)
            with tempfile.TemporaryDirectory() as folder:
                path=Path(folder)/"manufactured_config.json";path.write_text(json.dumps(raw),encoding="utf-8")
                with w.bindings(c) as executor:
                    # Actual native train Config.load / Policy Config.from_dict
                    # reconstruction routes, without constructing a model/ENV.
                    self.assertIs(executor.Config,e.ScaleConfig)
                    loaded=executor.Config.load(path)
                    rebuilt=executor.Config.from_dict(deepcopy(record["environment_config"]))
                    for value in (loaded,rebuilt):self.assertTrue(j.exact(value.to_dict(),raw))
                    mo=executor.MethodOptions(**c["declaration"]["method_options"])
                    self.assertTrue(j.exact(asdict(mo),c["declaration"]["method_options"]))
                    if n==4:
                        self.assertIs(type(mo),j.NativePool12N4Options)
                        self.assertEqual(pickle.loads(pickle.dumps(mo))._joint_profile,j.N34_STATE8_11_PROFILE)
            eval_cfg=deepcopy(cfg);eval_cfg.faults=[];eval_cfg.validate()
            self.assertTrue(j.exact({k:v for k,v in eval_cfg.to_dict().items() if k!="faults"},
                {k:v for k,v in raw.items() if k!="faults"}))

    def test_v27_resealed_state_aliases_wrong_N_nearby_and_cached_runtime_rejected(self):
        p=j.N34_STATE8_11_PROFILE
        for n,method in product((2,3,4),("full","usde_only")):
            c=context(n,method,p);good={2:5.0,3:8.0,4:11.0}[n]
            bad_values=(int(good),True,False,str(good),good+.001,0.0,-1.0,
                *(v for v in (5.0,8.0,11.0) if v!=good))
            for bad in bad_values:
                damaged=deepcopy(c);damaged["declaration"]["config"]["state_period"]=bad
                damaged["declaration_sha256"]=w.digest_json(damaged["declaration"])
                with self.subTest(n=n,method=method,bad=bad),self.assertRaises(ValueError):w._authenticate_joint_context(damaged)
            for bad in (float("nan"),float("inf"),float("-inf")):
                damaged=deepcopy(c);damaged["declaration"]["config"]["state_period"]=bad
                with self.assertRaises(ValueError):w.digest_json(damaged["declaration"])
            env=fixture(n,method,p)
            try:
                for bad in (*bad_values,float("nan"),float("inf")):
                    env.cfg.state_period=bad
                    with self.subTest(n=n,bad=bad),self.assertRaisesRegex(ValueError,"cached full typed runtime"):env.validate_selector_identity()
                env.cfg.state_period=good;env.validate_selector_identity()
            finally:env.cfg.state_period=good;env.close()
            if n>2:
                raw=deepcopy(c["declaration"]["config"]);raw["state_period"]=int(good)
                cfg=e.ScaleConfig.from_dict(raw);self.assertIs(type(cfg.to_dict()["state_period"]),int)
                _,mo,ro,_=e.build_settings(n,30,method,p,[])
                with self.assertRaises(ValueError):e.validate_joint_settings(cfg,method,mo,ro,p)

    def test_v27_old_K26_profile_reseal_or_unrelated_science_cannot_migrate(self):
        for n,method in product((3,4),("full","usde_only")):
            c=context(n,method,j.N4_COORD8_PROFILE)
            c["declaration"]["config"]["state_period"]={3:8.0,4:11.0}[n]
            c["declaration_sha256"]=w.digest_json(c["declaration"])
            with self.assertRaises(ValueError):w._authenticate_joint_context(c)
            c=context(n,method,j.N34_STATE8_11_PROFILE)
            for section,key,bad in (("config","coordination_service_interval",4.0),("config","gamma",.999),
                ("config","state_ttl",120.0),("config","slow_period",10),("routing_options","state_stale_s",90.0),
                ("method_options","mac_child_lead_s",16.8),("learning","hidden_dim",256)):
                damaged=deepcopy(c);damaged["declaration"][section][key]=bad
                damaged["declaration_sha256"]=w.digest_json(damaged["declaration"])
                with self.subTest(n=n,section=section,key=key),self.assertRaises(ValueError):w._authenticate_joint_context(damaged)

    def test_v27_whole_factory_and_helper_functions_reverse_to_pinned_K26(self):
        old=historical_source("iterative_candidates_20261017/n4_coord8_pool12_v26_frozen/code/exp7_c07_scaling_20261012",
            files=("environment.py","joint_clocks.py"))
        self.assertEqual(j.digest(old/"environment.py"),"2153c9c25bb61f2330eb24b7b8b4964bdc76b595d420233ad1ffd04290aff227")
        self.assertEqual(j.digest(old/"joint_clocks.py"),"2e82b4549b085ebb9b7650fb69de85da33b8a0357de450b35758907c8934fffe")
        dump=lambda node:ast.dump(node,include_attributes=False)
        for filename,module in (("environment.py",e),("joint_clocks.py",j)):
            before={x.name:x for x in ast.parse((old/filename).read_text(encoding="utf-8-sig")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
            after={x.name:deepcopy(x) for x in ast.parse(Path(module.__file__).read_text(encoding="utf-8-sig")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
            if filename=="environment.py":
                after=restore_v28_environment_functions(after)
                after["build_settings"]=restore_v27_factory(after["build_settings"])
            else:after=restore_v27_scope_functions(after)
            self.assertEqual(before.keys(),after.keys())
            for name,node in before.items():self.assertEqual(dump(node),dump(after[name]),(filename,name))


class JointPHYLocalizationRoot16Tests(NoPhysics):
    def test_v28_all_six_complete_scientific_records_exact_K27_inverse_and_sameN_fairness(self):
        p=j.JOINT_PHY_LOC_ROOT16_PROFILE
        for n,method,faults in product((2,3,4),("full","usde_only"),(None,[])):
            a=e.build_settings(n,30,method,j.N34_STATE8_11_PROFILE,faults)
            z=e.build_settings(n,30,method,p,faults)
            expected_cfg=deepcopy(a[0].to_dict());expected_mo=deepcopy(asdict(a[1]))
            if n==3:
                expected_cfg.update(slot_duration=0.5,hello_period=45.0,service_ack_timeout=88.0,
                    grant_ttl=100.0,localization_service_interval=8.0)
                expected_mo["mac_child_lead_s"]=2*(50*0.5)-12.0
            if n==4:
                expected_cfg.update(tdma_sensors_per_group=6,slot_duration=0.55,hello_period=80.0,
                    coordination_service_interval=4.0,localization_service_interval=6.0,
                    service_ack_timeout=116.0,grant_ttl=116.0)
                expected_mo.update(mac_pool_slots=16,mac_child_max_active=4,mac_child_lead_s=2*(55*0.55)-12.0)
            self.assertTrue(j.exact(z[0].to_dict(),expected_cfg));self.assertTrue(j.exact(asdict(z[1]),expected_mo))
            self.assertTrue(j.exact(asdict(z[2]),asdict(a[2])))
            before=w.declaration(n,30,method,j.N34_STATE8_11_PROFILE,faults)
            after=w.declaration(n,30,method,p,faults)
            self.assertEqual(before.keys(),after.keys())
            for key in ("learning","training_protocol","reward","ending","old_weights_allowed"):
                self.assertTrue(j.exact(before[key],after[key]))
            if n==2:
                self.assertIs(type(z[0]),e.OriginalConfig)
                self.assertNotIn("localization_service_interval",z[0].to_dict())
                self.assertEqual(json.dumps(before["config"],sort_keys=True),json.dumps(after["config"],sort_keys=True))
            other=e.build_settings(n,30,"usde_only" if method=="full" else "full",p,faults)
            self.assertTrue(j.exact(z[0].to_dict(),other[0].to_dict()))
            self.assertTrue(j.exact(e._expected_joint_queue_options(z[0]),e._expected_joint_queue_options(other[0])))
            mo=asdict(z[1]);mo["mac_enabled"]=False
            control=asdict(other[1]);control["mac_enabled"]=False;self.assertTrue(j.exact(mo,control))

    def test_v28_actual_native_calendar_arithmetic_complete_clock_and_physical_slot_bound(self):
        for n in (2,3,4):
            cfg,mo,_,d=e.build_settings(n,30,"full",j.JOINT_PHY_LOC_ROOT16_PROFILE,[])
            net=e.AcousticNetwork(cfg,cfg.seed);owners=list(net.slot_owners)
            expected=[]
            for offset in range(0,30,cfg.tdma_sensors_per_group):
                expected.extend(range(n+1));expected.extend(range(n+1+offset,min(n+31,n+1+offset+cfg.tdma_sensors_per_group)))
            self.assertEqual(owners,expected);self.assertEqual(len(owners),{2:60,3:50,4:55}[n])
            frame=len(owners)*cfg.slot_duration;turn=(n+2)*net.cooperative_slot_gap*(1+1/max(1,net.max_management_run))
            clock=dict(frame_s=frame,cooperative_turn_s=turn,service_renew_lead_s=frame+turn+cfg.slot_duration,
                service_retry_interval_s=2*frame+turn+cfg.slot_duration,protected_sensor_home_gap_s=2*frame,
                slot_count=len(owners),bit_rate=cfg.bit_rate,slot_s=cfg.slot_duration,max_packet_bits=net.max_packet_bits)
            self.assertTrue(j.exact(d["clock"],clock));self.assertTrue(j.exact(j.registered_frame(j.JOINT_PHY_LOC_ROOT16_PROFILE,n),frame))
            self.assertEqual(j.registered_group(j.JOINT_PHY_LOC_ROOT16_PROFILE,n),3 if n==2 else 6)
            self.assertTrue(j.exact(mo.mac_child_lead_s,14.4 if n==2 else 2*frame-12.0))
            if n>2:
                self.assertTrue(j.exact(cfg.service_ack_timeout,float(max(80,math.ceil(clock["service_retry_interval_s"])))))
                self.assertTrue(j.exact(cfg.grant_ttl,float(max(100,math.ceil(clock["service_retry_interval_s"])))))
            cfg.validate()
            if n==4:
                bad=deepcopy(cfg);bad.slot_duration=0.4
                with self.assertRaises(ValueError):bad.validate()
                self.assertFalse(j.exact(mo.mac_child_lead_s,48.5))

    def test_v28_native_ROOT16_C03_full_MRO_exact_tuple_class_and_pickle(self):
        p=j.JOINT_PHY_LOC_ROOT16_PROFILE;calls=[];old=sys.getprofile()
        original=b.OriginalC03Options.__dict__["__post_init__"].__code__
        def trace(frame,event,arg):
            if event=="call" and frame.f_code is original:calls.append(type(frame.f_locals["self"]))
            if event=="call" and frame.f_code.co_name=="__post_init__" and j.code_signature(frame.f_code)==j._PRIMITIVE_CODE:
                raise AssertionError("V28 MUST NOT use pool20 validation-domain insertion")
        for method in ("full_v6","usde_only_v6"):
            cfg,mo,ro,_=e.build_settings(4,30,method,p,[]);values=asdict(mo)
            calls.clear();sys.setprofile(trace)
            try:value=j.build_options(4,30,p,method,values)
            finally:sys.setprofile(old)
            self.assertEqual(calls,[j.NativeRoot16Child4N4Options])
            self.assertEqual(tuple(values[key] for key in b.BUDGET_FIELDS),(16,2,28,4,2,30,2,3))
            self.assertEqual(j.NativeRoot16Child4N4Options.__mro__,(j.NativeRoot16Child4N4Options,*b.OriginalC07Options.__mro__))
            self.assertNotIn(j._JointC03Insertion,j.NativeRoot16Child4N4Options.__mro__)
            self.assertNotIn(b._C03RootBudgetValidation,j.NativeRoot16Child4N4Options.__mro__)
            self.assertEqual(tuple(fields(value)),tuple(fields(b.OriginalC07Options)))
            proof=j.native_root16_child4_validation_proof()
            self.assertEqual(proof["registered_budget_tuple"],[16,2,28,4,2,30,2,3])
            self.assertEqual((proof["original_pool_validation_lower"],proof["original_pool_validation_upper"]),(2,16))
            self.assertTrue(proof["original_C03_validator_used"]);self.assertFalse(proof["pool20_validator_insertion_used"])
            restored=pickle.loads(pickle.dumps(value));self.assertIs(type(restored),j.NativeRoot16Child4N4Options)
            self.assertEqual(restored._joint_profile,p);self.assertTrue(j.exact(asdict(restored),values))
            for key,bad in (("mac_pool_slots",16.0),("mac_pool_slots",True),("mac_pool_slots",20),
                ("mac_auv_slots",3),("mac_max_leases",30),("mac_child_max_active",8),
                ("mac_child_slots_per_sensor",3),("mac_coop_lease_frames",15),("mac_frame_stride",1),("mac_child_lease_frames",2)):
                with self.subTest(key=key,bad=bad),self.assertRaises(ValueError):j.build_options(4,30,p,method,{**values,key:bad})
            with self.assertRaises(ValueError):j.NativeRoot16Child4N4Options(**values)
            with self.assertRaises(ValueError):e.validate_joint_settings(cfg,method,b.OriginalC07Options(**values),ro,p)
            with self.assertRaises(ValueError):j._restore_options(j.N34_STATE8_11_PROFILE,values)
        self.assertIs(sys.getprofile(),old);self.assertIsNone(j._SCOPE.get())

    def test_v28_options_cancel_restores_context_without_changing_error(self):
        p=j.JOINT_PHY_LOC_ROOT16_PROFILE;values=j.expected_options(4,"full_v6",p)
        for error in (ValueError("prepared constructor"),KeyboardInterrupt("prepared cancel"),SystemExit("prepared exit")):
            with patch.object(j,"NativeRoot16Child4N4Options",side_effect=error):
                try:j.build_options(4,30,p,"full_v6",values)
                except BaseException as caught:self.assertIs(caught,error)
                else:self.fail("exact error must propagate")
            self.assertIsNone(j._SCOPE.get())

    def test_v28_LOC_presence_JSON_deepcopy_pickle_and_original_N2_old_profile_omission(self):
        for p,n,method in product(j.PROFILES,(2,3,4),("full","usde_only")):
            cfg=e.build_settings(n,30,method,p,[])[0];raw=cfg.to_dict()
            for value in (e.ScaleConfig.from_dict(deepcopy(raw)),deepcopy(cfg),pickle.loads(pickle.dumps(cfg))):
                self.assertTrue(j.exact(value.to_dict(),raw))
            if p!=j.JOINT_PHY_LOC_ROOT16_PROFILE or n==2:self.assertNotIn("localization_service_interval",raw)
            if n==2:self.assertIs(type(cfg),e.OriginalConfig)
        cfg=e.build_settings(3,30,"full",j.N34_STATE8_11_PROFILE,[])[0]
        raw={**cfg.to_dict(),"localization_service_interval":12.0}
        explicit=e.ScaleConfig.from_dict(raw)
        for value in (explicit,e.ScaleConfig.from_dict(explicit.to_dict()),deepcopy(explicit),pickle.loads(pickle.dumps(explicit))):
            self.assertTrue(j.exact(value.to_dict(),raw));self.assertIs(type(value.to_dict()["localization_service_interval"]),float)
        self.assertNotIn("_explicit_localization_service_interval",asdict(explicit))
        for bad in (12,True,False,"12.0",0.0,-1.0,float("nan"),float("inf")):
            with self.subTest(bad=bad),self.assertRaises(ValueError):e.ScaleConfig.from_dict({**raw,"localization_service_interval":bad})
        with self.assertRaises(ValueError):e.ScaleConfig.from_dict({**raw,"unknown_CFG":1})

    def test_v28_whole_saved_context_train_Config_and_Policy_rebuild_routes(self):
        for n,method in product((2,3,4),("full","usde_only")):
            c=context(n,method,j.JOINT_PHY_LOC_ROOT16_PROFILE);record=saved(c)
            self.assertIs(w.validate_checkpoint_metadata(record),record)
            with tempfile.TemporaryDirectory() as folder:
                config_path=Path(folder)/"manufactured_loc_config.json"
                config_path.write_text(json.dumps(c["declaration"]["config"]),encoding="utf-8")
                with w.bindings(c) as executor:
                    loaded=executor.Config.load(config_path);rebuilt=executor.Config.from_dict(record["environment_config"])
                    self.assertTrue(j.exact(loaded.to_dict(),rebuilt.to_dict()))
                    self.assertEqual(loaded.fingerprint,record["config_fingerprint"])
                    mo=executor.MethodOptions(**record["method_options"])
                    self.assertIs(type(mo),j.NativeRoot16Child4N4Options if n==4 else b.OriginalC07Options)
            for section,key,bad in (("config","localization_service_interval",12.0),
                ("config","slot_duration",0.6),("config","gamma",.999),("routing_options","state_stale_s",90.0)):
                damaged=deepcopy(c);damaged["declaration"][section][key]=bad
                damaged["declaration_sha256"]=w.digest_json(damaged["declaration"])
                if n==2 and key=="slot_duration":continue
                with self.subTest(n=n,key=key),self.assertRaises(ValueError):w._authenticate_joint_context(damaged)

    def test_v28_cached_actual_whole_queue_type_values_and_CFG_drift_refused(self):
        for n,method in product((2,3,4),("full","usde_only")):
            env=fixture(n,method,j.JOINT_PHY_LOC_ROOT16_PROFILE)
            try:
                original=env.network.queue_options;fixed=deepcopy(env._joint_expected_DTO)
                self.assertIs(type(original),QueueOptions)
                independent=dict(management_burst=1,management_rescue_burst=2,hello_ack_rescue_fraction=0.5,
                    state_service_s=6.0,coord_service_s={2:8.0,3:16./3,4:4.0}[n],ack_service_s=3.0,
                    request_service_s=6.0,localization_service_s={2:12.0,3:8.0,4:6.0}[n],
                    data_service_s=6.0,other_service_s=12.0,deadline_weight=0.5,deadline_bonus_cap=2.0)
                self.assertTrue(j.exact(asdict(original),independent))
                self.assertTrue(j.exact(e._expected_joint_queue_options(env.cfg),independent))
                for key,bad in (("localization_service_s",12),("localization_service_s",True),
                    ("localization_service_s",99.0),("coord_service_s",99.0),("state_service_s",3.0),
                    ("deadline_weight",0.0),("management_burst",2)):
                    env.network.queue_options=e.replace(original,**{key:bad})
                    with self.subTest(n=n,key=key),self.assertRaisesRegex(ValueError,"whole original QueueOptions"):env.validate_selector_identity()
                env.network.queue_options=SimpleNamespace(**asdict(original))
                with self.assertRaisesRegex(ValueError,"whole original QueueOptions"):env.validate_selector_identity()
                env.network.queue_options=original;env.validate_selector_identity()
                self.assertTrue(j.exact(env._joint_expected_DTO,fixed))
                if n>2:
                    old=env.cfg.localization_service_interval;env.cfg.localization_service_interval=12.0
                    with self.assertRaisesRegex(ValueError,"cached full typed runtime"):env.validate_selector_identity()
                    env.cfg.localization_service_interval=old
            finally:env.network.queue_options=original;env.close()

    def test_v28_two_resets_reapply_after_final_native_network_replacement_zero_physics(self):
        for n,method in product((2,3,4),("full","usde_only")):
            env=fixture(n,method,j.JOINT_PHY_LOC_ROOT16_PROFILE);calls=[];result=object()
            def inert_reset(instance,seed=None):
                # Manufacture ONLY replacement queue state. No ENV constructor,
                # movement, network.advance, actors or actual native reset.
                self.assertIs(instance,env);calls.append(seed)
                instance.network.queue_options=QueueOptions();return result
            try:
                for seed in (101,102):
                    with patch.object(e.OriginalC07,"reset",new=inert_reset):
                        self.assertIs(env.reset(seed),result)
                    self.assertTrue(j.exact(asdict(env.network.queue_options),e._expected_joint_queue_options(env.cfg)))
                    for kind in ("LOCALIZATION","LOCALIZATION_PING","LOCALIZATION_FIX"):
                        self.assertTrue(j.exact(env.network._service_interval(kind),{2:12.0,3:8.0,4:6.0}[n]))
                self.assertEqual(calls,[101,102]);self.assertEqual(env.step_count,0);self.assertEqual(env.network.time,0.0)
            finally:env.close()

    def test_v28_direct_step_bad_queue_or_fake_class_refuses_before_native_delegate(self):
        for method in ("full","usde_only"):
            env=fixture(4,method,j.JOINT_PHY_LOC_ROOT16_PROFILE);original=env.network.queue_options
            try:
                with patch.object(e.OriginalC07,"step",side_effect=AssertionError("NO native transition")) as delegate:
                    for wrong in (e.replace(original,localization_service_s=12.0),SimpleNamespace(**asdict(original))):
                        env.network.queue_options=wrong
                        with self.assertRaisesRegex(ValueError,"whole original QueueOptions"):env.step(object(),1)
                    self.assertEqual(delegate.call_count,0)
                self.assertEqual(env.step_count,0);self.assertEqual(env.network.time,0.0)
            finally:env.network.queue_options=original;env.close()

    def test_v28_direct_step_exact_single_delegate_and_uninitialized_refuses(self):
        env=fixture(4,"full",j.JOINT_PHY_LOC_ROOT16_PROFILE);calls=[];actions=object();topology=object();returned=object()
        def native_step(instance,a,t=None):calls.append((instance,a,t));return returned
        try:
            with patch.object(e.OriginalC07,"step",new=native_step):
                self.assertIs(env.step(actions,topology),returned)
                self.assertEqual(len(calls),1);self.assertIs(calls[0][0],env);self.assertIs(calls[0][1],actions);self.assertIs(calls[0][2],topology)
                self.assertIs(env.step(actions),returned)
                self.assertEqual(len(calls),2);self.assertIs(calls[1][0],env);self.assertIs(calls[1][1],actions);self.assertIsNone(calls[1][2])
                for state in (None,False,1):
                    if state is None:del env._joint_initialized
                    else:env._joint_initialized=state
                    with self.subTest(state=state),self.assertRaisesRegex(ValueError,"before complete initialization"):env.step(actions)
                    self.assertEqual(len(calls),2)
            self.assertIs(e.environment_class(j.JOINT_PHY_LOC_ROOT16_PROFILE),e.DeclaredJointPHYLOCRoot16C07Env)
            for index,p in enumerate(j.PROFILES[:-1]):
                cls=e.environment_class(p)
                self.assertEqual(cls.__name__,"DeclaredJoint_"+str(index)+"_C07Env")
                self.assertEqual(cls.__mro__,(cls,*e.DeclaredJointC07Env.__mro__))
                self.assertNotIn("step",cls.__dict__);self.assertIs(cls.step,e.OriginalC07.step)
        finally:env._joint_initialized=True;env.close()

    def test_v28_old_profiles_reject_LOC_or_new_tuple_instead_of_silent_migration(self):
        for p,n in product((j.POOL12_PROFILE,j.N4_COORD8_PROFILE,j.N34_STATE8_11_PROFILE),(3,4)):
            c=context(n,"full",p);c["declaration"]["config"]["localization_service_interval"]={3:8.0,4:6.0}[n]
            c["declaration_sha256"]=w.digest_json(c["declaration"])
            with self.subTest(profile=p,n=n),self.assertRaises(ValueError):w._authenticate_joint_context(c)
        for n in (3,4):
            c=context(n,"full",j.JOINT_PHY_LOC_ROOT16_PROFILE)
            missing=deepcopy(c);missing["declaration"]["config"].pop("localization_service_interval")
            missing["declaration_sha256"]=w.digest_json(missing["declaration"])
            with self.assertRaises(ValueError):w._authenticate_joint_context(missing)
            wrong=deepcopy(c);wrong["profile"]=j.N34_STATE8_11_PROFILE
            with self.assertRaises(ValueError):w._authenticate_joint_context(wrong)
            for bad in (int({3:8.0,4:6.0}[n]),True,float("nan"),float("inf")):
                damaged=deepcopy(c);damaged["declaration"]["config"]["localization_service_interval"]=bad
                if type(bad) is float and not math.isfinite(bad):
                    with self.assertRaises(ValueError):w.digest_json(damaged["declaration"])
                else:
                    damaged["declaration_sha256"]=w.digest_json(damaged["declaration"])
                    with self.assertRaises(ValueError):w._authenticate_joint_context(damaged)

    def test_v28_only_explicit_ports_reverse_pinned_K27_full_function_AST(self):
        old=historical_source("iterative_candidates_20261017/n34_state8_11_coord8_pool12_v27_frozen/code/exp7_c07_scaling_20261012",
            files=("environment.py","joint_clocks.py"))
        for filename,module,pin,restore in (("environment.py",e,"418158c4aa44ff876552b47232f2296f70167dba549273ad0419c8389dc7fa3c",restore_v28_environment_functions),
            ("joint_clocks.py",j,"b2eaf9b55947721ae54d04ebd5f8e4845f6ed4ea5aa4cfe9ddf7ee2782a9c39b",restore_v28_scope_functions)):
            self.assertEqual(j.digest(old/filename),pin)
            definitions=lambda text:{node.name:node for node in ast.parse(text).body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
            before=definitions((old/filename).read_text(encoding="utf-8"));after=restore(definitions(Path(module.__file__).read_text(encoding="utf-8")))
            self.assertEqual(before.keys(),after.keys())
            for name in before:self.assertEqual(ast.dump(before[name],include_attributes=False),ast.dump(after[name],include_attributes=False),(filename,name))


class SelectorAndLifecycleTests(NoPhysics):
    def test_all24_fixed_dispatch_full_H2_only_USDE_none_and_N2_H1(self):
        for p in j.PROFILES:
            for n in (2,3,4):
                for m in ("full","usde_only"):
                    env=fixture(n,m,p)
                    try:
                        self.assertIs(env._c04_child_tick.__func__,j._H2 if m=="full" and j.HORIZONS[p][n]==2 else j._ORIGINAL)
                        env.validate_selector_identity();self.assertEqual(env.step_count,0);self.assertEqual(env.network.time,0.)
                    finally:env.close()

    def test_H2_exact_instance_restore_missing_method_and_foreign_refusal(self):
        env=fixture(3,"full",j.PROFILES[2]);handle=env._joint_selector_handle
        del env.__dict__[j.INNER];handle.check(reset_deleted=True)
        env.__dict__[j.INNER]=MethodType(j._ORIGINAL,env)
        with self.assertRaises(ValueError):handle.check()
        with self.assertRaises(ValueError):handle.restore()
        env.__dict__[j.INNER]=handle.bound
        del env.__dict__[j.INNER];handle.restore();self.assertNotIn(j.OWNER,env.__dict__)
        env.close();self.assertIs(env._c04_child_tick.__func__,j._ORIGINAL)

    def test_onlyMAX_source_proof_and_actual_typed_code_nonMAX_drift(self):
        self.assertEqual(j._PROOF["changed_AST_sites"],1);self.assertTrue(j._PROOF["reverse_AST_identical"])
        code=j._H2.__code__
        index=next(i for i,x in enumerate(code.co_consts) if type(x) is float and x==.25)
        const=list(code.co_consts);const[index]=.5
        j._H2.__code__=code.replace(co_consts=tuple(const))
        try:
            with self.assertRaises(ValueError):j.fast_runtime_check()
        finally:j._H2.__code__=code
        self.assertFalse(j.exact(1,1.));self.assertFalse(j.exact(1,True))
        self.assertNotEqual(j.constant_signature(1),j.constant_signature(1.))

    def test_drifted_code_does_not_prevent_own_identity_cleanup(self):
        env=fixture(4,"full",j.PROFILES[1]);handle=env._joint_selector_handle;code=j._H2.__code__
        j._H2.__defaults__=(None,)
        try:
            with self.assertRaises(ValueError):env.validate_selector_identity()
            handle.restore();self.assertTrue(handle.closed);self.assertNotIn(j.OWNER,env.__dict__)
        finally:j._H2.__defaults__=None;env.close()

    def test_fast100_checks_no_disk_compile_or_mutable_DTO_alias(self):
        env=fixture(4,"full",j.PROFILES[1])
        try:
            with patch("builtins.open",side_effect=AssertionError("NO runtime open")),\
                 patch.object(Path,"read_bytes",side_effect=AssertionError("NO runtime disk")),\
                 patch("builtins.compile",side_effect=AssertionError("NO runtime compile")),\
                 patch.object(j,"dependencies",side_effect=AssertionError("NO boundary proof in step")):
                for _ in range(100):env.validate_selector_identity()
                env.cfg.hello_period=20.
                with self.assertRaises(ValueError):env.validate_selector_identity()
                env.cfg.hello_period=40.
        finally:env.close()

    def test_actual_topologies_and_getter_clock_and_owner_guards(self):
        env=fixture(4,"full",j.PROFILES[1]);top=env.network.topologies
        try:
            env.network.topologies=list(reversed(top))
            with self.assertRaises(ValueError):env.validate_selector_identity()
            env.network.topologies=top
            env.network.candidate_topologies=lambda:top
            with self.assertRaises(ValueError):env.validate_selector_identity()
            del env.network.__dict__["candidate_topologies"]
            env.network.slot_owners=list(reversed(env.network.slot_owners))
            with self.assertRaises(ValueError):env.validate_selector_identity()
        finally:env.close()
    def test_original_timer_anchors_strict_types_and_drift_do_not_rebuild_cache(self):
        env=fixture(4,"full",j.PROFILES[1])
        try:
            expected=deepcopy(env._joint_expected_DTO)
            for owner,key in ((env.network,"probe_timeout"),(env,"service_retry_interval"),(env,"service_renew_lead")):
                original=getattr(owner,key)
                for value in (1.,int(original),True,float("nan"),original+1e-6):
                    setattr(owner,key,value)
                    with self.subTest(timer=key,value=value),self.assertRaisesRegex(ValueError,"timer identity"):
                        env.validate_selector_identity()
                    self.assertTrue(j.exact(env._joint_expected_DTO,expected))
                setattr(owner,key,original+5e-9);env.validate_selector_identity()
                setattr(owner,key,original)
        finally:env.close()

    def test_reset_cancel_before_native_reset_removes_ownhook_sameobject(self):
        env=fixture(3,"full",j.PROFILES[2]);error=KeyboardInterrupt("manufactured reset boundary")
        try:
            with patch.object(j,"full_source_validate",side_effect=error):
                try:env.reset(42)
                except BaseException as caught:self.assertIs(caught,error)
                else:self.fail("cancel must propagate")
            self.assertNotIn(j.OWNER,env.__dict__);self.assertTrue(env._joint_selector_handle.closed)
        finally:env.close()
    def test_H1_USDE_reject_foreign_H2_and_profile_runtime_migration(self):
        for n,m,p in ((3,"full",j.PROFILES[0]),(4,"usde_only",j.PROFILES[3]),(2,"full",j.PROFILES[3])):
            env=fixture(n,m,p);handle=j.SelectorHandle(env)
            try:
                env._joint_selector_handle=handle
                with self.assertRaises(ValueError):env.validate_selector_identity()
            finally:
                handle.restore();env._joint_selector_handle=None;env.close()
        env=fixture(4,"full",j.PROFILES[1])
        try:
            env._joint_profile=j.PROFILES[0]
            with self.assertRaises(ValueError):env.validate_selector_identity()
        finally:env._joint_profile=j.PROFILES[1];env.close()

    def test_nesting_old_profiles_newprofiles_writers_global_restoration_withoutfiles(self):
        names=("TaskV4Env","MethodOptions","Config","Policy","sources","save_bundle","atomic_json","load_checkpoint")
        before={name:getattr(w.native,name) for name in names};values=[];c=context(profile=j.PROFILES[3])
        with patch.object(w.native,"save_bundle",lambda v,*args:values.append(deepcopy(v))):
            for error in (ValueError("body"),KeyboardInterrupt("cancel"),SystemExit("exit")):
                try:
                    with w.bindings(c) as outer:
                        self.assertIsInstance(outer,w._JointNativeFacade)
                        outer.save_bundle({"opaque":"manufactured"},Path("not_written"))
                        for p in (b.ROOT_BUDGET_PROFILE,e.n4_child_h2.PROFILE,j.PROFILES[0]):
                            with w.bindings(context(profile=p)) as inner:
                                if p==b.ROOT_BUDGET_PROFILE:self.assertIs(inner,w.native)
                        raise error
                except BaseException as caught:self.assertIs(caught,error)
            self.assertTrue(w.json_value_type_exact(values[0]["scale_context"],c))
        self.assertTrue(all(getattr(w.native,name) is value for name,value in before.items()))
        self.assertIsNone(j._SCOPE.get());self.assertIsNone(b._CONSTRUCTION_SCOPE.get())

    def test_owned_cleanup_multi_cancel_preserves_body_nonowner_and_manualonce(self):
        calls=[]
        class Owned(e.DeclaredJointC07Env):
            def close(self):
                calls.append(self.name);self._joint_close_attempted=True
                if self.error is not None:self._joint_close_error=self.error;raise self.error
            def verify_closed_identity(self):
                if self._joint_close_error is not None:raise self._joint_close_error
        def item(name,error):
            x=object.__new__(Owned);x.name=name;x.error=error;x._joint_close_attempted=False;x._joint_close_error=None;return x
        ordinary=ValueError("ordinary");cancel=KeyboardInterrupt("secondary")
        owned=[item("a",ordinary),item("b",cancel),item("healthy",None)]
        with self.assertRaises(KeyboardInterrupt) as caught:w._JointNativeFacade._cleanup_environments(owned)
        self.assertIs(caught.exception,cancel);self.assertEqual(calls,["healthy","b","a"])
        body=SystemExit("body");w._JointNativeFacade._cleanup_environments(owned,body);self.assertEqual(len(body.__notes__),2)
        with self.assertRaises(ValueError):w._JointNativeFacade._cleanup_environments([SimpleNamespace(close=lambda:self.fail("foreign"))])
        env=fixture(4,"full",j.PROFILES[1])
        with patch.object(env._joint_selector_handle,"restore",wraps=env._joint_selector_handle.restore) as restore:
            env.close();w._JointNativeFacade._cleanup_environments([env]);env.close();self.assertEqual(restore.call_count,1)
    def test_direct_native_train_setup_owned_before_early_failure_cancel_and_normalclose(self):
        p=j.PROFILES[3];c=context(profile=p);made=[]
        def inert_init(instance,*args,**kwargs):
            fixture(4,"full",p,target=instance);made.append(instance)
        cfg,mo,ro,_=e.build_settings(4,30,"full",p,[])
        with patch.object(e.DeclaredJointC07Env,"__init__",new=inert_init):
            for label in ("native reset setup","native Agent setup","output setup","manifest setup"):
                for error in (ValueError(label),KeyboardInterrupt(label),SystemExit(label)):
                    try:
                        with w.bindings(c) as executor:
                            # Native train calls module TaskV4Env directly,
                            # not Policy.make_environment. No real train here.
                            env=w.native.TaskV4Env(cfg,"full_v6",mo,ro)
                            self.assertTrue(any(value is env for value in executor.owned_environments))
                            raise error
                    except BaseException as caught:self.assertIs(caught,error)
                    self.assertTrue(env._joint_close_attempted);self.assertTrue(env._joint_selector_handle.closed)
                    self.assertNotIn(j.OWNER,env.__dict__)
            with w.bindings(c) as executor:
                env=w.native.TaskV4Env(cfg,"full_v6",mo,ro)
                with patch.object(env._joint_selector_handle,"restore",wraps=env._joint_selector_handle.restore) as restore:
                    env.close()
                    executor.cleanup_owned()
                    self.assertEqual(restore.call_count,1)
        self.assertTrue(all(value._joint_close_attempted for value in made))
    def test_constructor_owner_registration_cancel_cleans_without_overwriting_error(self):
        p=j.PROFILES[3];c=context(profile=p);made=[];error=KeyboardInterrupt("registration")
        def inert_init(instance,*args,**kwargs):fixture(4,"full",p,target=instance);made.append(instance)
        class InterruptedList(list):
            def append(self,value):raise error
        cfg,mo,ro,_=e.build_settings(4,30,"full",p,[])
        with patch.object(e.DeclaredJointC07Env,"__init__",new=inert_init):
            try:
                with w.bindings(c) as executor:
                    executor.owned_environments=InterruptedList()
                    w.native.TaskV4Env(cfg,"full_v6",mo,ro)
            except BaseException as caught:self.assertIs(caught,error)
            else:self.fail("registration cancellation must remain visible")
        self.assertTrue(made[0]._joint_close_attempted);self.assertNotIn(j.OWNER,made[0].__dict__)
    def test_facade_original_validator_first_and_early_make_setup_cancel_owned_cleanup(self):
        real=w.native;native_class=real.Policy;native_members=dict(native_class.__dict__)
        c=context(profile=j.PROFILES[3]);value=saved(c);schema=fixture(4,"full",j.PROFILES[3])
        value["observation_schema"]=environment_schema(schema);schema.close()
        made=[];events=[];failure=[None]
        class FakePolicy:
            def __init__(self,checkpoint,*args,**kwargs):
                events.append("constructor");self.checkpoint=checkpoint
                self.cfg=e.ScaleConfig.from_dict(checkpoint["environment_config"])
                self.method=real.get_method(checkpoint["method_id"]);self.schema=checkpoint["observation_schema"]
            def validate_environment(self,env):
                events.append("original_validate")
                if failure[0] is not None:raise failure[0]
                w_original_validate(self,env)  # Actual original native validator function.
            def make_environment(self):
                env=fixture(4,"full",j.PROFILES[3]);made.append(env)
                self.validate_environment(env);return env
        w_original_validate=w._ORIGINAL_POLICY_VALIDATE
        proxy=SimpleNamespace(**vars(real));proxy.Policy=FakePolicy
        members=dict(FakePolicy.__dict__);codes={k:v.__code__ for k,v in members.items() if inspect.isfunction(v)}
        meta={k:(deepcopy(v.__defaults__),deepcopy(v.__kwdefaults__),deepcopy(v.__annotations__))
            for k,v in members.items() if inspect.isfunction(v)}
        with patch.object(w,"native",proxy),patch.object(w,"_ORIGINAL_POLICY",FakePolicy),\
             patch.object(w,"_ORIGINAL_POLICY_VALIDATE",FakePolicy.validate_environment),\
             patch.object(w,"_ORIGINAL_POLICY_MEMBERS",members),patch.object(w,"_ORIGINAL_POLICY_CODES",codes),\
             patch.object(w,"_ORIGINAL_POLICY_CALLABLE_META",meta):
            with w.bindings(c) as executor:
                policy=executor.Policy(value,"cpu");env=policy.make_environment()
                self.assertEqual(events[-1],"original_validate")
                env.__dict__[j.INNER]=MethodType(j._ORIGINAL,env)
                with self.assertRaises(ValueError):policy.validate_environment(env)
                env.__dict__[j.INNER]=env._joint_selector_handle.bound;env.close()
                for error in (ValueError("early validation"),KeyboardInterrupt("early cancel"),SystemExit("early exit")):
                    failure[0]=error
                    try:policy.make_environment()
                    except BaseException as caught:self.assertIs(caught,error)
                    else:self.fail("must reject make before return")
                    finally:failure[0]=None
                    self.assertTrue(made[-1]._joint_close_attempted);self.assertNotIn(j.OWNER,made[-1].__dict__)
            for label in ("fault setup","mkdir setup","threads setup"):
                for error in (OSError(label),KeyboardInterrupt(label)):
                    try:
                        with w.bindings(c) as executor:
                            env=executor.Policy(value,"cpu").make_environment();raise error
                    except BaseException as caught:self.assertIs(caught,error)
                    self.assertTrue(env._joint_close_attempted);self.assertNotIn(j.OWNER,env.__dict__)
        self.assertIs(real.Policy,native_class);self.assertEqual(native_class.__dict__,native_members)

    def test_export_original_train_eval_bridge_AST_and_P0_metadata_only(self):
        c=context(profile=j.PROFILES[1]);value=saved(c)
        with w.bindings(c) as executor:
            exported=executor.export(value);self.assertTrue(w.json_value_type_exact(exported["scale_context"],c))
        source=Path(w.__file__).read_text(encoding="utf-8")
        self.assertIn("original(env)  # Preserve the original validator and error first.",source)
        self.assertNotIn("except ValueError",source[source.index("class _JointNativeFacade"):source.index("@contextmanager\ndef bindings")])
        text=Path(w.__file__).with_name("evaluation.py").read_text(encoding="utf-8")
        self.assertIn("ROOT_BUDGET_PROFILE,N4_H2_PROFILE,*JOINT_PROFILES",text)
        self.assertNotIn("step",e.DeclaredJointC07Env.__dict__)
        self.assertNotIn("_c04_child_tick",e.DeclaredJointC07Env.__dict__)


if __name__=="__main__":unittest.main()
