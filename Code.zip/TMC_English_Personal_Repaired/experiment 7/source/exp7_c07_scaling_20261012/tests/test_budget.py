"""Isolated standard-library tests: no environment, learner or simulation imports."""
import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest import mock


MODULE_PATH = Path(__file__).resolve().parents[1] / "budget.py"
SPEC = importlib.util.spec_from_file_location("isolated_c07_budget", MODULE_PATH)
budget = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(budget)


class BudgetTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.ledger = budget.BudgetLedger(self.root / "ledger.json")

    def reserve(self, attempt="a", model="full3", steps=50_000, *, arm="full", seed=7,
                config=None, ledger=None, **kwargs):
        return (ledger or self.ledger).reserve(attempt, model, arm, seed,
            config if config is not None else {"n_auv": 3, "revision": "test"},
            self.root / (attempt + "_output"), steps, **kwargs)

    def test_default_is_aggregate_and_creation_never_overwrites(self):
        snapshot = self.ledger.snapshot()
        self.assertEqual(snapshot["mode"], "aggregate")
        self.assertEqual(snapshot["development_limit"], 100_000)
        with self.assertRaises(FileExistsError):
            budget.BudgetLedger(self.ledger.path, fresh=True)
        with self.assertRaises(budget.BudgetError):
            budget.BudgetLedger(self.ledger.path, mode="per_model")
        with self.assertRaises(budget.BudgetError):
            budget.BudgetLedger(self.ledger.path, limit=99_999)

    def test_limit_cannot_be_increased(self):
        for limit in (100_001, 0, True):
            with self.subTest(limit=limit), self.assertRaises(budget.BudgetError):
                budget.BudgetLedger(self.root / f"invalid_{limit}.json", limit=limit)

    def test_fresh_output_required_even_when_empty(self):
        output = self.root / "a_output"
        output.mkdir()
        with self.assertRaises(FileExistsError):
            self.reserve()
        self.assertEqual(self.ledger.snapshot()["attempts"], [])

    def test_deleted_output_path_is_still_never_reusable(self):
        self.reserve()
        self.ledger.finish("a", 1)
        (self.root / "a_output").rmdir()
        with self.assertRaises(FileExistsError):
            self.ledger.reserve("b", "other", "full", 7, {"n_auv": 4},
                                self.root / "a_output", 1)

    def test_active_reserves_full_target_and_finish_releases_only_unexecuted_work(self):
        self.reserve(steps=80_000)
        self.ledger.update("a", 30_000)
        usage = self.ledger.snapshot()["development_usage"]
        self.assertEqual(usage, dict(executed_steps=30_000,
                         active_unexecuted_reserved_steps=50_000, capacity_used=80_000))
        with self.assertRaises(budget.BudgetExceeded):
            self.reserve("b", "full4", 20_001, config={"n_auv": 4})
        self.ledger.finish("a", 30_000, status="failed")
        self.reserve("b", "full4", 70_000, config={"n_auv": 4})
        self.assertEqual(self.ledger.snapshot()["development_usage"]["capacity_used"], 100_000)

    def test_per_model_cap_is_explicit_and_other_models_do_not_share_it(self):
        ledger = budget.BudgetLedger(self.root / "per_model.json", mode="per_model")
        self.reserve("a", "full3", 100_000, ledger=ledger)
        self.reserve("b", "full4", 100_000, ledger=ledger, config={"n_auv": 4})
        self.assertEqual(ledger.snapshot()["development_usage"]["capacity_used"], 200_000)
        ledger.finish("a", 100_000)
        with self.assertRaises(budget.BudgetExceeded):
            self.reserve("c", "full3", 1, ledger=ledger)

    def test_failed_rollback_counts_physical_work_not_checkpoint_counter(self):
        self.reserve("failed", steps=50_000)
        self.ledger.finish("failed", 30_000, status="failed")
        with self.assertRaises(budget.BudgetExceeded):
            self.reserve("resume_too_long", steps=80_000, resume_from_step=20_000,
                         resume_parent_attempt="failed")
        resumed = self.reserve("resume", steps=70_000, resume_from_step=20_000,
                               resume_parent_attempt="failed")
        self.assertEqual(resumed["resume_from_step"], 20_000)
        self.ledger.finish("resume", 70_000)
        self.assertEqual(self.ledger.snapshot()["development_usage"]["executed_steps"], 100_000)

    def test_discarded_attempt_also_consumes_budget(self):
        self.reserve(steps=100_000)
        self.ledger.finish("a", 99_999, status="discarded")
        self.reserve("b", "other", 1, config={"n_auv": 4})
        with self.assertRaises(budget.BudgetExceeded):
            self.reserve("c", "another", 1, config={"n_auv": 2})

    def test_duplicate_active_attempt_and_reusable_attempt_id_are_rejected(self):
        self.reserve()
        with self.assertRaises(budget.BudgetError):
            self.reserve("b", steps=1)
        self.ledger.finish("a", 1)
        with self.assertRaises(budget.BudgetError):
            self.reserve("a", steps=1)
        self.assertFalse((self.root / "b_output").exists())

    def test_model_cannot_be_relabeled_or_its_config_changed(self):
        self.reserve()
        self.ledger.finish("a", 1)
        with self.assertRaises(budget.BudgetError):
            self.reserve("b", "renamed", 1)
        with self.assertRaises(budget.BudgetError):
            self.reserve("c", "full3", 1, config={"n_auv": 4})
        with self.assertRaises(budget.BudgetError):
            self.reserve("d", "full3", 1, seed=8)

    def test_resume_requires_finished_matching_parent_and_reachable_checkpoint(self):
        with self.assertRaises(budget.BudgetError):
            self.reserve(resume_from_step=1)
        with self.assertRaises(budget.BudgetError):
            self.reserve(resume_parent_attempt="missing")
        self.reserve()
        with self.assertRaises(budget.BudgetError):
            self.reserve("b", steps=1, resume_parent_attempt="a")
        self.ledger.finish("a", 10)
        with self.assertRaises(budget.BudgetError):
            self.reserve("c", steps=1, resume_from_step=11, resume_parent_attempt="a")
        with self.assertRaises(budget.BudgetError):
            self.reserve("d", "other", 1, config={"n_auv": 4}, resume_parent_attempt="a")

    def test_progress_is_monotone_and_finished_attempts_are_immutable(self):
        self.reserve()
        self.ledger.update("a", 10)
        with self.assertRaises(budget.BudgetError):
            self.ledger.update("a", 9)
        self.ledger.update("a", 10)
        self.ledger.finish("a", 10)
        with self.assertRaises(budget.BudgetError):
            self.ledger.update("a", 11)
        with self.assertRaises(budget.BudgetError):
            self.ledger.finish("a", 10)

    def test_noninteger_counts_and_invalid_finish_status_are_rejected(self):
        self.reserve()
        for steps in (True, -1, 1.5):
            with self.subTest(steps=steps), self.assertRaises(budget.BudgetError):
                self.ledger.update("a", steps)
        with self.assertRaises(budget.BudgetError):
            self.ledger.finish("a", 0, status="ignored")
        self.assertEqual(self.ledger.snapshot()["attempts"][0]["status"], "active")

    def test_actual_overrun_is_saved_before_error_and_never_forgiven(self):
        self.reserve(steps=100_000)
        with self.assertRaises(budget.BudgetExceeded):
            self.ledger.update("a", 100_001)
        self.assertEqual(self.ledger.snapshot()["development_usage"]["capacity_used"], 100_001)
        with self.assertRaises(budget.BudgetExceeded):
            self.ledger.finish("a", 100_001, status="failed")
        record = self.ledger.snapshot()["attempts"][0]
        self.assertEqual(record["status"], "failed")
        self.assertTrue(record["reservation_overrun"])
        with self.assertRaises(budget.BudgetExceeded):
            self.reserve("b", "other", 1, config={"n_auv": 4})

    def test_full_stage_needs_explicit_confirmation_and_does_not_reset_development(self):
        self.reserve("dev", steps=100_000)
        self.ledger.finish("dev", 100_000)
        for confirmation in (None, "yes", True):
            with self.subTest(confirmation=confirmation), self.assertRaises(budget.BudgetError):
                self.reserve("full_invalid", steps=450_000, stage="full",
                             full_training_confirmation=confirmation)
        self.reserve("full", steps=450_000, stage="full",
                     full_training_confirmation=budget.FULL_CONFIRMATION)
        snapshot = self.ledger.snapshot()
        self.assertEqual(snapshot["development_usage"]["executed_steps"], 100_000)
        self.assertEqual(snapshot["full_usage"]["capacity_used"], 450_000)
        with self.assertRaises(budget.BudgetError):
            self.reserve("misclassified", "other", 1, config={"n_auv": 4},
                         full_training_confirmation=budget.FULL_CONFIRMATION)
        with self.assertRaises(budget.BudgetExceeded):
            self.reserve("more_dev", "other", 1, config={"n_auv": 4})

    def test_configuration_snapshot_is_copied_and_nonfinite_config_is_rejected(self):
        original = {"n_auv": 3, "options": {"v": 1}}
        record = self.reserve(config=original)
        original["options"]["v"] = 99
        record["config"]["options"]["v"] = 88
        self.assertEqual(self.ledger.snapshot()["attempts"][0]["config"]["options"]["v"], 1)
        with self.assertRaises(budget.BudgetError):
            self.reserve("b", "other", 1, config={"bad": float("nan")})

    def test_crash_leaves_active_reservation_and_reopen_does_not_reset_it(self):
        self.reserve(steps=80_000)
        self.ledger.update("a", 12_000)
        reopened = budget.BudgetLedger(self.ledger.path)
        self.assertEqual(reopened.snapshot()["development_usage"]["capacity_used"], 80_000)
        with self.assertRaises(budget.BudgetError):
            self.reserve("b", steps=1, ledger=reopened)

    def test_failed_atomic_replace_preserves_previous_ledger(self):
        self.reserve()
        original = self.ledger.path.read_bytes()
        with mock.patch.object(budget.os, "replace", side_effect=PermissionError("test")):
            with self.assertRaises(PermissionError):
                self.ledger.update("a", 10)
        self.assertEqual(self.ledger.path.read_bytes(), original)
        self.assertEqual(list(self.root.glob("ledger.json.*.tmp")), [])

    def test_concurrent_reservations_cannot_oversubscribe_aggregate_capacity(self):
        barrier = threading.Barrier(2)
        results = []
        def worker(index):
            barrier.wait()
            try:
                self.reserve(str(index), f"model{index}", 60_000, config={"n_auv": index + 2})
                results.append("reserved")
            except budget.BudgetExceeded:
                results.append("blocked")
        workers = [threading.Thread(target=worker, args=(i,)) for i in range(2)]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join(timeout=10)
            self.assertFalse(worker.is_alive())
        self.assertCountEqual(results, ["reserved", "blocked"])
        self.assertEqual(self.ledger.snapshot()["development_usage"]["capacity_used"], 60_000)

    def test_advisory_lock_times_out_and_then_releases(self):
        with budget._file_lock(self.ledger.lock_path):
            with self.assertRaises(TimeoutError):
                with budget._file_lock(self.ledger.lock_path, timeout=.02):
                    self.fail("Second independent handle acquired the occupied lock")
        with budget._file_lock(self.ledger.lock_path, timeout=.02):
            pass

    def test_corrupt_ledger_is_rejected_instead_of_reset(self):
        self.ledger.path.write_text("{truncated", encoding="utf-8")
        with self.assertRaises(budget.BudgetError):
            budget.BudgetLedger(self.ledger.path)
        self.assertEqual(self.ledger.path.read_text(encoding="utf-8"), "{truncated")

    def test_cli_is_only_accounting_and_full_confirmation_is_required(self):
        config = self.root / "config.json"
        config.write_text(json.dumps({"n_auv": 3}), encoding="utf-8")
        argv = ["--ledger", str(self.ledger.path), "reserve", "--attempt-id", "cli", "--model-id", "cli_model",
                "--arm", "full", "--seed", "7", "--config", str(config), "--output", str(self.root / "cli_output"),
                "--requested-steps", "450000", "--stage", "full"]
        with self.assertRaises(budget.BudgetError):
            budget.main(argv)
        self.assertFalse((self.root / "cli_output").exists())


if __name__ == "__main__":
    unittest.main()
