"""Pure geometry / AST / restoration checks; no environment steps or learning."""
import ast
from copy import deepcopy
import hashlib
import inspect
import math
from pathlib import Path
import sys
import textwrap
from types import SimpleNamespace
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012 import deployment
from usv_auv import environment as core


class FixedGridDeploymentContracts(unittest.TestCase):
    def config(self, n, area=200., layout="scale_grid"):
        return SimpleNamespace(n_auv=n, area_size=area, deployment_layout=layout)

    def test_two_AUV_exact_original_expression_for_all_layouts(self):
        for layout in ("scale_grid", "line", None, "another_declared_layout"):
            for area in (200., 100., 137.5):
                expected=np.column_stack((np.linspace(.30,.70,2)*area,
                                          np.full(2,.45*area)))
                np.testing.assert_array_equal(deployment.deployment_positions(self.config(2,area,layout)),expected)

    def test_nongrid_three_four_exact_original_expression(self):
        for n in (3,4):
            expected=np.column_stack((np.linspace(.30,.70,n)*200.,np.full(n,.45*200.)))
            np.testing.assert_array_equal(deployment.deployment_positions(self.config(n,layout="line")),expected)
            cfg=self.config(n)
            del cfg.deployment_layout
            np.testing.assert_array_equal(deployment.deployment_positions(cfg),expected)

    def test_triangle_exact_ID_order_and_orientation(self):
        expected=np.asarray(((.3,.45-.4/(2*math.sqrt(3))),
                             (.7,.45-.4/(2*math.sqrt(3))),
                             (.5,.45+.4/math.sqrt(3))))*200.
        np.testing.assert_array_equal(deployment.deployment_positions(self.config(3)),expected)

    def test_square_exact_ID_order_and_orientation(self):
        expected=np.asarray(((.3,.25),(.7,.25),(.7,.65),(.3,.65)))*200.
        np.testing.assert_array_equal(deployment.deployment_positions(self.config(4)),expected)

    def test_centroid_bounds_and_preserved_minimum_spacing(self):
        for area in (100.,137.5,200.):
            for n in (2,3,4):
                xy=deployment.deployment_positions(self.config(n,area))
                self.assertEqual(xy.shape,(n,2))
                self.assertTrue(np.all(np.isfinite(xy)))
                self.assertTrue(np.all((xy>=0)&(xy<=area)))
                np.testing.assert_allclose(xy.mean(axis=0),np.array([.5,.45])*area,rtol=0,atol=1e-12)
                distances=[np.linalg.norm(xy[i]-xy[j]) for i in range(n) for j in range(i)]
                self.assertAlmostEqual(min(distances),.4*area,places=12)
                if n==3:
                    np.testing.assert_allclose(distances,np.full(3,.4*area),rtol=0,atol=1e-12)

    def test_pure_function_never_reads_seed_sensor_or_truth(self):
        class GeometryOnly:
            n_auv=4
            area_size=200.
            deployment_layout="scale_grid"
            def __getattr__(self,name):
                raise AssertionError("Illegal scene/state read: "+name)
        cfg=GeometryOnly()
        first=deployment.deployment_positions(cfg)
        second=deployment.deployment_positions(cfg)
        np.testing.assert_array_equal(first,second)
        first[0]=[-999.,-999.]
        np.testing.assert_array_equal(second,deployment.deployment_positions(cfg))

    def test_invalid_geometry_rejected(self):
        for n,area in ((1,200.),(5,200.),(True,200.),(3,0.),(4,float("nan")),(3,True)):
            with self.assertRaises(ValueError):
                deployment.deployment_positions(self.config(n,area))

    def test_AST_only_single_assignment_value_changes(self):
        original=ast.parse(textwrap.dedent(inspect.getsource(deployment._ORIGINAL_RESET)))
        changed,audit=deployment._transform_reset_ast(original)
        self.assertEqual(audit["assignment_count"],1)
        self.assertTrue(audit["remaining_reset_AST_identical"])
        self.assertEqual(audit["original_AST_sha256"],audit["restored_AST_sha256"])
        self.assertNotEqual(audit["original_AST_sha256"],audit["transformed_AST_sha256"])
        old_site=deployment._position_assignments(original)[0]
        new_site=deployment._position_assignments(changed)[0]
        self.assertEqual(ast.unparse(new_site.value),"deployment_positions(c)")
        new_site.value=deepcopy(old_site.value)
        self.assertEqual(deployment._dump(changed),deployment._dump(original))

    def test_AST_rejects_drift_or_multiple_sites(self):
        original=ast.parse(textwrap.dedent(inspect.getsource(deployment._ORIGINAL_RESET)))
        altered=deepcopy(original)
        deployment._position_assignments(altered)[0].value=ast.parse("np.zeros((c.n_auv,2))",mode="eval").body
        with self.assertRaises(ValueError):
            deployment._transform_reset_ast(altered)
        duplicated=deepcopy(original)
        duplicated.body[0].body.append(deepcopy(deployment._position_assignments(duplicated)[0]))
        with self.assertRaises(ValueError):
            deployment._transform_reset_ast(duplicated)

    def test_nested_scope_restores_original_method(self):
        before=core.CooperativeEnv.reset
        self.assertIs(before,deployment._ORIGINAL_RESET)
        with deployment.deployment_port():
            outer=core.CooperativeEnv.reset
            self.assertIs(outer,deployment._PORTED_RESET)
            with deployment.deployment_port():
                self.assertIs(core.CooperativeEnv.reset,outer)
            self.assertIs(core.CooperativeEnv.reset,outer)
        self.assertIs(core.CooperativeEnv.reset,before)

    def test_scope_restores_on_exception_and_preserves_original_disk_source(self):
        before=core.CooperativeEnv.reset
        source=Path(inspect.getsourcefile(before))
        identity=hashlib.sha256(source.read_bytes()).hexdigest()
        with self.assertRaisesRegex(RuntimeError,"unit fixture"):
            with deployment.deployment_port():
                self.assertIs(core.CooperativeEnv.reset,deployment._PORTED_RESET)
                raise RuntimeError("unit fixture")
        self.assertIs(core.CooperativeEnv.reset,before)
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),identity)

    def test_unknown_external_patch_is_not_overwritten(self):
        before=core.CooperativeEnv.reset
        def unrelated(self,seed=None):
            raise AssertionError("Not executed")
        try:
            core.CooperativeEnv.reset=unrelated
            with self.assertRaises(RuntimeError):
                with deployment.deployment_port():
                    self.fail("Unknown patch must not enter context")
            self.assertIs(core.CooperativeEnv.reset,unrelated)
        finally:
            core.CooperativeEnv.reset=before

    def test_public_audit_returns_copy(self):
        value=deployment.deployment_ast_audit()
        value["assignment_count"]=99
        self.assertEqual(deployment.deployment_ast_audit()["assignment_count"],1)


if __name__=="__main__":
    unittest.main()
