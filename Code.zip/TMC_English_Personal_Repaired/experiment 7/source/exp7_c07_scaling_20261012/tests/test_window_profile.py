"""Native C07 parameter-only window candidate; no simulation or learning."""
from dataclasses import asdict, replace
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012.environment import build_settings,make_environment,PROFILES
from exp7_c07_scaling_20261012.paths import SOURCE,reference_config,reference_metadata
from exp7_c07_scaling_20261012.deployment import deployment_positions
from usv_auv.config import Config as OriginalConfig
from usv_auv import environment as original_core
from v6_candidates.c07.environment import TaskV4Env as OriginalC07
from v6_candidates.c04.environment import TaskV4Env as IntentEnv
from v6_candidates.c03.mac import ChildLease
from v6_candidates.c02.mac import SlotLease


V4="adaptive_packet_grid_queue_v4"
V5="adaptive_packet_grid_window_v5"


class ChildWindowCandidateContracts(unittest.TestCase):
    def test_profile_is_explicitly_registered(self):
        self.assertIn(V5,PROFILES)

    def test_two_AUV_entire_original_settings_preserved(self):
        expected_config=json.loads(reference_config().read_text(encoding="utf-8-sig"))
        for method in ("full_v6","usde_only_v6"):
            cfg,options,routing,diagnostic=build_settings(2,30,method,V5)
            saved=json.loads(reference_metadata(method).read_text(encoding="utf-8-sig"))
            self.assertIs(type(cfg),OriginalConfig)
            self.assertEqual(cfg.to_dict(),expected_config)
            self.assertEqual(asdict(options),saved["method_options"])
            self.assertEqual(asdict(routing),saved["routing_options"])
            self.assertNotIn("child_window_adaptation",diagnostic)
            env=make_environment(2,30,method,V5)
            self.addCleanup(env.close)
            self.assertIs(type(env),OriginalC07)

    def test_inherits_V4_except_two_native_MethodOptions_fields(self):
        for n in (3,4):
            for method in ("full","usde_only"):
                old_cfg,old_options,old_routing,_=build_settings(n,30,method,V4)
                cfg,options,routing,diagnostic=build_settings(n,30,method,V5)
                self.assertEqual(cfg.to_dict(),old_cfg.to_dict())
                self.assertEqual(asdict(routing),asdict(old_routing))
                changes={key for key,value in asdict(options).items() if value!=asdict(old_options)[key]}
                self.assertEqual(changes,{"mac_child_lease_frames","mac_child_lead_s"})
                self.assertEqual(options.mac_child_lease_frames,3)
                self.assertEqual(options.mac_frame_stride,2)
                self.assertAlmostEqual(options.mac_child_lead_s,30. if n==3 else 36.)
                self.assertEqual(cfg.coordination_service_interval,16./n)
                self.assertEqual(cfg.deployment_layout,"scale_grid")
                self.assertEqual(options.mac_pool_slots,6+2*n)
                self.assertEqual(options.mac_max_leases,6+5*n)
                self.assertIn("irrevocable",diagnostic["child_window_adaptation"]["tradeoff"])

    def test_full_and_USDE_same_scale_common_config_and_parameters(self):
        for n,sensors in ((3,30),(4,30),(3,45),(4,60)):
            a=build_settings(n,sensors,"full",V5)
            b=build_settings(n,sensors,"usde_only",V5)
            self.assertEqual(a[0].to_dict(),b[0].to_dict())
            self.assertEqual(asdict(a[2]),asdict(b[2]))
            left,right=asdict(a[1]),asdict(b[1])
            self.assertTrue(left.pop("mac_enabled"))
            self.assertFalse(right.pop("mac_enabled"))
            self.assertEqual(left,right)

    def test_management_aware_MIN_lead_strictly_less_than_next_frame(self):
        for n,sensors,expected_frame,expected_turn,expected_lead in ((3,30,42.,31.5,30.),(4,30,48.,43.2,36.),
                                                                   (3,45,63.,31.5,31.5),(4,60,96.,43.2,43.2)):
            cfg,options,_,diagnostic=build_settings(n,sensors,"full",V5)
            clock=diagnostic["clock"]
            self.assertAlmostEqual(clock["frame_s"],expected_frame)
            self.assertAlmostEqual(clock["cooperative_turn_s"],expected_turn)
            self.assertAlmostEqual(options.mac_child_lead_s,expected_lead)
            self.assertGreater(options.mac_child_lead_s,0)
            self.assertLess(options.mac_child_lead_s,clock["frame_s"])
            self.assertGreaterEqual(clock["frame_s"]-options.mac_child_lead_s,options.mac_decision_interval_s)
            self.assertEqual((cfg.bit_rate,cfg.slot_duration),(16000.,.6))

    def test_load_too_small_for_native_lead_search_is_rejected(self):
        with self.assertRaisesRegex(ValueError,"strictly within"):
            build_settings(3,3,"full",V5)

    def test_halfopen_stride2_one_two_three_frames_have_one_one_two_opportunities(self):
        parent=SlotLease(epoch=0,lease_id=1,donor=4,borrower=0,slot_offset=4,
                         start_frame=10,end_frame=40,frame_stride=2)
        for frames,expected in ((1,[12]),(2,[12]),(3,[12,14])):
            child=ChildLease(parent=parent,child_id=frames,borrower=4,start_frame=12,end_frame=12+frames)
            self.assertEqual([frame for frame in range(12,12+frames) if child.active(frame)],expected)
            self.assertFalse(child.active(12+frames))
            self.assertFalse(child.active(13))
        # Parent clipping is native: a requested maximum3frame window does not
        # guarantee two opportunities near its parent's immutable expiry.
        short_parent=replace(parent,end_frame=13)
        short_child=ChildLease(parent=short_parent,child_id=4,borrower=4,start_frame=12,end_frame=13)
        self.assertEqual([frame for frame in range(12,15) if short_child.active(frame)],[12])

    def selection_fixture(self, *, n=3, time=0., offset=54, parent_start=0, lead=None):
        cfg,options,_,_=build_settings(n,30,"full",V5)
        if lead is not None:
            options=replace(options,mac_child_lead_s=lead)
        slot_owners=[]
        sensors=list(range(n+1,n+31))
        for beginning in range(0,30,3):
            slot_owners.extend(range(n+1))
            slot_owners.extend(sensors[beginning:beginning+3])
        parent=SlotLease(epoch=0,lease_id=1,donor=slot_owners[offset],borrower=0,slot_offset=offset,
                         start_frame=parent_start,end_frame=parent_start+30,frame_stride=2).to_dict()
        pool=dict(parent=parent,child_windows=[])
        calls=[]
        def propose(parent_id,borrower,start_frame,end_frame):
            calls.append(dict(parent=parent_id,borrower=borrower,start=start_frame,end=end_frame))
            return 1
        frame=len(slot_owners)*cfg.slot_duration
        net=SimpleNamespace(time=time,current_frame=int(time//frame),frame_duration=frame,slot_duration=.6,
                            cooperative_slot_gap=(n+4)*.6,slot_owners=tuple(slot_owners),
                            available_pool_leases=lambda:[pool],propose_child=propose)
        fixture=SimpleNamespace(cfg=cfg,method_options=options,network=net,
                                mac_scheduler_metrics={"child_leases_requested":0},mac_scheduler_events=[])
        fixture._c04_child_tick=lambda candidates,pools:IntentEnv._c04_child_tick(fixture,candidates,pools)
        return fixture,calls

    def test_native_selector_MIN_lead_rejects_equal_but_accepts_later(self):
        # offset53*.6=31.8, now1.8 => exactly30s MIN lead: rejected by >.
        equal,calls=self.selection_fixture(time=1.8,offset=53)
        IntentEnv._child_tick(equal,[(4,1.)])
        self.assertEqual(calls,[])
        later,calls=self.selection_fixture(time=1.8,offset=54)
        IntentEnv._child_tick(later,[(4,1.)])
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0]["end"]-calls[0]["start"],3)

    def test_native_selector_still_rejects_beyond_one_frame(self):
        beyond,calls=self.selection_fixture(time=0.,offset=4,parent_start=1)
        IntentEnv._child_tick(beyond,[(4,1.)])
        self.assertEqual(calls,[])  # first44.4s > frame42s despite passingMINlead.
        boundary,calls=self.selection_fixture(time=2.4,offset=4,parent_start=1)
        IntentEnv._child_tick(boundary,[(4,1.)])
        self.assertEqual(len(calls),1)  # first44.4-now2.4=42s is admitted.

    def qualifying_donor_offsets(self,n,*,lead=None,parent_start=0):
        cfg,options,_,_=build_settings(n,30,"full",V5)
        slot_owners=[]
        sensors=list(range(n+1,n+31))
        for beginning in range(0,30,3):
            slot_owners.extend(range(n+1))
            slot_owners.extend(sensors[beginning:beginning+3])
        period=int(len(slot_owners)*cfg.slot_duration*options.mac_frame_stride)
        tick=int(options.mac_decision_interval_s)
        qualified=set()
        # Examine one mature parent-active period; no environment/net advance
        # occurs. The existing selector is called on independent valid-parent
        # fixtures, just as its12s tick would encounter each donor phase.
        for donor in sensors:
            offset=slot_owners.index(donor)
            for time in range(period,2*period,tick):
                fixture,calls=self.selection_fixture(n=n,time=float(time),offset=offset,
                                                     parent_start=parent_start,lead=lead)
                IntentEnv._child_tick(fixture,[(n+1,1.)])
                if calls:
                    qualified.add(offset)
                    break
        return {slot_owners.index(donor) for donor in sensors},qualified

    def test_every_original_SN_donor_phase_gets_a_qualifying_native_tick(self):
        for n in(3,4):
            for parent_phase in(0,1):
                expected,qualified=self.qualifying_donor_offsets(n,parent_start=parent_phase)
                self.assertEqual(qualified,expected)
                self.assertEqual(len(qualified),30)

    def test_unclamped_management_turn_exposes_phase_alias_regression(self):
        for n,raw_lead in((3,31.5),(4,43.2)):
            expected,qualified=self.qualifying_donor_offsets(n,lead=raw_lead,parent_start=0)
            self.assertLess(len(qualified),len(expected))
            self.assertEqual(len(expected-qualified),3 if n==3 else 18)

    def test_no_original_source_mutation_or_controller_override_on_reset(self):
        originals={path:hashlib.sha256(path.read_bytes()).hexdigest() for path in SOURCE.rglob("*.py")}
        previous_reset=original_core.CooperativeEnv.reset
        for n in (3,4):
            for method in ("full","usde_only"):
                env=make_environment(n,30,method,V5)
                self.addCleanup(env.close)
                env.reset(7)
                self.assertIs(original_core.CooperativeEnv.reset,previous_reset)
                np.testing.assert_array_equal(env.auv_positions,deployment_positions(env.cfg))
                self.assertEqual(env.network.queue_options.coord_service_s,16./n)
                self.assertEqual(env.method_options.mac_child_lease_frames,3)
                self.assertIs(env.step.__func__,OriginalC07.step)
                self.assertIs(env._select_targets.__func__,OriginalC07._select_targets)
                self.assertIs(env._child_tick.__func__,IntentEnv._child_tick)
        self.assertEqual(originals,{path:hashlib.sha256(path.read_bytes()).hexdigest() for path in SOURCE.rglob("*.py")})


if __name__=="__main__":
    unittest.main()
