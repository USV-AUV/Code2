"""Existing C07 queue parameter scaling, not new slots or a motion policy."""
from dataclasses import asdict
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012.environment import make_environment,build_settings

class QueueScaleProfileTests(unittest.TestCase):
    def test_only_native_coord_service_parameter_changes_for_both_arms(self):
        for n in (2,3,4):
            settings=[]
            for method in ("full","usde_only"):
                baseline=make_environment(n,30,method,"adaptive_packet_grid_v3")
                adapted=make_environment(n,30,method,"adaptive_packet_grid_queue_v4")
                self.addCleanup(baseline.close);self.addCleanup(adapted.close)
                before=asdict(baseline.network.queue_options)
                after=asdict(adapted.network.queue_options)
                self.assertEqual(after,{**before,"coord_service_s":16./n})
                self.assertEqual(len(baseline.network.slot_owners),len(adapted.network.slot_owners))
                self.assertEqual((baseline.cfg.bit_rate,baseline.cfg.slot_duration),(adapted.cfg.bit_rate,adapted.cfg.slot_duration))
                for seed in (7,42):
                    adapted.reset(seed)
                    self.assertEqual(adapted.network.queue_options.coord_service_s,16./n)
                settings.append(adapted.cfg.to_dict())
            self.assertEqual(settings[0],settings[1])
    def test_original_two_configuration_and_options_remain_exact(self):
        for method in ("full","usde_only"):
            original=build_settings(2,30,method,"natural")
            adapted=build_settings(2,30,method,"adaptive_packet_grid_queue_v4")
            self.assertEqual(original[0].to_dict(),adapted[0].to_dict())
            self.assertEqual(asdict(original[1]),asdict(adapted[1]))
            self.assertEqual(asdict(original[2]),asdict(adapted[2]))

if __name__=="__main__": unittest.main()
