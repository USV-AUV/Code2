"""V9 integration preparation: synthetic identities and zero-step factories.

No real weights, Policy.__init__, actors, optimizers or train/probe loop run.
Native environment construction/reset tests prohibit env.step/network.advance.
Legacy seven-profile oracle is frozen V6; V8 uses a separate native-calendar
oracle derived from that frozen V5 builder, never pretending frozen V6 has V8.
"""
from copy import deepcopy
from dataclasses import asdict, fields
import inspect
import json
import math
from pathlib import Path
import sys
import unittest
from unittest import mock

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012 import environment as adapter, workflow, paths, root_budget
from exp7_c07_scaling_20261012.tests.test_calendar_profile import frozen_v6_alias, HISTORICAL_V6
from usv_auv.network import AcousticNetwork
from usv_auv.deploy import environment_schema
from usv_auv.config import Config as OriginalConfig
from v6_candidates.c07.environment import TaskV4Env as OriginalC07, MethodOptions as OriginalOptions
from v6_candidates.c04.environment import TaskV4Env as IntentEnv


V5 = "adaptive_packet_grid_window_v5"
V8 = "adaptive_packet_grid_calendar_v8"
V9 = root_budget.ROOT_BUDGET_PROFILE
LEGACY_SEVEN = ("natural", "adaptive_v1", "adaptive_packet_v2", "adaptive_packet_grid_v3",
                "adaptive_packet_grid_queue_v4", V5, "adaptive_packet_grid_pool_v6")
BOUND_NAMES = ("Config", "TaskV4Env", "MethodOptions", "sources", "TRAIN_FORMAT", "INFERENCE_FORMAT",
               "MAX_TRAIN_STEPS", "load_checkpoint", "save_bundle", "atomic_json")


def changed(left, right):
    return {key: {"old": left.get(key), "new": value}
            for key, value in right.items() if left.get(key) != value}


def v8_native_oracle(old, n, sensors, method, faults):
    """Independent pre-V9 calendar semantics on the immutable V5 builder."""
    cfg, mo, ro, diagnostic = old.build_settings(n, sensors, method, V5, faults)
    result = deepcopy(diagnostic)
    result["profile"] = V8
    if n == 2:
        return cfg, mo, ro, result
    raw = cfg.to_dict()
    raw["tdma_sensors_per_group"] = n+1
    new_cfg = old.ScaleConfig.from_dict(raw)
    clock = old._clock_diagnostics(new_cfg)
    reference, reference_mo, _ = old._reference(old.canonical_method(method))
    budget = float(math.ceil(clock["service_retry_interval_s"]))
    raw["service_ack_timeout"] = max(reference["service_ack_timeout"], budget)
    raw["grant_ttl"] = max(reference["grant_ttl"], budget)
    new_cfg = old.ScaleConfig.from_dict(raw)
    values = asdict(mo)
    values["mac_child_lead_s"] = min(clock["cooperative_turn_s"], clock["frame_s"]-mo.mac_decision_interval_s)
    new_mo = OriginalOptions(**values)
    result.update(clock=clock, config_changes=changed(reference, new_cfg.to_dict()),
                  option_changes=changed(reference_mo, values))
    result["child_window_adaptation"].update(
        minimum_command_lead_s=new_mo.mac_child_lead_s,
        native_next_opportunity_search_max_s=clock["frame_s"],
        eligible_phase_width_s=clock["frame_s"]-new_mo.mac_child_lead_s)
    before, after = AcousticNetwork(cfg, cfg.seed), AcousticNetwork(new_cfg, new_cfg.seed)
    old_frame, frame = len(before.slot_owners)*cfg.slot_duration, clock["frame_s"]
    old_coop, coop = before.slot_owners.count(0), after.slot_owners.count(0)
    native_caps = {"mac_pool_slots": [2,16], "mac_auv_slots": [1,8], "mac_max_leases": [1,30],
                   "mac_child_max_active": [1,8], "mac_child_slots_per_sensor": [1,4], "mac_child_lease_frames": [1,3]}
    result["calendar_adaptation"] = dict(
        inherited_profile=V5, root_parameter="Config.tdma_sensors_per_group",
        root_parameter_changes={"tdma_sensors_per_group": {"old": cfg.tdma_sensors_per_group, "new": n+1}},
        declared_config_diff_from_v5=changed(cfg.to_dict(), new_cfg.to_dict()),
        declared_option_diff_from_v5=changed(asdict(mo), values), routing_options_unchanged_from_v5=True,
        calendar_source="unchanged usv_auv.network.AcousticNetwork native grouping algorithm",
        slot_count_rule="n_sensors + (n_auv + 1) * ceil(n_sensors / tdma_sensors_per_group)",
        old_slot_count=len(before.slot_owners), new_slot_count=len(after.slot_owners),
        old_frame_s=old_frame, new_frame_s=frame, sn_home_opportunities_per_frame=1,
        old_sn_home_opportunities_per_s=1./old_frame, new_sn_home_opportunities_per_s=1./frame,
        old_cooperative_opportunities_per_node_per_frame=old_coop,
        new_cooperative_opportunities_per_node_per_frame=coop,
        old_cooperative_opportunities_per_node_per_s=old_coop/old_frame,
        new_cooperative_opportunities_per_node_per_s=coop/frame,
        old_max_cooperative_gap_s=before.cooperative_slot_gap, new_max_cooperative_gap_s=after.cooperative_slot_gap,
        old_parent_lease_max_s=mo.mac_coop_lease_frames*old_frame,
        new_parent_lease_max_s=new_mo.mac_coop_lease_frames*frame,
        old_unclipped_child_window_s=mo.mac_child_lease_frames*old_frame,
        new_unclipped_child_window_s=new_mo.mac_child_lease_frames*frame,
        old_parent_active_opportunity_spacing_s=mo.mac_frame_stride*old_frame,
        new_parent_active_opportunity_spacing_s=new_mo.mac_frame_stride*frame,
        old_protected_sensor_home_gap_s=2*old_frame, new_protected_sensor_home_gap_s=2*frame,
        native_mac_budget=dict(n_auv=n, nominal_requested_parent_rights=mo.mac_pool_slots+n*mo.mac_auv_slots,
                              declared_global_parent_limit=mo.mac_max_leases, native_caps=native_caps),
        mac_demand_report_interval_s=72., clocks_rederived_from_actual_native_calendar=True,
        channel_airtime_redistributed=True, physical_slots_or_bitrate_added=False,
        new_scheduler_or_information=False, constructor_selects_or_trains=False,
        selection_status="This constructor does not select or launch candidates; consult the external campaign plan and actual ledger",
        tradeoff="Existing channel airtime is redistributed from ROOT/AUV cooperative opportunities to SN home opportunities. Cooperative opportunity frequency decreases and maximum gaps increase: paid STATE/COORD/REQUEST/ACK and MAC setup may get worse, including relative to USDE-only. Frame-counted parent lease seconds, child opportunity spacing/window seconds and protected home gaps change with the native frame. Original frame limits and native caps remain unchanged. No delivery, throughput, safety or ordering guarantee; no candidate selection or training result is implied.")
    return new_cfg, new_mo, ro, result


def context(n=4, method="full", profile=V9):
    value = workflow.declaration(n, 30, method, profile, faults=[])
    return dict(version=workflow.VERSION, profile=profile, declaration=value,
                declaration_sha256=workflow.digest_json(value), stage="development")


def synthetic_checkpoint(value):
    declared = value["declaration"]
    cfg = adapter.ScaleConfig.from_dict(declared["config"])
    spec = workflow.native.get_method(declared["method"])
    return dict(format=workflow.INFERENCE_FORMAT, scale_context=deepcopy(value), global_step=0, seed=7,
                method_id=spec.method_id, method_spec=spec.to_dict(), method_fingerprint=spec.fingerprint,
                environment_config=cfg.to_dict(), config_fingerprint=cfg.fingerprint,
                method_options=deepcopy(declared["method_options"]), routing_options=deepcopy(declared["routing_options"]),
                learning_config=deepcopy(declared["learning"]), training_protocol=deepcopy(declared["training_protocol"]),
                revision_learning_options=asdict(workflow.native.RevisionLearningOptions(
                    area_size=cfg.area_size, max_speed=cfg.max_speed, dt=cfg.dt, action_frame=cfg.action_frame)),
                source_hashes=workflow.source_hashes(), agents=[{"actor": {}} for _ in range(cfg.n_auv)],
                topology={"online": {}} if spec.use_topology else None)


class RootBudgetBuilderContracts(unittest.TestCase):
    def test_explicit_registration_and_default_preserved(self):
        self.assertEqual(adapter.PROFILES, LEGACY_SEVEN+(V8,V9,"adaptive_packet_grid_n4_child_h2_v11")+adapter.joint_clocks.PROFILES)
        self.assertEqual(adapter.build_settings.__defaults__[0], "adaptive_v1")

    def test_complete_V5_cfg_ro_clock_and_all_nonbudget_MO_preserved(self):
        for n in (3,4):
            for method in ("full", "usde_only"):
                before = adapter.build_settings(n,30,method,V5)
                after = adapter.build_settings(n,30,method,V9)
                cfg, mo, ro, d = after
                self.assertEqual(cfg.to_dict(), before[0].to_dict())
                self.assertEqual(asdict(ro), asdict(before[2]))
                self.assertEqual(d["clock"], before[3]["clock"])
                self.assertEqual(d["child_window_adaptation"], before[3]["child_window_adaptation"])
                expected = {"mac_pool_slots": {"old": 12 if n==3 else 14, "new": 15 if n==3 else 20},
                            "mac_auv_slots": {"old": 3, "new": 2}}
                if n==4:
                    expected["mac_max_leases"] = {"old": 26, "new": 28}
                self.assertEqual(changed(asdict(before[1]),asdict(mo)), expected)
                self.assertEqual(d["root_budget_adaptation"]["declared_option_diff_from_v5"], expected)
                self.assertEqual(d["root_budget_adaptation"]["declared_config_diff_from_v5"], {})
                self.assertEqual(tuple(fields(mo)),tuple(fields(OriginalOptions)))
                self.assertEqual((cfg.tdma_sensors_per_group,mo.mac_child_lease_frames,mo.mac_coop_lease_frames,
                                  mo.mac_frame_stride,mo.mac_demand_report_interval_s),(3,3,30,2,72.))
                self.assertEqual(type(mo), OriginalOptions if n==3 else root_budget._RegisteredN4RootBudgetOptions)

    def test_n2_entire_cfg_MO_RO_and_diagnostics_except_profile_are_original(self):
        for method in ("full_v6", "usde_only_v6"):
            before = adapter.build_settings(2,30,method,V5)
            after = adapter.build_settings(2,30,method,V9)
            self.assertIs(type(after[0]),OriginalConfig)
            self.assertIs(type(after[1]),OriginalOptions)
            self.assertEqual(after[0].to_dict(), before[0].to_dict())
            self.assertEqual(asdict(after[1]),asdict(before[1]))
            self.assertEqual(asdict(after[2]),asdict(before[2]))
            a,b=deepcopy(after[3]),deepcopy(before[3])
            a.pop("profile");b.pop("profile")
            self.assertEqual(a,b)
            self.assertNotIn("root_budget_adaptation",after[3])

    def test_same_scale_full_USDE_common_config_and_options(self):
        for n in (2,3,4):
            full=adapter.build_settings(n,30,"full",V9)
            usde=adapter.build_settings(n,30,"usde_only",V9)
            self.assertEqual(full[0].to_dict(),usde[0].to_dict())
            self.assertEqual(asdict(full[2]),asdict(usde[2]))
            a,b=asdict(full[1]),asdict(usde[1])
            self.assertTrue(a.pop("mac_enabled"));self.assertFalse(b.pop("mac_enabled"))
            self.assertEqual(a,b)
            if n>2:self.assertEqual(full[3]["root_budget_adaptation"],usde[3]["root_budget_adaptation"])

    def test_only_common30_scope_and_old_native_cap_remain(self):
        for n in (3,4):
            for sensors in (n,29,31,45,60):
                with self.subTest(n=n,sensors=sensors),self.assertRaises(ValueError):
                    adapter.build_settings(n,sensors,"full",V9)
        options=asdict(adapter.build_settings(4,30,"full",V9)[1])
        with self.assertRaisesRegex(ValueError,"mac_pool_slots"):
            OriginalOptions(**options)
        with self.assertRaisesRegex(ValueError,"Native C07"):
            adapter.validate_scale_mac_budget(4,options)

    def test_domain_proof_has_logical_source_SHA_and_no_absolute_paths(self):
        for n in (3,4):
            value=workflow.declaration(n,30,"full",V9)
            d=value["scale_diagnostics"]["root_budget_adaptation"]
            self.assertEqual(d["nominal_root_remainder_if_child_cap_fully_occupied"],3*n)
            self.assertEqual(d["nominal_global_parent_rights"],21 if n==3 else 28)
            self.assertEqual(d["validation_domain_scale_port"],n==4)
            self.assertEqual(d["originally_validated_pool_configuration"],n!=4)
            proof=d["n4_scoped_validation_domain_proof"]
            self.assertNotIn("original_source",proof)
            self.assertEqual(proof["original_source_key"],"original/v6_candidates/c03/environment.py")
            self.assertEqual(proof["original_source_sha256"],workflow.source_hashes()[proof["original_source_key"]])
            self.assertEqual(proof["changed_ast_sites"],1)
            self.assertTrue(proof["remaining_validator_AST_identical"])
            self.assertTrue(proof["method_options_schema_unchanged"])
            self.assertFalse(d["physical_slots_or_bitrate_added"])
            self.assertFalse(d["new_scheduler_or_information"])
            self.assertFalse(d["constructor_selects_or_trains"])
            encoded=json.dumps(value,sort_keys=True,allow_nan=False)
            self.assertNotIn(str(paths.SOURCE),encoded)
            self.assertNotIn("C:\\",encoded)
            self.assertEqual(json.loads(encoded),value)

    def test_legacy_seven_complete_dictionary_regression_against_frozen_V6(self):
        if not HISTORICAL_V6.is_file():self.skipTest("Historical immutable V6 oracle not packaged")
        old=frozen_v6_alias()
        self.assertEqual(old.PROFILES,LEGACY_SEVEN)
        for profile in LEGACY_SEVEN:
            for n,sensors in ((2,30),(3,30),(4,30),(3,45),(4,60)):
                for method in ("full","usde_only"):
                    for faults in (None,[]):
                        with self.subTest(profile=profile,n=n,sensors=sensors,method=method,faults=faults):
                            a=adapter.build_settings(n,sensors,method,profile,faults)
                            b=old.build_settings(n,sensors,method,profile,faults)
                            self.assertEqual(a[0].to_dict(),b[0].to_dict())
                            self.assertEqual(asdict(a[1]),asdict(b[1]))
                            self.assertEqual(asdict(a[2]),asdict(b[2]))
                            self.assertEqual(a[3],b[3])

    def test_V8_complete_dictionary_regression_against_independent_native_oracle(self):
        if not HISTORICAL_V6.is_file():self.skipTest("Historical immutable V5 builder not packaged")
        old=frozen_v6_alias()
        for n,sensors in ((2,30),(3,30),(4,30),(3,45),(4,60)):
            for method in ("full","usde_only"):
                for faults in (None,[]):
                    with self.subTest(n=n,sensors=sensors,method=method,faults=faults):
                        a=adapter.build_settings(n,sensors,method,V8,faults)
                        b=v8_native_oracle(old,n,sensors,method,faults)
                        self.assertEqual(a[0].to_dict(),b[0].to_dict())
                        self.assertEqual(asdict(a[1]),asdict(b[1]))
                        self.assertEqual(asdict(a[2]),asdict(b[2]))
                        self.assertEqual(a[3],b[3])

    def test_learning_training_protocol_reward_action_and_ending_unchanged(self):
        for n in (2,3,4):
            for method in ("full","usde_only"):
                old,new=workflow.declaration(n,30,method,V5),workflow.declaration(n,30,method,V9)
                for key in ("config","learning","training_protocol","routing_options","reward","ending","old_weights_allowed"):
                    self.assertEqual(new[key],old[key])


class RootBudgetBindingContracts(unittest.TestCase):
    def globals(self):return {name:getattr(workflow.native,name) for name in BOUND_NAMES}
    def assert_restored(self,values):
        for name,value in values.items():self.assertIs(getattr(workflow.native,name),value,name)

    def test_recursive_JSON_comparison_does_not_coerce_types(self):
        self.assertTrue(workflow.json_value_type_exact({"a":[True,1,1.,None]}, {"a":[True,1,1.,None]}))
        for a,b in ((True,1),(1,1.),([1],[1.]),({"a":False},{"a":0}),([1],(1,)),
                    ({1:"a"},{1:"a"}),(float("nan"),float("nan")),(float("inf"),float("inf"))):
            with self.subTest(a=a,b=b):self.assertFalse(workflow.json_value_type_exact(a,b))

    def test_original_native_default_only_mac_enabled_and_old_context_constructors(self):
        for method in ("full_v6","usde_only_v6"):
            ctx=context(4,method)
            with workflow.bindings(ctx):
                default=workflow.native.default_method_options(method)
                self.assertIs(type(default),OriginalOptions)
                self.assertEqual(default.mac_pool_slots,10)
                self.assertEqual(default.mac_enabled,method=="full_v6")
                with self.assertRaises(ValueError):workflow.native.MethodOptions(mac_enabled=1)
        for profile in LEGACY_SEVEN+(V8,):
            cfg,mo,_,_=adapter.build_settings(4,30,"full",profile)
            with workflow.bindings({"profile":profile}):
                made=workflow.native.MethodOptions(**asdict(mo))
                self.assertIs(type(made),OriginalOptions)
                self.assertEqual(asdict(made),asdict(mo))
                with self.assertRaisesRegex(ValueError,"mac_pool_slots"):
                    workflow.native.MethodOptions(**context()["declaration"]["method_options"])

    def test_complete_candidate_options_require_exact_authenticated_context(self):
        for n in (2,3,4):
            for method in ("full","usde_only"):
                ctx=context(n,method)
                with workflow.bindings(ctx):
                    mo=workflow.native.MethodOptions(**ctx["declaration"]["method_options"])
                    self.assertEqual(asdict(mo),ctx["declaration"]["method_options"])
                    self.assertIs(type(mo),OriginalOptions if n<4 else root_budget._RegisteredN4RootBudgetOptions)
                self.assertIsNone(root_budget._CONSTRUCTION_SCOPE.get())

    def test_value_or_type_drift_and_partial_pool20_never_reconstruct(self):
        ctx=context()
        for field,value in (("mac_pool_slots",20.),("mac_auv_slots",2.),("mac_enabled",1),
                            ("mac_child_lead_s",36),("mac_decision_interval_s",12),
                            ("mac_max_leases",27),("mac_routed_auv_commits",1)):
            bad={**ctx["declaration"]["method_options"],field:value}
            with self.subTest(field=field,value=value),workflow.bindings(ctx):
                with self.assertRaisesRegex(ValueError,"JSON value and type"):
                    workflow.native.MethodOptions(**bad)
        with workflow.bindings(ctx):
            with self.assertRaisesRegex(ValueError,"mac_pool_slots"):
                workflow.native.MethodOptions(mac_enabled=True,mac_pool_slots=20)

    def test_wrong_scope_missing_SHA_or_forged_typed_declaration_rejected(self):
        values=context()["declaration"]["method_options"]
        contexts=[{"profile":V9}, {**context(),"declaration_sha256":"0"*64}]
        for key,value in (("n_auv",4.),("n_sensors",29),("profile",V5),("old_weights_allowed",0)):
            bad=context();bad["declaration"][key]=value
            bad["declaration_sha256"]=workflow.digest_json(bad["declaration"])
            contexts.append(bad)
        bad=context();bad["declaration"]["method_options"]["mac_enabled"]=1
        bad["declaration_sha256"]=workflow.digest_json(bad["declaration"]);contexts.append(bad)
        for bad in contexts:
            with self.subTest(bad=bad),workflow.bindings(bad):
                with self.assertRaises(ValueError):workflow.native.MethodOptions(**values)
                self.assertIs(type(workflow.native.MethodOptions(mac_enabled=True)),OriginalOptions)

    def test_context_snapshot_and_all_native_globals_restore_on_nested_exception(self):
        before=self.globals();outer=context()
        with self.assertRaisesRegex(RuntimeError,"synthetic"):
            with workflow.bindings(outer):
                active=self.globals()
                saved=deepcopy(outer["declaration"]["method_options"])
                outer["declaration"]["method_options"]["mac_pool_slots"]=16
                self.assertEqual(workflow.native.MethodOptions(**saved).mac_pool_slots,20)
                with workflow.bindings({"profile":V5}):
                    with self.assertRaisesRegex(ValueError,"mac_pool_slots"):
                        workflow.native.MethodOptions(**saved)
                    with workflow.bindings(context(3)):
                        self.assertEqual(workflow.native.MethodOptions(**context(3)["declaration"]["method_options"]).mac_pool_slots,15)
                        with self.assertRaises(ValueError):workflow.native.MethodOptions(**saved)
                self.assert_restored(active)
                self.assertEqual(workflow.native.MethodOptions(**saved).mac_pool_slots,20)
                raise RuntimeError("synthetic binding failure")
        self.assert_restored(before)
        self.assertIs(workflow.native.MethodOptions,OriginalOptions)

    def test_native_fresh_and_resume_run_options_reconstruct_exact_declaration(self):
        for n in (3,4):
            for method in ("full","usde_only"):
                ctx=context(n,method);declared=ctx["declaration"]
                saved={"method_id":declared["method"],"method_options":declared["method_options"],
                       "routing_options":declared["routing_options"]}
                with workflow.bindings(ctx):
                    for record in (None,saved):
                        mo,ro=workflow.native.run_options(record,declared["method_options"],
                                                        declared["routing_options"],declared["method"])
                        self.assertEqual(asdict(mo),declared["method_options"])
                        self.assertEqual(asdict(ro),declared["routing_options"])
                    with self.assertRaises(ValueError):
                        workflow.native.run_options(saved,{**declared["method_options"],"mac_auv_slots":3},
                                                    method_id=declared["method"])

    def test_V9_saved_metadata_uses_same_frozen_declaration_as_constructor(self):
        ctx=context();expected=deepcopy(ctx);values=expected["declaration"]["method_options"]
        with mock.patch.object(workflow.native,"save_bundle") as save, \
             mock.patch.object(workflow.native,"atomic_json") as publish:
            with workflow.bindings(ctx):
                ctx["declaration"]["method_options"]["mac_pool_slots"]=16
                workflow.native.save_bundle({"method_options":values},"unused_no_file")
                written=save.call_args.args[0]
                self.assertTrue(workflow.json_value_type_exact(written["scale_context"],expected))
                written["scale_context"]["declaration"]["method_options"]["mac_pool_slots"]=1
                workflow.native.atomic_json({"status":"synthetic"},"manifest.json")
                self.assertTrue(workflow.json_value_type_exact(publish.call_args.args[0]["scale_context"],expected))
                self.assertEqual(workflow.native.MethodOptions(**values).mac_pool_slots,20)

    def test_nested_writes_keep_inner_checkpoint_and_manifest_identity(self):
        pairs=((context(4,profile=V9),context(3,profile=V9)),
               (context(4,profile=V9),context(3,profile=V5)),
               (context(4,profile=V5),context(3,profile=V9)))
        for outer,inner in pairs:
            with self.subTest(outer=outer["profile"],inner=inner["profile"]):
                with mock.patch.object(workflow.native,"save_bundle") as save, \
                     mock.patch.object(workflow.native,"atomic_json") as publish:
                    before=self.globals()
                    checkpoint={"method_options":deepcopy(inner["declaration"]["method_options"])}
                    original=deepcopy(checkpoint)
                    with workflow.bindings(outer):
                        outer_globals=self.globals()
                        with workflow.bindings(inner):
                            inner_globals=self.globals()
                            self.assertIs(workflow._binding_writer_target(workflow.native.save_bundle,"save_bundle"),save)
                            self.assertIs(workflow._binding_writer_target(workflow.native.atomic_json,"atomic_json"),publish)
                            workflow.native.save_bundle(checkpoint,"unused_nested_no_file",True)
                            saved=save.call_args.args[0]
                            self.assertTrue(workflow.json_value_type_exact(saved["scale_context"],inner))
                            self.assertTrue(workflow.json_value_type_exact(saved["method_options"],inner["declaration"]["method_options"]))
                            for filename in ("manifest.json","summary.json"):
                                workflow.native.atomic_json({"status":"synthetic"},filename)
                                self.assertTrue(workflow.json_value_type_exact(publish.call_args.args[0]["scale_context"],inner))
                            workflow.native.atomic_json({"status":"synthetic"},"progress.json")
                            self.assertNotIn("scale_context",publish.call_args.args[0])
                            with self.assertRaisesRegex(RuntimeError,"nested synthetic"):
                                with workflow.bindings(context(2,profile=V9)):
                                    raise RuntimeError("nested synthetic writer failure")
                            self.assert_restored(inner_globals)
                        self.assert_restored(outer_globals)
                        workflow.native.save_bundle({},"unused_outer_no_file")
                        self.assertTrue(workflow.json_value_type_exact(save.call_args.args[0]["scale_context"],outer))
                        workflow.native.atomic_json({},"manifest.json")
                        self.assertTrue(workflow.json_value_type_exact(publish.call_args.args[0]["scale_context"],outer))
                    self.assert_restored(before)
                    self.assertEqual(checkpoint,original)
                    self.assertEqual(save.call_count,2)
                    self.assertEqual(publish.call_count,4)


class RootBudgetLoaderAndZeroStepContracts(unittest.TestCase):
    def test_mock_snapshot_loader_type_exact_config_MO_and_declaration(self):
        for n in (2,3,4):
            for method in ("full","usde_only"):
                saved=synthetic_checkpoint(context(n,method))
                with mock.patch.object(workflow,"raw_load",return_value=saved) as loader:
                    self.assertIs(workflow.load_new_checkpoint("unused_synthetic_no_weights.pt"),saved)
                    loader.assert_called_once_with("unused_synthetic_no_weights.pt")
        saved=synthetic_checkpoint(context())
        cases=[]
        for section,field,value in (("method_options","mac_pool_slots",20.),
                                    ("method_options","mac_child_lead_s",36),
                                    ("environment_config","service_grant_aware",1),
                                    ("learning_config","hidden_dim",128.)):
            bad=deepcopy(saved);bad[section][field]=value;cases.append(bad)
        bad=deepcopy(saved);bad["scale_context"]["declaration"]["old_weights_allowed"]=0;cases.append(bad)
        for bad in cases:
            with self.subTest(bad=bad),mock.patch.object(workflow,"raw_load",return_value=bad):
                with self.assertRaises(ValueError):workflow.load_new_checkpoint("unused_synthetic_no_weights.pt")

    def test_original_NativePolicy_validate_settings_factory_and_reset_zero_steps(self):
        with mock.patch.object(OriginalC07,"step",side_effect=AssertionError("ENV.step forbidden")), \
             mock.patch.object(AcousticNetwork,"advance",side_effect=AssertionError("network.advance forbidden")):
            for n in (2,3,4):
                for method in ("full","usde_only"):
                    ctx=context(n,method);saved=synthetic_checkpoint(ctx)
                    cfg=adapter.ScaleConfig.from_dict(saved["environment_config"])
                    direct=adapter.make_environment(n,30,method,V9,faults=[])
                    self.addCleanup(direct.close)
                    direct.reset(42)
                    self.assertEqual((direct.step_count,direct.time,direct.network.time,direct.network._slot_index),(0,0.,0.,0))
                    policy=object.__new__(workflow.native.Policy)
                    policy.cfg=cfg;policy.method=direct.method;policy.checkpoint=saved
                    policy.schema=environment_schema(direct)
                    with workflow.bindings(ctx):
                        workflow.native.validate_settings(saved,cfg)
                        made=policy.make_environment()
                        self.addCleanup(made.close)
                        made.reset(42)
                        policy.validate_environment(made)
                        self.assertEqual(made.cfg.to_dict(),ctx["declaration"]["config"])
                        self.assertEqual(asdict(made.method_options),ctx["declaration"]["method_options"])
                        self.assertEqual(environment_schema(made),policy.schema)
                        self.assertEqual((made.step_count,made.time,made.network.time,made.network._slot_index),(0,0.,0.,0))
                        self.assertEqual(made.network.slot_owners,direct.network.slot_owners)
                        self.assertEqual(made.network.frame_duration,{2:36.,3:42.,4:48.}[n])
                        if n>2:self.assertIs(made._child_tick.__func__,IntentEnv._child_tick)
                    self.assertFalse(hasattr(policy,"actors"));self.assertFalse(hasattr(policy,"topology"))
        self.assertIs(adapter.ScaledC07Env.step,OriginalC07.step)
        self.assertIs(workflow.native.MethodOptions,OriginalOptions)

    def test_original_functions_learners_and_scientific_source_identities_are_retained(self):
        invariants={name:getattr(workflow.native,name) for name in
                    ("Policy","train","run_options","validate_settings","default_method_options",
                     "ImprovedTD3Agent","MaskedDoubleDQN","learning_config","training_protocol")}
        native_validator=OriginalOptions.__dict__["__post_init__"]
        with workflow.bindings(context()):
            for name,value in invariants.items():self.assertIs(getattr(workflow.native,name),value)
            self.assertIs(OriginalOptions.__dict__["__post_init__"],native_validator)
        manifest=paths.EXPERIMENT/"iterative_candidates_20261012"/"packet_grid_window_v5"/"code"/"PACKAGE_MANIFEST.json"
        if manifest.is_file():
            old=json.loads(manifest.read_text(encoding="utf-8"))["source_hashes"]
            keys={key for key in old if key.startswith(("original/","reference/"))}
            self.assertEqual(len(keys),110)
            now=workflow.source_hashes()
            self.assertEqual({key:now[key] for key in keys},{key:old[key] for key in keys})
        for item in invariants.values():
            self.assertTrue(Path(inspect.getfile(item)).resolve().is_relative_to(paths.SOURCE.resolve()))


if __name__=="__main__":unittest.main(verbosity=2)
