"""Prepared root-budget constructor contracts: no ENV/net steps or learning.

Fixtures are in-memory original MethodOptions dictionaries, ASTs and harmless
dataclass pickle records. No environment, scheduler, actor, optimizer, real
checkpoint, probe, training, profile registration or loader binding executes.
All30-donor permission/ACK/commit/drop fixtures are explicitly outside scope.
"""
import ast
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from dataclasses import FrozenInstanceError, asdict, fields
import hashlib
import inspect
import json
from pathlib import Path
import pickle
import sys
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012 import environment as adapter
_PROFILES_BEFORE_HELPER_IMPORT = adapter.PROFILES
from exp7_c07_scaling_20261012 import root_budget as port
from v6_candidates.c07.environment import MethodOptions as OriginalC07Options
from v6_candidates.c03.environment import MethodOptions as OriginalC03Options
from v6_candidates.c04.environment import MethodOptions as OriginalC04Options
from v6_candidates.c06.environment import MethodOptions as OriginalC06Options


V5 = "adaptive_packet_grid_window_v5"
V9 = port.ROOT_BUDGET_PROFILE
REGISTERED = (V5, V9)  # Synthetic caller registry; never mutate adapter.PROFILES.
OLD_PROFILES = tuple(profile for profile in adapter.PROFILES if profile != V9)


def v5_fixture(n, mac_enabled=True):
    """Synthetic field dictionary for native/V5 options, not a real model."""
    values = asdict(OriginalC07Options(mac_enabled=mac_enabled))
    if n > 2:
        values.update(mac_pool_slots=6+2*n, mac_max_leases=6+5*n,
                      mac_child_max_active=2*n, mac_child_slots_per_sensor=2,
                      mac_child_lease_frames=3, mac_child_lead_s=30. if n == 3 else 36.)
    return values


def candidate_fixture(n, mac_enabled=True):
    values = v5_fixture(n, mac_enabled)
    if n > 2:
        values.update(port.registered_budget_values(n))
    return values


def build(n, values=None, *, profile=V9, sensors=30, registered_profiles=REGISTERED):
    return port.build_root_budget_method_options(n, sensors, profile,
        candidate_fixture(n) if values is None else values, registered_profiles=registered_profiles)


class RootBudgetScopeContracts(unittest.TestCase):
    def test_module_does_not_register_profile_or_change_defaults(self):
        self.assertIs(adapter.PROFILES, _PROFILES_BEFORE_HELPER_IMPORT)
        self.assertEqual(adapter.build_settings.__defaults__[0], "adaptive_v1")
        self.assertEqual(adapter.make_environment.__defaults__[0], "adaptive_v1")
        self.assertEqual(port.build_root_budget_method_options.__kwdefaults__["registered_profiles"], ())

    def test_n3_is_exact_native_class_and_n4_only_scoped_native_subclass(self):
        for n, pool, children, global_cap in ((3, 15, 6, 21), (4, 20, 8, 28)):
            for enabled in (True, False):
                before = v5_fixture(n, enabled)
                requested = candidate_fixture(n, enabled)
                actual = build(n, requested)
                self.assertEqual(asdict(actual), requested)
                self.assertIs(type(actual), OriginalC07Options if n == 3 else port._RegisteredN4RootBudgetOptions)
                self.assertIsInstance(actual, OriginalC07Options)
                self.assertEqual((actual.mac_pool_slots, actual.mac_auv_slots, actual.mac_max_leases),
                                 (pool, 2, global_cap))
                self.assertEqual(actual.mac_child_max_active, children)
                self.assertEqual(pool-children, 3*n)
                self.assertEqual(pool+n*actual.mac_auv_slots, global_cap)
                self.assertLessEqual(global_cap, 30)
                changed = {key for key in before if before[key] != requested[key]}
                self.assertEqual(changed, {"mac_pool_slots", "mac_auv_slots"} if n == 3 else
                                 {"mac_pool_slots", "mac_auv_slots", "mac_max_leases"})
                for key in set(before)-changed:
                    self.assertEqual(asdict(actual)[key], before[key])
                self.assertEqual((actual.mac_child_lease_frames, actual.mac_frame_stride,
                                  actual.mac_coop_lease_frames, actual.mac_demand_report_interval_s),
                                 (3, 2, 30, 72.))

    def test_n2_entire_native_options_and_class_preserved_even_if_v9_registered(self):
        for enabled in (True, False):
            expected = v5_fixture(2, enabled)
            for profile in adapter.PROFILES+(V9, "not_registered"):
                actual = build(2, expected, profile=profile)
                self.assertIs(type(actual), OriginalC07Options)
                self.assertEqual(asdict(actual), expected)
                self.assertEqual((actual.mac_pool_slots, actual.mac_child_max_active,
                                  actual.mac_auv_slots, actual.mac_max_leases), (10, 4, 3, 16))

    def test_old_unregistered_and_n2_constructors_never_gain_pool20(self):
        values = candidate_fixture(4)
        for n in (2, 3, 4):
            for profile in OLD_PROFILES+("unknown_profile",):
                for registry in ((), OLD_PROFILES, OLD_PROFILES+(V9,)):
                    with self.subTest(n=n, profile=profile, registry=registry):
                        with self.assertRaisesRegex(ValueError, "mac_pool_slots"):
                            build(n, values, profile=profile, registered_profiles=registry)
        for registry in ((), OLD_PROFILES):
            with self.assertRaisesRegex(ValueError, "mac_pool_slots"):
                build(4, values, registered_profiles=registry)
        with self.assertRaisesRegex(ValueError, "mac_pool_slots"):
            build(2, values, registered_profiles=REGISTERED)
        with self.assertRaisesRegex(ValueError, "mac_pool_slots"):
            OriginalC07Options(**values)
        with self.assertRaisesRegex(ValueError, "constructor scope"):
            port._RegisteredN4RootBudgetOptions(**values)
        with self.assertRaisesRegex(ValueError, "constructor scope"):
            port._C03RootBudgetValidation(**asdict(OriginalC03Options()))

    def test_old_profiles_return_native_options_with_original_clipping_semantics(self):
        # Original natural n3/n4 may request more nominal rights than the
        # historical shared16 cap. Do not retrofit V9's actual-n check here.
        original = v5_fixture(2)
        for n in (2, 3, 4):
            for profile in OLD_PROFILES+("unknown_profile", V9):
                actual = build(n, original, profile=profile, registered_profiles=OLD_PROFILES)
                self.assertIs(type(actual), OriginalC07Options)
                self.assertEqual(asdict(actual), original)
                if n > 2:
                    self.assertGreater(actual.mac_pool_slots+n*actual.mac_auv_slots, actual.mac_max_leases)

    def test_exact_registered_tuple_only_and_no_general_pool17_to20_domain(self):
        good = candidate_fixture(4)
        for pool in (2, 15, 16, 17, 18, 19, 21, 30):
            with self.subTest(pool=pool), self.assertRaises(ValueError):
                build(4, {**good, "mac_pool_slots": pool})
        mutations = {"mac_auv_slots": (1, 3), "mac_max_leases": (29, 30),
                     "mac_child_max_active": (6, 7), "mac_child_slots_per_sensor": (1, 3),
                     "mac_coop_lease_frames": (15, 29), "mac_frame_stride": (3, 4),
                     "mac_child_lease_frames": (1, 2)}
        for field, values in mutations.items():
            for value in values:
                expected = "Actual n_auv" if field == "mac_auv_slots" and value == 3 else "registered"
                with self.subTest(field=field, value=value), self.assertRaisesRegex(ValueError, expected):
                    build(4, {**good, field: value})

    def test_actual_n_global_sensor_bound_and_root_surplus_checked(self):
        for n in (3, 4):
            values = candidate_fixture(n)
            with self.assertRaisesRegex(ValueError, "Actual n_auv"):
                build(n, {**values, "mac_max_leases": values["mac_max_leases"]-1})
            with self.assertRaisesRegex(ValueError, "Actual n_auv"):
                build(n, {**values, "mac_max_leases": 31})
            with self.assertRaisesRegex(ValueError, "root rights"):
                build(n, {**values, "mac_child_max_active": values["mac_pool_slots"]})
            for sensors in (n, 20, 29, 31, 45, 60):
                with self.subTest(n=n, sensors=sensors), self.assertRaisesRegex(ValueError, "common30"):
                    build(n, values, sensors=sensors)

    def test_identity_and_budget_fields_are_strictly_typed_without_coercion(self):
        for n in (True, 3., "4", 1, 5):
            with self.subTest(n=n), self.assertRaises(ValueError):
                build(n, candidate_fixture(4))
        for sensors in (True, 30., "30", 0):
            with self.subTest(sensors=sensors), self.assertRaises(ValueError):
                build(4, sensors=sensors)
        for profile in (True, None, 9):
            with self.subTest(profile=profile), self.assertRaises(ValueError):
                build(4, profile=profile)
        for registry in ([V9], (V9, V9), (V9, True), V9):
            with self.subTest(registry=registry), self.assertRaises(ValueError):
                build(4, registered_profiles=registry)
        for field in port.BUDGET_FIELDS:
            for value in (True, False, float(candidate_fixture(4)[field]), str(candidate_fixture(4)[field])):
                with self.subTest(field=field, value=value), self.assertRaisesRegex(ValueError, "integer"):
                    build(4, {**candidate_fixture(4), field: value})

    def test_complete_original_schema_required_no_extra_metadata(self):
        values = candidate_fixture(4)
        for field in ("mac_enabled", "task_report_ttl_s", "mac_child_lead_s", "prediction_tau_s"):
            missing = deepcopy(values)
            missing.pop(field)
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, "field schema"):
                build(4, missing)
        with self.assertRaisesRegex(ValueError, "field schema"):
            build(4, {**values, "profile": V9})
        with self.assertRaises(TypeError):
            port.build_root_budget_method_options(4, 30, V9, object(), registered_profiles=REGISTERED)
        self.assertEqual(tuple(fields(port._RegisteredN4RootBudgetOptions)), tuple(fields(OriginalC07Options)))
        self.assertEqual(set(vars(build(4))), set(values))
        with self.assertRaises(FrozenInstanceError):
            build(4).profile = V9

    def test_input_mapping_is_not_mutated_and_returned_budget_mapping_is_copied(self):
        values = candidate_fixture(4)
        before = deepcopy(values)
        build(4, values)
        self.assertEqual(values, before)
        proposed = port.registered_budget_values(4)
        proposed["mac_pool_slots"] = 16
        self.assertEqual(port.registered_budget_values(4)["mac_pool_slots"], 20)
        with self.assertRaises(TypeError):
            port.REGISTERED_TUPLES[4] = (16, 2, 28, 8, 2, 30, 2, 3)


class RootBudgetValidationChainContracts(unittest.TestCase):
    def test_C03_AST_exact_single_upper_literal_and_original_super_anchor(self):
        audit = port.c03_domain_port_audit()
        self.assertEqual(audit["changed_ast_sites"], 1)
        self.assertEqual((audit["changed_field"], audit["original_upper"], audit["ported_upper"]),
                         ("mac_pool_slots", 16, 20))
        self.assertEqual(audit["original_validator_ast_sha256"], audit["restored_validator_ast_sha256"])
        self.assertNotEqual(audit["original_validator_ast_sha256"], audit["ported_validator_ast_sha256"])
        self.assertTrue(audit["remaining_validator_AST_identical"])
        self.assertIs(port._PORTED_C03_POST_INIT.__closure__[0].cell_contents, OriginalC03Options)
        self.assertIs(port._PORTED_C03_POST_INIT.__globals__, OriginalC03Options.__post_init__.__globals__)
        self.assertEqual(port._PORTED_C03_POST_INIT.__code__.co_freevars,
                         OriginalC03Options.__post_init__.__code__.co_freevars)
        mro = port._RegisteredN4RootBudgetOptions.__mro__
        start = mro.index(OriginalC04Options)
        self.assertEqual(mro[start:start+3], (OriginalC04Options, port._C03RootBudgetValidation, OriginalC03Options))
        self.assertIs(OriginalC07Options, OriginalC06Options)
        self.assertIn(OriginalC06Options, mro)
        audit["original_upper"] = 999
        self.assertEqual(port.c03_domain_port_audit()["original_upper"], 16)

    def test_all_nonbudget_original_invalid_inputs_still_reject_with_same_exception(self):
        invalid = {
            # Original C06 and C04 after the lower chain returns.
            "slot_task_scheduler": [False],
            "mac_child_lead_s": [0., -1., float("nan"), float("inf"), True],
            # Original C02 inherited constraints.
            "mac_coop_leases_per_borrower": [0, 9, True],
            "mac_sensor_prepare_lead_frames": [0, 6, True],
            "mac_demand_fallback_age_s": [0., float("nan"), float("inf"), True],
            "mac_sensor_prediction_min_packets": [0., float("nan"), float("inf"), True],
            # Original C01 feature identity, timing and native MacOptions.
            "mac_enabled": [1, None], "mac_routed_auv_commits": [1, None],
            "task_advice": [True], "service_release": [True],
            "mac_decision_interval_s": [0., float("nan"), float("inf"), True],
            "mac_demand_report_interval_s": [0., float("nan"), float("inf"), True],
            "mac_demand_ttl_s": [0., float("nan"), float("inf"), True],
            "mac_requests_per_tick": [0, 31, True],
            "mac_max_leases_per_borrower": [0, 31, True],
            "mac_prepare_lead_frames": [0, 6, True],
            "mac_lease_frames": [0, 31, True],
            # Original V5 checks EVERY inherited task-v4 field explicitly.
            "prediction_tau_s": [0., float("nan"), float("inf")],
            "navigation_fix_sigma": [0., float("nan"), float("inf")],
            "missing_velocity_sigma": [0., float("nan"), float("inf")],
            "task_report_ttl_s": [0., float("nan"), float("inf")],
            "conflict_age_s": [0., float("nan"), float("inf")],
            "conflict_distance_margin_m": [0., float("nan"), float("inf")],
            "peer_reserved_priority": [0., 2., float("nan")],
            "queue_empty_packets": [0., float("nan"), float("inf")],
            "service_piggyback": [1, None],
            "nominal_travel_speed": [0., float("nan"), float("inf")],
            "visit_packet_budget": [0., float("nan"), float("inf")],
            "advice_ttl_s": [0., float("nan"), float("inf")],
            "decision_interval_s": [0., float("nan"), float("inf")],
            "coordination_tolerance": [-.1, 1., float("nan"), float("inf")],
        }
        good = candidate_fixture(4)
        for field, values in invalid.items():
            for value in values:
                original_projection = {**good, "mac_pool_slots": 16, field: value}
                candidate = {**good, field: value}
                with self.subTest(field=field, value=value):
                    with self.assertRaises((ValueError, TypeError)) as expected:
                        OriginalC07Options(**original_projection)
                    with self.assertRaises(type(expected.exception)) as actual:
                        build(4, candidate)
                    self.assertEqual(str(actual.exception), str(expected.exception))
                    self.assertIsNone(port._CONSTRUCTION_SCOPE.get())

    def test_budget_original_errors_reject_and_do_not_expand_any_other_domain(self):
        bad = {"mac_pool_slots": [1, 21, True], "mac_auv_slots": [0, 9, True],
               "mac_max_leases": [0, 31, True], "mac_child_max_active": [0, 9, True],
               "mac_child_slots_per_sensor": [0, 5, True],
               "mac_coop_lease_frames": [0, 31, True],
               "mac_frame_stride": [1, 6, True], "mac_child_lease_frames": [0, 4, True]}
        good = candidate_fixture(4)
        for field, values in bad.items():
            for value in values:
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    build(4, {**good, field: value})
        self.assertIsNone(port._CONSTRUCTION_SCOPE.get())
        with self.assertRaisesRegex(ValueError, "constructor scope"):
            port._RegisteredN4RootBudgetOptions(**good)

    def test_original_source_classes_globals_and_MRO_are_not_mutated(self):
        originals = OriginalC07Options.__mro__[:-1]
        before = {cls: (cls.__mro__, cls.__dict__.get("__post_init__"), tuple(fields(cls))) for cls in originals}
        files = {Path(inspect.getsourcefile(cls)).resolve() for cls in originals}
        identities = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
        registry = adapter.PROFILES
        for n in (2, 3, 4):
            for enabled in (True, False):
                build(n, candidate_fixture(n, enabled))
        self.assertIs(adapter.PROFILES, registry)
        for cls, state in before.items():
            self.assertEqual(cls.__mro__, state[0])
            self.assertIs(cls.__dict__.get("__post_init__"), state[1])
            self.assertEqual(tuple(fields(cls)), state[2])
        self.assertEqual({path: hashlib.sha256(path.read_bytes()).hexdigest() for path in files}, identities)
        self.assertTrue(sys.dont_write_bytecode)

    def test_scoped_permission_resets_on_error_and_is_thread_local(self):
        def authorized():
            for index in range(40):
                actual = build(4, candidate_fixture(4, index % 2 == 0))
                self.assertEqual(actual.mac_pool_slots, 20)
                self.assertIsNone(port._CONSTRUCTION_SCOPE.get())
            return "authorized"
        def unauthorized():
            for _ in range(40):
                with self.assertRaisesRegex(ValueError, "constructor scope"):
                    port._RegisteredN4RootBudgetOptions(**candidate_fixture(4))
                with self.assertRaisesRegex(ValueError, "mac_pool_slots"):
                    OriginalC07Options(**candidate_fixture(4))
                self.assertIsNone(port._CONSTRUCTION_SCOPE.get())
            return "native rejected"
        with ThreadPoolExecutor(max_workers=2) as executor:
            jobs = [executor.submit(authorized), executor.submit(unauthorized)]
            self.assertEqual([job.result() for job in jobs], ["authorized", "native rejected"])
        self.assertIsNone(port._CONSTRUCTION_SCOPE.get())


class RootBudgetSerializationContracts(unittest.TestCase):
    def test_JSON_roundtrip_and_dataclass_schema_field_types_match_original(self):
        for n in (2, 3, 4):
            for enabled in (True, False):
                actual = build(n, candidate_fixture(n, enabled))
                encoded = json.dumps(asdict(actual), sort_keys=True, allow_nan=False)
                restored = build(n, json.loads(encoded))
                self.assertEqual(asdict(restored), asdict(actual))
                self.assertEqual(tuple(fields(type(restored))), tuple(fields(OriginalC07Options)))
                self.assertEqual({field.name: field.type for field in fields(restored)},
                                 {field.name: field.type for field in fields(OriginalC07Options)})
                self.assertEqual(set(vars(restored)), set(asdict(actual)))
                self.assertEqual(type(restored), type(actual))

    def test_in_memory_dataclass_pickle_roundtrip_revalidates_only_fixed_n4_scope(self):
        for n in (2, 3, 4):
            for enabled in (True, False):
                actual = build(n, candidate_fixture(n, enabled))
                for protocol in (4, pickle.HIGHEST_PROTOCOL):
                    restored = pickle.loads(pickle.dumps(actual, protocol=protocol))
                    self.assertEqual(type(restored), type(actual))
                    self.assertEqual(asdict(restored), asdict(actual))
                    self.assertEqual(set(vars(restored)), set(asdict(actual)))
                    self.assertIsNone(port._CONSTRUCTION_SCOPE.get())
                    if n == 4:
                        with self.assertRaisesRegex(ValueError, "mac_pool_slots"):
                            OriginalC07Options(**asdict(restored))
                        with self.assertRaisesRegex(ValueError, "constructor scope"):
                            type(restored)(**asdict(restored))

    def test_pickle_restore_refuses_wrong_tuple_and_invalid_original_field(self):
        class SyntheticRestoreRecord:
            def __init__(self, values):
                self.values = values
            def __reduce__(self):
                return port._restore_registered_n4_options, (self.values,)
        for changes in ({"mac_pool_slots": 19}, {"slot_task_scheduler": False},
                        {"mac_child_lead_s": 0.}, {"mac_demand_ttl_s": float("inf")}):
            record = SyntheticRestoreRecord({**candidate_fixture(4), **changes})
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                pickle.loads(pickle.dumps(record))
            self.assertIsNone(port._CONSTRUCTION_SCOPE.get())

    def test_audit_is_explicit_configuration_domain_port_and_not_protocol_proof(self):
        audit = port.c03_domain_port_audit()
        self.assertTrue(audit["method_options_schema_unchanged"])
        self.assertTrue(audit["registration_does_not_change_adapter_PROFILES"])
        self.assertTrue(audit["no_remote_information"])
        self.assertFalse(audit["original_class_or_globals_modified"])
        self.assertFalse(audit["physical_slots_or_bitrate_added"])
        self.assertFalse(audit["constructor_selects_or_trains"])
        self.assertIn("configuration", audit["tradeoff"])
        self.assertIn("unproved", audit["tradeoff"])
        self.assertEqual(json.loads(json.dumps(audit, allow_nan=False)), audit)
        tree = ast.parse(inspect.getsource(port))
        attributes = {node.attr for node in ast.walk(tree) if isinstance(node, ast.Attribute)}
        self.assertTrue(attributes.isdisjoint({"grants", "buffers", "sensor_positions", "received_states",
                                              "root_records", "_child_commits", "auv_positions"}))


if __name__ == "__main__":
    unittest.main(verbosity=2)
