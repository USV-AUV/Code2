"""New fixed-deployment profile integration; no learning or performance claim."""
from dataclasses import asdict
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012.environment import build_settings,make_environment
from exp7_c07_scaling_20261012.deployment import deployment_positions
from usv_auv.environment import CooperativeEnv

class GridEnvironmentTests(unittest.TestCase):
    def test_n2_profile_has_exact_existing_settings_and_observations(self):
        for method in ("full","usde_only"):
            previous=build_settings(2,30,method,"adaptive_packet_v2")
            current=build_settings(2,30,method,"adaptive_packet_grid_v3")
            self.assertEqual(previous[0].to_dict(),current[0].to_dict())
            self.assertEqual(asdict(previous[1]),asdict(current[1]))
            env1=make_environment(2,30,method,"adaptive_packet_v2")
            env2=make_environment(2,30,method,"adaptive_packet_grid_v3")
            self.addCleanup(env1.close);self.addCleanup(env2.close)
            np.testing.assert_array_equal(env1.reset(42)[0],env2.reset(42)[0])
    def test_fixed_geometry_common_full_usde_and_native_safety_reward(self):
        original=CooperativeEnv.reset
        for n in (3,4):
            envs=[make_environment(n,30,method,"adaptive_packet_grid_v3") for method in ("full","usde_only")]
            for env in envs:
                self.addCleanup(env.close)
                obs,info=env.reset(42)
                np.testing.assert_array_equal(env.auv_positions,deployment_positions(env.cfg))
                self.assertEqual(obs.shape,(n,45 if n==3 else 49))
                self.assertFalse(hasattr(env,"actor_rewards"))
                # Short ordinary native motion proves the port restored before
                # step. No shield/fixed-horizon/terminal rewrite is installed.
                result=env.step(np.zeros((n,2),np.float32),0 if env.method.use_topology else None)
                self.assertTrue(np.isfinite(result[0]).all())
                self.assertTrue(np.isfinite(result[1]))
                self.assertIs(CooperativeEnv.reset,original)
            self.assertEqual(envs[0].cfg.to_dict(),envs[1].cfg.to_dict())
    def test_layout_changes_only_initial_geometry_not_shared_physics(self):
        for n in (3,4):
            line=build_settings(n,30,"full","adaptive_packet_v2")
            grid=build_settings(n,30,"full","adaptive_packet_grid_v3")
            self.assertEqual({k:v for k,v in grid[0].to_dict().items() if k!="deployment_layout"},line[0].to_dict())
            self.assertEqual(asdict(grid[1]),asdict(line[1]))
            self.assertEqual(asdict(grid[2]),asdict(line[2]))

if __name__=="__main__": unittest.main()
