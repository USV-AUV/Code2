"""Pure SimpleNamespace/list contracts; no env, network, learner or model."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace as NS
import unittest

PATH = Path(__file__).resolve().parents[1]/"passive_journal.py"
SPEC = importlib.util.spec_from_file_location("passive_journal_pure_fixture_tests", PATH)
passive = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(passive)


class PassiveJournalContracts(unittest.TestCase):
    def fixture(self):
        env = NS(network=NS(mac_events=[]),mac_scheduler_events=[],c04_task_events=[],
            c06_task_events=[],c07_task_events=[],service_end_events=[])
        return env,passive.make_passive_journal(env,enabled=True)

    def test_disabled_factory_is_default_and_does_not_inspect_owner(self):
        class Forbidden:
            def __getattribute__(self,key):
                raise AssertionError("Disabled observer may not inspect anything")
        self.assertIsNone(passive.make_passive_journal())
        self.assertIsNone(passive.make_passive_journal(Forbidden()))
        with self.assertRaises(passive.PassiveJournalContractError):
            passive.make_passive_journal(enabled=1)

    def test_cursor_exactly_once_and_empty_redrain(self):
        env,journal = self.fixture()
        env.network.mac_events.append(dict(time=.1,event="child_commit_received"))
        first = journal.drain(step_end=1,time_s=1.)
        self.assertEqual([(r["stream"],r["stream_index"]) for r in first["records"]],[("net.mac_events",0)])
        self.assertEqual(journal.drain(step_end=1,time_s=1.)["records"],[])
        env.network.mac_events.append(dict(time=1.5,event="child_slot"))
        third = journal.drain(step_end=2,time_s=2.)
        self.assertEqual([r["stream_index"] for r in third["records"]],[1])

    def test_only_six_registered_streams_are_copied(self):
        env,journal = self.fixture()
        env.service_protocol_events = [dict(time=1.,event="NOT IN P0")]
        env.other_events = [dict(time=1.,event="NOT IN P0")]
        result = journal.drain(step_end=1,time_s=1.)
        self.assertEqual(result["records"],[])
        self.assertEqual(set(result["statistics"]["streams"]),{name for name,_,_ in passive.STREAMS})

    def test_same_time_different_streams_has_no_native_global_order(self):
        env,journal = self.fixture()
        env.network.mac_events.append(dict(time=1.,event="native_MAC"))
        env.c07_task_events.append(dict(time=1.,event="native_task"))
        result = journal.drain(step_end=2,time_s=2.)
        self.assertEqual(len(result["records"]),2)
        self.assertTrue(all(r["cross_stream_global_order"] == "unknown" for r in result["records"]))
        self.assertEqual(result["statistics"]["cross_stream_global_order"],"unknown")
        self.assertFalse(any("event_seq" in record for record in result["records"]))

    def test_raw_native_time_is_distinct_from_capture_step_end(self):
        env,journal = self.fixture()
        env.network.mac_events.append(dict(time=.2,event="native_MAC"))
        record = journal.drain(step_end=10,time_s=10.)["records"][0]
        self.assertEqual(record["native_time_s"],.2)
        self.assertEqual(record["recorded_at_step_end"],dict(step=10,time_s=10.))
        self.assertEqual(record["native_record"]["time"],.2)

    def test_missing_stream_is_unavailable_not_observed_zero(self):
        env = NS(network=NS(mac_events=[]))
        journal = passive.make_passive_journal(env,enabled=True)
        result = journal.drain(step_end=0,time_s=0.)
        state = result["statistics"]["streams"]["env.c07_task_events"]
        self.assertEqual(state["availability"],"missing")
        self.assertIsNone(state["records_copied"])
        self.assertIsNone(state["next_cursor"])
        self.assertEqual(result["statistics"]["streams"]["net.mac_events"]["records_copied"],0)

    def test_missing_time_and_explicit_null_time_remain_distinct(self):
        env,journal = self.fixture()
        env.c04_task_events.extend([dict(event="no time"),dict(time=None,event="explicit null")])
        records = journal.drain(step_end=1,time_s=1.)["records"]
        self.assertEqual([r["native_time_status"] for r in records],["missing","null"])
        self.assertTrue(all(r["native_time_s"] is None for r in records))
        self.assertNotIn("time",records[0]["native_record"])

    def test_append_only_shrink_is_rejected_without_mutating_native(self):
        env,journal = self.fixture()
        env.network.mac_events.append(dict(time=1.,event="A"))
        journal.drain(step_end=1,time_s=1.)
        env.network.mac_events.clear()
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"shrank"):
            journal.drain(step_end=2,time_s=2.)
        self.assertEqual(env.network.mac_events,[])

    def test_list_replacement_and_network_reset_need_new_explicit_binding(self):
        env,journal = self.fixture()
        env.c07_task_events = []
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"replaced"):
            journal.drain(step_end=1,time_s=1.)
        fresh = passive.make_passive_journal(env,enabled=True)
        env.network = NS(mac_events=[])
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"network binding replaced"):
            fresh.drain(step_end=1,time_s=1.)

    def test_consumed_prefix_entry_replace_or_reorder_is_rejected(self):
        env,journal = self.fixture()
        env.network.mac_events.extend([dict(time=.1,event="A"),dict(time=.2,event="B")])
        journal.drain(step_end=1,time_s=1.)
        env.network.mac_events.reverse()
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"prefix entry"):
            journal.drain(step_end=2,time_s=2.)

    def test_malformed_stream_or_event_is_rejected(self):
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"plain list"):
            passive.make_passive_journal(NS(network=NS(mac_events=())),enabled=True)
        env,journal = self.fixture()
        env.c07_task_events.append("not a dict")
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"plain dictionary"):
            journal.drain(step_end=1,time_s=1.)

    def test_bad_native_time_bool_string_or_nonfinite_is_rejected(self):
        for value in (True,"soon",float("nan"),float("inf")):
            env,journal = self.fixture()
            env.network.mac_events.append(dict(time=value,event="bad time"))
            with self.subTest(value=value),self.assertRaises(passive.PassiveJournalContractError):
                journal.drain(step_end=1,time_s=1.)

    def test_json_copy_is_detached_and_plain_tuple_is_serializable(self):
        env,journal = self.fixture()
        event = dict(time=1.,event="child",child=dict(parent=dict(lease_id=3),windows=[1,3]),owners=(0,1))
        env.network.mac_events.append(event)
        before = copy.deepcopy(event)
        result = journal.drain(step_end=1,time_s=1.)
        self.assertEqual(event,before)
        copied = result["records"][0]["native_record"]
        self.assertEqual(copied["owners"],[0,1])
        copied["child"]["parent"]["lease_id"] = 999
        copied["child"]["windows"].append(5)
        self.assertEqual(event,before)
        json.dumps(result,allow_nan=False)

    def test_unknown_values_keys_cycles_do_not_call_conversion_helpers(self):
        class ForbiddenConversion:
            def to_dict(self):
                raise AssertionError("No user conversion")
            def tolist(self):
                raise AssertionError("No user conversion")
        cyclic = [];cyclic.append(cyclic)
        for event in (dict(time=1.,value=ForbiddenConversion()),dict(time=1.,value={1:"bad key"}),dict(time=1.,value=cyclic)):
            env,journal = self.fixture();env.network.mac_events.append(event)
            with self.subTest(event_type=type(event["value"]).__name__),self.assertRaises(passive.PassiveJournalContractError):
                journal.drain(step_end=1,time_s=1.)

    def test_no_native_mutation_or_read_append_counter(self):
        env,journal = self.fixture()
        env.network.metrics = dict(native_counter=4)
        env.metrics = dict(native_counter=7)
        env.network.mac_events.append(dict(time=1.,event="A"))
        before = copy.deepcopy(vars(env));network_before = copy.deepcopy(vars(env.network))
        result = journal.drain(step_end=1,time_s=1.)
        self.assertEqual(vars(env.network),network_before)
        self.assertEqual(env.metrics,before["metrics"])
        self.assertEqual(env.c04_task_events,before["c04_task_events"])
        self.assertFalse(result["execution_observation"])
        self.assertFalse(result["root_information_source"])

    def test_fail_behavior_getters_are_never_called(self):
        def forbidden(*args,**kwargs):
            raise AssertionError("Behavior getter or physical call was invoked")
        env = NS(network=NS(mac_events=[],advance=forbidden),mac_scheduler_events=[],c04_task_events=[],
            c06_task_events=[],c07_task_events=[],service_end_events=[],step=forbidden,
            _mac_candidates=forbidden,_conflict_keys=forbidden,_conflict_needs_notification=forbidden,
            _peer_reservations=forbidden,_queue_forecast=forbidden,targets=forbidden)
        passive.make_passive_journal(env,enabled=True).drain(step_end=1,time_s=1.)
        class PropertyOwner:
            calls = 0
            @property
            def c07_task_events(self):
                self.calls += 1
                raise AssertionError("Property was evaluated")
        owner = PropertyOwner()
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"stored attribute"):
            passive.make_passive_journal(owner,enabled=True)
        self.assertEqual(owner.calls,0)

    def test_imports_are_standard_library_only_no_runtime_file_or_hook_work(self):
        tree = ast.parse(PATH.read_text(encoding="utf-8"))
        roots = set()
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):
                roots.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node,ast.ImportFrom):
                roots.add(node.module.split(".")[0])
        self.assertEqual(roots,{"__future__","inspect","json","math"})
        self.assertFalse(any(isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in
            {"open","exec","eval","__import__"} for node in ast.walk(tree)))

    def test_late_stream_failure_does_not_commit_any_earlier_cursor(self):
        env,journal = self.fixture()
        env.network.mac_events.append(dict(time=1.,event="good"))
        env.service_end_events.append("malformed last stream")
        with self.assertRaises(passive.PassiveJournalContractError):
            journal.drain(step_end=1,time_s=1.)
        env.service_end_events[0] = dict(time=1.,event="repaired before cursor commit")
        result = journal.drain(step_end=1,time_s=1.)
        self.assertEqual([(r["stream"],r["stream_index"]) for r in result["records"]],
            [("net.mac_events",0),("env.service_end_events",0)])
        self.assertEqual(result["statistics"]["drain_calls"],1)

    def test_step_context_is_explicit_typed_and_monotone(self):
        env,journal = self.fixture()
        for step,time in ((True,1.),(1,True),(-1,1.),(1,float("inf"))):
            with self.subTest(step=step,time=time),self.assertRaises(passive.PassiveJournalContractError):
                journal.drain(step_end=step,time_s=time)
        journal.drain(step_end=3,time_s=3.)
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"backwards"):
            journal.drain(step_end=2,time_s=2.)

    def test_missing_stream_cannot_silently_appear_on_bound_journal(self):
        env = NS(network=NS(mac_events=[]))
        journal = passive.make_passive_journal(env,enabled=True)
        env.c07_task_events = []
        with self.assertRaisesRegex(passive.PassiveJournalContractError,"appeared"):
            journal.drain(step_end=1,time_s=1.)


if __name__ == "__main__":
    unittest.main()
