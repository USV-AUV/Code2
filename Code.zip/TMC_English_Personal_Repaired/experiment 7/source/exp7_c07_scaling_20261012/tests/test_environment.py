"""Independent C07 scale contracts; short environment tests, never training.

The two-AUV oracle is constructed from the immutable original reference files,
not from the adapter's settings. Synthetic packet arrivals are explicit unit
fixtures for received information and paid certificate handling.
"""
from copy import deepcopy
from dataclasses import asdict
from itertools import product
import json
import math
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012.environment import build_settings, make_environment
from exp7_c07_scaling_20261012.paths import reference_config, reference_metadata
from usv_auv.config import Config
from usv_auv.network import AcousticNetwork, Delivery, Packet
from v4_task_20260917_r2 import environment as task_base
from v6_candidates.c07.environment import TaskV4Env as OriginalC07, MethodOptions, local_fields, slow_fields
from v6_candidates.c07.routing import RoutingOptions


PROFILES = ("natural", "adaptive_v1")
METHODS = ("full_v6", "usde_only_v6")
SCALE_FIELDS = {"n_auv", "n_sensors", "faults", "declared_packet_bits"}
ADAPTIVE_CLOCK_FIELDS = {"grant_ttl", "service_ack_timeout"}


def original_settings(method):
    raw = json.loads(reference_config().read_text(encoding="utf-8-sig"))
    metadata = json.loads(reference_metadata(method).read_text(encoding="utf-8-sig"))
    return raw, metadata["method_options"], metadata["routing_options"]


def complete_depth_two_routes(n):
    # Independent depth-two definition: every non-root parent is itself a
    # direct child of root. This excludes self-loops, cycles and depth three.
    return [p for p in product(range(n + 1), repeat=n)
            if all(parent == 0 or p[parent - 1] == 0 for parent in p)]


def team_reward_from_accounting(env, before, energy_before, old_distance, terminated):
    c = env.cfg
    bits = env.metrics["collected_bits"] - before["collected_bits"]
    lost = env.metrics["overflow_bits"] - before["overflow_bits"]
    energy = (env.metrics["propulsion_energy_j"] - before["propulsion_energy_j"]
              + env.metrics["usv_energy_j"] - before["usv_energy_j"]
              + float(np.sum(env.network.energy_j)) - energy_before)
    ages = [env.time - d.packet.created_at
            if (d := env.network.received_states.get(i + 1)) is not None else env.time
            for i in range(c.n_auv)]
    new_distance = np.array([np.linalg.norm(env.nav[i].position - env.sensor_positions[env.targets[i]])
                             for i in range(c.n_auv)])
    progress = float((np.sum(old_distance) - c.gamma *
                      (0. if terminated else np.sum(new_distance))) / c.area_size)
    return (c.reward_data_weight * bits / c.reward_data_scale
            - c.reward_overflow_weight * lost / c.reward_overflow_scale
            - c.reward_energy_weight * energy / c.reward_energy_scale
            - c.reward_age_weight * sum(ages) / c.reward_age_scale
            - c.reward_safety_weight * terminated + c.reward_progress_weight * progress)


class C07ScaleEnvironmentContracts(unittest.TestCase):
    def make(self, n=2, method="full_v6", profile="natural", **kwargs):
        env = make_environment(n, 30, method, profile=profile, **kwargs)
        self.addCleanup(env.close)
        return env

    def original(self, method):
        raw, options, routing = original_settings(method)
        env = OriginalC07(Config.from_dict(deepcopy(raw)), method,
                          MethodOptions(**options), RoutingOptions(**routing))
        self.addCleanup(env.close)
        return env

    def assert_state_equal(self, native, scaled):
        np.testing.assert_array_equal(native.targets, scaled.targets)
        np.testing.assert_array_equal(native.target_since, scaled.target_since)
        np.testing.assert_array_equal(native.next_reconsider_at, scaled.next_reconsider_at)
        np.testing.assert_array_equal(native.auv_positions, scaled.auv_positions)
        np.testing.assert_array_equal(native.usv_position, scaled.usv_position)
        np.testing.assert_array_equal(native.executed_velocities, scaled.executed_velocities)
        np.testing.assert_array_equal(native.network.energy_j, scaled.network.energy_j)
        self.assertEqual(native.metrics, scaled.metrics)
        self.assertEqual(native.network.metrics, scaled.network.metrics)
        self.assertEqual(native.collected, scaled.collected)
        self.assertEqual(native.acknowledged, scaled.acknowledged)
        self.assertEqual(native.network.faults, scaled.network.faults)
        self.assertEqual(native.network.root_parents, scaled.network.root_parents)
        self.assertEqual(native.network.local_versions, scaled.network.local_versions)

    def test_two_auv_settings_are_the_original_reference_for_both_profiles(self):
        for method, profile in product(METHODS, PROFILES):
            with self.subTest(method=method, profile=profile):
                raw, options, routing = original_settings(method)
                cfg, actual_options, actual_routing, diagnostics = build_settings(2, 30, method, profile=profile)
                self.assertIs(type(cfg), Config)
                self.assertEqual(cfg.to_dict(), raw)
                self.assertEqual(asdict(actual_options), options)
                self.assertEqual(asdict(actual_routing), routing)
                self.assertEqual(diagnostics["config_changes"], {})
                self.assertEqual(diagnostics["option_changes"], {})
                env = self.make(2, method, profile)
                self.assertIs(type(env), OriginalC07)
                self.assertEqual(env.cfg.faults, raw["faults"])
                self.assertEqual(env.network.max_packet_bits, 2304)

    def test_two_auv_exact_native_transitions_seed42_with_original_faults(self):
        action_rng = np.random.default_rng(20261012)
        actions = np.empty((120, 2, 2), dtype=np.float32)
        actions[:, :, 0] = action_rng.uniform(-.99, -.85, (120, 2))
        actions[:, :, 1] = action_rng.uniform(-.7, .7, (120, 2))
        for method, profile in product(METHODS, PROFILES):
            with self.subTest(method=method, profile=profile):
                native, scaled = self.original(method), self.make(2, method, profile)
                left, left_info = native.reset(seed=42)
                right, right_info = scaled.reset(seed=42)
                np.testing.assert_array_equal(left, right)
                self.assertEqual(left_info, right_info)
                self.assertTrue(native.cfg.faults)
                self.assert_state_equal(native, scaled)
                for step, action in enumerate(actions):
                    slow_left, mask_left = native.slow_state()
                    slow_right, mask_right = scaled.slow_state()
                    np.testing.assert_array_equal(slow_left, slow_right)
                    np.testing.assert_array_equal(mask_left, mask_right)
                    topology = 0 if step % native.cfg.slow_period == 0 else None
                    left_result = native.step(action.copy(), topology)
                    right_result = scaled.step(action.copy(), topology)
                    np.testing.assert_array_equal(left_result[0], right_result[0])
                    self.assertEqual(left_result[1:], right_result[1:])
                    self.assert_state_equal(native, scaled)
                    np.testing.assert_array_equal(scaled.last_actions, action)
                    if left_result[2] or left_result[3]:
                        break
                self.assertGreater(scaled.step_count, 0)
                self.assertLessEqual(scaled.step_count, 120)

    def test_complete_native_topologies_and_natural_observation_dimensions(self):
        for n, local_dim, root_dim, actions in ((2, 41, 90, 4), (3, 45, 133, 11), (4, 49, 180, 42)):
            for profile in PROFILES:
                with self.subTest(n=n, profile=profile):
                    original_constructor = task_base.TaskV4Env.__init__
                    env = self.make(n, profile=profile)
                    self.assertIs(task_base.TaskV4Env.__init__, original_constructor)
                    self.assertIs(type(env.network)._enumerate_topologies, AcousticNetwork._enumerate_topologies)
                    self.assertEqual(env.network.candidates, complete_depth_two_routes(n))
                    self.assertEqual(env.network.n_actions, actions)
                    self.assertEqual(env.observation_schema, local_fields(n))
                    self.assertEqual(env.slow_observation_schema, slow_fields(n))
                    self.assertEqual((env.observation_dim, env.slow_observation_dim), (local_dim, root_dim))
                    self.assertEqual(env.last_observations.shape, (n, local_dim))
                    slow, mask = env.slow_state()
                    self.assertEqual(slow.shape, (root_dim,))
                    self.assertEqual(mask.shape, (actions,))
                    self.assertTrue(mask[0])
                    self.assertTrue(np.isfinite(slow).all())
                    self.assertTrue(np.isfinite(env.last_observations).all())
                    self.assertIs(type(env).step, OriginalC07.step)
                    self.assertIs(type(env)._select_targets, OriginalC07._select_targets)
                    self.assertFalse(any(cls.__name__ == "FixedHorizonSafety" for cls in type(env).__mro__))
                    if n >= 3:
                        self.assertNotIn((0, 1, 2) + (0,) * (n - 3), env.network.candidates)
                        self.assertIn((0,) + (1,) * (n - 1), env.network.candidates)
                    if n == 4:
                        self.assertIn((0, 0, 1, 2), env.network.candidates)
                    star = self.make(n, "usde_only_v6", profile)
                    self.assertEqual(star.network.candidates, [(0,) * n])
                    self.assertFalse(star.method.use_topology)
                    self.assertFalse(star.method_options.mac_enabled)

    def test_only_declared_scale_and_protocol_settings_change(self):
        for n, method, profile in product((3, 4), METHODS, PROFILES):
            with self.subTest(n=n, method=method, profile=profile):
                raw, original_options, routing = original_settings(method)
                cfg, options, actual_routing, diagnostics = build_settings(n, 30, method, profile=profile)
                changed = {k for k, value in cfg.to_dict().items() if raw.get(k) != value}
                allowed = SCALE_FIELDS | (ADAPTIVE_CLOCK_FIELDS if profile == "adaptive_v1" else set())
                self.assertLessEqual(changed, allowed)
                for field, value in raw.items():
                    if field not in allowed:
                        self.assertEqual(getattr(cfg, field), value, field)
                self.assertEqual(asdict(actual_routing), routing)
                self.assertEqual(set(diagnostics["config_changes"]), changed)
                self.assertEqual(diagnostics["profile"], profile)
                for field, change in diagnostics["config_changes"].items():
                    self.assertEqual(change, {"old": raw.get(field), "new": cfg.to_dict()[field]})
                option_changes = {k for k, value in asdict(options).items() if original_options[k] != value}
                self.assertEqual(set(diagnostics["option_changes"]), option_changes)
                if profile == "natural":
                    self.assertEqual(asdict(options), original_options)
                    self.assertEqual(cfg.grant_ttl, raw["grant_ttl"])
                    self.assertEqual(cfg.service_ack_timeout, raw["service_ack_timeout"])
                else:
                    self.assertLessEqual(option_changes, {"mac_max_leases", "mac_child_slots_per_sensor",
                        "mac_child_max_active", "mac_prepare_lead_frames", "mac_coop_lease_frames"})
                    env = self.make(n, method, profile)
                    frame = len(env.network.slot_owners) * cfg.slot_duration
                    service_budget = math.ceil(env.service_retry_interval)
                    self.assertEqual(cfg.grant_ttl, max(raw["grant_ttl"], service_budget))
                    self.assertEqual(cfg.service_ack_timeout, max(raw["service_ack_timeout"], service_budget))
                    self.assertEqual(options.mac_max_leases, options.mac_pool_slots + n * options.mac_auv_slots)
                    self.assertEqual(options.mac_pool_slots, 10)
                    self.assertEqual(options.mac_auv_slots, 3)
                    self.assertEqual(options.mac_child_slots_per_sensor, 1)
                    self.assertEqual(options.mac_child_max_active, n)
                    self.assertLess(options.mac_child_max_active, options.mac_pool_slots)
                    self.assertEqual(options.mac_prepare_lead_frames, max(1, min(5, math.ceil(108 / frame))))
                    expected_frames = max(1, min(30, math.ceil(cfg.target_max_dwell / frame)))
                    self.assertEqual(options.mac_coop_lease_frames, expected_frames)
                    self.assertGreaterEqual(options.mac_prepare_lead_frames * frame, 108)
                    self.assertGreaterEqual(options.mac_coop_lease_frames * frame, cfg.target_max_dwell)
                    self.assertLess(options.mac_coop_lease_frames * frame, cfg.target_max_dwell + frame)
                    self.assertEqual(options.mac_coop_lease_frames, 8 if n == 3 else 7)
                    self.assertEqual(options.mac_coop_lease_frames * frame, 336.)

    def test_full_and_own_scale_usde_share_all_common_settings(self):
        for n, profile in product((2, 3, 4), PROFILES):
            with self.subTest(n=n, profile=profile):
                full_cfg, full_options, full_route, _ = build_settings(n, 30, "full_v6", profile=profile)
                usde_cfg, usde_options, usde_route, _ = build_settings(n, 30, "usde_only_v6", profile=profile)
                self.assertEqual(full_cfg.to_dict(), usde_cfg.to_dict())
                full_dict, usde_dict = asdict(full_options), asdict(usde_options)
                self.assertTrue(full_dict.pop("mac_enabled"))
                self.assertFalse(usde_dict.pop("mac_enabled"))
                self.assertEqual(full_dict, usde_dict)
                self.assertEqual(full_route, usde_route)

    def test_physical_calendar_rate_packet_charges_and_native_deployment(self):
        raw, _, _ = original_settings("full_v6")
        for n, profile in product((2, 3, 4), PROFILES):
            # Explicit sensor groups retain the original calendar construction.
            with self.subTest(n=n, profile=profile):
                env = self.make(n, profile=profile)
                expected_calendar = []
                for start in range(0, 30, 3):
                    expected_calendar.extend(range(n + 1))
                    expected_calendar.extend(range(n + 1 + start, n + 1 + min(30, start + 3)))
                self.assertEqual(env.network.slot_owners, tuple(expected_calendar))
                self.assertEqual(len(expected_calendar), 10 * (n + 4))
                self.assertEqual(env.cfg.slot_duration, .6)
                self.assertEqual(env.cfg.bit_rate, 16000)
                self.assertEqual(env.cfg.state_packet_bits, 1536)
                self.assertEqual(env.cfg.data_packet_bits + env.cfg.data_header_bits, 2304)
                self.assertEqual(env.cfg.control_packet_bits, 512)
                expected_cap = 2304 if n == 2 else max(8 * (40 + 112 * n), 8 * (40 + 112 * (n - 1) + 8 + 128))
                self.assertEqual(env.network.max_packet_bits, expected_cap)
                self.assertLessEqual(expected_cap, 4096)
                distance = math.sqrt(2 * raw["area_size"] ** 2 + raw["sensor_depth"] ** 2)
                self.assertLessEqual(expected_cap / env.cfg.bit_rate + distance / env.cfg.sound_speed
                    + env.cfg.guard_time + env.cfg.processing_delay, env.cfg.slot_duration)
                np.testing.assert_array_equal(env.auv_positions[:, 0], np.linspace(.3, .7, n) * raw["area_size"])
                np.testing.assert_array_equal(env.auv_positions[:, 1], np.full(n, .45 * raw["area_size"]))

    def install_received_states(self, env):
        states = {}
        for i in range(env.cfg.n_auv):
            state = env._state_payload(i)
            states[str(i + 1)] = deepcopy(state)
            # Native C07 removes this local-only metadata from the charged
            # COORD peer record. All original timestamps and service evidence
            # must still be carried; this is not nearest-peer truncation.
            states[str(i + 1)].pop("localization_time", None)
            packet = Packet(i + 1, 0, "STATE", state, env.time, env.cfg.state_packet_bits, seq=i + 1)
            env.network.receive_cache[0][i + 1] = Delivery(packet, 0, env.time, i + 1)
        return states

    def test_all_root_received_states_have_paid_complete_coord_carriers(self):
        for n, method, profile in product((3, 4), METHODS, PROFILES):
            with self.subTest(n=n, method=method, profile=profile):
                env = self.make(n, method, profile)
                states = self.install_received_states(env)
                env._publish_coord()
                packets = [q.packet for q in env.network._queues[0] if q.packet.kind == "COORD"]
                self.assertEqual({p.dst for p in packets}, set(range(1, n + 1)))
                self.assertEqual(len(packets), n)
                for packet in packets:
                    self.assertEqual(packet.payload["states"], states)
                    self.assertEqual(packet.size_bits, 8 * (40 + 112 * n))
                    self.assertLessEqual(packet.size_bits, env.network.max_packet_bits)
                self.assertTrue(all(cache is None for cache in env.coord_cache))
                packet = next(p for p in packets if p.dst == 1)
                env._deliver([Delivery(packet, 1, env.time, 0)])
                self.assertEqual(env.coord_cache[0]["states"], states)

    def test_two_ack_backed_certificates_fit_and_require_actual_carrier_receipt(self):
        for n, profile in product((3, 4), PROFILES):
            with self.subTest(n=n, profile=profile):
                env = self.make(n, profile=profile)
                states = self.install_received_states(env)
                identifiers = []
                for donor in (n + 1, n + 2):
                    identifier = env.network.request_lease(donor, 1, start_frame=3, end_frame=4)
                    self.assertIsNotNone(identifier)
                    identifiers.append(identifier)
                    lease = env.network._root_requests[identifier]
                    ack = Packet(donor, 0, "MAC_ACK", lease.to_dict(), env.time, 512, seq=donor)
                    env.network._receive(ack, 0, donor)
                    self.assertIsNotNone(env.network.root_records[identifier]["ack_received_at"])
                self.assertEqual(env.network._borrower_commits[1], {})
                env._publish_coord()
                packet = next(q.packet for q in env.network._queues[0]
                              if q.packet.kind == "COORD" and q.packet.dst == 1)
                self.assertEqual(set(packet.payload["states"]), set(states) - {"1"})
                self.assertEqual(len(packet.payload["mac_leases"]), 2)
                self.assertEqual(packet.size_bits, 8 * (40 + 112 * (n - 1) + 8 + 2 * 64))
                self.assertLessEqual(packet.size_bits, env.network.max_packet_bits)
                self.assertEqual(env.network._borrower_commits[1], {})
                env.network._receive(packet, 1, 0)
                self.assertEqual(set(env.network._borrower_commits[1]), set(identifiers))

    def test_scale_steps_keep_final_motion_and_original_shared_team_reward(self):
        for n, method, profile in product((3, 4), METHODS, PROFILES):
            with self.subTest(n=n, method=method, profile=profile):
                env = self.make(n, method, profile)
                env.reset(seed=42)
                for step in range(12):
                    action = np.tile(np.array([-.95, .1], dtype=np.float32), (n, 1))
                    decoded = env.decode_actions(action, env.cfg.max_speed, env.cfg.action_frame, env.last_observations)
                    before = dict(env.metrics)
                    energy_before = float(np.sum(env.network.energy_j))
                    old_distance = np.array([np.linalg.norm(env.nav[i].position - env.sensor_positions[env.targets[i]])
                                             for i in range(n)])
                    obs, reward, terminated, truncated, info = env.step(action, 0 if step % 5 == 0 else None)
                    np.testing.assert_array_equal(env.last_actions, action)
                    np.testing.assert_array_equal(env.executed_velocities, decoded)
                    self.assertEqual(reward, team_reward_from_accounting(env, before, energy_before, old_distance, terminated))
                    self.assertTrue(np.isfinite(obs).all())
                    self.assertNotIn("actor_rewards", info)
                    self.assertNotIn("local_rewards", info)
                    self.assertFalse(hasattr(env, "peer_memory"))
                    self.assertEqual(env.done, terminated or truncated)
                    if terminated or truncated:
                        break

    def test_boundary_failure_remains_absorbing_with_original_reward(self):
        for n, profile in product((3, 4), PROFILES):
            with self.subTest(n=n, profile=profile):
                env = self.make(n, profile=profile)
                env.auv_positions[0, 0] = env.cfg.area_size + 5
                before = dict(env.metrics)
                energy_before = float(np.sum(env.network.energy_j))
                old_distance = np.array([np.linalg.norm(env.nav[i].position - env.sensor_positions[env.targets[i]])
                                         for i in range(n)])
                _, reward, terminated, truncated, info = env.step(np.tile([-1., 0.], (n, 1)), 0)
                self.assertTrue(terminated)
                self.assertFalse(truncated)
                self.assertTrue(env.done)
                self.assertEqual(info["termination_reason"], "boundary")
                self.assertEqual(reward, team_reward_from_accounting(env, before, energy_before, old_distance, True))
                with self.assertRaisesRegex(RuntimeError, "reset"):
                    env.step(np.tile([-1., 0.], (n, 1)))

    def test_unreceived_peer_truth_does_not_enter_local_or_root_observations(self):
        for n, profile in product((3, 4), PROFILES):
            with self.subTest(n=n, profile=profile):
                env = self.make(n, profile=profile)
                local_before = env._observations()[0].copy()
                root_before, mask_before = env.slow_state()
                env.auv_positions[1:] = np.nan
                env.targets[1:] = (env.targets[1:] + 1) % env.cfg.n_sensors
                env.grants = None
                env.buffers = None
                np.testing.assert_array_equal(env._observations()[0], local_before)
                root_after, mask_after = env.slow_state()
                np.testing.assert_array_equal(root_after, root_before)
                np.testing.assert_array_equal(mask_after, mask_before)

    def test_out_of_scope_scale_method_and_undeclared_profile_fail(self):
        for n in (1, 6, 8, True):
            with self.subTest(n=n), self.assertRaises(ValueError):
                build_settings(n, 30, "full_v6")
        with self.assertRaises(ValueError):
            build_settings(3, 30, "full_v6", profile="winner")
        with self.assertRaises(ValueError):
            build_settings(3, 30, "gnn")
        with self.assertRaises(ValueError):
            build_settings(4, 3, "full_v6")


if __name__ == "__main__":
    unittest.main()
