"""Prepared V5 calendar descendant: synthetic/zero-step, zero-learning checks.

AcousticNetwork calendars are constructed but NEVER advanced. Child scheduler
fixtures only call the unchanged C04 selector with explicit received-parent
facts. NativePolicy factory checks use object.__new__, not Policy.__init__ or
weights. No checkpoint file, actor, optimizer, replay or train loop is opened.
The real environment factory tests reset/construct only, with step/advance
patched to fail. These tests therefore execute zero physical env/net steps.
"""
from copy import deepcopy
from dataclasses import asdict, replace
import hashlib
import importlib.util
import inspect
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest import mock

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012 import environment as adapter
from exp7_c07_scaling_20261012 import paths, workflow, joint_clocks
from exp7_c07_scaling_20261012.deployment import deployment_positions
from usv_auv.config import Config as OriginalConfig
from usv_auv.deploy import environment_schema
from usv_auv.network import AcousticNetwork
from v6_candidates.c07.environment import TaskV4Env as OriginalC07
from v6_candidates.c04.environment import TaskV4Env as IntentEnv
from v6_candidates.c02.mac import DynamicMacNetwork as ParentNetwork, SlotLease
from v6_candidates.c03.mac import ChildLease


V5 = "adaptive_packet_grid_window_v5"
V6 = "adaptive_packet_grid_pool_v6"
V8 = "adaptive_packet_grid_calendar_v8"
OLD_PROFILES = ("natural", "adaptive_v1", "adaptive_packet_v2",
                "adaptive_packet_grid_v3", "adaptive_packet_grid_queue_v4", V5, V6)
HISTORICAL_V6 = (paths.EXPERIMENT / "iterative_candidates_20261012" /
                 "packet_grid_pool_v6" / "code" / "exp7_c07_scaling_20261012" / "environment.py")


def changes(before, after):
    return {key: {"old": before.get(key), "new": value}
            for key, value in after.items() if before.get(key) != value}


def frozen_v6_alias():
    # Relative .paths/.deployment imports intentionally bind to the SAME live
    # dependency/reference paths as adapter. Only the adapter constructor body
    # is loaded from the immutable pre-V8 oracle; no frozen runtime is launched.
    name = "exp7_c07_scaling_20261012._calendar_legacy_v6_oracle"
    spec = importlib.util.spec_from_file_location(name, HISTORICAL_V6)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module  # dataclass processing requires its module alias.
    try:
        spec.loader.exec_module(module)
    finally:
        sys.modules.pop(name, None)
    return module


class CalendarInterfaceContracts(unittest.TestCase):
    def test_explicit_profile_registration_and_default_unchanged(self):
        self.assertEqual(adapter.PROFILES, OLD_PROFILES + (V8, "adaptive_packet_grid_root_budget_v9", "adaptive_packet_grid_n4_child_h2_v11", *joint_clocks.PROFILES))
        self.assertEqual(adapter.build_settings.__defaults__[0], "adaptive_v1")
        self.assertEqual(adapter.make_environment.__defaults__[0], "adaptive_v1")

    def test_every_legacy_profile_entire_settings_and_diagnostics_equal_frozen_v6(self):
        if not HISTORICAL_V6.is_file():
            self.skipTest("Immutable historical V6 oracle is absent in a standalone package")
        before_sha = hashlib.sha256(HISTORICAL_V6.read_bytes()).hexdigest()
        old = frozen_v6_alias()
        self.assertEqual(old.PROFILES, OLD_PROFILES)
        self.assertIs(old.reference_config, paths.reference_config)
        self.assertIs(old.reference_metadata, paths.reference_metadata)
        self.assertIs(old.OriginalConfig, adapter.OriginalConfig)
        self.assertIs(old.AcousticNetwork, adapter.AcousticNetwork)
        self.assertEqual(old.reference_config(), adapter.reference_config())
        for profile in OLD_PROFILES:
            for n, sensors in ((2, 30), (3, 30), (4, 30), (3, 45), (4, 60)):
                for method in ("full", "usde_only"):
                    for faults in (None, []):
                        with self.subTest(profile=profile, n=n, sensors=sensors, method=method, faults=faults):
                            expected = old.build_settings(n, sensors, method, profile, faults)
                            actual = adapter.build_settings(n, sensors, method, profile, faults)
                            self.assertEqual(actual[0].to_dict(), expected[0].to_dict())
                            self.assertEqual(asdict(actual[1]), asdict(expected[1]))
                            self.assertEqual(asdict(actual[2]), asdict(expected[2]))
                            self.assertEqual(actual[3], expected[3])
        self.assertEqual(hashlib.sha256(HISTORICAL_V6.read_bytes()).hexdigest(), before_sha)
        self.assertTrue(sys.dont_write_bytecode)

    def test_two_AUV_config_options_routing_are_entire_original(self):
        expected = json.loads(paths.reference_config().read_text(encoding="utf-8-sig"))
        for method in ("full_v6", "usde_only_v6"):
            cfg, mo, ro, diagnostic = adapter.build_settings(2, 30, method, V8)
            metadata = json.loads(paths.reference_metadata(method).read_text(encoding="utf-8-sig"))
            self.assertIs(type(cfg), OriginalConfig)
            self.assertEqual(cfg.to_dict(), expected)
            self.assertEqual(asdict(mo), metadata["method_options"])
            self.assertEqual(asdict(ro), metadata["routing_options"])
            self.assertEqual(cfg.tdma_sensors_per_group, 3)
            self.assertEqual(diagnostic["config_changes"], {})
            self.assertEqual(diagnostic["option_changes"], {})
            self.assertNotIn("calendar_adaptation", diagnostic)
            self.assertNotIn("child_window_adaptation", diagnostic)

    def test_only_G_and_calendar_derived_clock_and_MIN_fields_change_against_V5(self):
        for n, group, ack, lead in ((3, 4, 111., 25.2), (4, 5, 127., 24.)):
            for method in ("full", "usde_only"):
                old = adapter.build_settings(n, 30, method, V5)
                new = adapter.build_settings(n, 30, method, V8)
                cfg, mo, ro, diagnostic = new
                self.assertEqual(changes(old[0].to_dict(), cfg.to_dict()), {
                    "tdma_sensors_per_group": {"old": 3, "new": group},
                    "service_ack_timeout": {"old": 117. if n == 3 else 140., "new": ack},
                    "grant_ttl": {"old": 117. if n == 3 else 140., "new": ack}})
                self.assertEqual(set(changes(asdict(old[1]), asdict(mo))), {"mac_child_lead_s"})
                self.assertAlmostEqual(mo.mac_child_lead_s, lead)
                self.assertEqual(asdict(ro), asdict(old[2]))
                self.assertEqual((cfg.deployment_layout, cfg.coordination_service_interval), ("scale_grid", 16./n))
                self.assertEqual((mo.mac_pool_slots, mo.mac_child_max_active, mo.mac_max_leases),
                                 (12, 6, 21) if n == 3 else (14, 8, 26))
                self.assertEqual((mo.mac_auv_slots, mo.mac_child_slots_per_sensor), (3, 2))
                self.assertEqual((mo.mac_child_lease_frames, mo.mac_frame_stride, mo.mac_coop_lease_frames), (3, 2, 30))
                self.assertEqual((mo.mac_decision_interval_s, mo.mac_demand_report_interval_s,
                                  mo.mac_demand_ttl_s), (12., 72., 90.))
                declared = diagnostic["calendar_adaptation"]
                self.assertEqual(declared["declared_config_diff_from_v5"], changes(old[0].to_dict(), cfg.to_dict()))
                self.assertEqual(declared["declared_option_diff_from_v5"], changes(asdict(old[1]), asdict(mo)))
                self.assertEqual(declared["inherited_profile"], V5)
                self.assertTrue(declared["routing_options_unchanged_from_v5"])

    def test_same_scale_full_USDE_entire_common_configuration_is_equal(self):
        for n, sensors in ((2, 30), (3, 30), (4, 30), (3, 45), (4, 60)):
            a = adapter.build_settings(n, sensors, "full", V8, faults=[])
            b = adapter.build_settings(n, sensors, "usde_only", V8, faults=[])
            self.assertEqual(a[0].to_dict(), b[0].to_dict())
            self.assertEqual(asdict(a[2]), asdict(b[2]))
            left, right = asdict(a[1]), asdict(b[1])
            self.assertTrue(left.pop("mac_enabled"))
            self.assertFalse(right.pop("mac_enabled"))
            self.assertEqual(left, right)
            if n > 2:
                self.assertEqual(a[3]["calendar_adaptation"], b[3]["calendar_adaptation"])

    def test_actual_native_calendar_counts_home_coop_gap_and_packet_fit(self):
        for n, slot_count, frame, cooperative_count, gap in ((2, 60, 36., 10, 3.6),
                                                            (3, 62, 37.2, 8, 4.8),
                                                            (4, 60, 36., 6, 6.)):
            cfg, _, _, diagnostic = adapter.build_settings(n, 30, "full", V8)
            net = AcousticNetwork(cfg, cfg.seed)
            self.assertEqual(net.time, 0.)
            self.assertEqual(net._slot_index, 0)
            self.assertEqual(len(net.slot_owners), slot_count)
            self.assertEqual(slot_count, 30 + (n+1)*math.ceil(30/cfg.tdma_sensors_per_group))
            self.assertAlmostEqual(slot_count*cfg.slot_duration, frame)
            self.assertAlmostEqual(net.cooperative_slot_gap, gap)
            self.assertEqual({net.slot_owners.count(node) for node in range(n+1)}, {cooperative_count})
            self.assertEqual({net.slot_owners.count(node) for node in range(n+1, n+31)}, {1})
            self.assertEqual((cfg.bit_rate, cfg.slot_duration, cfg.bandwidth_hz), (16000., .6, 8000.))
            self.assertEqual(net.max_packet_bits, {2: 2304, 3: 3200, 4: 4096}[n])
            bound = (net.max_packet_bits/cfg.bit_rate +
                     math.sqrt(2*cfg.area_size**2+cfg.sensor_depth**2)/cfg.sound_speed +
                     cfg.guard_time + cfg.processing_delay)
            self.assertLessEqual(bound, cfg.slot_duration)
            self.assertEqual(diagnostic["clock"]["slot_count"], slot_count)

    def test_all_clocks_derive_from_actual_calendar_and_MIN_band_has_native_tick(self):
        for n, frame, turn, renew, retry, ack, lead in (
                (3, 37.2, 36., 73.8, 111., 111., 25.2),
                (4, 36., 54., 90.6, 126.6, 127., 24.)):
            cfg, mo, _, diagnostic = adapter.build_settings(n, 30, "full", V8)
            clock = diagnostic["clock"]
            for key, expected in (("frame_s", frame), ("cooperative_turn_s", turn),
                                  ("service_renew_lead_s", renew), ("service_retry_interval_s", retry),
                                  ("protected_sensor_home_gap_s", 2*frame)):
                self.assertAlmostEqual(clock[key], expected)
            self.assertEqual((cfg.service_ack_timeout, cfg.grant_ttl), (ack, ack))
            self.assertAlmostEqual(mo.mac_child_lead_s, lead)
            self.assertAlmostEqual(mo.mac_child_lead_s, min(turn, frame-mo.mac_decision_interval_s))
            self.assertGreaterEqual(frame-mo.mac_child_lead_s, mo.mac_decision_interval_s)
            self.assertGreater(mo.mac_child_lead_s, 0.)
            self.assertLess(mo.mac_child_lead_s, frame)

    def test_native_caps_and_v5_quotas_remain_unchanged(self):
        for n in (3, 4):
            mo = adapter.build_settings(n, 30, "full", V8)[1]
            budget = adapter.validate_scale_mac_budget(n, mo)
            self.assertEqual(budget["native_caps"]["mac_pool_slots"], [2, 16])
            self.assertEqual(budget["native_caps"]["mac_auv_slots"], [1, 8])
            self.assertEqual(budget["native_caps"]["mac_max_leases"], [1, 30])
            self.assertEqual(budget["nominal_requested_parent_rights"], 21 if n == 3 else 26)
            self.assertEqual(asdict(mo)["mac_pool_slots"], 12 if n == 3 else 14)

    def test_diagnostics_declare_redistribution_and_changed_physical_lease_horizons(self):
        for n, old_frame, frame, old_coop, new_coop in ((3, 42., 37.2, 10, 8), (4, 48., 36., 10, 6)):
            d = adapter.build_settings(n, 30, "full", V8)[3]["calendar_adaptation"]
            self.assertAlmostEqual(d["old_frame_s"], old_frame)
            self.assertAlmostEqual(d["new_frame_s"], frame)
            self.assertEqual(d["old_cooperative_opportunities_per_node_per_frame"], old_coop)
            self.assertEqual(d["new_cooperative_opportunities_per_node_per_frame"], new_coop)
            self.assertGreater(d["new_sn_home_opportunities_per_s"], d["old_sn_home_opportunities_per_s"])
            self.assertLess(d["new_cooperative_opportunities_per_node_per_s"], d["old_cooperative_opportunities_per_node_per_s"])
            self.assertAlmostEqual(d["new_parent_lease_max_s"], 30*frame)
            self.assertAlmostEqual(d["new_unclipped_child_window_s"], 3*frame)
            self.assertAlmostEqual(d["new_parent_active_opportunity_spacing_s"], 2*frame)
            self.assertAlmostEqual(d["new_protected_sensor_home_gap_s"], 2*frame)
            self.assertEqual(d["mac_demand_report_interval_s"], 72.)
            self.assertTrue(d["channel_airtime_redistributed"])
            self.assertTrue(d["clocks_rederived_from_actual_native_calendar"])
            for key in ("physical_slots_or_bitrate_added", "new_scheduler_or_information", "constructor_selects_or_trains"):
                self.assertFalse(d[key])
            self.assertNotIn("selected", d)
            self.assertNotIn("trained", d)
            self.assertEqual(d["selection_status"],
                             "This constructor does not select or launch candidates; consult the external campaign plan and actual ledger")
            self.assertIn("may get worse", d["tradeoff"])
            self.assertIn("No delivery, throughput, safety or ordering guarantee", d["tradeoff"])

    def test_cfg_MO_RO_and_complete_declaration_JSON_roundtrip(self):
        for n in (2, 3, 4):
            for method in ("full", "usde_only"):
                cfg, mo, ro, _ = adapter.build_settings(n, 30, method, V8)
                loaded_cfg = adapter.ScaleConfig.from_dict(json.loads(json.dumps(cfg.to_dict(), allow_nan=False)))
                loaded_mo = adapter.MethodOptions(**json.loads(json.dumps(asdict(mo), allow_nan=False)))
                loaded_ro = adapter.RoutingOptions(**json.loads(json.dumps(asdict(ro), allow_nan=False)))
                self.assertEqual(loaded_cfg.to_dict(), cfg.to_dict())
                self.assertEqual(loaded_cfg.fingerprint, cfg.fingerprint)
                self.assertEqual(asdict(loaded_mo), asdict(mo))
                self.assertEqual(asdict(loaded_ro), asdict(ro))
                declared = workflow.declaration(n, 30, method, V8)
                self.assertEqual(json.loads(json.dumps(declared, sort_keys=True, allow_nan=False)), declared)

    def test_original_learning_reward_action_and_protocol_declaration_unchanged(self):
        for n in (2, 3, 4):
            for method in ("full", "usde_only"):
                old = workflow.declaration(n, 30, method, V5)
                new = workflow.declaration(n, 30, method, V8)
                for key in ("learning", "training_protocol", "routing_options", "reward", "ending", "old_weights_allowed"):
                    self.assertEqual(new[key], old[key])
                self.assertFalse(new["old_weights_allowed"])
                self.assertEqual(new["config"]["action_frame"], old["config"]["action_frame"])

    def test_original_scientific_source_and_reference_identities_match_frozen_v5(self):
        manifest = (paths.EXPERIMENT / "iterative_candidates_20261012" /
                    "packet_grid_window_v5" / "code" / "PACKAGE_MANIFEST.json")
        if not manifest.is_file():
            self.skipTest("Historical V5 evidence is absent in a standalone package")
        expected = json.loads(manifest.read_text(encoding="utf-8"))["source_hashes"]
        keys = {key for key in expected if key.startswith(("original/", "reference/"))}
        self.assertEqual(len(keys), 110)
        current = workflow.source_hashes()
        self.assertEqual({key: current[key] for key in keys}, {key: expected[key] for key in keys})
        # Adapter identities intentionally change; this is scientific-source
        # preservation, not permission to load an old adapter-bound checkpoint.
        self.assertNotEqual(current["adapter/environment.py"], expected["adapter/environment.py"])
        for item in (OriginalC07, AcousticNetwork, workflow.native.Policy, workflow.native.ImprovedTD3Agent):
            self.assertTrue(Path(inspect.getfile(item)).resolve().is_relative_to(paths.SOURCE.resolve()))


class CalendarChildPhaseContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.settings = {n: adapter.build_settings(n, 30, "full", V8) for n in (3, 4)}
        cls.calendars = {n: AcousticNetwork(cls.settings[n][0], cls.settings[n][0].seed) for n in (3, 4)}

    def fixture(self, n, time, donor, parent_phase=0, lead=None):
        cfg, mo, _, _ = self.settings[n]
        if lead is not None:
            mo = replace(mo, mac_child_lead_s=lead)
        calendar = self.calendars[n]
        parent = SlotLease(epoch=0, lease_id=1, donor=donor, borrower=0,
                           slot_offset=calendar.slot_owners.index(donor), start_frame=parent_phase,
                           end_frame=parent_phase+mo.mac_coop_lease_frames, frame_stride=mo.mac_frame_stride)
        pool = dict(parent=parent.to_dict(), child_windows=[])
        calls = []
        def propose(parent_id, borrower, start_frame, end_frame):
            calls.append(dict(parent=parent_id, borrower=borrower, start=start_frame, end=end_frame))
            return 1
        net = SimpleNamespace(time=time, frame_duration=len(calendar.slot_owners)*cfg.slot_duration,
                              slot_duration=cfg.slot_duration, cooperative_slot_gap=calendar.cooperative_slot_gap,
                              slot_owners=calendar.slot_owners, available_pool_leases=lambda: [pool],
                              propose_child=propose)
        net.current_frame = ParentNetwork.current_frame.fget(net)
        fixture = SimpleNamespace(cfg=cfg, method_options=mo, network=net,
                                  mac_scheduler_metrics={"child_leases_requested": 0}, mac_scheduler_events=[])
        fixture._c04_child_tick = lambda candidates, pools: IntentEnv._c04_child_tick(fixture, candidates, pools)
        return fixture, calls, parent

    def qualifying_call(self, n, donor, parent_phase, tick_phase, lead=None):
        cfg, mo, _, _ = self.settings[n]
        frame = len(self.calendars[n].slot_owners)*cfg.slot_duration
        # One joint stride-calendar/decision-tick period: n3 = 372 s,
        # n4 = 72 s. Use the shared 0.2 s lattice of 1 s physics and 0.6 s
        # slots; this is arithmetic only, not a change to either real clock.
        period = math.lcm(round(frame*mo.mac_frame_stride*5), round(mo.mac_decision_interval_s*5))/5
        beginning = 2*mo.mac_frame_stride*frame
        for tick in range(round(period/mo.mac_decision_interval_s)):
            time = beginning + tick_phase + tick*mo.mac_decision_interval_s
            fixture, calls, parent = self.fixture(n, time, donor, parent_phase, lead)
            IntentEnv._child_tick(fixture, [(donor, 1.)])
            if calls:
                return fixture, calls[0], parent
        return None

    def test_every_SN_parent_parity_and_native_tick_origin_reaches_real_selector(self):
        # All 60 origins on the real clock's 0.2 s joint lattice plus an
        # off-lattice phase demonstrate reachability, not just a positive band.
        for n in (3, 4):
            cfg, mo, _, _ = self.settings[n]
            calendar = self.calendars[n]
            frame = len(calendar.slot_owners)*cfg.slot_duration
            for parent_phase in (0, 1):
                for tick_phase in [index/5 for index in range(60)] + [.137]:
                    for donor in range(n+1, n+31):
                        with self.subTest(n=n, parent_phase=parent_phase, tick_phase=tick_phase, donor=donor):
                            result = self.qualifying_call(n, donor, parent_phase, tick_phase)
                            self.assertIsNotNone(result)
                            fixture, call, parent = result
                            first = call["start"]*frame+parent.slot_offset*cfg.slot_duration
                            self.assertGreater(first-fixture.network.time, mo.mac_child_lead_s)
                            self.assertLessEqual(first-fixture.network.time, frame+1e-10)
                            self.assertEqual(call["end"]-call["start"], 3)
                            child = ChildLease(parent=parent, child_id=1, borrower=donor,
                                               start_frame=call["start"], end_frame=call["end"])
                            self.assertEqual([f for f in range(call["start"], call["end"]) if child.active(f)],
                                             [call["start"], call["start"]+2])
            self.assertEqual(calendar.time, 0.)
            self.assertEqual(calendar._slot_index, 0)

    def test_retaining_old_n4_MIN36_under_F36_gives_empty_native_search(self):
        for donor in range(5, 35):
            for parent_phase in (0, 1):
                self.assertIsNone(self.qualifying_call(4, donor, parent_phase, 0., lead=36.))

    def test_MIN_lower_bound_remains_strict_without_selector_rewrite(self):
        for n in (3, 4):
            cfg, mo, _, _ = self.settings[n]
            donor = n+30
            first = self.calendars[n].slot_owners.index(donor)*cfg.slot_duration
            time = first-mo.mac_child_lead_s
            equal, calls, _ = self.fixture(n, time, donor)
            IntentEnv._child_tick(equal, [(donor, 1.)])
            self.assertEqual(calls, [])
            later, calls, _ = self.fixture(n, time-1e-6, donor)
            IntentEnv._child_tick(later, [(donor, 1.)])
            self.assertEqual(len(calls), 1)


class CalendarNativeFactoryContracts(unittest.TestCase):
    def test_zero_step_native_factory_schema_calendar_and_service_clock_consistency(self):
        import numpy as np
        # Native real constructors/reset execute, but physics/net advancement
        # is forbidden throughout, including constructors reached by Policy.
        with mock.patch.object(OriginalC07, "step", side_effect=AssertionError("physical env.step forbidden")), \
                mock.patch.object(AcousticNetwork, "advance", side_effect=AssertionError("network.advance forbidden")):
            for n in (2, 3, 4):
                for method in ("full", "usde_only"):
                    cfg, mo, ro, diagnostic = adapter.build_settings(n, 30, method, V8, faults=[])
                    env = adapter.make_environment(n, 30, method, V8, faults=[])
                    self.addCleanup(env.close)
                    self.assertEqual((env.step_count, env.time, env.network.time, env.network._slot_index), (0, 0., 0., 0))
                    if n == 2:
                        self.assertIs(type(env), OriginalC07)
                    else:
                        self.assertIs(type(env)._select_targets, OriginalC07._select_targets)
                        self.assertIs(type(env)._child_tick, IntentEnv._child_tick)
                        np.testing.assert_array_equal(env.auv_positions, deployment_positions(cfg))
                    self.assertEqual(env.network.queue_options.coord_service_s, 16./n)
                    self.assertAlmostEqual(env.service_retry_interval, diagnostic["clock"]["service_retry_interval_s"])
                    self.assertAlmostEqual(env.service_renew_lead, diagnostic["clock"]["service_renew_lead_s"])
                    self.assertEqual(env.network.slot_owners, AcousticNetwork(cfg, cfg.seed).slot_owners)
                    self.assertEqual(env.method.use_topology, method == "full")
                    policy = object.__new__(workflow.native.Policy)
                    policy.cfg = adapter.ScaleConfig.from_dict(deepcopy(cfg.to_dict()))
                    policy.method = env.method
                    policy.schema = environment_schema(env)
                    policy.checkpoint = {"method_options": asdict(mo), "routing_options": asdict(ro)}
                    with workflow.bindings({"profile": V8}):
                        made = policy.make_environment()
                    self.addCleanup(made.close)
                    self.assertEqual(made.cfg.to_dict(), cfg.to_dict())
                    self.assertEqual(made.network.slot_owners, env.network.slot_owners)
                    self.assertEqual((made.step_count, made.time, made.network.time), (0, 0., 0.))
                    policy.validate_environment(made)
                    self.assertFalse(hasattr(policy, "actors"))
                    self.assertFalse(hasattr(policy, "topology"))
        self.assertIs(adapter.ScaledC07Env.step, OriginalC07.step)

    def test_synthetic_snapshot_accepts_current_binding_and_rejects_old_source_without_opening_weights(self):
        current_hashes = workflow.source_hashes()
        for n in (2, 3, 4):
            for method in ("full", "usde_only"):
                value = workflow.declaration(n, 30, method, V8, faults=[])
                cfg = adapter.ScaleConfig.from_dict(value["config"])
                spec = workflow.native.get_method(value["method"])
                # Dictionary-only loader fixture. raw_load is mocked, and
                # agents/topology have empty synthetic states, never weights.
                saved = dict(format=workflow.INFERENCE_FORMAT, environment_config=cfg.to_dict(),
                             config_fingerprint=cfg.fingerprint, method_id=spec.method_id,
                             method_spec=spec.to_dict(), method_fingerprint=spec.fingerprint,
                             method_options=value["method_options"], routing_options=value["routing_options"],
                             learning_config=value["learning"], training_protocol=value["training_protocol"],
                             revision_learning_options=asdict(workflow.native.RevisionLearningOptions(
                                 area_size=cfg.area_size, max_speed=cfg.max_speed, dt=cfg.dt, action_frame=cfg.action_frame)),
                             global_step=0, seed=7, source_hashes=current_hashes,
                             agents=[{"actor": {}} for _ in range(n)],
                             topology={"online": {}} if spec.use_topology else None,
                             scale_context=dict(version=workflow.VERSION, profile=V8, stage="development",
                                                declaration=value, declaration_sha256=workflow.digest_json(value)))
                with mock.patch.object(workflow, "raw_load", return_value=saved) as raw_load:
                    self.assertIs(workflow.load_new_checkpoint("unused_synthetic_no_file.pt"), saved)
                    raw_load.assert_called_once_with("unused_synthetic_no_file.pt")
                tampered = deepcopy(saved)
                tampered["source_hashes"]["adapter/environment.py"] = "0"*64
                with mock.patch.object(workflow, "raw_load", return_value=tampered):
                    with self.assertRaisesRegex(ValueError, "source identities"):
                        workflow.load_new_checkpoint("unused_synthetic_no_file.pt")


if __name__ == "__main__":
    unittest.main(verbosity=2)
