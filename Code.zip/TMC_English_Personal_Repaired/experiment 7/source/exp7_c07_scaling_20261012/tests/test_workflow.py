"""Zero-learning adapter tests; only a dummy executor may call its dummy step.

No original environment is instantiated or advanced, no optimizer is created,
and the native training loop is NEVER invoked. CUDA availability is mocked.
"""
from contextlib import ExitStack
from dataclasses import asdict
import copy
import importlib
import inspect
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock


sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
workflow = importlib.import_module("exp7_c07_scaling_20261012.workflow")
budget = importlib.import_module("exp7_c07_scaling_20261012.budget")
native = workflow.native

BOUND_NAMES = ("Config", "TaskV4Env", "sources", "TRAIN_FORMAT", "INFERENCE_FORMAT",
               "MAX_TRAIN_STEPS", "load_checkpoint", "save_bundle", "atomic_json")


class DummyEnvironment:
    """A pure counter, intentionally unrelated to the physics implementation."""
    fail = False

    def step(self, *args, **kwargs):
        if type(self).fail:
            raise RuntimeError("synthetic partial-step failure")
        return ("synthetic transition", args, kwargs)


class DummyConfig:
    def __init__(self, value):
        self.value = copy.deepcopy(value)

    def save(self, path):
        Path(path).write_text(json.dumps(self.value), encoding="utf-8")


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.context = {"version": workflow.VERSION, "profile": "natural",
                        "declaration_sha256": "synthetic-binding-only"}

    def globals(self):
        return {name: getattr(native, name) for name in BOUND_NAMES}

    def assert_restored(self, values):
        for name, value in values.items():
            self.assertIs(getattr(native, name), value, name)

    def fake_declaration(self, n=3, sensors=30, method="full_v6", profile="adaptive_v1", faults=None):
        return {"version": workflow.VERSION, "profile": profile, "n_auv": n,
            "n_sensors": sensors, "method": workflow.canonical_method(method),
            "config": {"n_auv": n, "n_sensors": sensors, "faults": faults or []},
            "method_options": {"mac_enabled": method in ("full", "full_v6")},
            "routing_options": {"decision_dwell_s": 45.}, "learning": {"batch_size": 64},
            "training_protocol": {"warmup_steps": 1000, "topology_warmup_steps": 20000,
                                  "smoke_overrides": False}, "old_weights_allowed": False}

    def args(self, **changes):
        values = dict(auv=3, sensors=30, method="full", profile="adaptive_v1", fault="reference",
            stage="development", confirm_full_training=None, resume=None, seed=7, steps=10,
            attempt_id="attempt", ledger=self.root / "ledger.json", budget_mode="aggregate",
            output=self.root / "attempt_output", resume_parent_attempt=None, device="cuda")
        values.update(changes)
        return SimpleNamespace(**values)

    def executor_patches(self, executor):
        stack = ExitStack()
        stack.enter_context(mock.patch.object(workflow, "declaration", side_effect=self.fake_declaration))
        stack.enter_context(mock.patch.object(workflow.ScaleConfig, "from_dict", side_effect=DummyConfig))
        stack.enter_context(mock.patch.object(workflow, "source_hashes", return_value={"synthetic": "sha"}))
        stack.enter_context(mock.patch.object(workflow, "ScaledC07Env", DummyEnvironment))
        stack.enter_context(mock.patch("torch.cuda.is_available", return_value=True))
        stack.enter_context(mock.patch.object(workflow.shutil, "disk_usage", return_value=SimpleNamespace(free=20*1024**3)))
        stack.enter_context(mock.patch.object(native, "train", side_effect=executor))
        return stack

    def new_checkpoint(self):
        # Config and learner dataclasses only: no environment/network/agent.
        config_data = json.loads(workflow.reference_config().read_text(encoding="utf-8-sig"))
        cfg = native.Config.from_dict(config_data)
        metadata = json.loads(workflow.reference_metadata("full_v6").read_text(encoding="utf-8-sig"))
        method = native.get_method("full_v6")
        declared = dict(version=workflow.VERSION, profile="natural", n_auv=cfg.n_auv,
            n_sensors=cfg.n_sensors, method=method.method_id, config=cfg.to_dict(),
            method_options=metadata["method_options"], routing_options=metadata["routing_options"],
            learning=asdict(native.learning_config(cfg)), training_protocol=native.training_protocol(cfg, False),
            old_weights_allowed=False)
        checkpoint = dict(format=workflow.TRAIN_FORMAT, environment_config=cfg.to_dict(),
            config_fingerprint=cfg.fingerprint, method_id=method.method_id,
            method_spec=method.to_dict(), method_fingerprint=method.fingerprint,
            method_options=metadata["method_options"], routing_options=metadata["routing_options"],
            learning_config=asdict(native.learning_config(cfg)),
            revision_learning_options=asdict(native.RevisionLearningOptions(area_size=cfg.area_size,
                max_speed=cfg.max_speed, dt=cfg.dt, action_frame=cfg.action_frame)),
            training_protocol=native.training_protocol(cfg, False), source_hashes={"synthetic": "sha"},
            global_step=10, seed=7, agents=[{"actor": {}} for _ in range(cfg.n_auv)],
            topology={"online": {}}, scale_context=dict(version=workflow.VERSION, profile="natural",
                declaration_sha256=workflow.digest_json(declared), declaration=declared,
                attempt_id="checkpoint_attempt", stage="development", budget_mode="aggregate"))
        return checkpoint, declared

    def test_native_learner_definitions_come_from_the_declared_original_source(self):
        for item in (native, native.ImprovedTD3Agent, native.MaskedDoubleDQN):
            location = Path(inspect.getfile(item)).resolve()
            self.assertTrue(location.is_relative_to(workflow.SOURCE.resolve()), location)

    def test_bindings_preserve_learner_schedule_and_restore_all_globals(self):
        before = self.globals()
        invariants = {name: getattr(native, name) for name in
                      ("train", "ImprovedTD3Agent", "MaskedDoubleDQN", "learning_config", "training_protocol")}
        with workflow.bindings(self.context, cap=100_000):
            self.assertIs(native.Config, workflow.ScaleConfig)
            self.assertIs(native.load_checkpoint, workflow.load_new_checkpoint)
            self.assertIs(native.sources, workflow.source_hashes)
            self.assertEqual(native.TRAIN_FORMAT, workflow.TRAIN_FORMAT)
            self.assertEqual(native.INFERENCE_FORMAT, workflow.INFERENCE_FORMAT)
            self.assertEqual(native.MAX_TRAIN_STEPS, 100_000)
            self.assertTrue(issubclass(native.TaskV4Env, workflow.ScaledC07Env))
            for name, value in invariants.items():
                self.assertIs(getattr(native, name), value, name)
        self.assert_restored(before)

    def test_bindings_restore_after_exception_and_nested_scope(self):
        before = self.globals()
        with self.assertRaisesRegex(RuntimeError, "synthetic"):
            with workflow.bindings(self.context, cap=100_000):
                outer = self.globals()
                with workflow.bindings({**self.context, "profile": "adaptive_v1"}, cap=450_000):
                    self.assertEqual(native.MAX_TRAIN_STEPS, 450_000)
                self.assert_restored(outer)
                raise RuntimeError("synthetic failure")
        self.assert_restored(before)

    def test_save_and_manifest_wrappers_attach_context_without_changing_inputs(self):
        checkpoint = {"format": "unbound", "agents": [{"actor": {"weight": 1}}],
                      "topology": {"online": {"weight": 2}}, "global_step": 10}
        original = copy.deepcopy(checkpoint)
        with mock.patch.object(native, "save_bundle") as save, mock.patch.object(native, "atomic_json") as publish:
            with workflow.bindings(self.context):
                native.save_bundle(checkpoint, self.root, True)
                written = save.call_args.args[0]
                self.assertEqual(written["scale_context"], self.context)
                self.assertEqual(native.export(written)["format"], workflow.INFERENCE_FORMAT)
                for name in ("manifest.json", "summary.json"):
                    native.atomic_json({"status": "synthetic"}, self.root / name)
                    self.assertEqual(publish.call_args.args[0]["scale_context"], self.context)
                native.atomic_json({"status": "running"}, self.root / "progress.json")
                self.assertNotIn("scale_context", publish.call_args.args[0])
        self.assertEqual(checkpoint, original)

    def test_old_weights_reject_before_any_native_migration_or_declaration(self):
        formats = ("collection-v6-c07-training-v1", "collection-v6-c07-long-training-v1",
                   "collection-v6-c07-long-inference-v1", "experiment7-generalize-3-4-terminal-train-continuing-eval-v2-dev90k-training")
        with mock.patch.object(workflow, "declaration") as declaration:
            for old_format in formats:
                with self.subTest(format=old_format), mock.patch.object(workflow, "raw_load", return_value={"format": old_format}):
                    with self.assertRaises(ValueError):
                        workflow.load_new_checkpoint("unused_checkpoint.pt")
            declaration.assert_not_called()

    def test_loader_accepts_new_identity_and_rejects_context_config_or_source_tampering(self):
        checkpoint, declared = self.new_checkpoint()
        with mock.patch.object(workflow, "declaration", return_value=declared), \
                mock.patch.object(workflow, "source_hashes", return_value={"synthetic": "sha"}):
            with mock.patch.object(workflow, "raw_load", return_value=checkpoint):
                self.assertIs(workflow.load_new_checkpoint("unused.pt"), checkpoint)
            changes = (("source_hashes", {"synthetic": "changed"}),
                       ("method_options", {"mac_enabled": False}),
                       ("routing_options", {}),
                       ("scale_context", {"version": "old", "profile": "natural"}),
                       ("scale_context", {"version": workflow.VERSION, "profile": "unknown"}),
                       ("scale_context", {**checkpoint["scale_context"], "declaration_sha256": "wrong"}))
            for key, value in changes:
                tampered = copy.deepcopy(checkpoint)
                tampered[key] = value
                with self.subTest(key=key, value=value), mock.patch.object(workflow, "raw_load", return_value=tampered):
                    with self.assertRaises(ValueError):
                        workflow.load_new_checkpoint("unused.pt")

    def test_loader_rejects_learner_schedule_method_and_stage_tampering(self):
        checkpoint, declared = self.new_checkpoint()
        changes = (("config_fingerprint", "changed"), ("learning_config", {}),
                   ("revision_learning_options", {}),
                   ("training_protocol", native.training_protocol(native.Config.from_dict(declared["config"]), True)),
                   ("method_spec", {}), ("method_fingerprint", "changed"), ("topology", None),
                   ("global_step", True), ("global_step", 100_001),
                   ("scale_context", {**checkpoint["scale_context"], "stage": "unknown"}),
                   ("scale_context", {**checkpoint["scale_context"], "declaration": {"tampered": True}}))
        with mock.patch.object(workflow, "declaration", return_value=declared), \
                mock.patch.object(workflow, "source_hashes", return_value={"synthetic": "sha"}):
            for key, value in changes:
                tampered = copy.deepcopy(checkpoint)
                tampered[key] = value
                with self.subTest(key=key, value=value), mock.patch.object(workflow, "raw_load", return_value=tampered):
                    with self.assertRaises(ValueError):
                        workflow.load_new_checkpoint("unused.pt")

    def test_native_policy_environment_construction_requires_the_binding_scope(self):
        # Do not invoke Policy.__init__, a real model, or a physical constructor.
        # Exercise its actual factory against explicitly synthetic constructors.
        policy = object.__new__(native.Policy)
        policy.cfg = SimpleNamespace(n_auv=3)
        policy.method = native.get_method("full_v6")
        policy.checkpoint = {"method_options": {}, "routing_options": {}}
        policy.validate_environment = mock.Mock()
        class FakeFactoryEnvironment:
            def __init__(self, cfg, method, options, routing):
                self.cfg, self.method_id = cfg, method
        class OriginalGuard:
            def __init__(self, *args):
                raise ValueError("synthetic original exact-two constructor guard")
        with mock.patch.object(native, "TaskV4Env", OriginalGuard), \
                mock.patch.object(native, "MethodOptions", side_effect=lambda **kwargs: kwargs), \
                mock.patch.object(native, "RoutingOptions", side_effect=lambda **kwargs: kwargs), \
                mock.patch.object(workflow, "ScaledC07Env", FakeFactoryEnvironment):
            with workflow.bindings(self.context):
                env = policy.make_environment()
                self.assertEqual(env.cfg.n_auv, 3)
                policy.validate_environment.assert_called_once_with(env)
            self.assertIs(native.TaskV4Env, OriginalGuard)
            with self.assertRaisesRegex(ValueError, "exact-two"):
                policy.make_environment()

    def test_dummy_executor_uses_cuda_full_schedule_fresh_learning_folder_and_real_ledger(self):
        args = self.args()
        before = self.globals()
        def dummy(parameters):
            self.assertEqual(parameters.device, "cuda")
            self.assertFalse(parameters.smoke)
            self.assertTrue(parameters.allow_long_run)
            self.assertEqual(parameters.milestones, [args.steps])
            self.assertEqual(parameters.log_every, 1000)
            self.assertEqual(parameters.checkpoint_every, 10000)
            self.assertEqual(parameters.output, args.output / "learning")
            self.assertTrue(args.output.is_dir())
            self.assertFalse(parameters.output.exists())
            env = native.TaskV4Env()
            for _ in range(parameters.steps):
                env.step("counter only")
            return {"global_step": parameters.steps}
        with self.executor_patches(dummy):
            result = workflow.train_declared(args)
        self.assert_restored(before)
        self.assertEqual(result["physical_steps_this_attempt"], args.steps)
        ledger = workflow.BudgetLedger(args.ledger).snapshot()
        self.assertEqual(ledger["attempts"][0]["status"], "completed")
        self.assertEqual(ledger["development_usage"]["executed_steps"], args.steps)

    def test_physical_step_is_charged_before_synthetic_optimizer_failure(self):
        args = self.args()
        before = self.globals()
        def dummy(parameters):
            native.TaskV4Env().step()
            raise RuntimeError("synthetic critic failure before native global_step increments")
        with self.executor_patches(dummy), self.assertRaisesRegex(RuntimeError, "synthetic critic"):
            workflow.train_declared(args)
        self.assert_restored(before)
        attempt = workflow.BudgetLedger(args.ledger).snapshot()["attempts"][0]
        self.assertEqual(attempt["executed_steps"], 1)
        self.assertEqual(attempt["status"], "failed")

    def test_preparation_io_failure_closes_the_attempt_without_executing_work(self):
        args = self.args()
        with self.executor_patches(lambda parameters: self.fail("Executor must not run after preparation fails")), \
                mock.patch.object(DummyConfig, "save", side_effect=OSError("synthetic preparation failure")), \
                self.assertRaisesRegex(OSError, "synthetic preparation"):
            workflow.train_declared(args)
        snapshot = workflow.BudgetLedger(args.ledger).snapshot()
        self.assertEqual(snapshot["attempts"][0]["status"], "failed")
        self.assertEqual(snapshot["development_usage"]["capacity_used"], 0)

    def test_failed_invoked_partial_step_is_conservatively_charged(self):
        called = []
        before = self.globals()
        class FailingDummy(DummyEnvironment):
            fail = True
        with mock.patch.object(workflow, "ScaledC07Env", FailingDummy):
            with self.assertRaisesRegex(RuntimeError, "synthetic partial-step"):
                with workflow.bindings(self.context, on_step=lambda: called.append(1)):
                    native.TaskV4Env().step()
        self.assert_restored(before)
        self.assertEqual(called, [1], "An invoked partially executed transition must not vanish from physical-work accounting")

    def test_failed_rollback_and_resume_do_not_forgive_earlier_physical_work(self):
        args = self.args()
        def fail_after_two(parameters):
            env = native.TaskV4Env()
            env.step()
            env.step()
            raise RuntimeError("synthetic checkpoint rollback")
        with self.executor_patches(fail_after_two), self.assertRaises(RuntimeError):
            workflow.train_declared(args)
        declared = self.fake_declaration()
        saved = {"global_step": 1, "seed": 7,
                 "scale_context": {"declaration_sha256": workflow.digest_json(declared)}}
        resume = self.args(attempt_id="resume", output=self.root / "resume_output",
                           resume="synthetic_trusted_resume.pt", resume_parent_attempt="attempt", steps=99_999)
        with self.executor_patches(lambda parameters: self.fail("Over-budget executor must never be invoked")), \
                mock.patch.object(workflow, "load_new_checkpoint", return_value=saved), \
                self.assertRaises(budget.BudgetExceeded):
            workflow.train_declared(resume)
        snapshot = workflow.BudgetLedger(args.ledger).snapshot()
        self.assertEqual(snapshot["development_usage"]["executed_steps"], 2)
        self.assertFalse(resume.output.exists())

    def test_cuda_and_disk_guards_reject_before_creating_a_reservation(self):
        for unavailable in ("cuda", "disk"):
            with self.subTest(unavailable=unavailable), self.executor_patches(lambda args: self.fail("Executor is forbidden")):
                target = mock.patch("torch.cuda.is_available", return_value=False) if unavailable == "cuda" else \
                    mock.patch.object(workflow.shutil, "disk_usage", return_value=SimpleNamespace(free=0))
                with target, self.assertRaises(RuntimeError):
                    workflow.train_declared(self.args())
            self.assertFalse((self.root / "ledger.json").exists())
            self.assertFalse((self.root / "attempt_output").exists())

    def test_full_stage_is_not_inferred_from_development_or_an_oversized_target(self):
        for args in (self.args(stage="full"), self.args(steps=100_001)):
            with self.executor_patches(lambda parameters: self.fail("No full or over-cap execution is permitted")), \
                    self.assertRaises(ValueError):
                workflow.train_declared(args)
            self.assertFalse(args.ledger.exists())
            self.assertFalse(args.output.exists())


if __name__ == "__main__":
    unittest.main()
