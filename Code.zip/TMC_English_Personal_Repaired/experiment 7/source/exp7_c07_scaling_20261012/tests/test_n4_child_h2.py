"""Unselected V11 metadata/lifecycle and zero-step constructors only.

No weights/optimizer/learning/trial. Native dependency libraries import, but
every ENV.step/network.advance is forbidden except a fake guarded-call test.
The latter is charged before rejection, yet executes zero original physics.
"""
from copy import deepcopy
from dataclasses import asdict, fields
import ast
import inspect
import pickle
from pathlib import Path
import sys
from types import MethodType, SimpleNamespace
import unittest
from unittest.mock import patch

sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp7_c07_scaling_20261012 import environment as envmod,workflow,root_budget,n4_child_h2 as h2
from exp7_c07_scaling_20261012.tests.test_root_budget_integration import context,synthetic_checkpoint
from usv_auv.network import AcousticNetwork


def ctx(n=4,method="full",profile=h2.PROFILE):
    value=context(n,method,profile)
    value.update(candidate_id="UNSELECTED_SYNTHETIC_ONLY",attempt_id="synthetic-only",
        development_model_limit=200000,budget_mode="per_model")
    return value


class InertInherited(envmod.OriginalC07):
    pass


class BuilderScope(unittest.TestCase):
    def test_all_legacy_profiles_against_actual_pinned_v9_builder_text(self):
        # Compile ONLY the old builder function, with the identical current
        # original native dependencies; do not import a second science tree.
        root=Path(envmod.__file__).resolve().parents[1]
        oldpath=root.parents[2]/"iterative_candidates_20261012/packet_grid_root_budget_v9/code/exp7_c07_scaling_20261012/environment.py"
        if not oldpath.is_file():self.skipTest("Research checkout V9 oracle not distributed")
        self.assertEqual(h2.digest(oldpath),"56238f3e175452f46dcb042ff7cbfa9b23518415cb8cb0834b2eca0b8c21cd6b")
        oldtree=ast.parse(oldpath.read_text(encoding="utf-8-sig"))
        function=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=="build_settings")
        namespace=dict(vars(envmod))
        exec(compile(ast.fix_missing_locations(ast.Module(body=[deepcopy(function)],type_ignores=[])),
            "<pinned-original-V9-builder-only>","exec",dont_inherit=True),namespace)
        oracle=namespace["build_settings"]
        for profile in envmod.PROFILES[:-5]:
            for n in (2,3,4):
                for method in ("full","usde_only"):
                    before=oracle(n,30,method,profile,[]);after=envmod.build_settings(n,30,method,profile,[])
                    self.assertTrue(h2.exact(before[0].to_dict(),after[0].to_dict()))
                    self.assertTrue(h2.exact(asdict(before[1]),asdict(after[1])))
                    self.assertTrue(h2.exact(asdict(before[2]),asdict(after[2])))
                    self.assertTrue(h2.exact(before[3],after[3]))

    def test_fixed_n4_only_mapping_full_typed_cfg_mo_ro_and_original_noise(self):
        self.assertEqual(dict(h2.HORIZONS),{2:1,3:1,4:2})
        for n in (2,3,4):
            for method in ("full","usde_only"):
                old=envmod.build_settings(n,30,method,root_budget.ROOT_BUDGET_PROFILE,[])
                new=envmod.build_settings(n,30,method,h2.PROFILE,[])
                self.assertTrue(h2.exact(old[0].to_dict(),new[0].to_dict()))
                self.assertTrue(h2.exact(asdict(old[2]),asdict(new[2])))
                mo=asdict(old[1]);mo["mac_child_lead_s"]=h2.MINIMUMS[n]
                self.assertTrue(h2.exact(mo,asdict(new[1])))
                self.assertEqual(new[0].exploration_noise,.15)
                self.assertEqual(new[3]["n4_H2_adaptation"]["selector_port"]["changed_AST_sites"],int(n==4))
                before_cfg,before_mo,_=envmod._reference(envmod.canonical_method(method))
                option_delta={k:{"old":before_mo.get(k),"new":v} for k,v in asdict(new[1]).items() if before_mo.get(k)!=v}
                self.assertTrue(h2.exact(new[3]["option_changes"],option_delta))
                if n==4:
                    v5=envmod.build_settings(n,30,method,"adaptive_packet_grid_window_v5",[])
                    delta={k:{"old":asdict(v5[1]).get(k),"new":v} for k,v in asdict(new[1]).items() if asdict(v5[1]).get(k)!=v}
                    self.assertTrue(h2.exact(new[3]["root_budget_adaptation"]["declared_option_diff_from_v5"],delta))
                self.assertEqual(tuple(fields(new[1])),tuple(fields(root_budget.OriginalC07Options)))
        self.assertEqual(envmod.build_settings.__defaults__[0],"adaptive_v1")
        self.assertEqual(envmod.make_environment.__defaults__[0],"adaptive_v1")

    def test_legacy_registration_preserved_and_scope_not_tunable(self):
        self.assertEqual(envmod.PROFILES[:-5],("natural","adaptive_v1","adaptive_packet_v2","adaptive_packet_grid_v3",
            "adaptive_packet_grid_queue_v4","adaptive_packet_grid_window_v5","adaptive_packet_grid_pool_v6",
            "adaptive_packet_grid_calendar_v8",root_budget.ROOT_BUDGET_PROFILE))
        for n,s in ((True,30),(4.0,30),(4,30.0),(4,31)):
            with self.subTest(n=n,s=s),self.assertRaises(ValueError):envmod.build_settings(n,s,"full",h2.PROFILE)
        self.assertIs(h2._ORIGINAL,envmod.OriginalC07._c04_child_tick)
        self.assertNotIn("step",envmod.DeclaredV11C07Env.__dict__)
        self.assertNotIn("_child_tick",envmod.DeclaredV11C07Env.__dict__)
        self.assertNotIn("_c04_child_tick",envmod.DeclaredV11C07Env.__dict__)

    def test_full_options_no_v9_token_identity_or_bool_float_aliases(self):
        values=h2.expected_options(4,"full_v6")
        for name,value in (("mac_pool_slots",20.0),("mac_child_lead_s",36.0),("mac_enabled",1),
                           ("mac_demand_report_interval_s",140.0)):
            with self.subTest(name=name),self.assertRaises(ValueError):
                h2.build_options(4,30,h2.PROFILE,"full_v6",{**values,name:value})
        with self.assertRaises(ValueError):h2.build_options(4,30,root_budget.ROOT_BUDGET_PROFILE,"full_v6",values)
        with self.assertRaises(ValueError):h2.N4H2Options(**values)
        with self.assertRaises(ValueError):root_budget._RegisteredN4RootBudgetOptions(**values)
        self.assertIsNone(h2._SCOPE.get());self.assertIsNone(root_budget._CONSTRUCTION_SCOPE.get())

    def test_controlled_options_pickle_preserves_own_profile_class(self):
        for method in ("full_v6","usde_only_v6"):
            value=h2.build_options(4,30,h2.PROFILE,method,h2.expected_options(4,method))
            restored=pickle.loads(pickle.dumps(value))
            self.assertIs(type(restored),h2.N4H2Options)
            self.assertTrue(h2.exact(asdict(value),asdict(restored)))
        with self.assertRaises(ValueError):h2._restore_options(root_budget.ROOT_BUDGET_PROFILE,h2.expected_options(4,"full_v6"))

    def test_options_token_restores_original_cancel_object(self):
        for error in (RuntimeError("synthetic"),KeyboardInterrupt("synthetic"),SystemExit("synthetic")):
            with self.subTest(error=type(error).__name__),patch.object(h2,"N4H2Options",side_effect=error):
                try:h2.build_options(4,30,h2.PROFILE,"full_v6",h2.expected_options(4,"full_v6"))
                except BaseException as caught:self.assertIs(caught,error)
                else:self.fail("cancel must propagate")
            self.assertIsNone(h2._SCOPE.get());self.assertIsNone(root_budget._CONSTRUCTION_SCOPE.get())

    def test_whole_context_and_saved_identity_reject_before_weights(self):
        value=ctx();saved=synthetic_checkpoint(value)
        self.assertIs(workflow.validate_checkpoint_metadata(saved),saved)
        for mutate in (lambda s:s["method_options"].update(mac_child_lead_s=36.0),
                       lambda s:s["environment_config"].update(exploration_noise=.05),
                       lambda s:s["scale_context"].update(profile=root_budget.ROOT_BUDGET_PROFILE),
                       lambda s:s["source_hashes"].update(extra="0"*64),
                       lambda s:s["training_protocol"].update(smoke=True)):
            wrong=deepcopy(saved);mutate(wrong)
            with self.assertRaises(ValueError):workflow.validate_checkpoint_metadata(wrong)
        wrong=deepcopy(value);wrong["declaration"]["reward"]="different"
        wrong["declaration_sha256"]=workflow.digest_json(wrong["declaration"])
        with self.assertRaises(ValueError):workflow._authenticate_v11_context(wrong)


class LifecycleAndBridge(unittest.TestCase):
    def test_instance_ownership_missing_reset_and_exact_restore(self):
        other=object.__new__(InertInherited)
        for original_entry in (False,True):
            env=object.__new__(InertInherited)
            old=MethodType(h2._ORIGINAL,env)
            if original_entry:env.__dict__[h2.INNER]=old
            before=dict(env.__dict__);handle=h2.SelectorHandle(env)
            self.assertIs(env._c04_child_tick.__func__,h2._H2)
            self.assertIs(other._c04_child_tick.__func__,h2._ORIGINAL)
            del env.__dict__[h2.INNER];handle.check(reset_deleted=True)
            self.assertIs(env.__dict__[h2.INNER],handle.bound)
            handle.restore();self.assertEqual(env.__dict__,before)
            with self.assertRaises(ValueError):handle.check()

    def test_reset_deleted_instance_cannot_be_stolen_by_nested_handle(self):
        env=object.__new__(InertInherited);handle=h2.SelectorHandle(env)
        del env.__dict__[h2.INNER]
        with self.assertRaises(ValueError):h2.SelectorHandle(env)
        handle.check(reset_deleted=True);handle.restore();self.assertEqual(env.__dict__,{})

    def test_restore_missing_method_clears_owner_and_restores_exact_original_entry(self):
        for original_entry in (False,True):
            env=object.__new__(InertInherited);bound=MethodType(h2._ORIGINAL,env)
            if original_entry:env.__dict__[h2.INNER]=bound
            before=dict(env.__dict__);handle=h2.SelectorHandle(env)
            del env.__dict__[h2.INNER]
            handle.restore();self.assertEqual(env.__dict__,before)
            self.assertTrue(handle.closed);self.assertNotIn(h2.OWNER,env.__dict__)
            if original_entry:self.assertIs(env.__dict__[h2.INNER],bound)

    def test_foreign_hook_and_typed_nonmax_code_drift_rejected(self):
        env=object.__new__(InertInherited);handle=h2.SelectorHandle(env)
        env.__dict__[h2.INNER]=MethodType(h2._ORIGINAL,env)
        with self.assertRaises(ValueError):handle.check(reset_deleted=True)
        env.__dict__[h2.INNER]=handle.bound;handle.restore()
        original=h2._H2.__code__
        try:
            constants=list(original.co_consts)
            index=next(i for i,x in enumerate(constants) if type(x) is float and x==.25)
            constants[index]=.5;h2._H2.__code__=original.replace(co_consts=tuple(constants))
            with self.assertRaises(ValueError):h2.validate_code()
        finally:h2._H2.__code__=original
        h2.validate_code()

    def test_derived_globals_and_defaults_cannot_be_injected(self):
        h2._H2.__globals__["min"]=lambda *args:0
        try:
            with self.assertRaises(ValueError):h2.validate_code()
        finally:del h2._H2.__globals__["min"]
        h2._H2.__defaults__=(None,)
        try:
            with self.assertRaises(ValueError):h2.validate_code()
        finally:h2._H2.__defaults__=None
        h2.validate_code()

    def test_zero_step_native_constructors_and_reset_all_six_arms(self):
        original_class=dict(workflow._ORIGINAL_POLICY.__dict__)
        with patch.object(AcousticNetwork,"advance",side_effect=AssertionError("NO network physics")),\
             patch.object(envmod.OriginalC07,"step",side_effect=AssertionError("NO ENV physics")):
            for n in (2,3,4):
                for method in ("full","usde_only"):
                    env=envmod.make_environment(n,30,method,h2.PROFILE,[])
                    try:
                        env.reset(42);env.validate_selector_identity()
                        self.assertEqual(env.step_count,0);self.assertEqual(env.network.time,0.)
                        self.assertIs(env._c04_child_tick.__func__,h2._H2 if n==4 else h2._ORIGINAL)
                        if n==4:
                            env.__dict__[h2.INNER]=MethodType(h2._ORIGINAL,env)
                            with self.assertRaises(ValueError):env.validate_selector_identity()
                            env.__dict__[h2.INNER]=env._v11_selector_handle.bound
                    finally:env.close()
        self.assertEqual(workflow._ORIGINAL_POLICY.__dict__,original_class)

    def test_fast_runtime_100_calls_no_open_readbytes_or_compile_and_no_mutable_cfg_alias(self):
        env=envmod.make_environment(4,30,"full",h2.PROFILE,[])
        try:
            env.reset(42)
            with patch("builtins.open",side_effect=AssertionError("NO runtime open")),\
                 patch.object(Path,"read_bytes",side_effect=AssertionError("NO runtime disk")),\
                 patch("builtins.compile",side_effect=AssertionError("NO runtime compile")),\
                 patch.object(h2,"dependencies",side_effect=AssertionError("NO runtime full PIN")):
                for _ in range(100):env.validate_selector_identity()
                env.cfg.exploration_noise=.05
                with self.assertRaises(ValueError):env.validate_selector_identity()
                env.cfg.exploration_noise=.15
            self.assertEqual(env.step_count,0);self.assertEqual(env.network.time,0.)
        finally:env.close()

    def test_actual_topology_reassignment_cannot_hide_behind_candidates_alias(self):
        env=envmod.make_environment(4,30,"full",h2.PROFILE,[])
        original=env.network.topologies;alias=env.network.candidates
        try:
            env.network.topologies=list(reversed(original))
            self.assertIs(env.network.candidates,alias)
            self.assertEqual(env.network.n_actions,len(original)+1)
            with self.assertRaises(ValueError):env.validate_selector_identity()
        finally:
            env.network.topologies=original;env.close()

    def test_full_reset_reference_drift_rejects_before_reset_and_cleans_hook(self):
        env=envmod.make_environment(4,30,"full",h2.PROFILE,[])
        original=h2.digest
        def drift(path):return "0"*64 if Path(path).name=="metadata.json" else original(path)
        try:
            with patch.object(h2,"digest",side_effect=drift),\
                 patch.object(envmod.ScaledC07Env,"reset",side_effect=AssertionError("NO reset after drift")) as reset:
                with self.assertRaises(ValueError):env.reset(42)
                reset.assert_not_called()
            self.assertTrue(env._v11_selector_handle.closed);self.assertNotIn(h2.OWNER,env.__dict__)
        finally:env.close()

    def test_nested_writers_native_globals_and_original_policy_unchanged(self):
        names=("Config","TaskV4Env","MethodOptions","sources","TRAIN_FORMAT","INFERENCE_FORMAT",
            "MAX_TRAIN_STEPS","load_checkpoint","save_bundle","atomic_json","Policy")
        before={name:getattr(workflow.native,name) for name in names}
        for error in (RuntimeError("synthetic"),KeyboardInterrupt("synthetic"),SystemExit("synthetic")):
            try:
                with workflow.bindings(ctx()) as outer:
                    self.assertIsInstance(outer,workflow._V11NativeFacade)
                    outer_env=workflow.native.TaskV4Env
                    with workflow.bindings(ctx(profile=root_budget.ROOT_BUDGET_PROFILE)) as old:
                        self.assertIs(old,workflow.native)
                    self.assertIs(workflow.native.TaskV4Env,outer_env)
                    raise error
            except BaseException as caught:self.assertIs(caught,error)
            self.assertTrue(all(getattr(workflow.native,name) is value for name,value in before.items()))
            self.assertIsNone(h2._SCOPE.get());self.assertIsNone(root_budget._CONSTRUCTION_SCOPE.get())

    def test_reset_cancel_restores_own_hook_preserves_original_object(self):
        for error in (RuntimeError("synthetic"),KeyboardInterrupt("synthetic"),SystemExit("synthetic")):
            env=envmod.make_environment(4,30,"full",h2.PROFILE,[])
            try:
                with patch.object(envmod.ScaledC07Env,"reset",side_effect=error):
                    try:env.reset(42)
                    except BaseException as caught:self.assertIs(caught,error)
                    else:self.fail("must propagate original")
                self.assertIs(env._c04_child_tick.__func__,h2._ORIGINAL)
                self.assertNotIn(h2.OWNER,env.__dict__)
                self.assertTrue(env._v11_selector_handle.closed)
            finally:env.close()

    def test_reset_deleted_method_then_cancel_cleanup_preserves_object_without_keyerror(self):
        error=KeyboardInterrupt("synthetic reset after deletion")
        env=envmod.make_environment(4,30,"full",h2.PROFILE,[])
        def fail(instance,seed=None):
            del instance.__dict__[h2.INNER]
            raise error
        try:
            with patch.object(envmod.ScaledC07Env,"reset",new=fail):
                try:env.reset(42)
                except BaseException as caught:self.assertIs(caught,error)
                else:self.fail("must propagate cancel")
            self.assertTrue(env._v11_selector_handle.closed);self.assertNotIn(h2.OWNER,env.__dict__)
            self.assertIs(env._c04_child_tick.__func__,h2._ORIGINAL)
            self.assertFalse(getattr(error,"__notes__",None))
        finally:env.close()

    def test_close_cleanup_new_cancel_priority_and_secondary_notes(self):
        for first,second,primary in ((ValueError("first"),KeyboardInterrupt("second"),"second"),
                                     (SystemExit("first"),ValueError("second"),"first")):
            env=envmod.make_environment(4,30,"full",h2.PROFILE,[])
            try:
                with patch.object(envmod.ScaledC07Env,"close",side_effect=first),\
                     patch.object(env._v11_selector_handle,"restore",side_effect=second):
                    try:env.close()
                    except BaseException as caught:
                        self.assertIs(caught,first if primary=="first" else second)
                        self.assertTrue(caught.__notes__)
                    else:self.fail("cleanup errors must remain visible")
            finally:
                env._v11_selector_handle.restore()
                envmod.ScaledC07Env.close(env)

    def test_invalid_invoked_step_is_charged_without_original_physics(self):
        charges=[];value=ctx();decl=value["declaration"]
        cfg,mo,ro,_=envmod.build_settings(4,30,"full",h2.PROFILE,[])
        with patch.object(envmod.OriginalC07,"step",side_effect=AssertionError("NO original physics")) as physical:
            with workflow.bindings(value,on_step=lambda:charges.append(1)) as executor:
                env=object.__new__(executor.TaskV4Env)
                env._v11_expected=(cfg,"full_v6",mo,ro);env._v11_declared_n_auv=4;env._v11_initialized=False
                env._v11_expected_DTO=envmod.validate_v11_settings(cfg,"full_v6",mo,ro)
                env._v11_selector_handle=None
                with self.assertRaises(ValueError):env.step(None,None)
            self.assertEqual(charges,[1]);physical.assert_not_called()

    def test_facade_calls_original_validator_first_without_policy_global_patch(self):
        # Manufacture a separate module-like proxy and inert Policy class.
        # Never modify real native.Policy methods/globals or call its __init__.
        real=workflow.native;original_class=real.Policy;original_members=dict(original_class.__dict__)
        value=ctx();saved=synthetic_checkpoint(value);events=[];failure=[None];captured=[]
        class InertPolicy:
            def __init__(self,checkpoint,*args,**kwargs):
                events.append("constructor")
                self.cfg=envmod.ScaleConfig.from_dict(checkpoint["environment_config"])
                self.method=real.get_method(checkpoint["method_id"]);self.checkpoint=checkpoint
            def validate_environment(self,env):
                events.append("native_validator")
                captured.append(env)
                if failure[0] is not None:raise failure[0]
                if env.cfg.to_dict()!=self.cfg.to_dict():raise ValueError("native validator first")
            def make_environment(self):
                env=workflow.native.TaskV4Env(self.cfg,self.method.method_id,
                    workflow.native.MethodOptions(**self.checkpoint["method_options"]),
                    real.RoutingOptions(**self.checkpoint["routing_options"]))
                self.validate_environment(env);return env
        proxy=SimpleNamespace(**vars(real));proxy.Policy=InertPolicy
        members=dict(InertPolicy.__dict__);codes={k:v.__code__ for k,v in members.items() if inspect.isfunction(v)}
        meta={k:(deepcopy(v.__defaults__),deepcopy(v.__kwdefaults__),deepcopy(v.__annotations__)) for k,v in members.items() if inspect.isfunction(v)}
        with patch.object(workflow,"native",proxy),patch.object(workflow,"_ORIGINAL_POLICY",InertPolicy),\
             patch.object(workflow,"_ORIGINAL_POLICY_VALIDATE",InertPolicy.validate_environment),\
             patch.object(workflow,"_ORIGINAL_POLICY_MEMBERS",members),patch.object(workflow,"_ORIGINAL_POLICY_CODES",codes),\
             patch.object(workflow,"_ORIGINAL_POLICY_CALLABLE_META",meta),\
             patch.object(AcousticNetwork,"advance",side_effect=AssertionError("NO physics")):
            with workflow.bindings(value) as executor:
                policy=executor.Policy(saved,"cpu");env=policy.make_environment()
                try:
                    env.reset(42);env.__dict__[h2.INNER]=MethodType(h2._ORIGINAL,env)
                    with self.assertRaises(ValueError):policy.validate_environment(env)
                    self.assertEqual(events[-1],"native_validator")
                    env.__dict__[h2.INNER]=env._v11_selector_handle.bound
                    env.cfg=deepcopy(env.cfg);env.cfg.exploration_noise=.05
                    with self.assertRaisesRegex(ValueError,"native validator first"):policy.validate_environment(env)
                    env.cfg=policy.cfg
                    wrong=deepcopy(saved);wrong["method_options"]["mac_child_lead_s"]=36.
                    with self.assertRaises(ValueError):executor.Policy(wrong,"cpu")
                    self.assertEqual(events.count("constructor"),1)
                finally:env.close()
                for error in (ValueError("validation early"),KeyboardInterrupt("validation cancel"),SystemExit("validation exit")):
                    failure[0]=error
                    try:policy.make_environment()
                    except BaseException as caught:self.assertIs(caught,error)
                    else:self.fail("make validation must fail")
                    finally:failure[0]=None
                    failed=captured[-1]
                    self.assertTrue(failed._v11_close_attempted);self.assertTrue(failed._v11_selector_handle.closed)
                    self.assertNotIn(h2.OWNER,failed.__dict__)
                outer_env=workflow.native.TaskV4Env
                for label in ("fault","mkdir","threads"):
                    for error in (OSError(label),KeyboardInterrupt(label)):
                        made=None
                        try:
                            with workflow.bindings(value) as child:
                                child_policy=child.Policy(saved,"cpu");made=child_policy.make_environment()
                                raise error  # Synthetic early eval-setup failure; no actual eval.
                        except BaseException as caught:self.assertIs(caught,error)
                        self.assertTrue(made._v11_close_attempted);self.assertTrue(made._v11_selector_handle.closed)
                        self.assertNotIn(h2.OWNER,made.__dict__)
                        self.assertIs(workflow.native.TaskV4Env,outer_env)
        self.assertIs(real.Policy,original_class);self.assertEqual(real.Policy.__dict__,original_members)

    def test_saved_export_context_and_nested_writer_ownership_without_file_IO(self):
        writes=[];publishes=[];value=ctx()
        def save(checkpoint,output,milestone=False):writes.append(deepcopy(checkpoint))
        def publish(record,path):publishes.append(deepcopy(record))
        with patch.object(workflow.native,"save_bundle",save),patch.object(workflow.native,"atomic_json",publish):
            with workflow.bindings(value) as outer:
                outer.save_bundle({"opaque":"manufactured"},Path("synthetic"))
                old=ctx(profile=root_budget.ROOT_BUDGET_PROFILE)
                with workflow.bindings(old) as inner:
                    self.assertIs(inner,workflow.native)
                    inner.save_bundle({"opaque":"manufactured"},Path("synthetic"))
                outer.atomic_json({"opaque":"manufactured"},Path("summary.json"))
                training=synthetic_checkpoint(value);training["format"]=workflow.TRAIN_FORMAT
                exported=outer.export(training)
                self.assertTrue(workflow.json_value_type_exact(exported["scale_context"],value))
        self.assertTrue(workflow.json_value_type_exact(writes[0]["scale_context"],value))
        self.assertTrue(workflow.json_value_type_exact(writes[1]["scale_context"],old))
        self.assertTrue(workflow.json_value_type_exact(publishes[0]["scale_context"],value))

    def test_multiple_owned_cleanup_does_not_leak_after_errors_or_mask_body(self):
        # Manufactured owned-type fixtures, no original ENV constructor/close.
        calls=[]
        class OwnedInert(envmod.DeclaredV11C07Env):
            def close(self):
                calls.append(self.name);self._v11_close_attempted=True
                if self.failure is not None:
                    self._v11_close_error=self.failure;raise self.failure
            def verify_closed_identity(self):
                if not self._v11_close_attempted or self._v11_close_error is not None:raise ValueError("not closed")
        def item(name,error=None):
            value=object.__new__(OwnedInert);value.name=name;value.failure=error
            value._v11_close_attempted=False;value._v11_close_error=None;return value
        first=ValueError("ordinary");cancel=KeyboardInterrupt("cleanup cancel")
        values=[item("first",first),item("cancel",cancel),item("healthy")]
        try:workflow._V11NativeFacade._cleanup_environments(values)
        except BaseException as caught:self.assertIs(caught,cancel);self.assertTrue(caught.__notes__)
        else:self.fail("cleanup must raise")
        self.assertEqual(calls,["healthy","cancel","first"])
        body=SystemExit("original body")
        workflow._V11NativeFacade._cleanup_environments(values,body)
        self.assertEqual(calls,["healthy","cancel","first"])
        self.assertEqual(len(body.__notes__),2)

    def test_normal_closed_owned_environment_not_double_closed(self):
        env=envmod.make_environment(4,30,"full",h2.PROFILE,[])
        with patch.object(env._v11_selector_handle,"restore",wraps=env._v11_selector_handle.restore) as restore:
            env.close();workflow._V11NativeFacade._cleanup_environments([env]);env.close()
            self.assertEqual(restore.call_count,1)
        env.__dict__[h2.INNER]=MethodType(h2._H2,env)
        with self.assertRaises(ValueError):workflow._V11NativeFacade._cleanup_environments([env])
        del env.__dict__[h2.INNER]

    def test_private_cleanup_rejects_nonowner_without_calling_legacy_close(self):
        calls=[];foreign=SimpleNamespace(close=lambda:calls.append("foreign"))
        with self.assertRaises(ValueError):workflow._V11NativeFacade._cleanup_environments([foreign])
        self.assertEqual(calls,[])

    def test_p0_matrix_and_facade_use_are_explicit_AST(self):
        path=Path(envmod.__file__).with_name("evaluation.py")
        text=path.read_text(encoding="utf-8")
        self.assertIn('context["profile"] in (ROOT_BUDGET_PROFILE,N4_H2_PROFILE,*JOINT_PROFILES)',text)
        self.assertIn("with bindings(context,cap=cap) as executor:",text)
        self.assertIn("policy=executor.Policy(saved,device)",text)


if __name__=="__main__":unittest.main()
