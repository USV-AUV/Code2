"""Prepared, explicitly scoped V9 MethodOptions constructor; no integration.

This module does not register a profile, replace an original class/global,
create an environment, load weights, or launch a candidate. The caller must
provide its registered profile tuple. Old/unregistered profiles and all n2
settings use the ORIGINAL C07 MethodOptions constructor without modification.

Only the exact registered n4/common30 tuple can use a local C03 validator whose
pool upper bound is 20 rather than 16. The original C04/C06 and C02/C01/V5
validators remain on the real call chain. This is an explicit scale-port of a
configuration validation domain, NOT an originally legal pool20, more PHY
capacity, an installed parent/child right, or a performance/safety guarantee.

Native workflow Policy/validate_settings/run_options reconstruction still needs
separate, authenticated integration by the caller. This prepared helper alone
does not make original checkpoint loaders accept pool20. No new MO fields or
remote information are introduced; asdict has the exact original field schema.
"""
import ast
from contextvars import ContextVar
from copy import deepcopy
from dataclasses import asdict, dataclass, fields
import hashlib
import inspect
from collections.abc import Mapping
import textwrap
from types import FunctionType, MappingProxyType

from . import paths  # Establish the explicit original scientific dependency.
from v6_candidates.c07.environment import MethodOptions as OriginalC07Options
from v6_candidates.c03.environment import MethodOptions as OriginalC03Options
from v6_candidates.c04.environment import MethodOptions as OriginalC04Options
from v6_candidates.c06.environment import MethodOptions as OriginalC06Options


ROOT_BUDGET_PROFILE = "adaptive_packet_grid_root_budget_v9"
BUDGET_FIELDS = ("mac_pool_slots", "mac_auv_slots", "mac_max_leases",
                 "mac_child_max_active", "mac_child_slots_per_sensor",
                 "mac_coop_lease_frames", "mac_frame_stride", "mac_child_lease_frames")
REGISTERED_TUPLES = MappingProxyType({
    3: (15, 2, 21, 6, 2, 30, 2, 3),
    4: (20, 2, 28, 8, 2, 30, 2, 3),
})
_ORIGINAL_FIELDS = tuple(fields(OriginalC07Options))
_FIELD_NAMES = frozenset(field.name for field in _ORIGINAL_FIELDS)
_N4_CONSTRUCTION_SCOPE = (4, 30, ROOT_BUDGET_PROFILE, REGISTERED_TUPLES[4])
_CONSTRUCTION_SCOPE = ContextVar("c07_registered_root_budget_constructor", default=None)


def _ast_dump(value):
    return ast.dump(value, include_attributes=False)


def _ported_c03_validator():
    """Copy only C03's pool16->20 literal; retain its original super anchor.

    The original zero-argument super closure names OriginalC03Options. Keeping
    that closure makes this local replacement continue at original C02 rather
    than accidentally call original C03 a second time. A local MRO insertion
    below C04 supplies the replacement; none of the original methods is edited.
    """
    original = OriginalC03Options.__dict__["__post_init__"]
    tree = ast.parse(textwrap.dedent(inspect.getsource(original)))
    if len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef):
        raise RuntimeError("Unexpected original C03 validator source shape")
    function = tree.body[0]
    if function.name != "__post_init__" or function.decorator_list:
        raise RuntimeError("Unexpected original C03 validator function")
    modified = deepcopy(function)
    sites = [node for node in ast.walk(modified)
             if isinstance(node, ast.Tuple) and len(node.elts) == 3
             and isinstance(node.elts[0], ast.Constant)
             and node.elts[0].value == "mac_pool_slots"]
    if (len(sites) != 1 or not isinstance(sites[0].elts[1], ast.Constant)
            or sites[0].elts[1].value != 2 or not isinstance(sites[0].elts[2], ast.Constant)
            or sites[0].elts[2].value != 16):
        raise RuntimeError("Original C03 must have one exact pool [2,16] validation site")
    sites[0].elts[2].value = 20
    restored = deepcopy(modified)
    restored_site = next(node for node in ast.walk(restored)
                         if isinstance(node, ast.Tuple) and len(node.elts) == 3
                         and isinstance(node.elts[0], ast.Constant)
                         and node.elts[0].value == "mac_pool_slots")
    restored_site.elts[2].value = 16
    if _ast_dump(restored) != _ast_dump(function):
        raise RuntimeError("C03 validator port changed more than the pool upper-bound literal")
    template = ast.ClassDef(name="_C03ValidatorTemplate", bases=[], keywords=[],
                            body=[modified], decorator_list=[])
    module = ast.fix_missing_locations(ast.Module(body=[template], type_ignores=[]))
    namespace = {"__name__": __name__}
    exec(compile(module, __file__, "exec"), namespace)
    code = namespace["_C03ValidatorTemplate"].__dict__["__post_init__"].__code__
    if code.co_freevars != original.__code__.co_freevars or code.co_freevars != ("__class__",):
        raise RuntimeError("Original C03 super closure changed")
    if original.__closure__[0].cell_contents is not OriginalC03Options:
        raise RuntimeError("Original C03 super must continue through its actual original class")
    ported = FunctionType(code, original.__globals__, original.__name__,
                          original.__defaults__, original.__closure__)
    ported.__module__ = __name__
    ported.__qualname__ = "_C03RootBudgetValidation.__post_init__"
    ported.__kwdefaults__ = original.__kwdefaults__
    ported.__annotations__ = dict(original.__annotations__)
    audit = dict(original_source=inspect.getsourcefile(original),
                 original_validator_ast_sha256=hashlib.sha256(_ast_dump(function).encode()).hexdigest(),
                 ported_validator_ast_sha256=hashlib.sha256(_ast_dump(modified).encode()).hexdigest(),
                 restored_validator_ast_sha256=hashlib.sha256(_ast_dump(restored).encode()).hexdigest(),
                 changed_ast_sites=1, changed_field="mac_pool_slots", original_upper=16, ported_upper=20,
                 remaining_validator_AST_identical=True,
                 super_closure_anchor="original v6_candidates.c03.environment.MethodOptions",
                 original_class_or_globals_modified=False)
    return ported, audit


_PORTED_C03_POST_INIT, _C03_DOMAIN_AUDIT = _ported_c03_validator()


def _require_n4_constructor_scope():
    if _CONSTRUCTION_SCOPE.get() != _N4_CONSTRUCTION_SCOPE:
        raise ValueError("Pool20 options require the explicit registered n4/common30 V9 constructor scope")


class _C03RootBudgetValidation(OriginalC03Options):
    def __post_init__(self):
        # The internal insertion class is not a generic expanded constructor
        # either. Only its checked complete-C07 factory scope can invoke it.
        _require_n4_constructor_scope()
        _PORTED_C03_POST_INIT(self)


def _check_scale_identity(n_auv, n_sensors, profile, registered_profiles):
    if type(n_auv) is not int or n_auv not in (2, 3, 4):
        raise ValueError("Root budget constructor supports only integer n_auv2/3/4")
    if type(n_sensors) is not int or n_sensors < n_auv:
        raise ValueError("Root budget constructor requires an integer sensor count >= n_auv")
    if type(profile) is not str:
        raise ValueError("Profile identity must be an explicit string")
    if (type(registered_profiles) is not tuple
            or any(type(value) is not str for value in registered_profiles)
            or len(set(registered_profiles)) != len(registered_profiles)):
        raise ValueError("Pass the caller's explicit tuple of distinct registered profile strings")


def _values(option_values):
    if isinstance(option_values, OriginalC07Options):
        return asdict(option_values)
    if not isinstance(option_values, Mapping):
        raise TypeError("MethodOptions input must be original options or a field mapping")
    return dict(option_values)


def _check_registered_tuple(n_auv, n_sensors, values):
    if n_sensors != 30:
        raise ValueError("Registered root-budget candidate is scoped to common30 sensors")
    if set(values) != _FIELD_NAMES:
        raise ValueError("Registered root-budget options must carry the entire unchanged original MO field schema")
    for field in BUDGET_FIELDS:
        if type(values[field]) is not int:
            raise ValueError("Registered root-budget " + field + " must be an integer, not coerced/bool")
    requested = values["mac_pool_slots"] + n_auv*values["mac_auv_slots"]
    if not requested <= values["mac_max_leases"] <= min(30, n_sensors):
        raise ValueError("Actual n_auv parent pool+n_auv*AUV quota must fit global<=30 and the real sensor count")
    if values["mac_child_max_active"] >= values["mac_pool_slots"]:
        raise ValueError("Retain original root rights: active child cap must be smaller than pool")
    if tuple(values[field] for field in BUDGET_FIELDS) != REGISTERED_TUPLES[n_auv]:
        raise ValueError("Options are outside the single registered n_auv root-budget tuple")


@dataclass(frozen=True)
class _RegisteredN4RootBudgetOptions(OriginalC07Options, _C03RootBudgetValidation):
    """Same native field schema; factory scope is external to the MO object."""

    def __post_init__(self):
        _require_n4_constructor_scope()
        _check_registered_tuple(4, 30, asdict(self))
        # Original C06 -> original C04 -> local C03 replacement -> original
        # C02/C01/V5. C05 supplies no independent __post_init__ override.
        super().__post_init__()

    def __reduce_ex__(self, protocol):
        # This named serialized class identifies only the fixed registered
        # n4/V9 tuple. Restore through the same checked factory, not a pickle
        # state injection that bypasses __post_init__. No metadata MO field.
        return _restore_registered_n4_options, (asdict(self),)


_EXPECTED_INSERTION = (OriginalC04Options, _C03RootBudgetValidation, OriginalC03Options)
_MRO = _RegisteredN4RootBudgetOptions.__mro__
_C04_INDEX = _MRO.index(OriginalC04Options)
if _MRO[_C04_INDEX:_C04_INDEX+3] != _EXPECTED_INSERTION:
    raise RuntimeError("The local C03 validator must be inserted immediately after original C04")
if OriginalC07Options is not OriginalC06Options:
    raise RuntimeError("Expected original C07 to export the complete C06 MethodOptions chain")
if tuple(fields(_RegisteredN4RootBudgetOptions)) != _ORIGINAL_FIELDS:
    raise RuntimeError("Scoped root-budget options must have the exact original dataclass field schema")


def build_root_budget_method_options(n_auv, n_sensors, profile, option_values, *, registered_profiles=()):
    """Create declared options without editing native classes or global state.

    The caller supplies its actual profile registry; default empty registration
    intentionally keeps the prepared/not-yet-integrated V9 on the original
    constructor. All n2/old/unknown profiles remain native, including native
    clipping/validation semantics. Registered V9 n3 remains OriginalC07Options.
    Only exact registered V9 n4/common30 uses the local pool-domain scale-port.
    """
    _check_scale_identity(n_auv, n_sensors, profile, registered_profiles)
    values = _values(option_values)
    if n_auv == 2 or profile != ROOT_BUDGET_PROFILE or profile not in registered_profiles:
        return OriginalC07Options(**values)
    _check_registered_tuple(n_auv, n_sensors, values)
    if n_auv == 3:
        return OriginalC07Options(**values)
    token = _CONSTRUCTION_SCOPE.set(_N4_CONSTRUCTION_SCOPE)
    try:
        return _RegisteredN4RootBudgetOptions(**values)
    finally:
        _CONSTRUCTION_SCOPE.reset(token)


def _restore_registered_n4_options(values):
    # Only the serialized scoped n4 class reaches this fixed restoration path.
    # OriginalOptions pickle remains the untouched original implementation.
    return build_root_budget_method_options(4, 30, ROOT_BUDGET_PROFILE, values,
                                            registered_profiles=(ROOT_BUDGET_PROFILE,))


def registered_budget_values(n_auv):
    """Return a fresh proposed tuple mapping; never mutate passed options."""
    if type(n_auv) is not int or n_auv not in REGISTERED_TUPLES:
        raise ValueError("Only n3/n4 have prepared root-budget tuple declarations")
    return dict(zip(BUDGET_FIELDS, REGISTERED_TUPLES[n_auv]))


def c03_domain_port_audit():
    """Copy of the exact one-literal AST proof, outside the MO wire schema."""
    result = deepcopy(_C03_DOMAIN_AUDIT)
    result.update(original_field_names=[field.name for field in _ORIGINAL_FIELDS],
                  effective_options_mro=[cls.__module__ + "." + cls.__qualname__ for cls in _MRO],
                  method_options_schema_unchanged=True,
                  registration_does_not_change_adapter_PROFILES=True,
                  no_remote_information=True,
                  physical_slots_or_bitrate_added=False,
                  constructor_selects_or_trains=False,
                  scope="only exact registered n4/common30 V9 tuple; all other constructors remain OriginalC07Options",
                  tradeoff="This expands the original C03 configuration validator domain for one explicit scale-port. More ROOT rights and fewer AUV-parent rights redistribute paid existing SN donor opportunities; installed rights, timely ACK/COMMIT/SUBCOMMIT, unique-owner correctness under all30 donors, safety and throughput remain unproved by this constructor.")
    return result
