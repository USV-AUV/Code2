"""Original C07, with explicit scale/protocol parameters, not a new controller.

No reward, estimator, actor output, routing predicate, topology enumeration,
packet lifecycle, physical TDMA calendar or collision termination is replaced.
For two AUVs every profile instantiates the untouched original environment.
The three/four-AUV port removes only the old constructor's exact-two guard.
"""
from contextlib import contextmanager
from copy import deepcopy
from itertools import product
from types import MethodType, MappingProxyType
from dataclasses import dataclass, asdict,replace
import hashlib
import json
import math
import threading

from .paths import SOURCE, reference_config, reference_metadata
from usv_auv.config import Config as OriginalConfig
from usv_auv.network import AcousticNetwork
from improved.environment import ImprovedEnv
from v4_task_20260917_r2 import environment as task_base
from v6_candidates.c07.environment import TaskV4Env as OriginalC07, MethodOptions, local_fields, slow_fields
from v6_candidates.c07.routing import RoutingOptions
from v6_candidates.c07.methods import get_method
from v4_task_20260917_r2.routing import QueueOptions as _OriginalQueueOptions
from .deployment import deployment_port
from .root_budget import (ROOT_BUDGET_PROFILE, build_root_budget_method_options,
                          registered_budget_values, c03_domain_port_audit, BUDGET_FIELDS)
from . import n4_child_h2, joint_clocks, child_deadline

PROFILES = ("natural", "adaptive_v1", "adaptive_packet_v2", "adaptive_packet_grid_v3", "adaptive_packet_grid_queue_v4", "adaptive_packet_grid_window_v5", "adaptive_packet_grid_pool_v6", "adaptive_packet_grid_calendar_v8", ROOT_BUDGET_PROFILE, n4_child_h2.PROFILE, *joint_clocks.PROFILES)
METHOD_ALIASES = {"full": "full_v6", "full_v6": "full_v6", "usde": "usde_only_v6",
                  "usde_only": "usde_only_v6", "usde_only_v6": "usde_only_v6"}
_CONSTRUCTOR_LOCK = threading.RLock()
_NATIVE_CANDIDATE_GETTER = AcousticNetwork.candidate_topologies
_NATIVE_CANDIDATE_GETTER_CODE = AcousticNetwork.candidate_topologies.__code__
_JOINT_GETTER_GLOBALS = dict(_NATIVE_CANDIDATE_GETTER.__globals__)
_JOINT_GETTER_META = deepcopy((_NATIVE_CANDIDATE_GETTER.__defaults__,
    _NATIVE_CANDIDATE_GETTER.__kwdefaults__,_NATIVE_CANDIDATE_GETTER.__annotations__))
_NATIVE_QUEUE_OPTIONS_CLASS = _OriginalQueueOptions
# Fixed source-derived public defaults, never reconstructed from a mutable
# runtime queue. V28 changes only the two explicitly declared service scalars.
_NATIVE_QUEUE_OPTIONS_DTO = MappingProxyType(dict(management_burst=1,management_rescue_burst=2,
    hello_ack_rescue_fraction=0.5,state_service_s=6.0,coord_service_s=8.0,ack_service_s=3.0,
    request_service_s=6.0,localization_service_s=12.0,data_service_s=6.0,other_service_s=12.0,
    deadline_weight=0.5,deadline_bonus_cap=2.0))

def canonical_method(method):
    try:
        return METHOD_ALIASES[method]
    except KeyError:
        raise ValueError("This study contains independently trained full and USDE-only arms") from None

@dataclass
class ScaleConfig(OriginalConfig):
    # A limit, not a fixed transmission size. The original sender charges each
    # actual STATE/COORD/certificate bit, PER, airtime and TX/RX energy.
    declared_packet_bits: int = 4096
    deployment_layout: str = "native_line"
    coordination_service_interval: float = 8.
    localization_service_interval: float = 12.

    def to_dict(self):
        value=super().to_dict()
        if value["deployment_layout"]=="native_line": value.pop("deployment_layout")
        # Preserve an explicitly supplied native default with its ORIGINAL type.
        # This serialization presence flag is not a dataclass/scientific field.
        if (value["coordination_service_interval"]==8. and
                not getattr(self,"_explicit_coordination_service_interval",False)):
            value.pop("coordination_service_interval")
        if (value["localization_service_interval"]==12. and
                not getattr(self,"_explicit_localization_service_interval",False)):
            value.pop("localization_service_interval")
        return value

    @property
    def max_packet_bits(self):
        return self.declared_packet_bits

    def validate(self):
        super().validate()
        if self.deployment_layout not in ("native_line","scale_grid"):
            raise ValueError("Deployment is a declared fixed geometry, never selected by sensor layouts")
        if not math.isfinite(self.coordination_service_interval) or self.coordination_service_interval<=0:
            raise ValueError("COORD priority service interval must be positive and finite")
        if (type(self.localization_service_interval) is not float or
                not math.isfinite(self.localization_service_interval) or self.localization_service_interval<=0):
            raise ValueError("LOC priority service interval must be a positive finite float")
        if type(self.declared_packet_bits) is not int or not 2304 <= self.declared_packet_bits <= 4096:
            raise ValueError("Declared packet cap must be 2304..4096 bits")
        worst_coord = max(8*(40+112*self.n_auv), 8*(40+112*(self.n_auv-1)+8+128))
        if self.declared_packet_bits < worst_coord:
            raise ValueError("Complete peer STATE records and two paid certificates must fit")
        distance = math.sqrt(2*self.area_size**2+self.sensor_depth**2)
        bound = self.max_packet_bits/self.bit_rate + distance/self.sound_speed + self.guard_time + self.processing_delay
        if bound > self.slot_duration:
            raise ValueError("Actual scale packet cap exceeds the original physical slot")

    @classmethod
    def from_dict(cls, data):
        if "declared_packet_bits" not in data:
            return OriginalConfig.from_dict(data)
        value=super().from_dict(data)
        if "coordination_service_interval" in data:
            value._explicit_coordination_service_interval=True
        if "localization_service_interval" in data:
            value._explicit_localization_service_interval=True
        return value

def _reference(method):
    cfg = json.loads(reference_config().read_text(encoding="utf-8-sig"))
    saved = json.loads(reference_metadata(method).read_text(encoding="utf-8-sig"))
    return cfg, dict(saved["method_options"]), dict(saved["routing_options"])

def _clock_diagnostics(cfg):
    # Instantiate the unmodified calendar, not a synthetic capacity multiplier.
    net = AcousticNetwork(cfg, cfg.seed)
    frame = len(net.slot_owners)*cfg.slot_duration
    turn = (cfg.n_auv+2)*net.cooperative_slot_gap*(1+1/max(1,net.max_management_run))
    return dict(frame_s=frame, cooperative_turn_s=turn,
                service_renew_lead_s=frame+turn+cfg.slot_duration,
                service_retry_interval_s=2*frame+turn+cfg.slot_duration,
                protected_sensor_home_gap_s=2*frame,
                slot_count=len(net.slot_owners), bit_rate=cfg.bit_rate, slot_s=cfg.slot_duration,
                max_packet_bits=net.max_packet_bits)


def validate_scale_mac_budget(n_auv, options):
    """Explicit new-capacity-profile guard; old natural clipping stays valid.

    These are the unchanged original C01/C03 MethodOptions limits. Native
    validation still runs afterwards; this guard additionally uses the ACTUAL
    AUV count where the original ancestor checked only its historical two.
    Quotas are paid donor-slot rights, never extra physical channel capacity.
    """
    if type(n_auv) is not int or n_auv not in (2,3,4):
        raise ValueError("Scale MAC budget supports only2/3/4 AUVs")
    values=options if isinstance(options,dict) else asdict(options)
    bounds={"mac_pool_slots":(2,16), "mac_auv_slots":(1,8), "mac_max_leases":(1,30),
            "mac_child_max_active":(1,8), "mac_child_slots_per_sensor":(1,4),
            "mac_child_lease_frames":(1,3)}
    for name,(lower,upper) in bounds.items():
        value=values.get(name)
        if type(value) is not int or not lower<=value<=upper:
            raise ValueError(f"Native C07 {name} must be an integer in [{lower},{upper}]")
    if values["mac_child_max_active"]>=values["mac_pool_slots"]:
        raise ValueError("Retain original root control rights after nominal child allocation")
    requested=values["mac_pool_slots"]+n_auv*values["mac_auv_slots"]
    if requested>values["mac_max_leases"]:
        raise ValueError("Scale parent pool+n_auv*auv quota exceeds declared shared parent budget")
    return dict(n_auv=n_auv, nominal_requested_parent_rights=requested,
                declared_global_parent_limit=values["mac_max_leases"],
                native_caps={name:list(interval) for name,interval in bounds.items()})


def _build_native_pool12_n4_settings(method,faults):
    """V13 science from lawful V5 DTOs, never instantiate a pool20 intermediate."""
    method=canonical_method(method);profile=joint_clocks.POOL12_PROFILE
    base_cfg,base_mo,routing,diagnostics=build_settings(4,30,method,"adaptive_packet_grid_window_v5",faults)
    reference_cfg,reference_mo,_=_reference(method)
    raw=base_cfg.to_dict();raw.update(tdma_sensors_per_group=4,hello_period=40.0)
    cfg=ScaleConfig.from_dict(raw);clocks=_clock_diagnostics(cfg)
    retry=float(math.ceil(clocks["service_retry_interval_s"]))
    raw.update(service_ack_timeout=max(reference_cfg["service_ack_timeout"],retry),
               grant_ttl=max(reference_cfg["grant_ttl"],retry))
    cfg=ScaleConfig.from_dict(raw);clocks=_clock_diagnostics(cfg)
    values=joint_clocks.expected_options(4,method,profile)
    options=joint_clocks.build_options(4,30,profile,method,values)
    differences=lambda a,b:{k:{"old":a.get(k),"new":v} for k,v in b.items() if not joint_clocks.exact(a.get(k),v)}
    if (not joint_clocks.exact(clocks["frame_s"],joint_clocks.registered_frame(profile,4)) or
            tuple(values[key] for key in BUDGET_FIELDS)!=joint_clocks.POOL12_TUPLE):
        raise ValueError("Native pool12 factory must retain the exact registered G4/H2/tuple")
    # These are strict reference DTO comparisons, not a second constructor
    # using the historical expanded pool20 domain.
    v13_mo=joint_clocks.expected_options(4,method,joint_clocks.HETEROGENEOUS_PROFILE)
    delta=differences(v13_mo,values)
    if not joint_clocks.exact(delta,{"mac_pool_slots":{"old":20,"new":12}}):
        raise ValueError("V16 permits only integer N4 mac_pool_slots20->12 relative to V13")
    v9_mo=asdict(base_mo);v9_mo.update(registered_budget_values(4))
    v12_cfg=deepcopy(cfg.to_dict());v12_cfg.update(tdma_sensors_per_group=6,hello_period=40.0,
        service_ack_timeout=126.0,grant_ttl=126.0)
    v12_mo=joint_clocks.expected_options(4,method,joint_clocks.LEGACY_PROFILES[-1])
    diagnostics=deepcopy(diagnostics)
    diagnostics.update(profile=profile,clock=clocks,config_changes=differences(reference_cfg,cfg.to_dict()),
        option_changes=differences(reference_mo,values),nominal_root_pool_remainder_if_all_installed=4)
    net=AcousticNetwork(cfg,cfg.seed);h,minimum=joint_clocks.registered(profile,4)
    diagnostics["joint_clock_adaptation"]=dict(inherited_profile=joint_clocks.HETEROGENEOUS_PROFILE,
        registered_H3_H4={str(k):v for k,v in joint_clocks.HORIZONS[profile].items()},
        declared_config_diff_from_v9=differences(base_cfg.to_dict(),cfg.to_dict()),
        declared_option_diff_from_v9=differences(v9_mo,values),
        selector=joint_clocks.selector_proof(4,profile,method),
        original_calendar_algorithm_unchanged=True,actual_slot_owners=list(net.slot_owners),
        actual_slot_duration_s=cfg.slot_duration,actual_cooperative_gap_s=net.cooperative_slot_gap,
        actual_max_management_run=net.max_management_run,config_equal_to_v9=False,
        routing_equal_to_v9=True,behavior_exploration_noise_unchanged=True,common30_only=True,
        constructor_selects_or_trains=False,
        selection_status="This constructor does not select or launch candidates; consult the external campaign plan and actual ledger",
        tradeoff="V13 calendar/HELLO/retry/child clocks remain unchanged. Only the exact native ROOT quota decreases; fewer paid parent requests can also reduce child/control availability and do not create free DATA or safety.")
    proof=joint_clocks.native_pool12_validation_proof()
    diagnostics["root_budget_adaptation"]=dict(inherited_profile="adaptive_packet_grid_window_v5",
        declared_config_diff_from_v5=differences(base_cfg.to_dict(),cfg.to_dict()),
        declared_option_diff_from_v5=differences(asdict(base_mo),values),routing_options_unchanged_from_v5=True,
        nominal_root_pool_slots=12,per_auv_parent_slots=2,nominal_global_parent_rights=20,
        declared_global_parent_limit=28,actual_sensor_donor_count=30,max_live_or_future_child_windows=8,
        nominal_root_remainder_if_child_cap_fully_occupied=4,
        nominal_root_remainder_rule="Native N4 P12-child8=4; not the historical pool20 3*n rule",
        original_pool_validation_upper=16,effective_pool_validation_upper=16,
        validation_domain_scale_port=False,originally_validated_pool_configuration=True,
        effective_options_class=type(options).__module__+"."+type(options).__qualname__,
        n4_scoped_validation_domain_proof=proof,physical_calendar_unchanged_from_v5=False,
        physical_slots_or_bitrate_added=False,new_scheduler_or_information=False,
        constructor_selects_or_trains=False,
        selection_status="This constructor does not select or launch candidates; consult the external campaign plan and actual ledger",
        tradeoff="The returned P12 options use the complete original C03 pool[2,16] validator and unchanged original C06/C04/C02/C01/V5 chain, no upper20 insertion. Parent12+4*2=20 fits the unchanged global28/common30 budget; active/future requests and received parents still differ. Fewer ROOT rights can lose control/child opportunities; no bandwidth, DATA-ready or performance guarantee.")
    diagnostics["child_window_adaptation"].update(minimum_command_lead_s=minimum,
        native_next_opportunity_search_max_s=h*clocks["frame_s"],eligible_phase_width_s=12.0,
        minimum_lead_rule="Fixed registered H*actual native frame - original12s decision interval",
        H2_hook_installed_for_full_only=method=="full_v6" and h==2)
    diagnostics["heterogeneous_calendar_adaptation"]=dict(inherited_profile=joint_clocks.LEGACY_PROFILES[-1],
        declared_config_diff_from_v12=differences(v12_cfg,cfg.to_dict()),
        declared_option_diff_from_v12=differences(v12_mo,values),N2_N3_numeric_settings_unchanged=True,
        parent_prepare_unchanged=True,existing_H2_selector_algorithm_unchanged=True,
        physical_bandwidth_or_slot_rate_increased=False,constructor_selects_or_trains=False,
        tradeoff="Retain V13 G4/F42/H2/MIN72. Relative to V12 the earlier G4 mechanical clocks still differ; the new scientific intervention relative to V13 is only ROOT pool20->12, not new slots or a selector.")
    diagnostics["pool_budget_adaptation"]=dict(inherited_profile=joint_clocks.HETEROGENEOUS_PROFILE,
        declared_config_diff_from_v13={},declared_option_diff_from_v13=delta,
        routing_options_unchanged=True,N2_N3_scientific_fields_unchanged=True,
        native_C03_validation=True,pool20_validation_port_used=False,
        registered_budget_tuple=list(joint_clocks.POOL12_TUPLE),nominal_requested_parent_rights=20,
        nominal_root_remainder_if_child_cap_fully_occupied=4,validation_proof=proof,
        calendar_HELLO_visit_learning_protocol_unchanged=True,physical_capacity_added=False,
        constructor_selects_or_trains=False,
        comparison_scope="Single scientific field relative to V13; relative to V15 also restores HELLO48.0 to V13 40.0",
        tradeoff="A smaller native ROOT request quota changes existing borrower fraction/count ordering and donor silence opportunities. ROOT parents are also child/control prerequisites; future/failed promises retain caps. Nominal freed quota is not observed DATA-ready or counterfactual gain; no performance or safety guarantee.")
    return cfg,options,routing,diagnostics


def build_settings(n_auv, n_sensors, method, profile="adaptive_v1", faults=None):
    if profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE:
        if type(n_auv) is not int or n_auv not in (2,3,4) or type(n_sensors) is not int or n_sensors!=30:
            raise ValueError("Conditional V28 joint/LOC profile requires typed N2/3/4/common30")
        cfg,old_options,routing,inherited=build_settings(n_auv,n_sensors,method,joint_clocks.N34_STATE8_11_PROFILE,faults)
        before_cfg,before_mo,before_ro=deepcopy(cfg.to_dict()),asdict(old_options),asdict(routing)
        differences=lambda a,b:{k:{"old":a.get(k),"new":v} for k,v in b.items() if not joint_clocks.exact(a.get(k),v)}
        if n_auv>2:
            raw=deepcopy(before_cfg);raw.update(joint_clocks.JOINT_PHY_LOC_SETTINGS[n_auv])
            cfg=ScaleConfig.from_dict(raw);clocks=_clock_diagnostics(cfg)
            reference_cfg,_,_=_reference(canonical_method(method))
            retry=float(math.ceil(clocks["service_retry_interval_s"]))
            raw.update(service_ack_timeout=max(reference_cfg["service_ack_timeout"],retry),
                grant_ttl=max(reference_cfg["grant_ttl"],retry))
            cfg=ScaleConfig.from_dict(raw)
        clocks=_clock_diagnostics(cfg)
        values=joint_clocks.expected_options(n_auv,canonical_method(method),profile)
        budget=validate_scale_mac_budget(n_auv,values)
        options=joint_clocks.build_options(n_auv,n_sensors,profile,canonical_method(method),values)
        cfg_delta,mo_delta=differences(before_cfg,cfg.to_dict()),differences(before_mo,values)
        expected_cfg=({} if n_auv==2 else {
            "slot_duration":{"old":0.6,"new":0.5},"hello_period":{"old":30.0,"new":45.0},
            "service_ack_timeout":{"old":106.0,"new":88.0},"grant_ttl":{"old":106.0,"new":100.0},
            "localization_service_interval":{"old":None,"new":8.0}} if n_auv==3 else {
            "tdma_sensors_per_group":{"old":4,"new":6},"slot_duration":{"old":0.6,"new":0.5625},
            "hello_period":{"old":40.0,"new":80.0},"coordination_service_interval":{"old":8.0,"new":4.0},
            "service_ack_timeout":{"old":134.0,"new":119.0},"grant_ttl":{"old":134.0,"new":119.0},
            "localization_service_interval":{"old":None,"new":6.0}})
        expected_mo=({} if n_auv==2 else {"mac_child_lead_s":{"old":48.0,"new":2*(50*0.5)-12.0}}
            if n_auv==3 else {"mac_pool_slots":{"old":12,"new":16},
                "mac_child_max_active":{"old":8,"new":4},
                "mac_child_lead_s":{"old":72.0,"new":2*(55*0.5625)-12.0}})
        restored_cfg=deepcopy(cfg.to_dict());restored_mo=deepcopy(values)
        for key in cfg_delta:
            if key in before_cfg:restored_cfg[key]=before_cfg[key]
            else:restored_cfg.pop(key)
        for key in mo_delta:restored_mo[key]=before_mo[key]
        if (not joint_clocks.exact(cfg_delta,expected_cfg) or not joint_clocks.exact(mo_delta,expected_mo) or
                not joint_clocks.exact(restored_cfg,before_cfg) or not joint_clocks.exact(restored_mo,before_mo) or
                not joint_clocks.exact(asdict(routing),before_ro) or
                not joint_clocks.exact(clocks["frame_s"],joint_clocks.registered_frame(profile,n_auv)) or
                (n_auv==2 and ("localization_service_interval" in cfg.to_dict() or type(cfg) is not OriginalConfig))):
            raise ValueError("V28 requires exact declared multi-field joint/LOC deltas and complete K27 inverse")
        diagnostics=deepcopy(inherited)
        for key in ("joint_clock_adaptation","root_budget_adaptation","child_window_adaptation","state_period_adaptation",
                "inherited_K26_coordination_priority_adaptation","inherited_K26_pool_budget_adaptation",
                "inherited_K26_heterogeneous_calendar_adaptation"):
            if key in diagnostics:diagnostics["inherited_K27_"+key]=diagnostics.pop(key)
        reference_cfg,reference_mo,_=_reference(canonical_method(method))
        net=AcousticNetwork(cfg,cfg.seed);h,minimum=joint_clocks.registered(profile,n_auv)
        diagnostics.update(profile=profile,clock=clocks,config_changes=differences(reference_cfg,cfg.to_dict()),
            option_changes=differences(reference_mo,values),
            nominal_root_pool_remainder_if_all_installed=values["mac_pool_slots"]-values["mac_child_max_active"])
        diagnostics["joint_clock_adaptation"]=dict(inherited_profile=joint_clocks.N34_STATE8_11_PROFILE,
            registered_H3_H4={str(k):v for k,v in joint_clocks.HORIZONS[profile].items()},
            declared_config_diff_from_K27=cfg_delta,declared_option_diff_from_K27=mo_delta,
            selector=joint_clocks.selector_proof(n_auv,profile,canonical_method(method)),
            original_calendar_algorithm_unchanged=True,actual_slot_owners=list(net.slot_owners),
            actual_slot_duration_s=cfg.slot_duration,actual_cooperative_gap_s=net.cooperative_slot_gap,
            actual_max_management_run=net.max_management_run,routing_equal_to_K27=True,
            behavior_exploration_noise_unchanged=True,common30_only=True,constructor_selects_or_trains=False,
            selection_status="Conditional source preparation only; external ROOT must separately decide activation after V27 closes",
            tradeoff="Multiple explicit public clock/queue/budget numerics, not a sole-scalar intervention. Paid original slots/certificates/TTL/PHY bytes and safety remain; more ROOT headroom can cost SN children or freshness. No gain guaranteed.")
        proof=joint_clocks.native_root16_child4_validation_proof() if n_auv==4 else None
        diagnostics["root_budget_adaptation"]=dict(nominal_root_pool_slots=values["mac_pool_slots"],
            per_auv_parent_slots=values["mac_auv_slots"],nominal_global_parent_rights=budget["nominal_requested_parent_rights"],
            declared_global_parent_limit=values["mac_max_leases"],actual_sensor_donor_count=n_sensors,
            max_live_or_future_child_windows=values["mac_child_max_active"],
            nominal_root_remainder_if_child_cap_fully_occupied=values["mac_pool_slots"]-values["mac_child_max_active"],
            registered_budget_tuple=[values[key] for key in BUDGET_FIELDS],
            native_C03_validation=True,original_pool_validation_upper=16,effective_pool_validation_upper=16,
            validation_domain_scale_port=False,pool20_validator_insertion_used=False,
            effective_options_class=type(options).__module__+"."+type(options).__qualname__,
            native_validation_proof=proof,constructor_selects_or_trains=False,
            tradeoff="N4 P16/q2/global28/child4 is within the full original C03 domain, not pool22 or a new validation-domain port. Parent requests/future silence count quota, child4 can reduce service concurrency; nominal remainder is not actual capacity.")
        diagnostics["child_window_adaptation"]=dict(minimum_command_lead_s=minimum,
            native_next_opportunity_search_max_s=h*clocks["frame_s"],
            eligible_phase_width_s=h*clocks["frame_s"]-minimum,
            minimum_lead_rule="Retain original N2 MIN14.4; N3/N4 H2 times exact actual frame minus original decision12",
            H2_hook_installed_for_full_only=n_auv>2 and canonical_method(method)=="full_v6")
        diagnostics["joint_phy_localization_adaptation"]=dict(inherited_profile=joint_clocks.N34_STATE8_11_PROFILE,
            declared_config_diff_from_K27=cfg_delta,declared_option_diff_from_K27=mo_delta,
            N2_scientific_CFG_MO_RO_learning_and_actual_queue_numerics_unchanged=True,
            new_profile_identity_not_original_whole_declaration_byte_identity=True,
            same_N_full_USDE_whole_config_and_queue_numerics_shared=True,
            coordination_service_interval=getattr(cfg,"coordination_service_interval",8.0),
            localization_service_interval=getattr(cfg,"localization_service_interval",12.0),
            expected_actual_queue_options=_expected_joint_queue_options(cfg),
            ordinary_STATE_interval_s=float(math.ceil(cfg.state_period/cfg.dt)*cfg.dt),
            ordinary_COORD_interval_s=float(math.ceil(cfg.state_period/(cfg.slow_period*cfg.dt))*cfg.slow_period*cfg.dt),
            localization_polling_rule="Unchanged max(state_period,2*(1+N+SN)*slot), checked on fast dt; service scalar is not poll or TTL",
            original_QueueOptions_algorithm_class_flow_keys_and_causal_bonus_unchanged=True,
            source_TTL90_routing_stale25_learning_reward_bytes_bitrate_guard_and_safety_unchanged=True,
            narrow_modeled_slot_margin_not_hardware_jitter_guarantee=True,
            conditional_preparation_not_launch_authority=True,constructor_selects_or_trains=False)
        diagnostics["child_delivery_priority"]=child_deadline.declaration(n_auv,canonical_method(method))
        return cfg,options,routing,diagnostics
    if profile==joint_clocks.N34_STATE8_11_PROFILE:
        if type(n_auv) is not int or n_auv not in (2,3,4) or type(n_sensors) is not int or n_sensors!=30:
            raise ValueError("V27 STATE8/11 requires typed N2/3/4/common30")
        cfg,old_options,routing,inherited=build_settings(n_auv,n_sensors,method,joint_clocks.N4_COORD8_PROFILE,faults)
        before_cfg,before_mo=deepcopy(cfg.to_dict()),asdict(old_options)
        differences=lambda a,b:{k:{"old":a.get(k),"new":v} for k,v in b.items() if not joint_clocks.exact(a.get(k),v)}
        if n_auv>2:
            raw=deepcopy(before_cfg);raw["state_period"]=joint_clocks.N34_STATE_PERIODS[n_auv]
            cfg=ScaleConfig.from_dict(raw)
        clocks=_clock_diagnostics(cfg)
        values=joint_clocks.expected_options(n_auv,canonical_method(method),profile)
        options=joint_clocks.build_options(n_auv,n_sensors,profile,canonical_method(method),values)
        cfg_delta,mo_delta=differences(before_cfg,cfg.to_dict()),differences(before_mo,values)
        expected_cfg={} if n_auv==2 else {"state_period":{"old":5.0,"new":joint_clocks.N34_STATE_PERIODS[n_auv]}}
        restored_cfg=deepcopy(cfg.to_dict())
        for key in cfg_delta:restored_cfg[key]=before_cfg[key]
        if (not joint_clocks.exact(cfg_delta,expected_cfg) or not joint_clocks.exact(mo_delta,{}) or
                not joint_clocks.exact(restored_cfg,before_cfg) or not joint_clocks.exact(clocks,inherited["clock"]) or
                not joint_clocks.exact(clocks["frame_s"],joint_clocks.registered_frame(profile,n_auv))):
            raise ValueError("V27 permits only typed N3 STATE5.0->8.0/N4 STATE5.0->11.0; other K26 science and native clocks must match")
        diagnostics=deepcopy(inherited);diagnostics.update(profile=profile,clock=clocks)
        # These records describe K26 before this STATE adaptation, not current
        # claims that STATE5 or all three scales remain unchanged.
        for key in ("coordination_priority_adaptation","heterogeneous_calendar_adaptation","pool_budget_adaptation"):
            if key in diagnostics:diagnostics["inherited_K26_"+key]=diagnostics.pop(key)
        reference_cfg,reference_mo,_=_reference(canonical_method(method))
        diagnostics["config_changes"]=differences(reference_cfg,cfg.to_dict())
        diagnostics["option_changes"]=differences(reference_mo,values)
        v9=build_settings(n_auv,30,method,ROOT_BUDGET_PROFILE,faults)
        adaptation=diagnostics["joint_clock_adaptation"]
        adaptation.update(inherited_profile=joint_clocks.N4_COORD8_PROFILE,
            declared_config_diff_from_v9=differences(v9[0].to_dict(),cfg.to_dict()),
            declared_option_diff_from_v9=differences(asdict(v9[1]),values),
            config_equal_to_v9=joint_clocks.exact(v9[0].to_dict(),cfg.to_dict()),
            routing_equal_to_v9=joint_clocks.exact(asdict(v9[2]),asdict(routing)),
            selector=joint_clocks.selector_proof(n_auv,profile,canonical_method(method)),
            tradeoff="Relative to K26 only N3 STATE8.0/N4 STATE11.0; different fast/slow ordinary submission clocks, same dirty-event rules and all paid/TTL/stale/learning/safety rules; no performance guarantee.")
        if n_auv>2:
            v5=build_settings(n_auv,30,method,"adaptive_packet_grid_window_v5",faults)
            diagnostics["root_budget_adaptation"].update(
                declared_config_diff_from_v5=differences(v5[0].to_dict(),cfg.to_dict()),
                declared_option_diff_from_v5=differences(asdict(v5[1]),values))
        diagnostics["state_period_adaptation"]=dict(inherited_profile=joint_clocks.N4_COORD8_PROFILE,
            declared_state_period_by_auv={str(n):v for n,v in joint_clocks.N34_STATE_PERIODS.items()},
            declared_config_diff_from_K26=cfg_delta,declared_option_diff_from_K26=mo_delta,
            N2_whole_science_unchanged=True,all_other_K26_scientific_fields_unchanged=True,
            same_N_full_USDE_whole_config_shared=True,
            ordinary_STATE_interval_s=float(math.ceil(cfg.state_period/cfg.dt)*cfg.dt),
            ordinary_COORD_interval_s=float(math.ceil(cfg.state_period/(cfg.slow_period*cfg.dt))*cfg.slow_period*cfg.dt),
            ordinary_intervals_are_nominal_no_dirty_not_delivery_guarantees=True,
            dirty_event_rules_unchanged=True,localization_polling_cadence_unchanged=True,
            coordination_priority_denominator_unchanged=True,source_TTL90_and_routing_stale25_not_relaxed=True,
            native_calendar_H2_MAC_learning_reward_PHY_safety_unchanged=True,physical_capacity_added=False,
            constructor_selects_or_trains=False,selected_or_validated_by_constructor=False,
            tradeoff="Less periodic STATE/ordinary COORD offer can worsen stale information. Dirty phase resets, replacement, finite paid rights and failures remain; no DATA or safety gain is guaranteed.")
        return cfg,options,routing,diagnostics
    if profile==joint_clocks.N4_COORD8_PROFILE:
        if type(n_auv) is not int or n_auv not in (2,3,4) or type(n_sensors) is not int or n_sensors!=30:
            raise ValueError("V26 COORD8 profile requires typed N2/3/4/common30")
        cfg,old_options,routing,diagnostics=build_settings(n_auv,n_sensors,method,joint_clocks.POOL12_PROFILE,faults)
        before_cfg,before_mo=deepcopy(cfg.to_dict()),asdict(old_options)
        differences=lambda a,b:{k:{"old":a.get(k),"new":v} for k,v in b.items() if not joint_clocks.exact(a.get(k),v)}
        if n_auv==4:
            raw=deepcopy(before_cfg);raw["coordination_service_interval"]=8.0
            cfg=ScaleConfig.from_dict(raw)
        clocks=_clock_diagnostics(cfg)
        values=joint_clocks.expected_options(n_auv,canonical_method(method),profile)
        options=joint_clocks.build_options(n_auv,n_sensors,profile,canonical_method(method),values)
        cfg_delta,mo_delta=differences(before_cfg,cfg.to_dict()),differences(before_mo,values)
        expected_cfg={} if n_auv!=4 else {"coordination_service_interval":{"old":4.0,"new":8.0}}
        restored_cfg=deepcopy(cfg.to_dict())
        for key in cfg_delta:restored_cfg[key]=before_cfg[key]
        if (not joint_clocks.exact(cfg_delta,expected_cfg) or not joint_clocks.exact(mo_delta,{}) or
                not joint_clocks.exact(restored_cfg,before_cfg) or not joint_clocks.exact(clocks,diagnostics["clock"]) or
                not joint_clocks.exact(clocks["frame_s"],joint_clocks.registered_frame(profile,n_auv))):
            raise ValueError("V26 permits only typed N4 coordination_service_interval4.0->8.0; all other science and native clocks must match V16")
        diagnostics=deepcopy(diagnostics);diagnostics.update(profile=profile,clock=clocks)
        reference_cfg,reference_mo,_=_reference(canonical_method(method))
        diagnostics["config_changes"]=differences(reference_cfg,cfg.to_dict())
        diagnostics["option_changes"]=differences(reference_mo,values)
        adaptation=diagnostics["joint_clock_adaptation"]
        adaptation.update(inherited_profile=joint_clocks.POOL12_PROFILE,
            selector=joint_clocks.selector_proof(n_auv,profile,canonical_method(method)))
        if n_auv==4:
            # Recompute whole baseline differences from actual DTOs. Neither an
            # obsolete pool20 constructor nor a metadata-only relabel is used.
            v5_cfg,v5_mo,v5_ro,_=build_settings(4,30,method,"adaptive_packet_grid_window_v5",faults)
            v9_cfg=deepcopy(v5_cfg.to_dict());v9_mo=asdict(v5_mo)
            v9_mo.update(registered_budget_values(4))
            adaptation.update(declared_config_diff_from_v9=differences(v9_cfg,cfg.to_dict()),
                declared_option_diff_from_v9=differences(v9_mo,values),
                config_equal_to_v9=joint_clocks.exact(v9_cfg,cfg.to_dict()),
                routing_equal_to_v9=joint_clocks.exact(asdict(v5_ro),asdict(routing)),
                tradeoff="V16 calendar/paid rights and state5 sampling unchanged; COORD8 only changes the native weighted-age priority denominator. Peer/certificate/conflict delivery or ordinary application service can improve or worsen; no extra capacity or gain is guaranteed.")
            budget=diagnostics["root_budget_adaptation"]
            budget.update(declared_config_diff_from_v5=differences(v5_cfg.to_dict(),cfg.to_dict()),
                declared_option_diff_from_v5=differences(asdict(v5_mo),values))
            v12_cfg=deepcopy(before_cfg);v12_cfg.update(tdma_sensors_per_group=6,service_ack_timeout=126.0,grant_ttl=126.0)
            v12_mo=joint_clocks.expected_options(4,canonical_method(method),joint_clocks.LEGACY_PROFILES[-1])
            diagnostics["heterogeneous_calendar_adaptation"].update(
                declared_config_diff_from_v12=differences(v12_cfg,cfg.to_dict()),
                declared_option_diff_from_v12=differences(v12_mo,values),
                tradeoff="V16 G4/F42/H2/MIN72 and native retry clocks are retained. Only the COORD priority denominator differs from V16; the full earlier calendar differences relative to V12 remain declared.")
            v13_cfg=deepcopy(before_cfg);v13_mo=deepcopy(before_mo);v13_mo["mac_pool_slots"]=20
            diagnostics["pool_budget_adaptation"].update(declared_config_diff_from_v13=differences(v13_cfg,cfg.to_dict()),
                declared_option_diff_from_v13=differences(v13_mo,values),calendar_HELLO_visit_learning_protocol_unchanged=False,
                comparison_scope="Relative to V16 only N4 coordination_service_interval4.0->8.0. Relative to V13 also native P20->P12; calendar/HELLO/visit/learning/state5 unchanged, the native COORD priority denominator intentionally differs.")
        diagnostics["coordination_priority_adaptation"]=dict(inherited_profile=joint_clocks.POOL12_PROFILE,
            declared_config_diff_from_v16=cfg_delta,declared_option_diff_from_v16=mo_delta,
            root_parameters=["Config.coordination_service_interval"] if n_auv==4 else [],N2_N3_scientific_fields_unchanged=True,
            routing_options_unchanged=True,native_calendar_and_all_derived_clocks_unchanged=True,
            native_pool12_and_complete_original_C03_validation_unchanged=True,existing_H2_selector_algorithm_unchanged=True,
            periodic_and_dirty_event_STATE_COORD_submission_cadence_unchanged=True,
            localization_polling_cadence_unchanged=True,source_state_period5_retained=True,
            same_N_full_USDE_whole_config_shared=True,deadline_and_causal_priority_bonuses_unchanged=True,source_TTL90_and_routing_stale25_not_relaxed=True,
            HELLO_visit_slow_gamma_learning_reward_PHY_safety_unchanged=True,physical_capacity_added=False,
            constructor_selects_or_trains=False,selected_or_validated_by_constructor=False,
            tradeoff="At a fixed local waiting age and gap only the N4 COORD weighted-age term changes from division by4.0 to8.0. This is priority, not an8s poll, reserved rate, or latency guarantee. Deadline/intent/conflict bonuses, all actual paid sends, state5/slow5/sourceTTL90/stale25 and all other applications remain unchanged. Deprioritized peer/certificate/conflict information can worsen behavior; no performance or safety guarantee.")
        return cfg,options,routing,diagnostics
    if profile==joint_clocks.POOL12_PROFILE:
        if type(n_auv) is not int or n_auv not in (2,3,4) or type(n_sensors) is not int or n_sensors!=30:
            raise ValueError("Native pool12 profile is strictly typed N2/3/4/common30-only")
        if n_auv==4:
            return _build_native_pool12_n4_settings(method,faults)
        cfg,old_options,routing,diagnostics=build_settings(n_auv,n_sensors,method,joint_clocks.HETEROGENEOUS_PROFILE,faults)
        options=joint_clocks.build_options(n_auv,n_sensors,profile,canonical_method(method),asdict(old_options))
        diagnostics=deepcopy(diagnostics);diagnostics["profile"]=profile
        diagnostics["joint_clock_adaptation"]["selector"]=joint_clocks.selector_proof(n_auv,profile,canonical_method(method))
        diagnostics["pool_budget_adaptation"]=dict(inherited_profile=joint_clocks.HETEROGENEOUS_PROFILE,
            declared_config_diff_from_v13={},declared_option_diff_from_v13={},routing_options_unchanged=True,
            N2_N3_scientific_fields_unchanged=True,native_C03_validation=True,pool20_validation_port_used=False,
            calendar_HELLO_visit_learning_protocol_unchanged=True,physical_capacity_added=False,
            constructor_selects_or_trains=False,
            comparison_scope="All N2/N3 scientific fields remain V13; native P12 intervention is N4 only")
        return cfg,options,routing,diagnostics
    if profile==joint_clocks.HELLO48_PROFILE:
        cfg,old_options,routing,diagnostics=build_settings(n_auv,n_sensors,method,joint_clocks.HETEROGENEOUS_PROFILE,faults)
        before=cfg.to_dict();raw=deepcopy(before)
        if n_auv==4:
            raw["hello_period"]=48.0
            cfg=ScaleConfig.from_dict(raw)
        values=asdict(old_options)
        options=joint_clocks.build_options(n_auv,n_sensors,profile,canonical_method(method),values)
        differences=lambda a,b:{k:{"old":a.get(k),"new":v} for k,v in b.items() if not joint_clocks.exact(a.get(k),v)}
        delta=differences(before,cfg.to_dict())
        expected={} if n_auv!=4 else {"hello_period":{"old":40.0,"new":48.0}}
        old_probe=float(max(before["hello_period"],diagnostics["clock"]["cooperative_turn_s"])+cfg.slot_duration)
        new_probe=float(max(cfg.hello_period,diagnostics["clock"]["cooperative_turn_s"])+cfg.slot_duration)
        if (not joint_clocks.exact(delta,expected) or not joint_clocks.exact(values,asdict(options)) or
                not joint_clocks.exact(_clock_diagnostics(cfg),diagnostics["clock"]) or
                not joint_clocks.exact(old_probe,new_probe)):
            raise ValueError("V15 permits only typed N4 HELLO40.0->48.0, with V13 MO/calendar/native timers unchanged")
        diagnostics=deepcopy(diagnostics);diagnostics["profile"]=profile
        diagnostics["config_changes"]=differences(_reference(canonical_method(method))[0],cfg.to_dict())
        adaptation=diagnostics["joint_clock_adaptation"]
        adaptation["selector"]=joint_clocks.selector_proof(n_auv,profile,canonical_method(method))
        if n_auv==4:
            adaptation["declared_config_diff_from_v9"]["hello_period"]["new"]=48.0
            diagnostics["root_budget_adaptation"]["declared_config_diff_from_v5"]["hello_period"]["new"]=48.0
            diagnostics["heterogeneous_calendar_adaptation"]["declared_config_diff_from_v12"].update(delta)
        diagnostics["hello_period_adaptation"]=dict(inherited_profile=joint_clocks.HETEROGENEOUS_PROFILE,
            existing_native_field="Config.hello_period",declared_config_diff_from_v13=delta,
            declared_option_diff_from_v13={},routing_options_unchanged=True,
            N2_N3_scientific_fields_unchanged=n_auv!=4,visit_packet_budget_unchanged=True,
            nominal_visit_packet_budget=values["visit_packet_budget"],
            native_calendar_and_retry_renew_ACK_grant_unchanged=True,
            old_native_probe_timeout_s=old_probe,new_native_probe_timeout_s=new_probe,
            old_native_ACK_rescue_threshold_s=.5*old_probe,new_native_ACK_rescue_threshold_s=.5*new_probe,
            paid_HELLO_ACK_per_actual_receive_unchanged=True,physical_capacity_added=False,
            constructor_selects_or_trains=False,
            comparison_scope="Single scientific field relative to V13; relative to V14 also restores visit_packet_budget6.0 to V13 4.0",
            tradeoff="Fewer periodic network HELLO submissions may only reduce replacements, not actual TX or paid ACK burden. Received link evidence, route/mask support and recovery may become stale; no TTL, priority, free information, slots or safety compensation. Probe/rescue clocks stay native under the existing fair-round clamp. No performance guarantee or launch is implied.")
        return cfg,options,routing,diagnostics
    if profile in joint_clocks.PROFILES:
        if type(n_auv) is not int or n_auv not in (2,3,4) or type(n_sensors) is not int or n_sensors!=30:
            raise ValueError("Unselected V12 joint profiles are strictly N2/3/4/common30-only")
        cfg,old_options,routing,diagnostics=build_settings(n_auv,n_sensors,method,ROOT_BUDGET_PROFILE,faults)
        old_cfg,old_mo=cfg.to_dict(),asdict(old_options)
        raw=deepcopy(old_cfg)
        if n_auv>2:
            raw.update(tdma_sensors_per_group=joint_clocks.registered_group(profile,n_auv),hello_period=float(20*n_auv/2))
            cfg=ScaleConfig.from_dict(raw)
            clocks=_clock_diagnostics(cfg)
            base_cfg,_,_=_reference(canonical_method(method))
            retry=float(math.ceil(clocks["service_retry_interval_s"]))
            raw.update(service_ack_timeout=max(base_cfg["service_ack_timeout"],retry),
                       grant_ttl=max(base_cfg["grant_ttl"],retry))
            cfg=ScaleConfig.from_dict(raw)
        clocks=_clock_diagnostics(cfg)
        h,minimum=joint_clocks.registered(profile,n_auv)
        if not joint_clocks.exact(clocks["frame_s"],joint_clocks.registered_frame(profile,n_auv)):
            raise ValueError("Actual original calendar does not match registered joint clocks")
        values=deepcopy(old_mo)
        if n_auv>2:values["mac_child_lead_s"]=minimum
        options=joint_clocks.build_options(n_auv,n_sensors,profile,canonical_method(method),values)
        before_cfg,before_mo,_=_reference(canonical_method(method))
        differences=lambda a,b:{k:{"old":a.get(k),"new":v} for k,v in b.items() if not joint_clocks.exact(a.get(k),v)}
        cfg_delta,mo_delta=differences(old_cfg,cfg.to_dict()),differences(old_mo,values)
        if n_auv>2 and (set(cfg_delta)!={"tdma_sensors_per_group","hello_period","service_ack_timeout","grant_ttl"}
                or set(mo_delta)!={"mac_child_lead_s"}):
            raise ValueError("Registered joint adaptation requires exactly four CFG clocks plus one existing MIN")
        if n_auv==2 and (cfg_delta or mo_delta):
            raise ValueError("Joint profiles must preserve complete original N2 CFG/MO")
        diagnostics=deepcopy(diagnostics)
        diagnostics.update(profile=profile,clock=clocks,
            config_changes=differences(before_cfg,cfg.to_dict()),option_changes=differences(before_mo,values))
        net=AcousticNetwork(cfg,cfg.seed)
        diagnostics["joint_clock_adaptation"]=dict(inherited_profile=ROOT_BUDGET_PROFILE,
            registered_H3_H4={str(k):v for k,v in joint_clocks.HORIZONS[profile].items()},
            declared_config_diff_from_v9=cfg_delta,declared_option_diff_from_v9=mo_delta,
            selector=joint_clocks.selector_proof(n_auv,profile,canonical_method(method)),
            original_calendar_algorithm_unchanged=True,actual_slot_owners=list(net.slot_owners),
            actual_slot_duration_s=cfg.slot_duration,actual_cooperative_gap_s=net.cooperative_slot_gap,
            actual_max_management_run=net.max_management_run,
            config_equal_to_v9=n_auv==2,routing_equal_to_v9=True,behavior_exploration_noise_unchanged=True,
            common30_only=True,selected=False,trained=False,
            tradeoff="Existing airtime is redistributed; HELLO costs real slots/bits; earlier H1 or later H2 paid receipt windows can both fail. No ordering, throughput or safety guarantee.")
        if n_auv>2:
            v5cfg,v5mo,_,_=build_settings(n_auv,30,method,"adaptive_packet_grid_window_v5",faults)
            budget=diagnostics["root_budget_adaptation"]
            budget.update(declared_config_diff_from_v5=differences(v5cfg.to_dict(),cfg.to_dict()),
                declared_option_diff_from_v5=differences(asdict(v5mo),values),
                effective_options_class=type(options).__module__+"."+type(options).__qualname__,
                physical_calendar_unchanged_from_v5=False,
                tradeoff=("Same V9 paid quotas/pool20 domain; N3 keeps V12 G6/H2 and N4 uses native G4/derived retry/MIN. N4 SN home opportunity rate decreases while cooperative opportunities become denser; no free capacity or ordering/safety guarantee."
                    if profile==joint_clocks.HETEROGENEOUS_PROFILE else "Same V9 paid parent/child quotas and scoped pool20 domain; G6/HELLO/retry/MIN clocks are explicitly changed, not free capacity or an original identical protocol."))
            diagnostics["child_window_adaptation"].update(minimum_command_lead_s=minimum,
                native_next_opportunity_search_max_s=h*clocks["frame_s"],eligible_phase_width_s=12.0,
                minimum_lead_rule="Fixed registered H*actual native frame - original12s decision interval",
                H2_hook_installed_for_full_only=canonical_method(method)=="full_v6" and h==2)
        if profile==joint_clocks.HETEROGENEOUS_PROFILE:
            baseline=build_settings(n_auv,30,method,joint_clocks.LEGACY_PROFILES[-1],faults)
            prior_cfg,prior_mo=baseline[0].to_dict(),asdict(baseline[1])
            delta_cfg,delta_mo=differences(prior_cfg,cfg.to_dict()),differences(prior_mo,values)
            if (set(delta_cfg)!=(set() if n_auv!=4 else {"tdma_sensors_per_group","service_ack_timeout","grant_ttl"}) or
                    set(delta_mo)!=(set() if n_auv!=4 else {"mac_child_lead_s"}) or
                    not joint_clocks.exact(asdict(routing),asdict(baseline[2]))):
                raise ValueError("Heterogeneous profile permits only N4 native G4 plus mechanically derived ACK/grant/MIN")
            # Constructor diagnostics must not permanently label a future
            # real checkpoint selected/unselected or trained/untrained.
            adaptation=diagnostics["joint_clock_adaptation"]
            adaptation.pop("selected",None);adaptation.pop("trained",None)
            adaptation.update(constructor_selects_or_trains=False,
                selection_status="This constructor does not select or launch candidates; consult the external campaign plan and actual ledger")
            diagnostics["heterogeneous_calendar_adaptation"]=dict(inherited_profile=joint_clocks.LEGACY_PROFILES[-1],
                declared_config_diff_from_v12=delta_cfg,declared_option_diff_from_v12=delta_mo,
                N2_N3_numeric_settings_unchanged=n_auv!=4,parent_prepare_unchanged=values["mac_prepare_lead_frames"]==3,
                existing_H2_selector_algorithm_unchanged=True,physical_bandwidth_or_slot_rate_increased=False,
                constructor_selects_or_trains=False,
                tradeoff="Native grouping redistributes the same paid airtime; N4 frame33->42, firstH2 band54..66->72..84, SN home rates decline. Longer setup/child/parent wallclock and future quotas may still worsen DATA or safety; no extra grant margin is added.")
        return cfg,options,routing,diagnostics
    if profile == n4_child_h2.PROFILE:
        if type(n_auv) is not int or n_auv not in (2,3,4) or type(n_sensors) is not int or n_sensors != 30:
            raise ValueError("The unselected V11 profile has fixed N2/3/4/common30 scope")
        cfg,old_options,routing,diagnostics = build_settings(n_auv,n_sensors,method,ROOT_BUDGET_PROFILE,faults)
        values=asdict(old_options)
        if n_auv==4:
            values["mac_child_lead_s"]=84.0
        options=n4_child_h2.build_options(n_auv,n_sensors,profile,canonical_method(method),values)
        diagnostics=deepcopy(diagnostics)
        diagnostics["profile"]=profile
        diagnostics["n4_H2_adaptation"]=n4_child_h2.selector_proof(n_auv)
        diagnostics["n4_H2_adaptation"].update(inherited_profile=ROOT_BUDGET_PROFILE,
            config_and_routing_unchanged=True,behavior_exploration_noise_unchanged=True,
            declared_option_diff_from_v9=({"mac_child_lead_s":{"old":36.0,"new":84.0}} if n_auv==4 else {}))
        if n_auv==4:
            diagnostics["option_changes"]["mac_child_lead_s"]={"old":14.4,"new":84.0}
            budget=diagnostics["root_budget_adaptation"]
            budget["declared_option_diff_from_v5"]["mac_child_lead_s"]={"old":36.0,"new":84.0}
            budget["effective_options_class"]=type(options).__module__+"."+type(options).__qualname__
            window=diagnostics["child_window_adaptation"]
            window.update(minimum_command_lead_s=84.0,native_next_opportunity_search_max_s=2*diagnostics["clock"]["frame_s"],
                eligible_phase_width_s=12.0,
                minimum_lead_rule="Fixed N4 H2: 2*original frame - original12s decision interval; N2/N3 retain H1",
                tradeoff="Later first window can improve paid receive lead but occupies future quotas, ages demand and increases censoring; no packet/safety guarantee")
        return cfg,options,routing,diagnostics
    if type(n_auv) is not int or n_auv not in (2,3,4):
        raise ValueError("Only 2,3,4 AUV are in scope")
    if type(n_sensors) is not int or n_sensors < n_auv:
        raise ValueError("At least one sensor per AUV is required")
    if profile not in PROFILES:
        raise ValueError("Unknown frozen scale profile")
    method = canonical_method(method)
    raw, options, routing = _reference(method)
    before_config, before_options = dict(raw), dict(options)
    raw.update(n_auv=n_auv, n_sensors=n_sensors)
    if faults is not None:
        raw["faults"] = faults
    if n_auv == 2:
        cfg = OriginalConfig.from_dict(raw)
    else:
        # Worst n3 payload=3200, n4=4096. Use their exact declared upper bounds.
        raw["declared_packet_bits"] = max(8*(40+112*n_auv),8*(40+112*(n_auv-1)+8+128))
        if profile in ("adaptive_packet_grid_v3","adaptive_packet_grid_queue_v4","adaptive_packet_grid_window_v5","adaptive_packet_grid_pool_v6","adaptive_packet_grid_calendar_v8",ROOT_BUDGET_PROFILE):
            raw["deployment_layout"]="scale_grid"
        if profile in ("adaptive_packet_grid_queue_v4","adaptive_packet_grid_window_v5","adaptive_packet_grid_pool_v6","adaptive_packet_grid_calendar_v8",ROOT_BUDGET_PROFILE):
            raw["coordination_service_interval"]=16./n_auv
        if profile=="adaptive_packet_grid_calendar_v8":
            # Independent V5 descendant, not the V6 pool candidate. The sole
            # root parameter change uses the existing native grouping field;
            # AcousticNetwork still constructs and charges every physical slot.
            # Fewer cooperative slots per frame redistribute existing airtime
            # to SN homes; bitrate, slot length and PHY priority stay unchanged.
            raw["tdma_sensors_per_group"]=n_auv+1
        cfg = ScaleConfig.from_dict(raw)
    clocks = _clock_diagnostics(cfg)
    if n_auv > 2 and profile in ("adaptive_v1","adaptive_packet_v2","adaptive_packet_grid_v3","adaptive_packet_grid_queue_v4","adaptive_packet_grid_window_v5","adaptive_packet_grid_pool_v6","adaptive_packet_grid_calendar_v8",ROOT_BUDGET_PROFILE):
        # These are protocol timing adaptations, NOT new channel bandwidth.
        # A basic/grant opportunity can span two original frames. Apply equally
        # to the full and USDE-only arms; pending packets are right-censored.
        service_budget = float(math.ceil(clocks["service_retry_interval_s"]))
        raw["service_ack_timeout"] = max(before_config["service_ack_timeout"], service_budget)
        raw["grant_ttl"] = max(before_config["grant_ttl"], service_budget)
        cfg = ScaleConfig.from_dict(raw)
        options.update(mac_max_leases=options["mac_pool_slots"]+n_auv*options["mac_auv_slots"],
                       mac_child_slots_per_sensor=1, mac_child_max_active=n_auv,
                       mac_prepare_lead_frames=max(1,min(5,math.ceil(108/clocks["frame_s"]))),
                       # One original maximum task-visit horizon, not a lease
                       # for nearly the entire1200s experiment. Expiry is native
                       # irrevocable-window expiry; reacquisition is still paid.
                       mac_coop_lease_frames=max(1,min(30,math.ceil(cfg.target_max_dwell/clocks["frame_s"]))))
        if profile in ("adaptive_packet_v2","adaptive_packet_grid_v3","adaptive_packet_grid_queue_v4","adaptive_packet_grid_window_v5","adaptive_packet_grid_pool_v6","adaptive_packet_grid_calendar_v8",ROOT_BUDGET_PROFILE):
            # Same C07 paid protocol: two child rights per simultaneous visit,
            # six NOMINAL root rights after all children are actually installed.
            # More loans steal existing SN slots; they create no new bandwidth.
            options.update(mac_pool_slots=6+2*n_auv,mac_max_leases=6+5*n_auv,
                           mac_child_slots_per_sensor=2,mac_child_max_active=2*n_auv,
                           mac_prepare_lead_frames=before_options["mac_prepare_lead_frames"],
                           mac_coop_lease_frames=before_options["mac_coop_lease_frames"])
        if profile in ("adaptive_packet_grid_window_v5","adaptive_packet_grid_pool_v6","adaptive_packet_grid_calendar_v8",ROOT_BUDGET_PROFILE):
            # Existing native C04 parameter: a MINIMUM command lead, not a
            # look-ahead horizon. Its selector still rejects a first opportunity
            # farther away than one physical frame. Native stride2 and half-open
            # windows mean1/2frames each contain one parent-active opportunity;
            # an un-clipped3frame child can use start and start+2. Permissions
            # remain paid, received, irrevocable and within the parent window.
            # Retain at least one entire native12s decision interval in the
            # eligible(MINlead,frame] phase band. A narrower band can exclude
            # certain donor offsets forever when parent stride/frame and the
            # existing decision tick are commensurate. No physical tick, slot
            # ownership or selector algorithm is changed to repair that alias.
            lead=min(clocks["cooperative_turn_s"],clocks["frame_s"]-options["mac_decision_interval_s"])
            if not 0<lead<clocks["frame_s"]:
                raise ValueError("Minimum child lead must fit strictly within the next native frame")
            options.update(mac_child_lease_frames=3,mac_child_lead_s=lead)
        if profile=="adaptive_packet_grid_pool_v6":
            # Native bounded capacities only. Three AUVs can have six current
            # visit children plus two old/future windows; four retain their
            # existing eight-child cap while increasing nominal root rights.
            # C07 still pays for every donor promise, ACK and certificate.
            options.update(mac_pool_slots=14 if n_auv==3 else 16,
                           mac_child_max_active=8,mac_max_leases=23 if n_auv==3 else 28)
            validate_scale_mac_budget(n_auv,options)
        if profile=="adaptive_packet_grid_calendar_v8":
            validate_scale_mac_budget(n_auv,options)
        if profile==ROOT_BUDGET_PROFILE:
            # Separate V5 descendant. AUV-parent2 and larger ROOT quotas are
            # paid donor-right redistribution, not new slots or bitrate. Only
            # n4/common30 expands the original pool16 validation envelope.
            options.update(registered_budget_values(n_auv))
    method_options = (build_root_budget_method_options(n_auv,n_sensors,profile,options,
                        registered_profiles=PROFILES) if profile==ROOT_BUDGET_PROFILE else MethodOptions(**options))
    routing_options = RoutingOptions(**routing)
    if method_options.mac_enabled != get_method(method).use_resource_mac:
        raise ValueError("USDE-only must not silently enable the communication bundle")
    diagnostics = dict(profile=profile, method=method, n_auv=n_auv, n_sensors=n_sensors,
        original_c07=True, team_reward="unchanged shared reward", safety="original absorbing termination",
        clock=clocks, config_changes={k:{"old":before_config.get(k),"new":v} for k,v in cfg.to_dict().items() if before_config.get(k)!=v},
        option_changes={k:{"old":before_options.get(k),"new":v} for k,v in options.items() if before_options.get(k)!=v},
        nominal_root_pool_remainder_if_all_installed=options["mac_pool_slots"]-options["mac_child_max_active"],
        note="Protocol adaptations are declared, not strict identical-protocol causal comparisons")
    if profile in ("adaptive_packet_grid_window_v5","adaptive_packet_grid_pool_v6","adaptive_packet_grid_calendar_v8",ROOT_BUDGET_PROFILE) and n_auv>2:
        diagnostics["child_window_adaptation"]=dict(minimum_command_lead_s=options["mac_child_lead_s"],
            native_next_opportunity_search_max_s=clocks["frame_s"],
            native_child_decision_interval_s=options["mac_decision_interval_s"],
            eligible_phase_width_s=clocks["frame_s"]-options["mac_child_lead_s"],
            minimum_lead_rule="min(management-aware cooperative turn, native frame - native child decision interval); avoid donor/tick phase aliasing",
            full_child_window_frames=options["mac_child_lease_frames"],parent_frame_stride=options["mac_frame_stride"],
            opportunities_in_unclipped_full_window=2,
            tradeoff="Longer irrevocable silence can waste root control rights or stale demand; parent-end clipping can leave fewer opportunities. No delivery or throughput guarantee.")
    if profile=="adaptive_packet_grid_pool_v6" and n_auv>2:
        budget=validate_scale_mac_budget(n_auv,options)
        diagnostics["pool_capacity_adaptation"]=dict(**budget,
            nominal_pool_slots=options["mac_pool_slots"],
            per_auv_parent_slots=options["mac_auv_slots"],
            max_live_or_future_child_windows=options["mac_child_max_active"],
            per_sensor_child_limit=options["mac_child_slots_per_sensor"],
            simultaneous_current_visit_child_demand=n_auv*options["mac_child_slots_per_sensor"],
            child_cap_headroom_for_old_or_future_windows=options["mac_child_max_active"]-n_auv*options["mac_child_slots_per_sensor"],
            nominal_root_pool_remainder_if_child_cap_fully_occupied=options["mac_pool_slots"]-options["mac_child_max_active"],
            physical_slots_or_bitrate_added=False, new_scheduler_or_information=False,
            selection_status="This constructor does not select or launch candidates; consult the external campaign plan and actual ledger",
            tradeoff="Larger declared pools take existing SN donor opportunities and paid management work. Active/future/old irrevocable promises still occupy original caps until expiry; nominal quota is not an installed certificate, a timely transmission, DATA throughput or safety guarantee.")
    if profile=="adaptive_packet_grid_calendar_v8" and n_auv>2:
        # Derive BOTH calendars using the unchanged native implementation. This
        # declares the complete difference against V5, not against V6 or a
        # hand-written calendar. Construction performs no network advance.
        old_cfg,old_mo,old_ro,old_diagnostics=build_settings(n_auv,n_sensors,method,
            "adaptive_packet_grid_window_v5",faults)
        old_net,new_net=AcousticNetwork(old_cfg,old_cfg.seed),AcousticNetwork(cfg,cfg.seed)
        old_frame,new_frame=old_diagnostics["clock"]["frame_s"],clocks["frame_s"]
        old_coop=old_net.slot_owners.count(0)
        new_coop=new_net.slot_owners.count(0)
        diagnostics["calendar_adaptation"]=dict(
            inherited_profile="adaptive_packet_grid_window_v5",
            root_parameter="Config.tdma_sensors_per_group",
            root_parameter_changes={"tdma_sensors_per_group":{"old":old_cfg.tdma_sensors_per_group,"new":cfg.tdma_sensors_per_group}},
            declared_config_diff_from_v5={k:{"old":old_cfg.to_dict().get(k),"new":v} for k,v in cfg.to_dict().items() if old_cfg.to_dict().get(k)!=v},
            declared_option_diff_from_v5={k:{"old":asdict(old_mo).get(k),"new":v} for k,v in options.items() if asdict(old_mo).get(k)!=v},
            routing_options_unchanged_from_v5=asdict(old_ro)==asdict(routing_options),
            calendar_source="unchanged usv_auv.network.AcousticNetwork native grouping algorithm",
            slot_count_rule="n_sensors + (n_auv + 1) * ceil(n_sensors / tdma_sensors_per_group)",
            old_slot_count=len(old_net.slot_owners),new_slot_count=len(new_net.slot_owners),
            old_frame_s=old_frame,new_frame_s=new_frame,
            sn_home_opportunities_per_frame=1,
            old_sn_home_opportunities_per_s=1./old_frame,new_sn_home_opportunities_per_s=1./new_frame,
            old_cooperative_opportunities_per_node_per_frame=old_coop,
            new_cooperative_opportunities_per_node_per_frame=new_coop,
            old_cooperative_opportunities_per_node_per_s=old_coop/old_frame,
            new_cooperative_opportunities_per_node_per_s=new_coop/new_frame,
            old_max_cooperative_gap_s=old_net.cooperative_slot_gap,
            new_max_cooperative_gap_s=new_net.cooperative_slot_gap,
            old_parent_lease_max_s=old_mo.mac_coop_lease_frames*old_frame,
            new_parent_lease_max_s=options["mac_coop_lease_frames"]*new_frame,
            old_unclipped_child_window_s=old_mo.mac_child_lease_frames*old_frame,
            new_unclipped_child_window_s=options["mac_child_lease_frames"]*new_frame,
            old_parent_active_opportunity_spacing_s=old_mo.mac_frame_stride*old_frame,
            new_parent_active_opportunity_spacing_s=options["mac_frame_stride"]*new_frame,
            old_protected_sensor_home_gap_s=2*old_frame,new_protected_sensor_home_gap_s=2*new_frame,
            native_mac_budget=validate_scale_mac_budget(n_auv,options),
            mac_demand_report_interval_s=options["mac_demand_report_interval_s"],
            clocks_rederived_from_actual_native_calendar=True,
            channel_airtime_redistributed=True,physical_slots_or_bitrate_added=False,
            new_scheduler_or_information=False,constructor_selects_or_trains=False,
            selection_status="This constructor does not select or launch candidates; consult the external campaign plan and actual ledger",
            tradeoff="Existing channel airtime is redistributed from ROOT/AUV cooperative opportunities to SN home opportunities. Cooperative opportunity frequency decreases and maximum gaps increase: paid STATE/COORD/REQUEST/ACK and MAC setup may get worse, including relative to USDE-only. Frame-counted parent lease seconds, child opportunity spacing/window seconds and protected home gaps change with the native frame. Original frame limits and native caps remain unchanged. No delivery, throughput, safety or ordering guarantee; no candidate selection or training result is implied.")
    if profile==ROOT_BUDGET_PROFILE and n_auv>2:
        old_cfg,old_mo,old_ro,_=build_settings(n_auv,n_sensors,method,
            "adaptive_packet_grid_window_v5",faults)
        port_audit=c03_domain_port_audit()
        # Declarations/checkpoints must be portable across the live research
        # tree and a future code package. Absolute inspector paths belong only
        # in external review, never in the configuration identity.
        port_audit.pop("original_source")
        port_audit["original_source_key"]="original/v6_candidates/c03/environment.py"
        port_audit["original_source_sha256"]=hashlib.sha256(
            (SOURCE/"v6_candidates"/"c03"/"environment.py").read_bytes()).hexdigest()
        diagnostics["root_budget_adaptation"]=dict(
            inherited_profile="adaptive_packet_grid_window_v5",
            declared_config_diff_from_v5={k:{"old":old_cfg.to_dict().get(k),"new":v} for k,v in cfg.to_dict().items() if old_cfg.to_dict().get(k)!=v},
            declared_option_diff_from_v5={k:{"old":asdict(old_mo).get(k),"new":v} for k,v in options.items() if asdict(old_mo).get(k)!=v},
            routing_options_unchanged_from_v5=asdict(old_ro)==asdict(routing_options),
            nominal_root_pool_slots=options["mac_pool_slots"],
            per_auv_parent_slots=options["mac_auv_slots"],
            nominal_global_parent_rights=options["mac_pool_slots"]+n_auv*options["mac_auv_slots"],
            declared_global_parent_limit=options["mac_max_leases"],
            actual_sensor_donor_count=n_sensors,
            max_live_or_future_child_windows=options["mac_child_max_active"],
            nominal_root_remainder_if_child_cap_fully_occupied=options["mac_pool_slots"]-options["mac_child_max_active"],
            nominal_root_remainder_rule="3*n_auv, compared with original2AUV pool10-child4=6",
            original_pool_validation_upper=16,
            effective_pool_validation_upper=20 if n_auv==4 else 16,
            validation_domain_scale_port=n_auv==4,
            originally_validated_pool_configuration=n_auv!=4,
            effective_options_class=type(method_options).__module__+"."+type(method_options).__qualname__,
            n4_scoped_validation_domain_proof=port_audit,
            physical_calendar_unchanged_from_v5=True,
            physical_slots_or_bitrate_added=False,new_scheduler_or_information=False,
            constructor_selects_or_trains=False,
            selection_status="This constructor does not select or launch candidates; consult the external campaign plan and actual ledger",
            tradeoff="The n4 pool20 tuple is an explicitly scoped configuration validation-domain scale-port beyond the original pool16 envelope, not an originally legal pool configuration. More ROOT-parent and fewer AUV-parent rights redistribute paid existing SN donor opportunities; child caps/windows, stride, G3, report72, ACK/GRANT clocks and original algorithms remain V5. Nominal ROOT remainder9/12 is not installed or timely control capacity. Protected donors may prevent filling the pool; missing ACK/COMMIT/SUBCOMMIT and irrevocable promises still waste rights. Full30-donor unique-owner/paid-protocol certification, performance and safety remain separate verification obligations; no ordering or throughput guarantee.")
    return cfg, method_options, routing_options, diagnostics

def _scale_task_constructor(self, cfg=None, method_id="full_v4", method_options=None, routing_options=None):
    """Verbatim ancestor setup except its historical n_auv==2 restriction."""
    self.method = task_base.get_method(method_id)
    self._task_ready = False
    ImprovedEnv.__init__(self,cfg,method_options or task_base.MethodOptions(),routing_options or task_base.routing_defaults())
    if self.cfg.state_packet_bits < 8*(128+task_base.TASK_EXTENSION_BYTES):
        raise ValueError("STATE lacks the reserved base128B +task64B budget")
    self.observation_schema = task_base.local_fields(self.cfg.n_auv)
    self.observation_dim = len(self.observation_schema)
    self.slow_observation_schema = task_base.slow_fields(self.cfg.n_auv)
    self.slow_observation_dim = len(self.slow_observation_schema)
    self.last_observations = self._observations()

@contextmanager
def _constructor_port():
    with _CONSTRUCTOR_LOCK:
        old = task_base.TaskV4Env.__init__
        task_base.TaskV4Env.__init__ = _scale_task_constructor
        try:
            yield
        finally:
            task_base.TaskV4Env.__init__ = old

class ScaledC07Env(OriginalC07):
    """No step/reward/target-selector override; only bounded constructor port."""
    def __init__(self,cfg,method_id,method_options,routing_options):
        if cfg.n_auv == 2:
            super().__init__(cfg,method_id,method_options,routing_options)
        else:
            with _constructor_port():
                super().__init__(cfg,method_id,method_options,routing_options)

    def reset(self,seed=None):
        if getattr(self.cfg,"deployment_layout","native_line")=="scale_grid":
            with deployment_port():
                result=super().reset(seed)
        else:
            result=super().reset(seed)
        interval=getattr(self.cfg,"coordination_service_interval",8.)
        if interval!=8.:
            # Existing C07 weighted waiting-age/deadline scheduler, unchanged
            # priorities, management rescue, MAC costs and all causal bonuses.
            # Both full and same-scale USDE share this declared parameter.
            self.network.queue_options=replace(self.network.queue_options,coord_service_s=interval)
        localization=getattr(self.cfg,"localization_service_interval",12.)
        if localization!=12.:
            # The FINAL inherited network now exists. Preserve every already
            # applied COORD/default option; the three original LOC flow kinds
            # all consume this one public QueueOptions scalar unchanged.
            self.network.queue_options=replace(self.network.queue_options,localization_service_s=localization)
        return result

def validate_v11_settings(cfg,method_id,method_options,routing_options):
    n=cfg.n_auv
    expected=build_settings(n,cfg.n_sensors,method_id,n4_child_h2.PROFILE,cfg.faults)
    if not (n4_child_h2.exact(cfg.to_dict(),expected[0].to_dict()) and
            n4_child_h2.exact(asdict(method_options),asdict(expected[1])) and
            n4_child_h2.exact(asdict(routing_options),asdict(expected[2]))):
        raise ValueError("Complete typed V11 CFG/MO/RO identity differs before behavior")
    return dict(config=deepcopy(expected[0].to_dict()),method=canonical_method(method_id),
        method_fingerprint=get_method(canonical_method(method_id)).fingerprint,
        method_options=deepcopy(asdict(expected[1])),routing_options=deepcopy(asdict(expected[2])))

class DeclaredV11C07Env(ScaledC07Env):
    """Identity/lifecycle only; original step/reward/outer selector inherited."""
    def __init__(self,cfg,method_id,method_options,routing_options):
        n4_child_h2.full_source_validate()
        self._v11_expected_DTO=validate_v11_settings(cfg,method_id,method_options,routing_options)
        self._v11_initialized=False
        self._v11_close_attempted=False
        self._v11_close_error=None
        self._v11_declared_n_auv=cfg.n_auv
        self._v11_expected=(cfg,method_id,method_options,routing_options)
        self._v11_selector_handle=(n4_child_h2.SelectorHandle(self) if cfg.n_auv==4 else None)
        try:
            super().__init__(cfg,method_id,method_options,routing_options)
            self._v11_initialized=True
            self._full_selector_identity(recache=True)
            self.validate_selector_identity()
        except BaseException as error:
            if self._v11_selector_handle is not None:
                n4_child_h2.preserve_cleanup(error,self._v11_selector_handle.restore,"V11 constructor hook cleanup also failed")
            raise

    def validate_selector_identity(self):
        cfg,method,mo,ro=self._v11_expected
        if type(cfg.n_auv) is not int or cfg.n_auv!=self._v11_declared_n_auv:
            raise ValueError("V11 environment scale cannot change after construction")
        expected=self._v11_expected_DTO
        if self._v11_initialized and (type(self.cfg.n_auv) is not int or self.cfg.n_auv!=self._v11_declared_n_auv
                or getattr(self.method,"method_id",None)!=expected["method"]
                or getattr(self.method,"fingerprint",None)!=expected["method_fingerprint"]):
            raise ValueError("V11 runtime scale/method cannot migrate by replacing its cfg/options")
        actual_cfg=self.cfg if self._v11_initialized else cfg
        actual_mo=self.method_options if self._v11_initialized else mo
        actual_ro=self.routing_options if self._v11_initialized else ro
        if not (n4_child_h2.exact(actual_cfg.to_dict(),expected["config"]) and
                n4_child_h2.exact(asdict(actual_mo),expected["method_options"]) and
                n4_child_h2.exact(asdict(actual_ro),expected["routing_options"])):
            raise ValueError("V11 cached full typed runtime CFG/MO/RO differs")
        if self._v11_initialized:
            schema=self._v11_expected_schema
            getter=self.network.candidate_topologies
            if not (type(getter) is MethodType and getter.__self__ is self.network and getter.__func__ is _NATIVE_CANDIDATE_GETTER
                    and _NATIVE_CANDIDATE_GETTER.__code__ is _NATIVE_CANDIDATE_GETTER_CODE):
                raise ValueError("V11 actual native topology getter identity changed")
            if not (n4_child_h2.exact(list(self.observation_schema),schema["local_fields"]) and
                    n4_child_h2.exact(list(self.slow_observation_schema),schema["slow_fields"]) and
                    type(self.observation_dim) is int and self.observation_dim==len(schema["local_fields"]) and
                    type(self.slow_observation_dim) is int and self.slow_observation_dim==len(schema["slow_fields"]) and
                    n4_child_h2.exact(self.observation_schema_version,schema["version"]) and
                    type(self.network.n_actions) is int and self.network.n_actions==schema["topology_actions"] and
                    n4_child_h2.exact([list(p) for p in self.network.candidates],schema["topology_candidates"]) and
                    n4_child_h2.exact([list(p) for p in self.network.topologies],schema["topology_candidates"]) and
                    n4_child_h2.exact([list(p) for p in getter()],schema["topology_candidates"])):
                raise ValueError("V11 runtime observation/schema identity drift")
        n4_child_h2.validate_environment_selector(self,self._v11_declared_n_auv)

    def _full_selector_identity(self,*,recache=False):
        n4_child_h2.full_source_validate()
        cfg,method,mo,ro=self._v11_expected
        active_cfg=self.cfg if self._v11_initialized else cfg
        active_mo=self.method_options if self._v11_initialized else mo
        active_ro=self.routing_options if self._v11_initialized else ro
        if type(active_cfg.n_auv) is not int or active_cfg.n_auv!=self._v11_declared_n_auv:
            raise ValueError("V11 full-boundary scale cannot migrate")
        expected=validate_v11_settings(active_cfg,method,active_mo,active_ro)
        # Preserve the original explicitly allowed evaluation fault exception.
        # No other cached field is rebuilt from mutable runtime objects.
        before={k:v for k,v in self._v11_expected_DTO["config"].items() if k!="faults"}
        after={k:v for k,v in expected["config"].items() if k!="faults"}
        if not n4_child_h2.exact(before,after):
            raise ValueError("Only original declared faults may differ at a full reset boundary")
        if recache:
            self._v11_expected_DTO=deepcopy(expected)
            n=self._v11_declared_n_auv
            spec=get_method(expected["method"])
            candidates=([list(p) for p in product(range(n+1),repeat=n) if all(AcousticNetwork._valid_path(i,p) for i in range(1,n+1))]
                if spec.use_topology else [[0 for _ in range(n)]])
            self._v11_expected_schema=dict(local_fields=list(local_fields(self._v11_declared_n_auv)),
                slow_fields=list(slow_fields(self._v11_declared_n_auv)),version=OriginalC07.observation_schema_version,
                topology_actions=len(candidates)+1,topology_candidates=candidates)
        self.validate_selector_identity()

    def reset(self,seed=None):
        try:
            self._full_selector_identity(recache=True)
            result=super().reset(seed)
            if self._v11_selector_handle is not None:
                self._v11_selector_handle.check(reset_deleted=True)
            self._full_selector_identity(recache=True)
            return result
        except BaseException as error:
            if self._v11_selector_handle is not None:
                n4_child_h2.preserve_cleanup(error,self._v11_selector_handle.restore,"V11 reset hook cleanup also failed")
            raise

    def close(self):
        if self._v11_close_attempted:
            if self._v11_close_error is not None:
                raise self._v11_close_error
            self.verify_closed_identity()
            return
        self._v11_close_attempted=True
        errors=[]
        try:
            super().close()
        except BaseException as error:
            errors.append(error)
        try:
            if self._v11_selector_handle is not None:
                self._v11_selector_handle.restore()
        except BaseException as error:
            errors.append(error)
        if errors:
            primary=next((e for e in errors if not isinstance(e,Exception)),errors[0])
            for error in errors:
                if error is not primary:
                    primary.add_note("Secondary V11 close/hook cleanup failure: "+repr(error))
            self._v11_close_error=primary
            raise primary

    def verify_closed_identity(self):
        if not self._v11_close_attempted or self._v11_close_error is not None:
            raise ValueError("V11 environment close is not successfully completed")
        if self._v11_selector_handle is not None and (not self._v11_selector_handle.closed or
                n4_child_h2.OWNER in self.__dict__):
            raise ValueError("Close-attempt flag cannot hide open/foreign selector ownership")
        if self._v11_selector_handle is not None:
            handle=self._v11_selector_handle
            if (handle.had_original_entry and self.__dict__.get(n4_child_h2.INNER) is not handle.original_entry
                    or not handle.had_original_entry and n4_child_h2.INNER in self.__dict__):
                raise ValueError("Close-attempt flag cannot hide a foreign/restored-method mismatch")

def _expected_joint_queue_options(cfg):
    """Fixed original public queue DTO + declared CFG, never mutable net state."""
    expected=dict(_NATIVE_QUEUE_OPTIONS_DTO)
    expected["coord_service_s"]=getattr(cfg,"coordination_service_interval",8.0)
    expected["localization_service_s"]=getattr(cfg,"localization_service_interval",12.0)
    return expected


def validate_joint_settings(cfg,method_id,method_options,routing_options,profile):
    n=cfg.n_auv
    expected=build_settings(n,cfg.n_sensors,method_id,profile,cfg.faults)
    if not (type(cfg) is type(expected[0]) and type(method_options) is type(expected[1]) and
            type(routing_options) is type(expected[2]) and
            (n!=4 or getattr(method_options,"_joint_profile",None)==profile) and
            joint_clocks.exact(cfg.to_dict(),expected[0].to_dict()) and
            joint_clocks.exact(asdict(method_options),asdict(expected[1])) and
            joint_clocks.exact(asdict(routing_options),asdict(expected[2]))):
        raise ValueError("Complete typed Joint CFG/MO/RO identity differs before behavior")
    result=dict(profile=profile,config=deepcopy(expected[0].to_dict()),method=canonical_method(method_id),
        clock=deepcopy(expected[3]["clock"]),calendar=deepcopy(expected[3]["joint_clock_adaptation"]),
        # Same source-derived native max(HELLO, management fair turn)+slot;
        # never use the mutable actual runtime timeout to rebuild this anchor.
        native_probe_timeout_s=float(max(expected[0].hello_period,
            expected[3]["clock"]["cooperative_turn_s"])+expected[0].slot_duration),
        method_fingerprint=get_method(canonical_method(method_id)).fingerprint,
        method_options=deepcopy(asdict(expected[1])),routing_options=deepcopy(asdict(expected[2])))
    if profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE:
        result["expected_queue_options"]=_expected_joint_queue_options(expected[0])
        result["child_delivery_priority"]=child_deadline.declaration(n,canonical_method(method_id))
    return result

class DeclaredJointC07Env(ScaledC07Env):
    """Identity/lifecycle only; original step/reward/outer selector inherited."""
    def __init__(self,cfg,method_id,method_options,routing_options,profile=None):
        profile=profile if profile is not None else getattr(type(self),"_joint_bound_profile",None)
        joint_clocks.registered(profile,cfg.n_auv)
        self._joint_profile=profile
        joint_clocks.full_source_validate()
        self._joint_expected_DTO=validate_joint_settings(cfg,method_id,method_options,routing_options,profile)
        if profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE:
            self._joint_expected_queue_type=_NATIVE_QUEUE_OPTIONS_CLASS
        self._joint_expected_types=(type(cfg),type(method_options),type(routing_options))
        self._joint_initialized=False
        self._joint_close_attempted=False
        self._joint_close_error=None
        self._joint_declared_n_auv=cfg.n_auv
        self._joint_expected=(cfg,method_id,method_options,routing_options)
        self._joint_selector_handle=(joint_clocks.SelectorHandle(self) if joint_clocks.HORIZONS[profile][cfg.n_auv]==2 and canonical_method(method_id)=="full_v6" else None)
        self._child_delivery_handle=None
        try:
            super().__init__(cfg,method_id,method_options,routing_options)
            self._joint_initialized=True
            self._full_selector_identity(recache=True)
            self.validate_selector_identity()
        except BaseException as error:
            if self._child_delivery_handle is not None:
                joint_clocks.preserve_cleanup(error,self._child_delivery_handle.restore,"V31 constructor rank cleanup also failed")
            if self._joint_selector_handle is not None:
                joint_clocks.preserve_cleanup(error,self._joint_selector_handle.restore,"Joint constructor hook cleanup also failed")
            raise

    def validate_selector_identity(self):
        cfg,method,mo,ro=self._joint_expected
        if type(cfg.n_auv) is not int or cfg.n_auv!=self._joint_declared_n_auv:
            raise ValueError("Joint environment scale cannot change after construction")
        expected=self._joint_expected_DTO
        if self._joint_profile!=expected["profile"] or getattr(type(self),"_joint_bound_profile",self._joint_profile)!=self._joint_profile:
            raise ValueError("Joint registered profile cannot migrate at runtime")
        if self._joint_initialized and (type(self.cfg.n_auv) is not int or self.cfg.n_auv!=self._joint_declared_n_auv
                or getattr(self.method,"method_id",None)!=expected["method"]
                or getattr(self.method,"fingerprint",None)!=expected["method_fingerprint"]):
            raise ValueError("Joint runtime scale/method cannot migrate by replacing its cfg/options")
        actual_cfg=self.cfg if self._joint_initialized else cfg
        actual_mo=self.method_options if self._joint_initialized else mo
        actual_ro=self.routing_options if self._joint_initialized else ro
        if not ((type(actual_cfg),type(actual_mo),type(actual_ro))==self._joint_expected_types and
                (self._joint_declared_n_auv!=4 or getattr(actual_mo,"_joint_profile",None)==self._joint_profile) and
                joint_clocks.exact(actual_cfg.to_dict(),expected["config"]) and
                joint_clocks.exact(asdict(actual_mo),expected["method_options"]) and
                joint_clocks.exact(asdict(actual_ro),expected["routing_options"])):
            raise ValueError("Joint cached full typed runtime CFG/MO/RO differs")
        if self._joint_initialized:
            schema=self._joint_expected_schema
            getter=self.network.candidate_topologies
            if not (type(getter) is MethodType and getter.__self__ is self.network and getter.__func__ is _NATIVE_CANDIDATE_GETTER
                    and _NATIVE_CANDIDATE_GETTER.__code__ is _NATIVE_CANDIDATE_GETTER_CODE and
                    joint_clocks.exact((_NATIVE_CANDIDATE_GETTER.__defaults__,_NATIVE_CANDIDATE_GETTER.__kwdefaults__,
                        _NATIVE_CANDIDATE_GETTER.__annotations__),_JOINT_GETTER_META) and
                    set(_NATIVE_CANDIDATE_GETTER.__globals__)==set(_JOINT_GETTER_GLOBALS) and
                    all(_NATIVE_CANDIDATE_GETTER.__globals__[key] is value for key,value in _JOINT_GETTER_GLOBALS.items())):
                raise ValueError("Joint actual native topology getter identity changed")
            if not (joint_clocks.exact(list(self.observation_schema),schema["local_fields"]) and
                    joint_clocks.exact(list(self.slow_observation_schema),schema["slow_fields"]) and
                    type(self.observation_dim) is int and self.observation_dim==len(schema["local_fields"]) and
                    type(self.slow_observation_dim) is int and self.slow_observation_dim==len(schema["slow_fields"]) and
                    joint_clocks.exact(self.observation_schema_version,schema["version"]) and
                    type(self.network.n_actions) is int and self.network.n_actions==schema["topology_actions"] and
                    joint_clocks.exact([list(p) for p in self.network.candidates],schema["topology_candidates"]) and
                    joint_clocks.exact([list(p) for p in self.network.topologies],schema["topology_candidates"]) and
                    joint_clocks.exact([list(p) for p in getter()],schema["topology_candidates"])):
                raise ValueError("Joint runtime observation/schema identity drift")
        if self._joint_initialized:
            c=expected["calendar"];clock=expected["clock"];net=self.network
            if not (joint_clocks.exact(list(net.slot_owners),c["actual_slot_owners"]) and
                    joint_clocks.exact(net.slot_duration,c["actual_slot_duration_s"]) and
                    joint_clocks.exact(net.frame_duration,clock["frame_s"]) and
                    joint_clocks.exact(net.cooperative_slot_gap,c["actual_cooperative_gap_s"]) and
                    type(net.max_management_run) is int and net.max_management_run==c["actual_max_management_run"]):
                raise ValueError("Joint actual original calendar clock/owner identity drift")
            # Original construction uses algebraically equivalent floating
            # expressions. Like the old joint probe, permit only 1e-8 absolute
            # arithmetic rounding, not an integer/float alias or stale clock.
            timers=((net.probe_timeout,expected["native_probe_timeout_s"]),
                (self.service_retry_interval,clock["service_retry_interval_s"]),
                (self.service_renew_lead,clock["service_renew_lead_s"]))
            if not all(type(actual) is float and math.isfinite(actual) and
                    type(anchor) is float and math.isfinite(anchor) and abs(actual-anchor)<=1e-8
                    for actual,anchor in timers):
                raise ValueError("Joint actual native probe/retry/renew timer identity drift")
            if self._joint_profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE:
                if (type(net.queue_options) is not self._joint_expected_queue_type or
                        not joint_clocks.exact(asdict(net.queue_options),expected["expected_queue_options"])):
                    raise ValueError("V28 actual whole original QueueOptions differs from fixed declared queue DTO")
        joint_clocks.validate_environment_selector(self,self._joint_declared_n_auv,self._joint_profile,expected["method"])
        if self._joint_initialized and self._joint_profile==child_deadline.PROFILE:
            if not joint_clocks.exact(expected["child_delivery_priority"],child_deadline.declaration(self._joint_declared_n_auv,expected["method"])):
                raise ValueError("V31 declared local priority differs")
            child_deadline.verify_environment(self)

    def _full_selector_identity(self,*,recache=False):
        joint_clocks.full_source_validate()
        cfg,method,mo,ro=self._joint_expected
        active_cfg=self.cfg if self._joint_initialized else cfg
        active_mo=self.method_options if self._joint_initialized else mo
        active_ro=self.routing_options if self._joint_initialized else ro
        if type(active_cfg.n_auv) is not int or active_cfg.n_auv!=self._joint_declared_n_auv:
            raise ValueError("Joint full-boundary scale cannot migrate")
        expected=validate_joint_settings(active_cfg,method,active_mo,active_ro,self._joint_profile)
        # Preserve the original explicitly allowed evaluation fault exception.
        # No other cached field is rebuilt from mutable runtime objects.
        before={k:v for k,v in self._joint_expected_DTO["config"].items() if k!="faults"}
        after={k:v for k,v in expected["config"].items() if k!="faults"}
        if not joint_clocks.exact(before,after):
            raise ValueError("Only original declared faults may differ at a full reset boundary")
        if (self._joint_profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE and
                not joint_clocks.exact(self._joint_expected_DTO["expected_queue_options"],expected["expected_queue_options"])):
            raise ValueError("V28 fixed expected whole QueueOptions cannot change at reset or recache")
        if recache:
            self._joint_expected_DTO=deepcopy(expected)
            n=self._joint_declared_n_auv
            spec=get_method(expected["method"])
            candidates=([list(p) for p in product(range(n+1),repeat=n) if all(AcousticNetwork._valid_path(i,p) for i in range(1,n+1))]
                if spec.use_topology else [[0 for _ in range(n)]])
            self._joint_expected_schema=dict(local_fields=list(local_fields(self._joint_declared_n_auv)),
                slow_fields=list(slow_fields(self._joint_declared_n_auv)),version=OriginalC07.observation_schema_version,
                topology_actions=len(candidates)+1,topology_candidates=candidates)
        self.validate_selector_identity()

    def reset(self,seed=None):
        try:
            self._full_selector_identity(recache=True)
            if self._child_delivery_handle is not None:
                self._child_delivery_handle.restore()
                self._child_delivery_handle=None
            result=super().reset(seed)
            if (self._joint_profile==child_deadline.PROFILE and self._joint_declared_n_auv in (3,4)
                    and self._joint_expected_DTO["method"]=="full_v6"):
                self._child_delivery_handle=child_deadline.RankHandle(self.network)
            if self._joint_selector_handle is not None:
                self._joint_selector_handle.check(reset_deleted=True)
            self._full_selector_identity(recache=True)
            return result
        except BaseException as error:
            if self._child_delivery_handle is not None:
                joint_clocks.preserve_cleanup(error,self._child_delivery_handle.restore,"V31 reset rank cleanup also failed")
            if self._joint_selector_handle is not None:
                joint_clocks.preserve_cleanup(error,self._joint_selector_handle.restore,"Joint reset hook cleanup also failed")
            raise

    def close(self):
        if self._joint_close_attempted:
            if self._joint_close_error is not None:
                raise self._joint_close_error
            self.verify_closed_identity()
            return
        self._joint_close_attempted=True
        errors=[]
        try:
            super().close()
        except BaseException as error:
            errors.append(error)
        try:
            if self._child_delivery_handle is not None:
                self._child_delivery_handle.restore()
        except BaseException as error:
            errors.append(error)
        try:
            if self._joint_selector_handle is not None:
                self._joint_selector_handle.restore()
        except BaseException as error:
            errors.append(error)
        if errors:
            primary=next((e for e in errors if not isinstance(e,Exception)),errors[0])
            for error in errors:
                if error is not primary:
                    primary.add_note("Secondary Joint close/hook cleanup failure: "+repr(error))
            self._joint_close_error=primary
            raise primary

    def verify_closed_identity(self):
        if not self._joint_close_attempted or self._joint_close_error is not None:
            raise ValueError("Joint environment close is not successfully completed")
        if self._child_delivery_handle is not None:
            self._child_delivery_handle.verify_closed()
        if self._joint_selector_handle is not None and (not self._joint_selector_handle.closed or
                joint_clocks.OWNER in self.__dict__):
            raise ValueError("Close-attempt flag cannot hide open/foreign selector ownership")
        if self._joint_selector_handle is not None:
            handle=self._joint_selector_handle
            if (handle.had_original_entry and self.__dict__.get(joint_clocks.INNER) is not handle.original_entry
                    or not handle.had_original_entry and joint_clocks.INNER in self.__dict__):
                raise ValueError("Close-attempt flag cannot hide a foreign/restored-method mismatch")


class DeclaredJointPHYLOCRoot16C07Env(DeclaredJointC07Env):
    """V28-only pre-step identity guard; unchanged native transition."""
    _joint_bound_profile=joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE

    def step(self, actions, topology_action=None):
        if getattr(self,"_joint_initialized",False) is not True:
            raise ValueError("V28 cannot step before complete initialization")
        self.validate_selector_identity()
        return super().step(actions, topology_action)


_JOINT_ENVIRONMENT_CLASSES={profile:(DeclaredJointPHYLOCRoot16C07Env
    if profile==joint_clocks.JOINT_PHY_LOC_ROOT16_PROFILE else
    type("DeclaredJoint_"+str(i)+"_C07Env",(DeclaredJointC07Env,),
        {"_joint_bound_profile":profile,"__module__":__name__}))
    for i,profile in enumerate(joint_clocks.PROFILES)}


def environment_class(profile):
    return _JOINT_ENVIRONMENT_CLASSES[profile] if profile in joint_clocks.PROFILES else DeclaredV11C07Env if profile==n4_child_h2.PROFILE else ScaledC07Env

def validate_declared_selector(env,profile):
    if profile in joint_clocks.PROFILES:
        if not isinstance(env,DeclaredJointC07Env) or env._joint_profile!=profile:
            raise ValueError("Joint policy requires actual registered profile ENV, not metadata-only identity")
        env.validate_selector_identity()
    if profile==n4_child_h2.PROFILE:
        if not isinstance(env,DeclaredV11C07Env):
            raise ValueError("V11 policy cannot validate an original H1 ENV by metadata alone")
        env.validate_selector_identity()

def make_environment(n_auv,n_sensors,method,profile="adaptive_v1",faults=None):
    cfg, options, routing, diagnostics = build_settings(n_auv,n_sensors,method,profile,faults)
    cls = _JOINT_ENVIRONMENT_CLASSES[profile] if profile in joint_clocks.PROFILES else DeclaredV11C07Env if profile==n4_child_h2.PROFILE else OriginalC07 if n_auv == 2 else ScaledC07Env
    env = cls(cfg,canonical_method(method),options,routing)
    env.scale_diagnostics = diagnostics
    validate_declared_selector(env,profile)
    return env
