"""Frozen-policy, failure-retaining evaluation; never imports an optimizer."""
import gzip
import inspect
import json
from pathlib import Path
import time
import numpy as np
import torch
from copy import deepcopy
from .workflow import native,bindings,load_new_checkpoint,source_hashes
from .measurement import PhysicalAudit,usable_installed_path
from .metrics import audit_unique_data,summarize_groups,paired_contrasts
from .evaluation_gate import validate_evaluation_seeds,confirmation_seeds,DEVELOPMENT_SEEDS
from .root_budget import ROOT_BUDGET_PROFILE
from .n4_child_h2 import PROFILE as N4_H2_PROFILE
from .joint_clocks import PROFILES as JOINT_PROFILES
from .passive_journal_io import make_passive_journal_writer
from usv_auv.train import atomic_json,file_digest,json_safe
from usv_auv.learning import seed_all
from scripts.tmc_network_observer import NetworkObserver
from scripts.summarize_tmc_retest import selected_specs,hop

def _passive_error(state,error,stage,*,preserve_original=False):
    """Logging failure only: never change ending/actions or replay a step."""
    state["observer_status"]="failed"
    state["logging_error"]=dict(stage=stage,type=type(error).__name__,message=str(error))
    if state["writer"] is not None:
        try:state["writer"].abort(stage=stage,error=error)
        except Exception as abort_error:
            state["abort_error"]=dict(type=type(abort_error).__name__,message=str(abort_error))
        except BaseException as abort_error:
            if not preserve_original:raise
            state["abort_error"]=dict(type=type(abort_error).__name__,message=str(abort_error),
                                      original_caller_exception_preserved=True)

def _open_passive(env,saved,identity,context,seed,folder,root):
    began=time.perf_counter()
    state=dict(seed=seed,sidecar_directory=str(root/f"seed_{seed}"),writer=None,
        observer_status="active",logging_wall_time_s=0.,last_completed_native_context=dict(step=0,time_s=0.))
    try:
        # Supplied identities and already stored native calendar; no behavior
        # getter, actor information, new native observation or method call.
        stored_network=inspect.getattr_static(env,"network")
        header=dict(n_auv=saved["environment_config"]["n_auv"],n_sensors=saved["environment_config"]["n_sensors"],
            slot_owners=inspect.getattr_static(stored_network,"slot_owners"),
            slot_duration=inspect.getattr_static(stored_network,"slot_duration"),
            source_hashes=saved["source_hashes"],model_sha256=identity["sha256"],profile=context["profile"],
            seed=seed,method=saved["method_id"],model_training_step=saved["global_step"])
        state["writer"]=make_passive_journal_writer(env,root/f"seed_{seed}",enabled=True,header=header,
                                                   episode_files_directory=folder,drain_period_s=10.)
    except Exception as error:_passive_error(state,error,"construction")
    finally:state["logging_wall_time_s"]+=time.perf_counter()-began
    return state

def _drain_passive(state,step_end,time_s,final=False):
    began=time.perf_counter()
    try:
        state["last_completed_native_context"]=dict(step=step_end,time_s=time_s)
        if state["observer_status"]!="active":return
        if final:
            state["logging_report"]=state["writer"].finalize(step_end=step_end,time_s=time_s)
            state["observer_status"]="completed"
        else:state["writer"].drain(step_end=step_end,time_s=time_s)
    except Exception as error:_passive_error(state,error,"finalize" if final else "drain")
    finally:state["logging_wall_time_s"]+=time.perf_counter()-began

def _write_passive_complete(root,states,original_status,original_error=None):
    """Separate observer status/report; no original metrics or timing mutation."""
    reports=[{key:value for key,value in state.items() if key!="writer"} for state in states]
    value=dict(format="c07_passive_evaluation_sidecars_v1",original_evaluation_status=original_status,
        observer_status="completed" if states and all(s["observer_status"]=="completed" for s in states) else "failed",
        episode_reports=reports,logging_wall_time_s=sum(s["logging_wall_time_s"] for s in states),
        logging_CPU_scope="External journal construction/drain/finalize/abort only; excluded from original inference_ms/step_ms",
        timing_boundary="Measured through each episode writer; this aggregate JSON write is outside method CPU and not self-timed",
        original_three_files_per_episode_unchanged=True,metrics75_unchanged=True,learning_steps=0,
        native_ending_changed=False,physics_replayed=False,cross_stream_global_order="unknown")
    if original_error is not None:value["original_error"]=dict(type=type(original_error).__name__,message=str(original_error))
    try:
        root.mkdir(parents=True,exist_ok=True)
        name="complete.json" if original_status=="completed" else "FAILED.json"
        if (root/name).exists():raise FileExistsError("Do not overwrite passive evaluation evidence")
        atomic_json(json_safe(value),root/name)
        return dict(observer_status=value["observer_status"],report_path=str(root/name))
    except Exception as error:
        # Caller still retains the original completed rows/error. No physical
        # retry is authorized by a failure to write the observer aggregate.
        return dict(observer_status="failed",aggregation_error=dict(type=type(error).__name__,message=str(error)),
                    original_evaluation_status=original_status,physics_replayed=False)

def evaluate_checkpoint(checkpoint,output,seeds,device="cpu",fault_profile="reference",validation_contract=None):
    output=Path(output).resolve()
    if output.exists(): raise FileExistsError("Evaluation needs a new output, including every failed attempt")
    seeds=list(seeds)
    if len(seeds)!=len(set(seeds)) or not seeds or len(seeds)>30:
        raise ValueError("Declare1..30 unique evaluation seeds")
    if validation_contract is None and any(type(seed)is not int or seed not in DEVELOPMENT_SEEDS for seed in seeds):
        raise ValueError("Only explicitly registered historical/renewed development seeds; formal confirmation stays sealed")
    saved=load_new_checkpoint(checkpoint)
    if fault_profile not in ("reference","direct1_outage","training"):
        raise ValueError("Unknown separately declared evaluation fault")
    identity=file_digest(checkpoint)
    phase=validate_evaluation_seeds(saved,identity["sha256"],seeds,validation_contract,
                                    fault_profile=fault_profile)
    context=saved["scale_context"]
    passive_enabled=context["profile"] in (ROOT_BUDGET_PROFILE,N4_H2_PROFILE,*JOINT_PROFILES)
    passive_root=output/"passive_sidecars"
    passive_states=[]
    cap=context.get("development_model_limit",100000) if context["stage"]=="development" else 450000
    # Keep bindings active across policy AND environment construction. Inference
    # uses only frozen actor/DDQN modules, no replay/Adam or test-time updates.
    with bindings(context,cap=cap) as executor:
        policy=executor.Policy(saved,device)
        env=policy.make_environment()
        policy.validate_environment(env)
        training_config=env.cfg.to_dict()
        # A declared fault counterfactual, not an environment/weight migration.
        # Copy to avoid mutating policy.cfg or the checkpoint's frozen config.
        if fault_profile!="training":
            env.cfg=deepcopy(env.cfg)
            env.cfg.faults=[] if fault_profile=="reference" else [{"src":0,"dst":1,"start":400.,"end":800.,"bidirectional":True}]
            env.cfg.validate()
        if {k:v for k,v in env.cfg.to_dict().items() if k!="faults"}!={k:v for k,v in training_config.items() if k!="faults"}:
            raise ValueError("Only declared faults may differ at frozen evaluation")
        output.mkdir(parents=True,exist_ok=False)
        records=[]
        original_evaluation_error=None
        torch.set_num_threads(1)
        try:
            for seed in seeds:
                seed_all(seed)
                obs,info=env.reset(seed)
                if fault_profile=="training": policy.validate_environment(env)
                physical=native.make_environment_observer(env,info,policy.method)
                network=NetworkObserver(env.network)
                safety=PhysicalAudit(env)
                total=aoi_sum=usable_sum=0.
                inference_ms,step_ms=[],[]
                recovery_since=recovered_at=lost_at=None
                fault=env.cfg.faults[0] if env.cfg.faults else None
                root_changes=0
                folder=output/f"seed_{seed}"
                folder.mkdir(exist_ok=False)
                passive_state=_open_passive(env,saved,identity,context,seed,folder,passive_root) if passive_enabled else None
                if passive_state is not None:passive_states.append(passive_state)
                with gzip.open(folder/"trace.jsonl.gz","xt",encoding="utf-8") as stream:
                    for index in range(env.cfg.episode_steps):
                        beginning=time.perf_counter()
                        previous_parents=env.network.active_parents
                        slow_mask=None
                        topo=None
                        if policy.topology is not None and env.step_count%env.cfg.slow_period==0:
                            state,mask=env.slow_state()
                            slow_mask=mask.tolist()
                            topo=policy.topology_action(state,mask)
                        actions=policy.act(obs)
                        inference_ms.append(1000*(time.perf_counter()-beginning))
                        obs,reward,terminated,truncated,info=env.step(actions,topo)
                        row=physical.after_step(info)
                        positions=env._positions_3d()
                        usable=[usable_installed_path(env.network,node,positions,env.time) for node in range(1,env.cfg.n_auv+1)]
                        aoi_sum+=sum(row["state_aoi_s"])*env.cfg.dt
                        usable_sum+=sum(usable)*env.cfg.dt
                        total+=reward
                        root_changes+=int(previous_parents!=env.network.active_parents)
                        if fault and fault["start"]<=env.time<=fault["end"] and not usable[0] and lost_at is None:
                            lost_at=env.time
                        if lost_at is not None and recovered_at is None:
                            recovery_since=(max(lost_at,env.time-env.cfg.dt) if recovery_since is None else recovery_since) if usable[0] else None
                            if recovery_since is not None and env.time-recovery_since>=10:
                                recovered_at=recovery_since
                        step_ms.append(1000*(time.perf_counter()-beginning))
                        stream.write(json.dumps(json_safe(dict(seed=seed,step=index+1,time=env.time,reward=reward,
                            actions=actions.tolist(),topology_request=topo,allowed_slow_mask=slow_mask,
                            terminated=terminated,truncated=truncated,metrics=info["metrics"],passive_environment=row,
                            installed_usable=usable,positions_xyz=positions.tolist(),targets=env.targets.tolist(),
                            physical_substeps=safety.samples[-env.cfg.substeps:])),allow_nan=False)+"\n")
                        # AFTER the original method clock and trace write. No
                        # new observation/action/slow-state call; logs cannot
                        # alter or replay this already completed native step.
                        if passive_state is not None:_drain_passive(passive_state,env.step_count,env.time)
                        if terminated or truncated: break
                if passive_state is not None:_drain_passive(passive_state,env.step_count,env.time,final=True)
                collected=audit_unique_data(sorted(env.collected),env.cfg.n_sensors,
                    expected_packets=int(info["metrics"]["collected_bits"]/env.cfg.data_packet_bits))
                eo,no=json_safe(physical.finalize()),json_safe(network.finalize(env.time))
                if not no["core_counter_reconciliation"]["all_observed_counters_match_core"]:
                    raise ValueError("Network paid-bit/event accounting mismatch")
                if no["logical"]["DATA"]["delivered_unique"]!=len(env.collected):
                    raise ValueError("Unique DATA counter mismatch")
                bm=json_safe(info["metrics"])
                affected=lost_at is not None
                recovery=dict(affected=affected,censored=affected and recovered_at is None,
                    lost_at_s=lost_at,recovered_at_s=recovered_at,
                    recovery_s=recovered_at-lost_at if affected and recovered_at is not None else None,
                    censor_followup_s=env.time-lost_at if affected and recovered_at is None else None,
                    definition="First AUV1 installed-path loss observed inside fault window to first10consecutive usable fast seconds; not stochastic DATA recovery or isolated fault causality")
                record=dict(n_auv=env.cfg.n_auv,n_sensors=env.cfg.n_sensors,method=policy.method.method_id,
                    profile=context["profile"],evaluation_fault=fault_profile,evaluation_faults=env.cfg.faults,
                    seed=seed,model_sha256=identity["sha256"],model_training_step=saved["global_step"],
                    duration_s=env.time,steps=index+1,terminated=terminated,truncated=truncated,
                    termination_reason=info["termination_reason"],ending_policy="original_absorbing_safety",
                    survived_full_horizon=not terminated and truncated,completed_full_horizon=truncated,
                    safety=safety.finalize(),distinct_sensors=eo["collection"]["distinct_served_sensors"],
                    collected_packets=len(env.collected),per_sensor_packets=eo["collection"]["collected_packets_per_sensor"],
                    unique_data_keys=[list(key) for key in sorted(env.collected)],collection_audit=collected,
                    ack_packets=len(env.acknowledged),metrics_base=bm,environment=eo,network=no,network_summary=no,
                    goodput_bit_s=bm["collected_bits"]/env.time,fixed_budget_goodput_bit_s=bm["collected_bits"]/1200,
                    collection_fraction=bm["collected_bits"]/(bm["initial_bits"]+bm["arrival_bits"]),
                    aoi_sum_s=aoi_sum,aoi_auv_seconds=env.cfg.n_auv*env.time,
                    connectivity_usable_auv_seconds=usable_sum,connectivity_observation_auv_seconds=env.cfg.n_auv*env.time,
                    energy_j=bm["total_energy_j"],recovery=recovery,root_view_route_changes=root_changes,
                    topology_requests=env.network.metrics.get("config_requests",0),return_value=total,
                    timing=dict(inference_mean_ms=float(np.mean(inference_ms)),inference_p95_ms=float(np.percentile(inference_ms,95)),
                        step_mean_ms=float(np.mean(step_ms)),step_p95_ms=float(np.percentile(step_ms,95))))
                datahop=hop(record,"DATA")
                # No DATA receiver-hop events means known zero trials, not a
                # successful ratio. Original observer omits empty by_kind rows.
                record.update(data_resolved_failures=datahop.get("resolved_failures",0),data_resolved_trials=datahop.get("resolved_trials",0))
                record["metrics75"]={key:dict(label=label.replace("total 30",f" {env.cfg.n_sensors}").replace("30 sensors",f"{env.cfg.n_sensors}node"),
                    unit=unit,value=getter(record)) for key,label,unit,section,getter in selected_specs()}
                if len(record["metrics75"])!=75: raise ValueError("Original75metric schema changed")
                with gzip.open(folder/"network_evidence.json.gz","xt",encoding="utf-8") as stream:
                    json.dump(no,stream,ensure_ascii=False,allow_nan=False)
                # Keep verbose event evidence once, not repeated in group rows.
                evidence_names=("hop_events","emissions","generation_events","delivery_events","protocol_events","queue_events")
                record["network"]=record["network_summary"]={k:v for k,v in no.items() if k not in evidence_names}
                atomic_json(json_safe(record),folder/"episode.json")
                records.append(record)
                with (output/"progress.jsonl").open("a",encoding="utf-8") as progress:
                    progress.write(json.dumps(dict(seed=seed,completed=len(records),files={p.name:file_digest(p) for p in folder.iterdir()}),allow_nan=False)+"\n")
            if file_digest(checkpoint)!=identity or source_hashes()!=saved["source_hashes"]:
                raise ValueError("Policy or source changed during evaluation")
            atomic_json(json_safe(dict(status="completed",rows=records,seeds=seeds,learning_steps=0,
                evaluation_phase=phase,model_sha256=identity["sha256"],all_failures_retained=True)),output/"complete.json")
            result=dict(status="completed",episodes=len(records),output=str(output))
            if passive_enabled:result["passive_journal"]=_write_passive_complete(passive_root,passive_states,"completed")
            return result
        except BaseException as original_error:
            original_evaluation_error=original_error
            if passive_enabled:
                for state in passive_states:
                    if state["observer_status"]=="active":
                        began=time.perf_counter()
                        _passive_error(state,original_error,"native_evaluation_error",preserve_original=True)
                        state["logging_wall_time_s"]+=time.perf_counter()-began
                try:_write_passive_complete(passive_root,passive_states,"failed",original_error)
                except BaseException:pass  # Aggregate cleanup cannot mask the actual caller error/cancellation.
            raise  # Keep the actual native/evaluator exception, not logging's.
        finally:
            if original_evaluation_error is None:env.close()
            else:
                try:env.close()
                except BaseException:pass  # Preserve the actual original exception object.

def analysis_scope(evaluations):
    """Keep opened confirmation separate and spend its frozen family alpha.

    Old development records without phase metadata remain descriptive only;
    no missing metadata can turn an already seen seed into a confirmation.
    This examines records only, and never constructs an environment.
    """
    phases=[]
    for value in evaluations:
        rows=value["rows"]
        seeds=value.get("seeds")
        if not rows or not isinstance(seeds,list) or len(seeds)!=len(set(seeds)):
            raise ValueError("Evaluation must declare all unique seeds and rows")
        if [row["seed"] for row in rows]!=seeds:
            raise ValueError("Evaluation rows disagree with the declared seed order")
        phase=value.get("evaluation_phase")
        if phase is None:
            if any(type(seed)is not int or not 10712000<=seed<10712030 for seed in seeds):
                raise ValueError("Missing phase metadata cannot authenticate confirmation")
            phase=dict(phase="development",seeds=seeds,primary="collected_packets",
                       confirmation_index=None,validation_contract_sha256=None,family_alpha=None)
        if phase.get("seeds")!=seeds or phase.get("primary")!="collected_packets":
            raise ValueError("Phase seeds or primary endpoint disagree with evaluation")
        faults={row["evaluation_fault"] for row in rows}
        if len(faults)!=1 or (phase.get("evaluation_fault") is not None and
                            phase["evaluation_fault"]!=next(iter(faults))):
            raise ValueError("Evaluation fault differs from its frozen phase")
        if phase.get("phase")=="holdout_validation":
            if (phase.get("holdout_opened") is not True or phase.get("already_opened") is not False or
                    phase.get("checkpoint_sha256")!=value.get("model_sha256") or
                    any(row["model_sha256"]!=value.get("model_sha256") for row in rows) or
                    any(row["model_training_step"]!=phase.get("model_training_step") for row in rows)):
                raise ValueError("Confirmation phase is not bound to actual frozen model rows")
            index=phase.get("confirmation_index")
            alpha=phase.get("family_alpha")
            digest=phase.get("validation_contract_sha256")
            if (type(index)is not int or index<1 or index>1000 or
                    isinstance(alpha,bool) or not isinstance(alpha,(int,float)) or
                    alpha!=.05/(2**index) or not isinstance(digest,str) or len(digest)!=64 or
                    phase.get("evaluation_fault")!=next(iter(faults))):
                raise ValueError("Confirmation needs its frozen contract, fault and alpha spending")
            if seeds!=list(confirmation_seeds(index)):
                raise ValueError("Confirmation needs all registered holdout seeds")
        elif phase.get("phase")=="development":
            if (any(type(seed)is not int or not 10712000<=seed<10712030 for seed in seeds) or
                    phase.get("validation_contract_sha256") is not None or
                    phase.get("confirmation_index") is not None or phase.get("family_alpha") is not None):
                raise ValueError("Development cannot borrow confirmation metadata or seeds")
        else:
            raise ValueError("Unknown evaluation phase")
        phases.append(phase)
    first=phases[0]
    for phase in phases[1:]:
        for key in ("phase","seeds","validation_contract_sha256","confirmation_index","family_alpha"):
            if phase.get(key)!=first.get(key):
                raise ValueError("Do not mix development, confirmation contracts, budgets or seed sets")
    confirmation=first["phase"]=="holdout_validation"
    return dict(phase=first["phase"],seeds=first["seeds"],primary="collected_packets",
                validation_contract_sha256=first.get("validation_contract_sha256"),
                confirmation_index=first.get("confirmation_index"),
                family_alpha=first["family_alpha"] if confirmation else .05,
                interpretation=("Frozen-candidate confirmation with registered sequential alpha spending; empirical, not a guarantee"
                                if confirmation else "Exploratory development evidence only; not untouched confirmation"))

def analyze_evaluations(paths,output):
    rows=[]
    evaluations=[]
    for path in paths:
        value=json.loads((Path(path)/"complete.json").read_text(encoding="utf-8"))
        if value.get("status")!="completed" or value.get("learning_steps")!=0:
            raise ValueError("Analyze only complete frozen evaluations; no resimulation")
        evaluations.append(value)
        rows.extend(value["rows"])
    scope=analysis_scope(evaluations)
    profiles={row["profile"] for row in rows}
    if len(profiles)!=1: raise ValueError("Analyze natural and adaptive profiles separately")
    if len({row["evaluation_fault"] for row in rows})!=1:
        raise ValueError("Fault conditions must be analyzed separately")
    if {row["n_sensors"] for row in rows}!={30}: raise ValueError("Cross-scale primary uses shared30SN workload only")
    if len({row["model_training_step"] for row in rows})!=1:
        raise ValueError("Cross-scale/ablation claims require identical actual training budgets")
    output=Path(output)
    output.mkdir(parents=True,exist_ok=False)
    # Confirmation spends progressively smaller alpha. Keep at least100
    # expected bootstrap samples per corrected tail rather than reporting
    # extrapolated extreme quantiles from an unchanged10k development run.
    repetitions=(max(10000,int(np.ceil(800/scope["family_alpha"])))
                 if scope["phase"]=="holdout_validation" else 10000)
    if repetitions>2000000:
        raise ValueError("Registered confirmation needs more than2M resamples; explicitly review analysis resources before proceeding")
    paired=paired_contrasts(rows,metrics=("collected_packets",),family_alpha=scope["family_alpha"],
                            repetitions=repetitions)
    paired["interpretation"]=scope["interpretation"]
    summary=dict(status="analysis_completed",groups=summarize_groups(rows),evaluation_scope=scope,
        paired=paired,profile=next(iter(profiles)),all_failures_retained=True,
        claim="Empirical estimates only; a prepared code package is not proof of the desired ordering")
    atomic_json(json_safe(summary),output/"analysis.json")
    return summary
