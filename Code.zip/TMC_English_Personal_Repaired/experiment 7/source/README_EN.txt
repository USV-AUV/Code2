Experiment 7 source package: see the root README.md for the private curated English view. The original authenticated source and raw evidence remain in the unfiltered archive.
