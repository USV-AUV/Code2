"""Portable Experiment 7 V31 release. Import/help/verify never simulate or learn.

Fresh reproduction is explicitly separate from the already completed confirmation.
The frozen scientific source, weights, original measurement code and original N2
Policy are not edited. Only the declared outer loader/seed/path boundary relocates.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
CODE = ROOT / 'source'
ARMS = ('original2', '3full', '3usde', '4full', '4usde')
FAULTS = ('reference', 'direct1_outage')
PROFILE = 'adaptive_packet_grid_joint_child_deadline_v31'

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(4*1024*1024), b''): h.update(b)
    return h.hexdigest()

def require(ok, message):
    if not ok: raise ValueError(message)

def write_new(p, value):
    with Path(p).open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def verify(data=False):
    m = read(ROOT / 'manifest.json')
    for relative, sha in m['files'].items():
        if not data and relative.startswith(('results/', 'models/checkpoints/')): continue
        p = (ROOT / relative).resolve()
        require(p.is_relative_to(ROOT.resolve()), 'Unsafe manifest path')
        require(p.is_file() and digest(p) == sha, 'Missing/changed: '+relative)
    c = read(ROOT / 'provenance/FROZEN_CONTRACT.json')
    for arm in ARMS:
        require(digest(ROOT / 'models' / arm / 'policy.pt') == c['models'][arm]['policy_sha256'], arm+' weight changed')
    print(json.dumps(dict(status='passed',include_raw_data=data,
        training_steps=0,simulation_steps=0,model_loads=0,CPU_reaudits=0)))
    return m, c

def train(a):
    verify()
    require(a.execute, 'Use --execute to explicitly start a NEW CUDA training run')
    output = Path(a.output).resolve()
    require(not output.exists() and not output.is_relative_to(ROOT), 'Choose an unused output outside the published Experiment 7')
    sys.path.insert(0, str(CODE))
    from exp7_c07_scaling_20261012.cli import parser
    from exp7_c07_scaling_20261012.workflow import train_declared
    n, method = int(a.arm[0]), 'usde_only' if a.arm.endswith('usde') else 'full'
    args = parser().parse_args(['train','--auv',str(n),'--sensors','30','--method',method,
        '--profile',PROFILE,'--fault','original_c07','--steps','450000','--seed','7',
        '--device','cuda','--output',str(output),'--ledger',str(output.parent/(output.name+'.ledger.json')),
        '--budget-mode','per_model','--candidate-id','published_v31_recipe_fresh_reproduction',
        '--development-limit','450000','--stage','full',
        '--confirm-full-training','I explicitly authorize full training'])
    print(json.dumps(train_declared(args), ensure_ascii=False))

def evaluate(a):
    _, original = verify()
    require(a.execute, 'Use --execute to start a NEW 300-episode CPU reproduction; published evidence is never overwritten')
    output = Path(a.output).resolve()
    require(not output.exists() and not output.is_relative_to(ROOT), 'Choose an unused output outside the publication')
    contract = read(ROOT / 'provenance/FROZEN_CONTRACT.json')
    for arm in ARMS: contract['models'][arm]['policy'] = str(ROOT/'models'/arm/'policy.pt')
    contract['publication_reproduction'] = dict(
        original_contract_sha256=digest(ROOT/'provenance/FROZEN_CONTRACT.json'),
        scope='Independent rerun of exposed published seeds; NOT new unseen confirmation',
        weights_and_scientific_functions_unchanged=True, learning_steps=0)
    output.mkdir(parents=True, exist_ok=False)
    cp = output/'REPRODUCTION_CONTRACT.json'
    write_new(cp, contract)
    sys.path.insert(0, str(CODE))
    sys.path.insert(0, str(ROOT/'tools'))
    wrapper = load('published_original_measurement_boundary', ROOT/'tools/v31_formal_worker.py')
    from exp7_c07_scaling_20261012 import evaluation as common
    from v6_campaigns.c07_1m_20260919 import workflow as native
    records = []
    for fault in FAULTS:
        for arm in ARMS:
            model = contract['models'][arm]
            target = output/'evaluations'/fault/arm
            def authorize(path, key, selected_fault, seeds, policy_sha, actual_output):
                require(Path(path).resolve()==cp and read(cp)==contract, 'Frozen reproduction contract changed')
                require(key==arm and selected_fault==fault and seeds==contract['seed_pools'][fault], 'Undeclared model/fault/seeds')
                require(policy_sha==model['policy_sha256'] and Path(actual_output).resolve()==target, 'Policy/output mismatch')
                for k in ARMS:
                    require(digest(contract['models'][k]['policy'])==contract['models'][k]['policy_sha256'], 'Five-model freeze changed')
                marker=output/(fault+'_'+arm+'.OPENED_BEFORE_ENV.json')
                write_new(marker, dict(created_at=datetime.now(timezone.utc).isoformat(),
                    arm=arm,fault=fault,seeds=seeds,
                    all_five_policy_sha256={k:contract['models'][k]['policy_sha256'] for k in ARMS},
                    contract_sha256=digest(cp),reproduction_not_new_confirmation=True))
                return dict(phase='published_holdout_reproduction',seeds=seeds,primary='collected_packets',
                    checkpoint_sha256=policy_sha,model_training_step=450000,
                    evaluation_fault=fault,validation_contract_sha256=digest(cp),
                    holdout_opened=True,already_opened=False,family_alpha=.05,
                    collection_family_comparisons=8,native_sequential_alpha_protocol=False,
                    reproduction_not_new_confirmation=True)
            worker, loaded, proof = wrapper.derive_measurement_worker(common,model,arm,fault,cp,target,
                native=native if arm=='original2' else None,authorize=authorize)
            result=worker(Path(model['policy']),target,contract['seed_pools'][fault],
                device='cpu',fault_profile=fault,validation_contract=cp)
            require(result['status']=='completed' and result['episodes']==30 and len(loaded)==1, 'Incomplete group; preserve output, never retry automatically')
            records.append(dict(arm=arm,fault=fault,complete_sha256=digest(target/'complete.json'),**proof))
            write_new(output/(fault+'_'+arm+'.PROVENANCE.json'), records[-1])
    write_new(output/'REPRODUCTION_ENDED.json',dict(episodes=300,learning_steps=0,groups=records,
        original_published_results_unchanged=True,new_confirmation_claim=False))

def report(a):
    verify()
    path=ROOT.parent/'selected_results'/'fleet_3auv_reference.csv'
    print(path.read_text(encoding='utf-8-sig'))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    s=p.add_subparsers(dest='action',required=True)
    q=s.add_parser('verify');q.add_argument('--data',action='store_true')
    s.add_parser('report')
    q=s.add_parser('train');q.add_argument('--arm',choices=ARMS[1:],required=True);q.add_argument('--output',required=True);q.add_argument('--execute',action='store_true')
    q=s.add_parser('evaluate');q.add_argument('--output',required=True);q.add_argument('--execute',action='store_true')
    a=p.parse_args()
    if a.action=='verify':verify(a.data)
    elif a.action=='train':train(a)
    elif a.action=='evaluate':evaluate(a)
    else:report(a)

if __name__=='__main__': main()
