"""Pure publication regression: no numerical imports, weights or ENV."""
import ast
import json
from pathlib import Path
import sys
import subprocess
import tempfile
import unittest
from types import SimpleNamespace
import latest

class PortableTests(unittest.TestCase):
    def test_all_scientific_files_byte_exact(self):
        m=latest.read(latest.ROOT/'manifest.json')
        for rel,sha in m['files'].items():
            if rel.startswith('source/'):
                self.assertEqual(latest.digest(latest.ROOT/rel),sha)

    def test_syntax_all_source(self):
        for path in (latest.ROOT/'source').rglob('*.py'):
            compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')

    def test_five_weights(self):
        c=latest.read(latest.ROOT/'provenance/FROZEN_CONTRACT.json')
        for arm in latest.ARMS:
            self.assertEqual(latest.digest(latest.ROOT/'models'/arm/'policy.pt'),c['models'][arm]['policy_sha256'])

    def test_complete300_and_all75(self):
        expected = [latest.ROOT/'results'/fault/arm/'complete.json'
                    for fault in latest.FAULTS for arm in latest.ARMS]
        if any(not path.is_file() for path in expected):
            self.skipTest('External 300-episode raw evaluation assets are not included in this personal edition')
        n=0
        for fault in latest.FAULTS:
            for arm in latest.ARMS:
                path=latest.ROOT/'results'/fault/arm/'complete.json'
                v=latest.read(path)
                self.assertEqual(v['learning_steps'],0)
                self.assertTrue(v['all_failures_retained'])
                self.assertEqual(len(v['rows']),30)
                for row in v['rows']:self.assertEqual(len(row['metrics75']),75)
                n+=len(v['rows'])
        self.assertEqual(n,300)

    def test_unchanged_measurement_boundary_fixture(self):
        sys.path.insert(0,str(latest.ROOT/'tools'))
        w=latest.load('portable_fixture_original_wrapper',latest.ROOT/'tools/v31_formal_worker.py')
        saved={'scale_context':{'profile':latest.PROFILE}}
        def original(path,output,seeds,validation_contract=None,fault_profile='reference'):
            s=load_new_checkpoint(path)
            return validate_evaluation_seeds(s,'a'*64,seeds,validation_contract,fault_profile=fault_profile)
        ns=dict(original.__globals__,load_new_checkpoint=lambda path:saved,validate_evaluation_seeds=lambda *x,**kw:None)
        from types import FunctionType
        f=FunctionType(original.__code__,ns,'evaluate_checkpoint',original.__defaults__)
        common=SimpleNamespace(evaluate_checkpoint=f,load_new_checkpoint=lambda path:saved)
        model={'policy':str(latest.ROOT/'models/3full/policy.pt')}
        old=w.g.validate_saved_policy
        try:
            w.g.validate_saved_policy=lambda s,m:None # fixture-only objects; no policy/ENV exists
            def gate(*args):return {'fixture_only':True}
            worker,loaded,proof=w.derive_measurement_worker(common,model,'3full','reference',Path('fixture_contract'),Path('fixture_output'),authorize=gate)
            self.assertIs(worker.__code__,f.__code__)
            self.assertEqual(set(proof['evaluation_global_bindings']),{'load_new_checkpoint','validate_evaluation_seeds'})
            self.assertEqual(worker(Path(model['policy']),Path('fixture_output'),[1],validation_contract=Path('fixture_contract')),{'fixture_only':True})
            self.assertEqual(len(loaded),1)
        finally:w.g.validate_saved_policy=old

    def test_no_numeric_import(self):
        # A fresh interpreter isolates this property from the notebook/host runtime,
        # which can eagerly import NumPy before tests begin.
        snippet = "import latest,sys; print(int('torch' not in sys.modules and 'numpy' not in sys.modules))"
        p = subprocess.run([sys.executable, '-S', '-c', snippet],
                           cwd=str(latest.ROOT), capture_output=True, text=True, check=True)
        self.assertEqual(p.stdout.strip(), '1')

if __name__=='__main__':unittest.main(verbosity=2)
