"""Portable, explicit entry points for the C07 collaboration release.

No training or simulation starts on import. Large evidence is losslessly zipped.
Use only trusted project checkpoints: PyTorch checkpoints contain pickle data.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
METHODS = ('full_v6','usde_only_v6','topology_only_v6',
           'synchronous_fim_rl','communication_aware_tmc')
NUMBERS = (1,2,3,5,6,7,8)

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''): h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def verify_summaries():
    """Verify user-confirmed current aggregate CSV files, NOT older archives."""
    base = ROOT / 'selected_results'
    metadata = read(base / 'selection_manifest.json')
    expected = metadata['packaged_table_sha256']
    listed = set(metadata['available_original_summary_tables'])
    if listed != set(expected):
        raise ValueError('Current summary table list and canonical hashes differ')
    actual = {p.name for p in (base / 'all_original_summary_tables').glob('*.csv')}
    if actual != listed:
        raise ValueError(f'Unexpected or missing current summary tables: {sorted(actual ^ listed)}')
    for name, sha256 in expected.items():
        actual_sha256 = digest(base / 'all_original_summary_tables' / name)
        if actual_sha256 != sha256:
            raise ValueError(f'Current summary SHA-256 mismatch: {name}')
    print(f'Current accepted summary tables verified: {len(expected)}/{len(expected)}. Historical versions are excluded from current hash checks.', flush=True)
    return expected

def verify():
    manifest=read(ROOT/'release_manifest.json')
    for name,sha in manifest['code_files'].items():
        if digest(ROOT/name)!=sha: raise ValueError(f'Release file changed: {name}')
    sys.path.insert(0, str(ROOT / 'experiment 1' / 'source'))
    from english_source_compat import verify_registry
    registry_status = verify_registry(ROOT / 'experiment 1' / 'source')
    verify_summaries()
    print(f"English-view integrity check passed: {len(manifest['code_files'])} file hashes; {registry_status['verified_localized_files']} source translations verified", flush=True)
    return manifest

def extract(selection):
    manifest=verify()
    assets=[a for a in manifest['assets'] if selection=='all' or a['category']==selection]
    if not assets: raise ValueError(f'No archive category: {selection}')
    for asset in assets:
        path=ROOT/'assets'/asset['name']
        if not path.exists(): raise FileNotFoundError(f'Download release asset to assets/: {path.name}')
        if digest(path)!=asset['sha256']: raise ValueError(f'Archive SHA mismatch: {path.name}')
        with zipfile.ZipFile(path) as archive:
            # Verify every member before writing any member in this archive.
            for info in archive.infolist():
                target=(ROOT/info.filename).resolve()
                if not target.is_relative_to(ROOT.resolve()): raise ValueError('Unsafe archive member')
                if target.exists() and digest(target)!=manifest['asset_files'][info.filename]:
                    raise ValueError(f'Refusing to overwrite modified file: {target}')
            for info in archive.infolist():
                target=ROOT/info.filename
                if not target.exists(): archive.extract(info,ROOT)
                if digest(target)!=manifest['asset_files'][info.filename]: raise ValueError('Extracted SHA mismatch')
        print('Verified and extracted:',asset['name'],flush=True)

def install_paths():
    for number in NUMBERS:
        p=ROOT/f'experiment {number}'
        if str(p) not in sys.path: sys.path.insert(0,str(p))
    sys.path.insert(0,str(ROOT/'experiment 1'/'source'))

def command(args,cwd):
    print('RUN:',sys.executable,*map(str,args),flush=True)
    subprocess.run([sys.executable,'-B','-X','utf8',*map(str,args)],cwd=cwd,check=True)

def train(args):
    verify()
    if args.device!='cuda':
        raise ValueError('Original five-system training requires CUDA; CPU is for inference and Experiment 7 training only')
    p=ROOT/'experiment 1'; src=p/'source'
    output=Path(args.output).resolve()
    if output.exists(): raise ValueError('Training output must be new')
    if args.method in METHODS[:3]:
        opts=p/'provenance'/'method_options'/f'{args.method}.json'
        routes=p/'provenance'/'routing_options'/f'{args.method}.json'
        cmd=['-m','v6_campaigns.c07_1m_20260919.workflow','train',
             '--method',args.method,'--config',p/'provenance'/'frozen_config.json',
             '--output',output,'--device',args.device,'--seed',str(args.seed),
             '--allow-long-run','--milestones',str(args.target),
             '--checkpoint-every','10000','--log-every','1000']
        if args.mode=='fresh':
            cmd += ['--steps',str(args.target),'--method-options',opts,'--routing-options',routes]
        else:
            start=100000 if args.mode=='continuation100k' else 450000
            if args.target<=start: raise ValueError('Target must exceed parent step')
            ckpt=p/'models'/('resume_100k' if start==100000 else '45w')/args.method/'checkpoint.pt'
            if not ckpt.exists(): raise FileNotFoundError('Run extract --category training first')
            cmd += ['--resume',ckpt,'--steps',str(args.target-start)]
    else:
        if args.mode!='fresh': raise ValueError('External baselines use fresh mode; native CLI also supports resume')
        cmd=['-m','baselines.train','--method',args.method,
             '--config',p/'provenance'/'baseline_campaign'/'frozen_config.json',
             '--output',output,'--device',args.device,'--seed',str(args.seed),'--steps',str(args.target),
             '--allow-long-run','--verify-sources','--milestones',str(args.target),
             '--checkpoint-every','10000','--log-every','1000']
    command(cmd,src)

def evaluate1(output,device):
    p=ROOT/'experiment 1'; out=Path(output).resolve()
    if out.exists(): raise ValueError('New output directory required')
    for m in METHODS:
        module='v6_campaigns.c07_1m_20260919.workflow' if m in METHODS[:3] else 'baselines.evaluate'
        args=['-m',module]+(['evaluate'] if m in METHODS[:3] else [])
        args += ['--method',m,'--checkpoint',p/'models'/'45w'/m/'policy.pt',
                 '--output',out/(m+'_0450000'),'--device',device,'--seed','9300000',
                 '--episodes','30','--steps','1200']
        if m in METHODS[3:]: args += ['--tmc-metrics','--verify-sources']
        command(args,p/'source')
    command(['compare_experiment1.py','--input',out,'--output',out.with_name(out.name+'_comparison')],ROOT)

def run_experiment(args):
    verify()
    n=args.number; p=ROOT/f'experiment {n}'
    if n==1: return evaluate1(args.output,args.device)
    if n in (2,3,5,6) and args.device!='cuda':
        raise ValueError('These registered runners require CUDA; CPU is supported for inference smoke and experiments 1/7/8')
    if n in (7,8) and args.device!='cpu': raise ValueError('Registered experiments 7/8 use CPU')
    if n==7:
        return command([p/'latest.py','evaluate','--output',Path(args.output).resolve(),'--execute'],ROOT)
    output=p/'runs'/args.output; report=p/'reports'/args.report
    if n in (2,3):
        command([f'run_experiment{n}.py','run','--preset','all','--output',output,'--execute'],p)
        if n==3:
            command(['compact_exp3.py','--input',output,'--output',report],ROOT)
        else:
            command([f'run_experiment{n}.py','analyze','--input',output,'--output',report],p)
    elif n in (5,6,8):
        command(['-m',f'exp{n}.pipeline','--run',output,'--report',report],p)

def smoke():
    verify();install_paths()
    import numpy as np
    import torch
    from exp3.runner import load,bind,routing_decision
    torch.set_num_threads(1)
    results=[]
    for method in METHODS:
        policy,env,factory,checkpoint,path=load(method,'cpu')
        obs,_=env.reset(seed=42);bind(policy,env)
        for i in range(12):
            topology=routing_decision(method,policy,env)
            action=policy.act(obs)
            if not np.isfinite(action).all(): raise ValueError('Nonfinite action')
            obs,_,terminated,truncated,info=env.step(action,topology_action=topology)
            if not np.isfinite(obs).all(): raise ValueError('Nonfinite state')
            if terminated or truncated: break
        results.append(dict(method=method,step=checkpoint['global_step'],steps=i+1,
                            fingerprint=env.cfg.fingerprint,policy_sha256=digest(path)))
        env.close()
    # All experiment modules can import using only this project.
    for n in (2,3,5,6,8):
        for mod in ('protocol','runner','analysis'): importlib.import_module(f'exp{n}.{mod}')
    print(json.dumps(dict(status='passed',training_steps=0,nonformal_seed=42,models=results),indent=2))

def audit_data(args):
    manifest=verify(); total=0;size=0
    if not manifest['asset_files']:
        print(json.dumps(dict(status='not_included', files=0, bytes=0, verified_episodes=0,
            reason='This personal review package omits external raw experiment assets; a 0-file check cannot certify the manuscript episode totals.'),indent=2))
        return
    for name,sha in manifest['asset_files'].items():
        if args.category!='all' and manifest['file_categories'][name]!=args.category: continue
        path=ROOT/name
        if not path.exists(): raise FileNotFoundError(f'Extract assets first: {name}')
        if digest(path)!=sha: raise ValueError(f'Data SHA mismatch: {name}')
        total+=1;size+=path.stat().st_size
    print(json.dumps(dict(status='passed',files=total,bytes=size,episodes=manifest['formal_episode_counts']),indent=2))

def main():
    p=argparse.ArgumentParser(description=__doc__); s=p.add_subparsers(dest='action',required=True)
    s.add_parser('verify');s.add_parser('verify-summaries');s.add_parser('smoke')
    for name in ('extract','audit-data'):
        a=s.add_parser(name);a.add_argument('--category',default='all')
    a=s.add_parser('train');a.add_argument('--method',choices=METHODS,required=True)
    a.add_argument('--mode',choices=['fresh','continuation100k','resume45w'],default='fresh')
    a.add_argument('--target',type=int,choices=[450000,1000000],default=450000)
    a.add_argument('--device',choices=['cpu','cuda'],default='cuda');a.add_argument('--seed',type=int,default=7,help='Training seed; default is the archived seed 7');a.add_argument('--output',required=True)
    a=s.add_parser('run');a.add_argument('--number',type=int,choices=NUMBERS,required=True)
    a.add_argument('--output',default='new_run');a.add_argument('--report',default='new_report')
    a.add_argument('--device',choices=['cpu','cuda'],default='cuda')
    args=p.parse_args()
    if args.action=='verify':verify()
    elif args.action=='verify-summaries':verify_summaries()
    elif args.action=='smoke':smoke()
    elif args.action=='extract':extract(args.category)
    elif args.action=='audit-data':audit_data(args)
    elif args.action=='train':train(args)
    elif args.action=='run':run_experiment(args)

if __name__=='__main__':main()
