import unittest

from exp5.protocol import (COMMON_WARMUP_STEPS, MODES, PROFILES, SEEDS,
                           fault_declaration, jobs, scheduled)


class ProtocolTest(unittest.TestCase):
    def test_matrix_unique(self):
        self.assertEqual(len(jobs()), 720)
        self.assertEqual(len(set(jobs())), 720)
        self.assertEqual(len(MODES), 8)
        self.assertEqual(len(PROFILES), 3)
        self.assertEqual(len(SEEDS), 30)

    def test_equal_budget_after_common_warmup(self):
        start = COMMON_WARMUP_STEPS // 5
        for mode in MODES[:5]:
            self.assertEqual([scheduled(mode, i) for i in range(start)],
                             [(True, False)] * start)
        expected = {
            "mobility_only": [(True, False), (False, False)],
            "topology_only_fixed_usv": [(False, True), (False, False)],
            "sequential_mobility_topology": [(True, False), (False, True)],
            "sequential_topology_mobility": [(False, True), (True, False)],
            "joint_equal_budget": [(True, True), (False, False)],
        }
        for mode, pattern in expected.items():
            self.assertEqual([scheduled(mode, start+i) for i in range(4)], pattern*2)

    def test_same_fault_window_and_bidirectional_pair(self):
        self.assertEqual(fault_declaration("reference"), [])
        for mode in ("direct1_outage", "direct2_outage"):
            fault, = fault_declaration(mode)
            self.assertEqual((fault["start"], fault["end"]), (400., 800.))
            self.assertEqual(fault["dst"], 0)
            self.assertTrue(fault["bidirectional"])


if __name__ == "__main__":
    unittest.main()
