"""Experiment 5: frozen-policy decision-scheduling evaluation."""
