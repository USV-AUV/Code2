"""Memory-bounded, SHA-verified, seed-paired Experiment 5 analysis."""
from __future__ import annotations
import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import statistics
import sys

import numpy as np

from .protocol import ROOT, FORMAT, MODES, PROFILES, SEEDS, MODEL_FOR, jobs
from .runner import digest, source_hashes, verified_complete, verify_package, write_json

LABELS = {
    "mobility_only": "USV planning only (fixed direct routes)",
    "topology_only_fixed_usv": "Topology updating only (fixed USV)",
    "sequential_mobility_topology": "Sequential: mobility then topology",
    "sequential_topology_mobility": "Sequential: topology then mobility",
    "joint_equal_budget": "Joint decisions with equal update budget",
    "joint_native": "Native full V6-C07",
    "trained_usde_only": "Trained USDE-only",
    "trained_no_usde": "Trained no-USDE (full coordination)",
}
REPETITIONS = 3000
RANDOM_SEED = 30092026


def ratio(n, d):
    return n / d if d else None


def hop_counts(row):
    kind = row["network"].get("by_kind", {}).get("DATA", {})
    w = kind.get("hop_delivery", {}).get("completion_window", {})
    return int(w.get("resolved_failures", 0)), int(w.get("resolved_trials", 0))


def aggregate(rows):
    if not rows:
        raise ValueError("Empty group")
    sums = {key: sum(float(r["raw"].get(key, 0)) for r in rows) for key in
            ("aoi_sum_s", "aoi_n", "local_sum_m", "local_n", "hold_sum_m", "hold_n",
             "usable_n", "path_n", "fim_sum", "fim_n", "usv_path_m")}
    failed = trials = 0
    for row in rows:
        f, t = hop_counts(row)
        failed += f
        trials += t
    collected = sum(r["collected_packets"] for r in rows)
    duration = sum(r["duration_s"] for r in rows)
    result = dict(episodes=len(rows), survived=sum(r["survived_full_horizon"] for r in rows),
                  packets_per_episode=collected / len(rows),
                  fixed_budget_goodput_bit_s=collected * 2048 / (1200 * len(rows)),
                  pooled_aoi_s=ratio(sums["aoi_sum_s"], sums["aoi_n"]),
                  data_hop_nondelivery=ratio(failed, trials),
                  local_mae_m=ratio(sums["local_sum_m"], sums["local_n"]),
                  usv_cache_mae_m=ratio(sums["hold_sum_m"], sums["hold_n"]),
                  installed_connectivity=ratio(sums["usable_n"], sums["path_n"]),
                  geometry_fim_logdet=ratio(sums["fim_sum"], sums["fim_n"]),
                  usv_path_m=sums["usv_path_m"] / len(rows),
                  total_energy_kj=statistics.fmean(r["metrics_base"]["total_energy_j"] / 1000 for r in rows),
                  topology_requests=statistics.fmean(r["topology_requests"] for r in rows),
                  actual_route_changes=statistics.fmean(r["route_changes"] for r in rows),
                  mean_duration_s=duration / len(rows),
                  raw=dict(**sums, collected_packets=collected, data_failed=failed,
                           data_resolved=trials, budget_s=1200 * len(rows),
                           actual_duration_s=duration))
    if result["data_hop_nondelivery"] is None:
        result["data_note"] = "N/A: zero resolved DATA hop trials; not zero failure"
    return result


def metric(rows, name):
    return aggregate(rows)[name]


def paired_ci(left, right, name, seed):
    lm = {r["seed"]: r for r in left}
    rm = {r["seed"]: r for r in right}
    if set(lm) != set(rm) or not lm:
        raise ValueError("Paired seed mismatch")
    ordered = sorted(lm)
    left = [lm[s] for s in ordered]
    right = [rm[s] for s in ordered]
    point_left, point_right = metric(left, name), metric(right, name)
    if point_left is None or point_right is None:
        return dict(left=point_left, right=point_right, difference=None, ci95=None)
    rng = np.random.default_rng(seed)
    samples = []
    for _ in range(REPETITIONS):
        ids = rng.integers(0, len(left), len(left))
        x = metric([left[i] for i in ids], name)
        y = metric([right[i] for i in ids], name)
        if x is not None and y is not None:
            samples.append(x - y)
    return dict(left=point_left, right=point_right,
                difference=point_left-point_right,
                ci95=[float(np.percentile(samples, 2.5)),
                      float(np.percentile(samples, 97.5))] if samples else None,
                valid_bootstrap=len(samples), bootstrap_repetitions=REPETITIONS)


def read_rows(run):
    plan = json.loads((run / "plan.json").read_text(encoding="utf-8"))
    if plan.get("format") != FORMAT or plan.get("smoke") or plan["jobs"] != [list(x) for x in jobs()]:
        raise ValueError("Wrong formal plan")
    if plan["source_hashes"] != source_hashes() or plan["experiment1_registry"] != verify_package():
        raise ValueError("Source or frozen model registry changed")
    complete = json.loads((run / "complete.json").read_text(encoding="utf-8"))
    if complete != dict(status="completed", count=len(jobs()), plan_sha256=digest(run / "plan.json")):
        raise ValueError("Run completion mismatch")
    rows = []
    for profile, mode, seed in jobs():
        base = run / profile / mode / str(seed)
        candidates = [base] + sorted(base.parent.glob(base.name + "__attempt*"))
        valid = [path for path in candidates if verified_complete(path)]
        if len(valid) != 1:
            raise ValueError(f"Expected one completed episode: {profile}/{mode}/{seed}")
        row = json.loads((valid[0] / "episode.json").read_text(encoding="utf-8"))
        if (row["format"], row["profile"], row["mode"], row["seed"], row["model_step"]) != (
                FORMAT, profile, mode, seed, 450000):
            raise ValueError("Episode identity mismatch")
        if row["policy_method"] != MODEL_FOR[mode] or len(row["metrics75"]) != 75:
            raise ValueError("Model or metric schema mismatch")
        if row["terminated"] == row["truncated"]:
            raise ValueError("Episode must have exactly one completion mode")
        if not math.isclose(row["raw"]["aoi_n"], row["steps"] * 2):
            raise ValueError("AoI AUV-second denominator mismatch")
        if row["raw"]["path_n"] != row["steps"] * 2:
            raise ValueError("Connectivity AUV-second denominator mismatch")
        if row["network"]["logical"]["DATA"]["delivered_unique"] != row["collected_packets"]:
            raise ValueError("DATA and collected packet reconciliation failed")
        rows.append(row)
    return rows, plan


def analyze(run, output):
    run, output = Path(run).resolve(), Path(output).resolve()
    allowed = (ROOT / "reports").resolve()
    if output == allowed or not output.is_relative_to(allowed) or output.exists():
        raise ValueError("Report must be a NEW subdirectory of experiment-5 reports")
    rows, plan = read_rows(run)
    indexed = defaultdict(list)
    for row in rows:
        indexed[(row["profile"], row["mode"])].append(row)
    groups = {p: {m: aggregate(indexed[p, m]) for m in MODES} for p in PROFILES}
    comparisons = {}
    for p_index, profile in enumerate(PROFILES):
        comparisons[profile] = {}
        for i, opponent in enumerate(("mobility_only", "topology_only_fixed_usv",
                                      "sequential_mobility_topology", "sequential_topology_mobility")):
            comparisons[profile][opponent] = {name: paired_ci(
                indexed[profile, "joint_equal_budget"], indexed[profile, opponent], name,
                RANDOM_SEED + p_index * 100 + i * 10 + j)
                for j, name in enumerate(("packets_per_episode", "pooled_aoi_s",
                                          "data_hop_nondelivery", "local_mae_m",
                                          "installed_connectivity", "usv_path_m"))}
    output.mkdir(parents=True)
    write_json(output / "analysis.json", dict(format=FORMAT, rows=len(rows),
               profiles=groups, paired=comparisons, bootstrap_seed=RANDOM_SEED,
               bootstrap_repetitions=REPETITIONS))
    write_json(output / "audit.json", dict(status="passed", unique_jobs=len(rows),
               distinct_keys=len({(r["profile"], r["mode"], r["seed"]) for r in rows}),
               every_episode_sha_verified=True, all_failures_retained=True,
               model_steps=sorted({r["model_step"] for r in rows}),
               policy_sha256={m: next(r["policy_sha256"] for r in rows if r["mode"] == m)
                              for m in MODES}, source_hashes=plan["source_hashes"],
               plan_sha256=digest(run / "plan.json")))
    lines = ["#  :  ", "",
             " : 30  /scenario, 8  , scenario 720 episode; failure. ",
             " ** ** Full V6-C07  ,  ;  . ",
             "DATA non-delivery, outage/ ,   PER. ", ""]
    for profile in PROFILES:
        lines.extend((f"## {profile}", "",
             "|   |  /episode↑ | pooled AoI/s↓ | DATA non-delivery(failure/ )↓ | ratio↑ | local localizationMAE/m↓ | USV MAE/m↓ | USV /m↓ |  FIM logdet↑ | energy/kJ↓ |  /30 |",
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"))
        for mode in MODES:
            g = groups[profile][mode]
            def fmt(value, n=2):
                return "N/A" if value is None else f"{value:.{n}f}"
            lines.append("| " + " | ".join((LABELS[mode], fmt(g["packets_per_episode"]),
                fmt(g["pooled_aoi_s"]),
                f"{fmt(100*g['data_hop_nondelivery'] if g['data_hop_nondelivery'] is not None else None)}% ({g['raw']['data_failed']}/{g['raw']['data_resolved']})",
                fmt(g["installed_connectivity"]), fmt(g["local_mae_m"]),
                fmt(g["usv_cache_mae_m"]), fmt(g["usv_path_m"]),
                fmt(g["geometry_fim_logdet"], 4), fmt(g["total_energy_kj"]),
                str(g["survived"]))) + " |")
        lines.append("")
    lines.extend((" ,   analysis.json. ",
                  "single training seed,   actor  . ",
                  "topology/collection,   USDE; topology USV,  . ", ""))
    (output / "REPORT_ZH.md").write_text("\n".join(lines), encoding="utf-8")
    return len(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(dict(episodes=analyze(args.run, args.output)), ensure_ascii=False))


if __name__ == "__main__":
    main()
