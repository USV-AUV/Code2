"""Evaluation-only slow-clock scheduling; frozen policies and physics are untouched."""
from .protocol import MODES, COMMON_WARMUP_STEPS, scheduled


def make_scheduled_environment(policy, mode):
    if mode not in MODES[:6] or policy.method.method_id != "full_v6":
        raise ValueError("Schedules require the frozen full V6-C07 policy")
    from v6_candidates.c07.environment import TaskV4Env, MethodOptions
    from v6_candidates.c07.routing import RoutingOptions

    class ScheduledEnvironment(TaskV4Env):
        def __init__(self):
            self.experiment5_mode = mode
            self.experiment5_plans = 0
            super().__init__(policy.cfg, policy.method.method_id,
                             MethodOptions(**policy.checkpoint["method_options"]),
                             RoutingOptions(**policy.checkpoint["routing_options"]))

        def reset(self, seed=None):
            result = super().reset(seed)
            self.experiment5_plans = 0
            return result

        def _plan_usv(self):
            tick = self.step_count // self.cfg.slow_period
            allow_plan, _ = scheduled(self.experiment5_mode, tick)
            if allow_plan:
                self.experiment5_plans += 1
                return super()._plan_usv()
            if (self.experiment5_mode == "topology_only_fixed_usv" and
                    self.step_count >= COMMON_WARMUP_STEPS):
                # This mode never runs the USV planner. No teleport or speed edit.
                self.usv_target = self.usv_position.copy()
            # Other modes hold the last legal target, continuing ordinary motion.

    env = ScheduledEnvironment()
    policy.validate_environment(env)
    return env


def topology_decision(policy, env, mode):
    if env.step_count % env.cfg.slow_period:
        return None
    tick = env.step_count // env.cfg.slow_period
    _, allow_topology = scheduled(mode, tick)
    if not allow_topology:
        return None
    if policy.topology is None:
        return None
    return policy.topology_action(*env.slow_state())
