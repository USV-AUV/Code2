"""One-shot formal orchestration; safe to resume incomplete episodes."""
import argparse
import json
from pathlib import Path

from .runner import run
from .analysis import analyze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()
    run_path, report_path = Path(args.run), Path(args.report)
    if not (run_path / "complete.json").exists():
        run(run_path, smoke=False)
    if report_path.exists():
        raise FileExistsError("Report destination exists; preserve it and choose a new directory")
    count = analyze(run_path, report_path)
    print(json.dumps(dict(status="complete", episodes=count, report=str(report_path)), ensure_ascii=False))


if __name__ == "__main__":
    main()
