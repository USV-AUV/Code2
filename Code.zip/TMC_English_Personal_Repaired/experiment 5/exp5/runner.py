"""Resumable immutable-evidence runner for Experiment 5."""
from __future__ import annotations
import argparse
from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import numpy as np

from .protocol import (ROOT, EXP1, EXP3, SOURCE, FORMAT, HORIZON, MODES,
                       PROFILES, SEEDS, MODEL_FOR, jobs, fault_declaration)

sys.dont_write_bytecode = True
for path in (SOURCE, EXP3):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from exp3.runner import digest, verify_package, load, bind
from .schedule import make_scheduled_environment, topology_decision


def write_json(path, obj):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(obj, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def source_hashes():
    paths = sorted((ROOT / "exp5").glob("*.py")) + [ROOT / "PROTOCOL_ZH.md"]
    return {str(path.relative_to(ROOT)): digest(path) for path in paths}


def installed_usable(env):
    """Offline true-geometry diagnostic. Never supplied to a policy."""
    net = env.network
    positions = np.asarray(env._positions_3d(), dtype=float)
    now = float(env.time)

    def edge(a, b):
        return (np.linalg.norm(positions[a] - positions[b]) <= net.max_range and
                not net._is_failed(a, b, now, now + 1e-9))

    result = []
    for source in range(1, env.cfg.n_auv + 1):
        version, node, seen, usable = net.active_version[source], source, set(), True
        while node:
            if node in seen or len(seen) >= env.cfg.n_auv:
                usable = False
                break
            seen.add(node)
            record = net.installed_routes.get(node, {}).get(version)
            if record is None or record[1] < now:
                usable = False
                break
            parent = record[0][node - 1]
            if not edge(node, parent):
                usable = False
                break
            node = parent
        result.append(usable)
    return result


def sample(env, previous_usv, last_collected, calc_fim):
    from usv_auv.planner import usbl_position_fim
    now, cfg = float(env.time), env.cfg
    aoi, hold, local = [], [], []
    for i in range(cfg.n_auv):
        delivery = env.network.received_states.get(i + 1)
        aoi.append(now - delivery.packet.created_at if delivery is not None else now)
        hold.append(float(np.linalg.norm(np.asarray(delivery.packet.payload["position"]) - env.auv_positions[i]))
                    if delivery is not None else None)
        local.append(float(np.linalg.norm(env.nav[i].position - env.auv_positions[i])))
    path = installed_usable(env)
    fim = []
    if calc_fim:
        for i in range(cfg.n_auv):
            information = usbl_position_fim(env.auv_positions[i], env.usv_position,
                                            cfg.auv_depth, cfg.usbl_sigma,
                                            cfg.usbl_bearing_sigma)
            sign, logdet = np.linalg.slogdet(np.eye(2) + information)
            if sign <= 0 or not math.isfinite(logdet):
                raise ValueError("Nonfinite FIM geometry")
            fim.append(float(logdet))
    collected = len(env.collected)
    row = dict(time_s=now, aoi_s=aoi, hold_error_m=hold,
               local_error_m=local, installed_usable=path, fim_logdet=fim,
               collected_increment=collected - last_collected,
               usv_step_m=float(np.linalg.norm(env.usv_position - previous_usv)),
               usv_xy=env.usv_position.tolist(), auv_xy=env.auv_positions.tolist(),
               root_parents=list(env.network.root_parents))
    if any(not math.isfinite(float(x)) for x in aoi + local):
        raise ValueError("Nonfinite observation")
    return row


def episode(policy, env, observer_factory, mode, profile, seed, directory, smoke=False):
    import torch
    from usv_auv.learning import seed_all
    from usv_auv.train import json_safe
    from exp3.measurement import PassiveNetworkObserver
    from scripts.summarize_tmc_retest import selected_specs
    seed_all(seed)
    obs, info = env.reset(seed=seed)
    bind(policy, env)
    if env.cfg.fingerprint != "48caa5c4f5bf9627":
        raise ValueError("Frozen physical configuration changed")
    for fault in fault_declaration(profile):
        env.network.add_fault(**fault)
    environmental = observer_factory(env, info, policy.method)
    network = PassiveNetworkObserver(env.network)
    stats = Counter()
    path_before = env.usv_position.copy()
    count_before = len(env.collected)
    previous_parents = tuple(env.network.root_parents)
    route_changes = 0
    topology_requests = 0
    max_steps = 40 if smoke else HORIZON
    try:
        with gzip.open(directory / "trace.jsonl.gz", "xt", encoding="utf-8") as stream:
            with torch.inference_mode():
                for index in range(max_steps):
                    topo = topology_decision(policy, env, mode)
                    if topo is not None:
                        topology_requests += 1
                    actions = policy.act(obs)
                    obs, reward, terminated, truncated, info = env.step(actions, topology_action=topo)
                    environmental.after_step(info)
                    row = sample(env, path_before, count_before,
                                 env.step_count % env.cfg.slow_period == 0)
                    stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                    stats["aoi_sum_s"] += sum(row["aoi_s"])
                    stats["aoi_n"] += len(row["aoi_s"])
                    stats["local_sum_m"] += sum(row["local_error_m"])
                    stats["local_n"] += len(row["local_error_m"])
                    stats["hold_sum_m"] += sum(x for x in row["hold_error_m"] if x is not None)
                    stats["hold_n"] += sum(x is not None for x in row["hold_error_m"])
                    stats["usable_n"] += sum(row["installed_usable"])
                    stats["path_n"] += len(row["installed_usable"])
                    stats["fim_sum"] += sum(row["fim_logdet"])
                    stats["fim_n"] += len(row["fim_logdet"])
                    stats["usv_path_m"] += row["usv_step_m"]
                    new_parents = tuple(row["root_parents"])
                    route_changes += new_parents != previous_parents
                    previous_parents = new_parents
                    path_before = env.usv_position.copy()
                    count_before = len(env.collected)
                    if terminated or truncated:
                        break
        duration = float(info["time"])
        metrics = json_safe(info["metrics"])
        net = json_safe(network.finalize(duration))
        if not net["core_counter_reconciliation"]["all_observed_counters_match_core"]:
            raise ValueError("Network observer disagrees with core")
        if net["logical"]["DATA"]["delivered_unique"] != len(env.collected):
            raise ValueError("Collected DATA and observer disagree")
        environmental_summary = json_safe(environmental.finalize())
        packet_bits = env.cfg.data_packet_bits
        record = dict(format=FORMAT, profile=profile, mode=mode, seed=seed,
                      policy_method=MODEL_FOR[mode], model_step=450000,
                      policy_sha256=digest(EXP1 / "models" / "45w" / MODEL_FOR[mode] / "policy.pt"),
                      faults=fault_declaration(profile), steps=index + 1, duration_s=duration,
                      terminated=bool(terminated), truncated=bool(truncated),
                      termination_reason=info["termination_reason"],
                      survived_full_horizon=bool(not terminated and index + 1 == HORIZON),
                      collected_packets=metrics["collected_bits"] / packet_bits,
                      ack_packets=metrics["ack_released_bits"] / packet_bits,
                      collection_fraction=metrics["collected_bits"] /
                          (metrics["initial_bits"] + metrics["arrival_bits"]),
                      goodput_bit_s=metrics["collected_bits"] / duration,
                      fixed_budget_goodput_bit_s=metrics["collected_bits"] / HORIZON,
                      metrics_base=metrics, environment=environmental_summary,
                      network={key: value for key, value in net.items() if key not in
                               ("hop_events", "emissions", "generation_events", "delivery_events",
                                "protocol_events", "queue_events")},
                      raw=dict(stats), route_changes=route_changes,
                      topology_requests=topology_requests,
                      usv_plan_decisions=getattr(env, "experiment5_plans", None),
                      formal_experiment=not smoke)
        # Preserve the established 75 metrics where their definition applies.
        full_record = dict(record, network=net)
        record["metrics75"] = {key: dict(label=label, unit=unit, value=getter(full_record))
                               for key, label, unit, _, getter in selected_specs()}
        if len(record["metrics75"]) != 75:
            raise ValueError("The established 75-metric schema changed")
        if mode in MODES[:5]:
            for key, item in record["metrics75"].items():
                if key.startswith("environment.planner_horizon_prediction."):
                    item["value"] = None  # skipped planning ticks are not real forecasts
        with gzip.open(directory / "network_evidence.json.gz", "xt", encoding="utf-8") as stream:
            json.dump(net, stream, ensure_ascii=False, allow_nan=False)
        write_json(directory / "episode.json", json_safe(record))
        write_json(directory / "complete.json", dict(status="completed", sha256={
            p.name: digest(p) for p in directory.iterdir() if p.is_file()}))
        return record
    finally:
        network.detach()


def verified_complete(path):
    marker = path / "complete.json"
    if not marker.is_file():
        return False
    obj = json.loads(marker.read_text(encoding="utf-8"))
    if obj.get("status") != "completed" or set(obj.get("sha256", {})) != {
            "trace.jsonl.gz", "network_evidence.json.gz", "episode.json"}:
        raise ValueError(f"Invalid completion marker: {marker}")
    for name, sha in obj["sha256"].items():
        if digest(path / name) != sha:
            raise ValueError(f"Episode evidence SHA changed: {path / name}")
    return True


def run(output, smoke=False):
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError("Formal evaluation requires CUDA")
    output = Path(output).resolve()
    category = (ROOT / ("verification" if smoke else "runs")).resolve()
    if not output.is_relative_to(category) or output == category:
        raise ValueError("Output must be within the matching experiment-5 directory")
    verified = verify_package()
    hashes = source_hashes()
    plan = dict(format=FORMAT, jobs=[(p, m, 42) for p in PROFILES[:1] for m in MODES]
                if smoke else jobs(), smoke=smoke, source_hashes=hashes,
                experiment1_registry=verified, training_steps=0,
                failure_policy="retain every physical termination; do not filter")
    output.mkdir(parents=True, exist_ok=True)
    plan_path = output / "plan.json"
    if plan_path.exists():
        if json.loads(plan_path.read_text(encoding="utf-8")) != plan:
            raise ValueError("Existing run plan differs; no overwrite")
    else:
        write_json(plan_path, plan)
    progress = output / "progress.jsonl"
    policy = env = observer_factory = loaded = None
    try:
        for profile, mode, seed in plan["jobs"]:
            base = output / profile / mode / str(seed)
            attempts = sorted(base.parent.glob(base.name + "__attempt*")) if base.parent.exists() else []
            choices = [base] + attempts
            completed = [path for path in choices if verified_complete(path)]
            if len(completed) > 1:
                raise ValueError(f"Duplicate completed job: {profile}/{mode}/{seed}")
            if completed:
                continue
            destination = base if not base.exists() else base.parent / (base.name + f"__attempt{len(attempts)+1}")
            if destination.exists():
                raise ValueError("Retry directory collision")
            if loaded != MODEL_FOR[mode]:
                if env is not None:
                    env.close()
                if policy is not None:
                    del policy
                policy, original, observer_factory, checkpoint, path = load(MODEL_FOR[mode], "cuda")
                if mode in MODES[:6]:
                    original.close()
                    env = None
                else:
                    env = original
                loaded = MODEL_FOR[mode]
            if mode in MODES[:6]:
                if env is not None:
                    env.close()
                env = make_scheduled_environment(policy, mode)
            destination.mkdir(parents=True)
            started = time.monotonic()
            record = episode(policy, env, observer_factory, mode, profile, seed, destination, smoke)
            with progress.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(dict(profile=profile, mode=mode, seed=seed,
                                             destination=str(destination.relative_to(output)),
                                             steps=record["steps"], seconds=time.monotonic()-started),
                                        ensure_ascii=False) + "\n")
        if verify_package() != verified or source_hashes() != hashes:
            raise ValueError("Source or frozen asset changed during run")
        write_json(output / "complete.json", dict(status="completed", count=len(plan["jobs"]),
                   plan_sha256=digest(plan_path)))
    finally:
        if env is not None:
            env.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("run", "check"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    if args.command == "run":
        run(args.output, args.smoke)
    else:
        path = Path(args.output)
        plan = json.loads((path / "plan.json").read_text(encoding="utf-8"))
        done = sum(verified_complete(path / p / m / str(s)) or any(
            verified_complete(x) for x in (path / p / m).glob(str(s)+"__attempt*"))
            for p, m, s in plan["jobs"])
        print(json.dumps(dict(done=done, total=len(plan["jobs"]),
                              complete=(path / "complete.json").exists()), ensure_ascii=False))


if __name__ == "__main__":
    main()
