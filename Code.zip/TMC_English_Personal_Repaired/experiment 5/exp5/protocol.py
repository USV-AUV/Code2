"""Predeclared, paired Experiment 5 design. No training is performed."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
EXP1 = PROJECT / "experiment 1"
EXP3 = PROJECT / "experiment 3"
SOURCE = EXP1 / "source"
FORMAT = "experiment5-joint-decision-frozen450k-v1"
SEEDS = tuple(range(9650000, 9650030))
PROFILES = ("reference", "direct1_outage", "direct2_outage")
MODES = (
    "mobility_only", "topology_only_fixed_usv", "sequential_mobility_topology",
    "sequential_topology_mobility", "joint_equal_budget", "joint_native",
    "trained_usde_only", "trained_no_usde",
)
MODEL_FOR = {mode: "full_v6" for mode in MODES[:6]} | {
    "trained_usde_only": "usde_only_v6", "trained_no_usde": "topology_only_v6",
}
HORIZON = 1200
FAULT_START, FAULT_END = 400., 800.
SLOW_TICKS_PER_CYCLE = 2
COMMON_WARMUP_STEPS = 30


def jobs():
    return [(profile, mode, seed) for profile in PROFILES for mode in MODES for seed in SEEDS]


def fault_declaration(profile):
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    if profile == "reference":
        return []
    node = 1 if profile == "direct1_outage" else 2
    return [dict(src=node, dst=0, start=FAULT_START, end=FAULT_END, bidirectional=True)]


def scheduled(mode, tick):
    """Equal-rate two-tick schedule for the five internal comparisons."""
    if tick < 0:
        raise ValueError("Negative slow tick")
    if mode in MODES[:5] and tick < COMMON_WARMUP_STEPS // 5:
        return True, False  # common observed-state warmup, fixed direct topology
    phase = (tick - COMMON_WARMUP_STEPS // 5) % SLOW_TICKS_PER_CYCLE
    return {
        "mobility_only": (phase == 0, False),
        "topology_only_fixed_usv": (False, phase == 0),
        "sequential_mobility_topology": (phase == 0, phase == 1),
        "sequential_topology_mobility": (phase == 1, phase == 0),
        "joint_equal_budget": (phase == 0, phase == 0),
        "joint_native": (True, True),
        "trained_usde_only": (True, False),
        "trained_no_usde": (True, True),
    }[mode]
