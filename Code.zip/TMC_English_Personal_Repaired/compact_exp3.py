"""Memory-bounded recovery of the completed Experiment 3 formal analysis.

The original analyzer and episode evidence remain untouched. Each episode is
fully hash-checked and validated before dropping fields that no downstream
analysis function reads (notably the large per-hop network event ledger).
"""
import json
from pathlib import Path
import release
release.install_paths()

from exp3 import analysis
from exp3.protocol import ROOT, METHODS, PROFILES, SEEDS
from exp3.runner import code_hashes, digest, verify_package


RETAIN = (
    'seed', 'steps', 'duration_s', 'survived_full_horizon',
    'termination_reason', 'collected_packets', 'experiment3', 'metrics75',
)


def compact_load_inputs(inputs):
    groups, paths, fingerprints, schemas, manifests = {}, {}, [], [], []
    for name in inputs:
        source = Path(name).resolve()
        complete = json.loads((source / 'complete.json').read_text(encoding='utf-8'))
        plan = json.loads((source / 'plan.json').read_text(encoding='utf-8'))
        analysis.validate_jobs(plan)
        if (complete.get('status') != 'completed'
                or complete.get('episodes') != len(plan['jobs'])
                or complete.get('formal_experiment') is not True):
            raise ValueError('Incomplete formal run')
        fingerprints.append((plan['code_hashes'], plan['package'], plan['device']))
        manifests.append(dict(directory=str(source), plan_sha256=digest(source / 'plan.json'),
                              complete_sha256=digest(source / 'complete.json')))
        for profile, strategy, seed in plan['jobs']:
            key = profile, strategy, seed
            if key in paths:
                raise ValueError('Duplicate episode across inputs')
            directory = source / profile / strategy / str(seed)
            manifest = json.loads((directory / 'complete.json').read_text(encoding='utf-8'))
            hashes = manifest.get('sha256', {})
            if (manifest.get('status') != 'completed'
                    or not {'episode.json', 'trace.jsonl.gz', 'events.json.gz'} <= set(hashes)):
                raise ValueError('Episode lacks a complete evidence manifest')
            for filename, sha in hashes.items():
                path = (directory / filename).resolve()
                if path.parent != directory.resolve() or digest(path) != sha:
                    raise ValueError('Episode evidence path or checksum mismatch')
            row = json.loads((directory / 'episode.json').read_text(encoding='utf-8'))
            analysis._validate_row(row, key, schemas)
            if row.get('policy_sha256') != plan['package']['policies_sha256'][strategy]:
                raise ValueError('Episode policy SHA disagrees with the frozen package')
            groups.setdefault((profile, strategy), []).append({k: row[k] for k in RETAIN})
            paths[key] = directory
            del row
        print(f'verified {len(plan["jobs"])} episodes: {source.name}', flush=True)
    expected = {(p, m, seed) for p in PROFILES for m in METHODS for seed in SEEDS}
    if set(paths) != expected:
        raise ValueError('Final analysis requires 13 profiles x five systems x 30 seeds')
    if any(f != fingerprints[0] for f in fingerprints):
        raise ValueError('Changed code, frozen package, or inference backend')
    if fingerprints[0][0] != code_hashes() or fingerprints[0][1] != verify_package():
        raise ValueError('Experiment source or frozen assets differ from run provenance')
    return groups, paths, fingerprints[0], manifests


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser(description='Memory-bounded original Experiment 3 statistics for NEW runs')
    parser.add_argument('--input',type=Path,nargs='+',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    release.verify()
    inputs,output=args.input,args.output
    if output.exists():
        raise SystemExit(f'Refusing to overwrite existing analysis: {output}')
    analysis._load_inputs = compact_load_inputs
    print(json.dumps(analysis.analyze_runs(inputs, output), ensure_ascii=False, indent=2))
