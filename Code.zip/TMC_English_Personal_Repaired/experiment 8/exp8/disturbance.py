from copy import deepcopy
import math

from exp2.channel import Channel, channel_patch, uniform
from exp3.currents import attach_current
from .protocol import current_spec


class JointChannel(Channel):
    def erased(self, src, dst, start, finish):
        item = self.spec["erasure"]
        if item is None or not self.spec["onset_s"] <= start < self.spec["clear_s"]:
            return False
        if not self.burst[int(start)]:
            return False
        slot = int(math.floor(start / self.network.slot_duration + 1e-8))
        failed = uniform(self.spec["seed"], "exp8_erasure", slot, src, dst) < item["probability"]
        self.events.append(dict(time_s=start, src=src, dst=dst, slot=slot,
                                probability=item["probability"], erased=failed))
        return failed


def attach(env, spec):
    flow = attach_current(env, current_spec(spec))
    channel = JointChannel(spec, env.network)
    original = env.network.on_transmit_payload
    bias_events = []
    def measured_reply(packet, transmitter, receiver, time, positions):
        payload = original(packet, transmitter, receiver, time, positions)
        if (payload is not None and packet.kind == "LOCALIZATION"
                and transmitter == spec["target"] and receiver == 0 and spec["bias_m"]
                and spec["onset_s"] <= time < spec["clear_s"]):
            payload = deepcopy(payload)
            before = list(payload["position"])
            payload["position"] = [float(x)+spec["bias_m"]*d
                                   for x, d in zip(before, spec["direction_xy"])]
            bias_events.append(dict(time_s=time, node=transmitter, before_xy=before,
                                    after_xy=payload["position"], source_time=payload["source_time"]))
        return payload
    env.network.on_transmit_payload = measured_reply
    return flow, channel, bias_events, original
