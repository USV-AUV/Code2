"""Frozen-policy joint stress and computational performance experiment."""
