import argparse
from pathlib import Path
import subprocess
import sys

def main():
    p=argparse.ArgumentParser();p.add_argument("--run",required=True);p.add_argument("--report",required=True)
    args=p.parse_args()
    # Keep orchestration stdlib-only and release Torch/DLL memory before analysis.
    if not (Path(args.run)/"complete.json").exists():
        print("phase=simulation",flush=True)
        subprocess.run([sys.executable,"-X","utf8","-m","exp8.runner","run","--output",args.run],check=True)
    print("phase=analysis",flush=True)
    subprocess.run([sys.executable,"-X","utf8","-m","exp8.analysis","--run",args.run,"--output",args.report],check=True)
    print("phase=completed",flush=True)

if __name__=="__main__": main()
