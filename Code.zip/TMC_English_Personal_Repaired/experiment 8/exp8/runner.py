"""Frozen-policy CPU evaluation with append-only independent attempts."""
from __future__ import annotations
import argparse
from collections import Counter
import gc
import gzip
import json
from pathlib import Path
import platform
import sys
import time
import numpy as np
from .protocol import ROOT, PROJECT, EXP1, EXP2, EXP3, EXP5, FORMAT, METHODS, PROFILES, HORIZON, jobs, scenario
sys.dont_write_bytecode = True
for path in (EXP1 / "source", EXP2, EXP3, EXP5):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))
from exp3.runner import digest, verify_package, load, bind, routing_decision
from exp5.runner import sample, verified_complete
from .disturbance import attach, channel_patch
from .runtime import Timing, memory


def write_json(path, obj):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(obj, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def source_hashes():
    paths = list((ROOT / "exp8").glob("*.py")) + list((ROOT / "tests").glob("*.py"))
    paths += list((ROOT / "commands").glob("*.ps1"))
    paths += [ROOT / n for n in ("PROTOCOL_EN.md", "README.md")]
    for directory, module in ((EXP2, "exp2"), (EXP3, "exp3"), (EXP5, "exp5")):
        paths += list((directory / module).glob("*.py"))
    return {str(p.relative_to(PROJECT)): digest(p) for p in sorted(paths)}


def episode(policy, env, factory, method, profile, seed, directory, synthetic=False, max_steps=None, spec_override=None):
    import torch
    from usv_auv.learning import seed_all
    from usv_auv.train import json_safe
    from exp3.measurement import PassiveNetworkObserver
    from scripts.summarize_tmc_retest import selected_specs
    started = time.monotonic()
    seed_all(seed)
    obs, info = env.reset(seed=seed)
    bind(policy, env)
    config = env.cfg.to_dict()
    if env.cfg.fingerprint != "48caa5c4f5bf9627":
        raise ValueError("Physical base configuration changed")
    if spec_override is not None and not synthetic:
        raise ValueError("Formal declarations cannot be overridden")
    spec = spec_override or scenario(profile, seed, synthetic)
    flow, channel, bias_events, original_payload = attach(env, spec)
    # Patch before observer binding: fixed-star observers otherwise retain the
    # original bound transmit method and bypass the external erasure overlay.
    patch_context = channel_patch()
    patch_context.__enter__()
    environmental = factory(env, info, policy.method)
    network = PassiveNetworkObserver(env.network)
    timing = Timing(env)
    baseline_memory = memory()
    peak_memory = dict(baseline_memory)
    stats = Counter()
    previous_usv, previous_count = env.usv_position.copy(), len(env.collected)
    previous_parents = tuple(env.network.root_parents)
    route_changes = requests = 0
    lost_information = False
    recovery_streak = 0
    recovery = None
    recovery_risk_observed = False
    counts = {"onset": None, "clear": None}
    try:
        with gzip.open(directory / "trace.jsonl.gz", "xt", encoding="utf-8") as stream:
            with torch.inference_mode():
                for index in range(max_steps or HORIZON):
                    timing_before = {k:len(v) for k,v in timing.values.items()}
                    start_ns = time.perf_counter_ns()
                    if policy.topology is not None and env.step_count % env.cfg.slow_period == 0:
                        topo = timing.measure("topology", routing_decision, method, policy, env)
                    else:
                        topo = routing_decision(method, policy, env)
                    requests += topo is not None
                    actions = timing.measure("follower", policy.act, obs)
                    obs, reward, terminated, truncated, info = env.step(actions, topology_action=topo)
                    timing.values["end_to_end"].append((time.perf_counter_ns()-start_ns)/1e6)
                    environmental.after_step(info)
                    row = sample(env, previous_usv, previous_count, env.step_count % env.cfg.slow_period == 0)
                    now = row["time_s"]
                    available = [env.network.received_states.get(i+1) is not None and age <= 60.
                                 for i, age in enumerate(row["aoi_s"])]
                    phase = "before" if now <= spec["onset_s"] else "during" if now <= spec["clear_s"] else "after"
                    row.update(actions=actions.tolist(), topology_request=topo, phase=phase,
                               information_available=available, terminated=bool(terminated),
                               truncated=bool(truncated), termination_reason=info["termination_reason"],
                               timing_ms={k: v[-1] if len(v)>timing_before[k] else None for k,v in timing.values.items()})
                    stream.write(json.dumps(json_safe(row), ensure_ascii=False, allow_nan=False)+"\n")
                    for prefix in ("", phase+"_"):
                        stats[prefix+"aoi_sum_s"] += sum(row["aoi_s"])
                        stats[prefix+"aoi_n"] += len(row["aoi_s"])
                        stats[prefix+"usable_n"] += sum(row["installed_usable"])
                        stats[prefix+"path_n"] += len(row["installed_usable"])
                        stats[prefix+"available_n"] += sum(available)
                        stats[prefix+"information_n"] += len(available)
                        stats[prefix+"collected_increment"] += row["collected_increment"]
                    stats["local_sum_m"] += sum(row["local_error_m"])
                    stats["local_n"] += len(row["local_error_m"])
                    stats["hold_sum_m"] += sum(x for x in row["hold_error_m"] if x is not None)
                    stats["hold_n"] += sum(x is not None for x in row["hold_error_m"])
                    stats["fim_sum"] += sum(row["fim_logdet"])
                    stats["fim_n"] += len(row["fim_logdet"])
                    stats["usv_path_m"] += row["usv_step_m"]
                    if phase == "during" and not all(available):
                        lost_information = True
                    if phase == "after" and lost_information and recovery is None:
                        recovery_risk_observed = True
                        recovery_streak = recovery_streak+1 if all(available) else 0
                        if recovery_streak >= 30:
                            recovery = now-spec["clear_s"]
                    if now == spec["onset_s"]:
                        counts["onset"] = len(env.collected)
                    if now == spec["clear_s"]:
                        counts["clear"] = len(env.collected)
                    parents = tuple(row["root_parents"])
                    route_changes += parents != previous_parents
                    previous_parents = parents
                    previous_usv, previous_count = env.usv_position.copy(), len(env.collected)
                    if index % 10 == 0:
                        current_memory = memory()
                        peak_memory = {k: max(peak_memory[k], current_memory[k]) for k in peak_memory}
                    if terminated or truncated:
                        break
        duration = float(info["time"])
        metrics = json_safe(info["metrics"])
        net = json_safe(network.finalize(duration))
        if not net["core_counter_reconciliation"]["all_observed_counters_match_core"]:
            raise ValueError("Network counters disagree")
        if net["logical"]["DATA"]["delivered_unique"] != len(env.collected):
            raise ValueError("Logical DATA collection mismatch")
        if env.cfg.to_dict() != config:
            raise ValueError("Base physics mutated")
        record = dict(format=FORMAT, profile=profile, mode=method, policy_method=method, seed=seed,
            model_step=450000, policy_sha256=digest(EXP1/"models"/"45w"/method/"policy.pt"),
            scenario=spec, steps=index+1, duration_s=duration, terminated=bool(terminated),
            truncated=bool(truncated), termination_reason=info["termination_reason"],
            survived_full_horizon=not terminated and index+1 == HORIZON,
            collected_packets=metrics["collected_bits"]/env.cfg.data_packet_bits,
            ack_packets=metrics["ack_released_bits"]/env.cfg.data_packet_bits,
            collection_fraction=metrics["collected_bits"]/(metrics["initial_bits"]+metrics["arrival_bits"]),
            goodput_bit_s=metrics["collected_bits"]/duration,
            fixed_budget_goodput_bit_s=metrics["collected_bits"]/HORIZON,
            metrics_base=metrics, environment=json_safe(environmental.finalize()),
            network={k:v for k,v in net.items() if k not in ("hop_events", "emissions", "generation_events",
                "delivery_events", "protocol_events", "queue_events")},
            raw=dict(stats), route_changes=route_changes, topology_requests=requests,
            event_planned_auv_seconds=2*(spec["clear_s"]-spec["onset_s"]),
            event_exposure_s=max(0.,min(duration,spec["clear_s"])-spec["onset_s"]),
            recovery=dict(information_lost=lost_information, risk_observed=recovery_risk_observed,
                recovered=recovery is not None, time_s=recovery, right_censored=lost_information and recovery is None,
                censor_time_s=max(0.,duration-spec["clear_s"]), counts=counts),
            runtime=timing.finalize(), runtime_samples_ms=timing.values,
            memory=dict(baseline=baseline_memory, peak=peak_memory,
                        increase={k:peak_memory[k]-baseline_memory[k] for k in peak_memory}),
            disturbance_evidence=dict(extra_erasure_trials=channel.events, biased_emissions=bias_events),
            wall_time_s=time.monotonic()-started, formal_experiment=not synthetic)
        full_record = dict(record, network=net)
        record["metrics75"] = {k:dict(label=label,unit=unit,value=getter(full_record))
            for k,label,unit,_,getter in selected_specs()}
        if not record["environment"]["planner_horizon_prediction"].get("applicable", True):
            for k,v in record["metrics75"].items():
                if k.startswith("environment.planner_horizon_prediction."):
                    v["value"] = None
        if len(record["metrics75"]) != 75:
            raise ValueError("75-metric schema changed")
        with gzip.open(directory/"network_evidence.json.gz", "xt", encoding="utf-8") as stream:
            json.dump(net, stream, ensure_ascii=False, allow_nan=False)
        write_json(directory/"episode.json", json_safe(record))
        write_json(directory/"complete.json", dict(status="completed",sha256={
            p.name:digest(p) for p in directory.iterdir() if p.is_file()}))
        return record
    finally:
        timing.detach()
        network.detach()
        env.network.on_transmit_payload = original_payload
        patch_context.__exit__(None, None, None)


def run(output, smoke=False):
    import torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    output = Path(output).resolve()
    allowed = (ROOT/("verification" if smoke else "runs")).resolve()
    if output == allowed or not output.is_relative_to(allowed):
        raise ValueError("Invalid output scope")
    registry, hashes = verify_package(), source_hashes()
    plan = dict(format=FORMAT, jobs=[(p,m,42) for p in PROFILES for m in METHODS] if smoke else jobs(),
        smoke=smoke, source_hashes=hashes, experiment1_registry=registry, training_steps=0,
        device="cpu", torch_threads=1, scenario_grid=[scenario(p,42 if smoke else 9690000,smoke) for p in PROFILES])
    output.mkdir(parents=True,exist_ok=True)
    if (output/"plan.json").exists():
        if json.loads((output/"plan.json").read_text(encoding="utf-8")) != json.loads(json.dumps(plan)):
            raise ValueError("Plan mismatch; no overwrite")
    else:
        write_json(output/"plan.json",plan)
        write_json(output/"hardware.json",dict(platform=platform.platform(),processor=platform.processor(),
            torch=torch.__version__,device="cpu",torch_threads=1, initial_memory=memory(),
            cuda_probe="Allocation/forward probe failed with torch.OutOfMemoryError; all five use CPU"))
    policy = env = loaded = None
    try:
        for profile, method, seed in plan["jobs"]:
            base = output/profile/method/str(seed)
            attempts = sorted(base.parent.glob(base.name+"__attempt*")) if base.parent.exists() else []
            completed = [p for p in [base]+attempts if verified_complete(p)]
            if len(completed)>1:
                raise ValueError("Duplicate completed job")
            if completed:
                continue
            destination = base if not base.exists() else base.parent/(base.name+f"__attempt{len(attempts)+1}")
            if destination.exists():
                raise ValueError("Attempt collision")
            if loaded != method:
                if env is not None:
                    env.close()
                policy = env = None
                gc.collect()
                policy,env,factory,checkpoint,path = load(method,"cpu")
                loaded=method
                del checkpoint
            destination.mkdir(parents=True)
            started=time.monotonic()
            row=episode(policy,env,factory,method,profile,seed,destination,smoke,120 if smoke else None)
            item=dict(profile=profile,method=method,seed=seed,destination=str(destination.relative_to(output)),
                      steps=row["steps"],survived=row["survived_full_horizon"],seconds=time.monotonic()-started)
            with (output/"progress.jsonl").open("a",encoding="utf-8") as stream:
                stream.write(json.dumps(item,ensure_ascii=False)+"\n")
            print(json.dumps(item,ensure_ascii=False),flush=True)
        if registry != verify_package() or hashes != source_hashes():
            raise ValueError("Source or asset changed")
        if not (output/"complete.json").exists():
            write_json(output/"complete.json",dict(status="completed",count=len(plan["jobs"]),plan_sha256=digest(output/"plan.json")))
    finally:
        if env is not None:
            env.close()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("run","check"))
    parser.add_argument("--output",required=True)
    parser.add_argument("--smoke",action="store_true")
    args=parser.parse_args()
    if args.command=="run":
        run(args.output,args.smoke)
    else:
        output=Path(args.output)
        progress=(output/"progress.jsonl").read_text(encoding="utf-8").splitlines() if (output/"progress.jsonl").exists() else []
        print(json.dumps(dict(completed_records=len(progress),last=json.loads(progress[-1]) if progress else None,
                             complete=(output/"complete.json").exists()),ensure_ascii=False))

if __name__=="__main__":
    main()
