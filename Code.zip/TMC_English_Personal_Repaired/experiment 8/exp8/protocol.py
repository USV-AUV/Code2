from pathlib import Path
import math

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
EXP1, EXP2, EXP3, EXP5 = (PROJECT / f"experiment {n}" for n in (1, 2, 3, 5))
METHODS = ("full_v6", "usde_only_v6", "topology_only_v6",
           "synchronous_fim_rl", "communication_aware_tmc")
FORMAT = "experiment8-five-system-joint-stress-v1"
SEEDS = tuple(range(9690000, 9690030))
HORIZON, ONSET, CLEAR, HARD_START = 1200, 400., 800., 500.
COMPONENTS = ("current", "burst", "multi_link", "bias", "radio")
# peak added current m/s, bad-state erasure probability, localization bias m,
# target direct-link outage s, other direct-link outage s, radio outage s
LEVELS = {
    "weak": (.10, .25, 2., 20., 5., 5.),
    "moderate": (.25, .50, 5., 50., 10., 15.),
    "severe": (.50, .70, 10., 100., 20., 40.),
    "extreme": (.80, .90, 20., 200., 40., 80.),
}
PROFILES = ("reference",) + tuple("joint_" + x for x in LEVELS) + tuple(
    "only_" + x for x in COMPONENTS)


def scenario(profile, seed, synthetic=False):
    if profile not in PROFILES or (not synthetic and seed not in SEEDS):
        raise ValueError("Unregistered scenario or seed")
    index = (seed - SEEDS[0]) % 30 if not synthetic else seed % 30
    target = 1 + index % 2
    angle = 2. * math.pi * index / 30.
    active = () if profile == "reference" else (
        COMPONENTS if profile.startswith("joint_") else (profile[5:],))
    level = profile[6:] if profile.startswith("joint_") else "moderate"
    speed, probability, bias, d1, d2, radio = LEVELS[level]
    start, clear, hard = (20., 100., 40.) if synthetic else (ONSET, CLEAR, HARD_START)
    result = dict(format=FORMAT, profile=profile, seed=int(seed), target=target,
                  level="none" if not active else level, components=list(active),
                  onset_s=start, clear_s=clear, direction_xy=[math.cos(angle), math.sin(angle)],
                  current_peak_mps=speed if "current" in active else 0.,
                  bias_m=bias if "bias" in active else 0.,
                  erasure=dict(kind="burst", probability=probability,
                               scope="all_acoustic_directed_links") if "burst" in active else None,
                  hard_events=[], snr_drop_db=0., snr_region_xy=[100., 100.], snr_radius_m=55.,
                  formal_experiment=not synthetic)
    def add(src, dst, duration):
        duration = min(duration, 20.) if synthetic else duration
        result["hard_events"].append(dict(src=src, dst=dst, start=hard,
                                          end=hard+duration, bidirectional=True))
    if "multi_link" in active:
        add(0, target, d1)
        add(0, 3-target, d2)
    if "radio" in active:
        for node in range(33):
            if node != target:
                add(target, node, radio)
    result["hard_start_s"] = hard
    return result


def current_spec(spec):
    return dict(format="experiment3-current-five-systems-v1", seed=spec["seed"],
                kind="time_varying" if spec["current_peak_mps"] else "reference",
                amplitude_mps=spec["current_peak_mps"], direction_xy=spec["direction_xy"],
                onset_s=spec["onset_s"], clear_s=spec["clear_s"], ramp_s=5.,
                period_s=60., correlation_s=20., knot_s=1.)


def jobs():
    return [(p, m, s) for p in PROFILES for m in METHODS for s in SEEDS]
