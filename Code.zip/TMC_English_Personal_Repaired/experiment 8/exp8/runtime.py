"""Passive Windows memory and wall-clock instrumentation, stdlib only."""
import ctypes
import os
import time
import numpy as np


class ProcessMemory(ctypes.Structure):
    _fields_ = [("cb", ctypes.c_ulong), ("PageFaultCount", ctypes.c_ulong)] + [
        (name, ctypes.c_size_t) for name in ("PeakWorkingSetSize", "WorkingSetSize",
        "QuotaPeakPagedPoolUsage", "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
        "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage", "PrivateUsage")]


def memory():
    if os.name != "nt":
        raise RuntimeError("This registered measurement uses Windows process counters")
    value = ProcessMemory()
    value.cb = ctypes.sizeof(value)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong]
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(value), value.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return dict(rss_bytes=int(value.WorkingSetSize), private_bytes=int(value.PrivateUsage))


def summary(values, deadline_ms, warmup=0):
    steady = values[min(warmup, len(values)):]
    if not steady:
        return dict(calls=len(values), steady_calls=0, warmup_discarded=len(values),
                    deadline_ms=deadline_ms, mean_ms=None, p50_ms=None, p95_ms=None,
                    p99_ms=None, max_ms=None, misses=None)
    return dict(calls=len(values), steady_calls=len(steady),
                warmup_discarded=len(values)-len(steady), deadline_ms=deadline_ms,
                mean_ms=float(np.mean(steady)), p50_ms=float(np.percentile(steady,50)),
                p95_ms=float(np.percentile(steady,95)), p99_ms=float(np.percentile(steady,99)),
                max_ms=float(max(steady)), misses=sum(v > deadline_ms for v in steady))


class Timing:
    def __init__(self, env):
        self.env = env
        self.values = {k: [] for k in ("follower", "topology", "leader", "end_to_end")}
        self.original = env._plan_usv
        def plan():
            return self.measure("leader", self.original)
        env._plan_usv = plan

    def measure(self, kind, function, *args, **kwargs):
        start = time.perf_counter_ns()
        result = function(*args, **kwargs)
        self.values[kind].append((time.perf_counter_ns()-start)/1e6)
        return result

    def finalize(self):
        fast = self.env.cfg.dt*1000.
        leader_period = (self.env.cfg.dt if getattr(self.env.method, "planner_kind", None) == "synchronous_fim"
                         else self.env.cfg.dt*self.env.cfg.slow_period)
        return dict(follower=summary(self.values["follower"], fast, 20),
                    topology=summary(self.values["topology"], fast*self.env.cfg.slow_period, 5),
                    leader=summary(self.values["leader"], leader_period*1000., 5),
                    end_to_end=summary(self.values["end_to_end"], fast, 20))

    def detach(self):
        self.env._plan_usv = self.original
