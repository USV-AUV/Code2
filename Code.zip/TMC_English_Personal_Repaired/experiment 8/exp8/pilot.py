"""Nonformal full-duration accounting and short seeded burst integration checks."""
import argparse
import gc
import json
from pathlib import Path
import torch
from .protocol import ROOT, METHODS, scenario
from .runner import load, episode, write_json, verify_package
from .analysis import group

def main():
    p=argparse.ArgumentParser();p.add_argument("--output",required=True);a=p.parse_args()
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    output=Path(a.output).resolve()
    if not output.is_relative_to(ROOT/"verification") or output.exists(): raise ValueError("New verification output required")
    output.mkdir(parents=True);registry=verify_package();results=[]
    for method in METHODS:
        policy,env,factory,checkpoint,path=load(method,"cpu")
        try:
            for profile,short in (("reference",False),("joint_extreme",False),("only_burst",True)):
                spec=scenario(profile,47,True)
                if not short:
                    spec.update(onset_s=400.,clear_s=800.,hard_start_s=500.)
                    formal_shape=scenario(profile,9690017)
                    spec["hard_events"]=formal_shape["hard_events"]
                directory=output/profile/method/"47";directory.mkdir(parents=True)
                r=episode(policy,env,factory,method,profile,47,directory,True,120 if short else None,spec)
                g=group([r])
                erased=sum(x["erased"] for x in r["disturbance_evidence"]["extra_erasure_trials"])
                if short and not erased: raise ValueError("Real burst branch was not exercised")
                item=dict(method=method,profile=profile,steps=r["steps"],seconds=r["wall_time_s"],
                    physical_reason=r["termination_reason"],extra_erased=erased,
                    biased_emissions=len(r["disturbance_evidence"]["biased_emissions"]),metrics75=len(g["metrics75"]),
                    planned_information=g["event_information_planned"],raw_data=g["raw"]["data_hop_nondelivery"])
                results.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
        finally:
            env.close()
        del policy,env,checkpoint
        gc.collect()
    write_json(output/"pilot_summary.json",dict(status="passed",formal_experiment=False,training_steps=0,
        experiment1_registry=registry,results=results))

if __name__=="__main__":main()
