"""Streaming validation and sufficient-statistic paired bootstrap."""
from collections import defaultdict, Counter
import argparse
import json
import math
from pathlib import Path
import numpy as np
from .protocol import ROOT, FORMAT, PROFILES, METHODS, jobs, scenario
from .runner import source_hashes, verify_package, digest, verified_complete, write_json
from exp5.analysis import aggregate as base_aggregate
from .runtime import summary

LABELS={"full_v6":"Full V6-C07","usde_only_v6":"USDE-only","topology_only_v6":"Topology-only (coordination without USDE)",
        "synchronous_fim_rl":"FIM+RL","communication_aware_tmc":"CA-TMC"}
REPETITIONS=2000
BOOTSTRAP_SEED=1102026
METRICS=("packets_per_episode","pooled_aoi_s","data_hop_nondelivery","installed_connectivity",
         "local_mae_m","event_information_planned","survival_fraction","control_bits_per_episode")

def ratio(n,d):
    return n/d if d else None

def sufficient(row,name):
    raw=row["raw"]
    if name=="packets_per_episode": return row["collected_packets"],1
    if name=="survival_fraction": return int(row["survived_full_horizon"]),1
    if name=="control_bits_per_episode": return row["network"]["control_plane"]["transmitted_frame_bits"],1
    if name=="data_hop_nondelivery":
        w=row["network"]["by_kind"].get("DATA",{}).get("hop_delivery",{}).get("completion_window",{})
        return w.get("resolved_failures",0),w.get("resolved_trials",0)
    keys={"pooled_aoi_s":("aoi_sum_s","aoi_n"),"installed_connectivity":("usable_n","path_n"),
          "local_mae_m":("local_sum_m","local_n"),"event_information_planned":("during_available_n",None)}
    n,d=keys[name]
    return raw.get(n,0),row["event_planned_auv_seconds"] if d is None else raw.get(d,0)

def paired(left,right,name,seed):
    left=sorted(left,key=lambda x:x["seed"]);right=sorted(right,key=lambda x:x["seed"])
    if [r["seed"] for r in left] != [r["seed"] for r in right]: raise ValueError("Unpaired seeds")
    a=np.asarray([sufficient(r,name) for r in left],dtype=float)
    b=np.asarray([sufficient(r,name) for r in right],dtype=float)
    point_a=ratio(*a.sum(axis=0));point_b=ratio(*b.sum(axis=0))
    if point_a is None or point_b is None:
        return dict(left=point_a,right=point_b,difference=None,ci95=None)
    ids=np.random.default_rng(seed).integers(0,len(left),(REPETITIONS,len(left)))
    aa=a[ids].sum(axis=1);bb=b[ids].sum(axis=1)
    valid=(aa[:,1]>0)&(bb[:,1]>0)
    delta=aa[valid,0]/aa[valid,1]-bb[valid,0]/bb[valid,1]
    return dict(left=point_a,right=point_b,difference=point_a-point_b,
                ci95=np.percentile(delta,[2.5,97.5]).tolist() if len(delta) else None,
                valid_bootstrap=len(delta),bootstrap_repetitions=REPETITIONS)

def group(rows):
    result=base_aggregate(rows)
    for name in METRICS:
        pairs=[sufficient(r,name) for r in rows]
        n=sum(p[0] for p in pairs);d=sum(p[1] for p in pairs)
        result[name]=ratio(n,d)
        result["raw"][name]=dict(numerator=n,denominator=d)
    result["event_information_actual"]=ratio(sum(r["raw"].get("during_available_n",0) for r in rows),
                                                   sum(r["raw"].get("during_information_n",0) for r in rows))
    result["event_exposure_mean_s"]=np.mean([r["event_exposure_s"] for r in rows]).item()
    result["termination_reasons"]=dict(Counter(r["termination_reason"] for r in rows))
    result["phases"]={p:dict(aoi_s=ratio(sum(r["raw"].get(p+"_aoi_sum_s",0) for r in rows),
                                          sum(r["raw"].get(p+"_aoi_n",0) for r in rows)),
                               aoi_denominator=sum(r["raw"].get(p+"_aoi_n",0) for r in rows),
                               packets=sum(r["raw"].get(p+"_collected_increment",0) for r in rows)/len(rows))
                       for p in ("before","during","after")}
    cp=[r["network"]["control_plane"] for r in rows]
    result["control_airtime_s_per_episode"]=sum(r["airtime_s"] for r in cp)/len(rows)
    result["control_airtime_fraction_actual"]=ratio(sum(r["airtime_s"] for r in cp),sum(r["duration_s"] for r in rows))
    recoveries=[r["recovery"] for r in rows]
    result["recovery"]=dict(episodes_information_lost=sum(r["information_lost"] for r in recoveries),
        recovered=sum(r["recovered"] for r in recoveries),right_censored=sum(r["right_censored"] for r in recoveries),
        recovered_only_mean_s=float(np.mean([r["time_s"] for r in recoveries if r["recovered"]])) if any(r["recovered"] for r in recoveries) else None,
        censor_before_clear=sum(r["right_censored"] and not r["risk_observed"] for r in recoveries),
        note="Statistical interpretation note30Statistical interpretation note; successful time")
    timings={}
    for kind,warmup in (("follower",20),("topology",5),("leader",5),("end_to_end",20)):
        values=[x for r in rows for x in r["runtime_samples_ms"][kind][warmup:]]
        deadline=rows[0]["runtime"][kind]["deadline_ms"]
        timings[kind]=summary(values,deadline)
    result["runtime"]=timings
    result["memory_peak_rss_mib"]=max(r["memory"]["peak"]["rss_bytes"] for r in rows)/2**20
    result["memory_peak_private_mib"]=max(r["memory"]["peak"]["private_bytes"] for r in rows)/2**20
    result["memory_max_episode_increase_mib"]=max(r["memory"]["increase"]["rss_bytes"] for r in rows)/2**20
    result["metrics75"]={}
    for key,item in rows[0]["metrics75"].items():
        values=[r["metrics75"][key]["value"] for r in rows if r["metrics75"][key]["value"] is not None]
        result["metrics75"][key]=dict(label=item["label"],unit=item["unit"],valid_episodes=len(values),
            missing_episodes=len(rows)-len(values),mean=float(np.mean(values)) if values else None,
            sd=float(np.std(values,ddof=1)) if len(values)>1 else None)
    return result

def read_rows(run):
    plan=json.loads((run/"plan.json").read_text(encoding="utf-8"))
    if plan["format"]!=FORMAT or plan["smoke"] or plan["jobs"]!=[list(x) for x in jobs()]: raise ValueError("Wrong plan")
    if plan["source_hashes"]!=source_hashes() or plan["experiment1_registry"]!=verify_package(): raise ValueError("Frozen source/asset changed")
    if json.loads((run/"complete.json").read_text(encoding="utf-8"))!=dict(status="completed",count=len(jobs()),plan_sha256=digest(run/"plan.json")):
        raise ValueError("Run incomplete")
    rows=[]
    for i,(p,m,s) in enumerate(jobs()):
        base=run/p/m/str(s)
        valid=[path for path in [base]+sorted(base.parent.glob(base.name+"__attempt*")) if verified_complete(path)]
        if len(valid)!=1: raise ValueError("Duplicate/missing completed episode")
        row=json.loads((valid[0]/"episode.json").read_text(encoding="utf-8"))
        if (row["format"],row["profile"],row["mode"],row["seed"],row["model_step"])!=(FORMAT,p,m,s,450000): raise ValueError("Identity mismatch")
        if row["policy_sha256"]!=plan["experiment1_registry"]["policies_sha256"][m] or row["scenario"]!=scenario(p,s): raise ValueError("Policy/scenario mismatch")
        if len(row["metrics75"])!=75 or row["terminated"]==row["truncated"] or row["raw"]["aoi_n"]!=2*row["steps"] or row["raw"]["path_n"]!=2*row["steps"]:
            raise ValueError("Metric denominator/termination invalid")
        if row["network"]["logical"]["DATA"]["delivered_unique"]!=row["collected_packets"]: raise ValueError("DATA mismatch")
        if row["raw"].get("during_information_n",0)!=2*row["event_exposure_s"]: raise ValueError("Exposure mismatch")
        row["network"]={k:row["network"][k] for k in ("by_kind","control_plane")}
        row.pop("disturbance_evidence")
        row.pop("environment")
        rows.append(row)
        if (i+1)%100==0: print(f"SHA/identity/denominators verified {i+1}/{len(jobs())}",flush=True)
    return rows,plan

def fmt(x,d=2): return "N/A" if x is None else f"{x:.{d}f}"

def analyze(run,output):
    run,output=Path(run).resolve(),Path(output).resolve()
    if not output.is_relative_to(ROOT/"reports") or output==ROOT/"reports" or output.exists(): raise ValueError("Use new report directory")
    rows,plan=read_rows(run)
    indexed=defaultdict(list)
    for row in rows: indexed[row["profile"],row["mode"]].append(row)
    groups={p:{m:group(indexed[p,m]) for m in METHODS} for p in PROFILES}
    paired_results={};degradation={};thresholds={}
    for pi,p in enumerate(PROFILES):
        paired_results[p]={m:{metric:paired(indexed[p,"full_v6"],indexed[p,m],metric,BOOTSTRAP_SEED+pi*1000+mi*20+k)
            for k,metric in enumerate(METRICS)} for mi,m in enumerate(METHODS[1:])}
        if p.startswith("joint_"):
            degradation[p]={m:{metric:paired(indexed[p,m],indexed["reference",m],metric,BOOTSTRAP_SEED+20000+pi*100+mi*10+k)
                for k,metric in enumerate(METRICS)} for mi,m in enumerate(METHODS)}
    for m in METHODS:
        levels=[]
        for p in PROFILES[1:5]:
            g=groups[p][m];ref=groups["reference"][m]
            retention=ratio(g["packets_per_episode"],ref["packets_per_episode"])
            fail=g["survival_fraction"]<.8 or retention is None or retention<.7 or g["event_information_planned"]<.8
            levels.append(dict(profile=p,survival=g["survival_fraction"],packet_retention=retention,
                               planned_event_information=g["event_information_planned"],engineering_screen_failed=fail))
        thresholds[m]=dict(grid=levels,first_failed_level=next((x["profile"] for x in levels if x["engineering_screen_failed"]),None),
                           reference_survived=groups["reference"][m]["survived"],note="Statistical interpretation note, Statistical interpretation note, Statistical interpretation note, Statistical interpretation note")
    output.mkdir(parents=True)
    write_json(output/"analysis.json",dict(format=FORMAT,unique_episodes=len(rows),profiles=groups,
        full_minus_comparator=paired_results,level_minus_reference=degradation,engineering_thresholds=thresholds,
        bootstrap_repetitions=REPETITIONS,bootstrap_seed=BOOTSTRAP_SEED,device="cpu"))
    write_json(output/"audit.json",dict(status="passed",unique_jobs=len(rows),distinct_keys=len({(r["profile"],r["mode"],r["seed"]) for r in rows}),
        every_episode_sha_verified=True,all_failures_retained=True,training_steps=0,model_step=450000,
        policy_sha256=plan["experiment1_registry"]["policies_sha256"],source_hashes=plan["source_hashes"],plan_sha256=digest(run/"plan.json"),
        denominator_checks="actual AoI/path AUV-seconds; event exposure; planned 800 AUV-seconds; DATA unique/75 schema"))
    lines=["#  :  CPU ","","1500episode,  45 , 10scenario×30 , failure all. ",
        "topologyC07collection,  USDE;  baselinesystem,  . single training seed across training seedsseed . ",
        "DATAnon-delivery outage/ ,  PER;  . node , physical. ",
        "window800 AUV ,  ;  AoI . ",""]
    all75=["#  75 metric","","episode±standard deviation;  pooled analysis.json , N/A 0. ",""]
    for p in PROFILES:
        lines += [f"## {p}","","| method |  /episode | AoI/s | DATAnon-delivery/% |  /% | local error/m | window/% | energy/kJ |  /30 |",
                  "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for m in METHODS:
            g=groups[p][m]
            lines.append("| "+" | ".join((LABELS[m],fmt(g["packets_per_episode"]),fmt(g["pooled_aoi_s"]),
                fmt(100*g["data_hop_nondelivery"]) if g["data_hop_nondelivery"] is not None else "N/A",
                fmt(100*g["installed_connectivity"]),fmt(g["local_mae_m"]),fmt(100*g["event_information_planned"]),fmt(g["total_energy_kj"]),str(g["survived"])))+" |")
        lines += ["","| method | follower P95/ms | topology P95/ms | leader P95/ms | completeP95/ms | completeP99/ms |  1s /  |  /MiB |  bit/episode |  airtime/s |",
                  "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for m in METHODS:
            g=groups[p][m];t=g["runtime"]
            lines.append("| "+" | ".join([LABELS[m]]+[fmt(t[k]["p95_ms"],3) for k in ("follower","topology","leader","end_to_end")]+[
                fmt(t["end_to_end"]["p99_ms"],3),f"{t['end_to_end']['misses']}/{t['end_to_end']['steady_calls']}",fmt(g["memory_peak_private_mib"]),fmt(g["control_bits_per_episode"]),fmt(g["control_airtime_s_per_episode"])])+" |")
        lines += ["","| method |  /s | episode |  /  | successful acknowledged/s |   |","|---|---:|---:|---:|---:|---|"]
        for m in METHODS:
            g=groups[p][m];r=g["recovery"]
            lines.append(f"| {LABELS[m]} | {fmt(g['event_exposure_mean_s'])} | {r['episodes_information_lost']} | {r['recovered']}/{r['right_censored']} | {fmt(r['recovered_only_mean_s'])} | {g['termination_reasons']} |")
        lines += ["","complete comparator95%  (2000 bootstrap,  ): ", "","| comparator | collection/  | AoI /s | DATA /  | window/  |","|---|---:|---:|---:|---:|"]
        for m in METHODS[1:]:
            items=[]
            for metric,scale in (("packets_per_episode",1),("pooled_aoi_s",1),("data_hop_nondelivery",100),("event_information_planned",100)):
                x=paired_results[p][m][metric]
                items.append("N/A" if x["ci95"] is None else f"{fmt(scale*x['difference'])} [{fmt(scale*x['ci95'][0])}, {fmt(scale*x['ci95'][1])}]")
            lines.append("| "+" | ".join([LABELS[m]]+items)+" |")
        lines.append("")
        all75 += [f"## {p}","","| metric | Display label | "+" | ".join(LABELS[m] for m in METHODS)+" |","|---|---|"+"---:|"*5]
        for key,item in groups[p][METHODS[0]]["metrics75"].items():
            values=[]
            for m in METHODS:
                x=groups[p][m]["metrics75"][key]
                values.append(f"{fmt(x['mean'],4)} ± {fmt(x['sd'],4)} (n={x['valid_episodes']})")
            all75.append("| "+" | ".join([item["label"],item["unit"]]+values)+" |")
        all75.append("")
    lines += ["##  ",""," :  <80%, collection<70%, window<80%. failure, method. ",""]
    for m in METHODS: lines.append(f"- {LABELS[m]}: Display label {thresholds[m]['first_failed_level'] or 'Display label'}. reference {thresholds[m]['reference_survived']}/30. ")
    lines += ["","CPUtime,  ; CUDAfailure,  CPU. Follower ; leadercomplete, duplicate. ",
        "warm-upepisode20 follower/complete5 topology/leader . topologytopology N/A.  ,  . ",
        "completemetric / , environment; episodewall time . time,  ,  episode/analysis. ",""]
    (output/"REPORT_ZH.md").write_text("\n".join(lines),encoding="utf-8")
    (output/"ALL_75_METRICS_ZH.md").write_text("\n".join(all75),encoding="utf-8")
    plots(groups,output)
    print(f"Analysis complete: {len(rows)} unique episodes",flush=True)
    return len(rows)

def plots(groups,output):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    profiles=PROFILES[:5];x=np.arange(5)
    fig,axes=plt.subplots(2,2,figsize=(11,8),constrained_layout=True)
    for m in METHODS:
        axes[0,0].plot(x,[groups[p][m]["packets_per_episode"] for p in profiles],marker="o",label=m)
        axes[0,1].plot(x,[groups[p][m]["pooled_aoi_s"] for p in profiles],marker="o")
        axes[1,0].plot(x,[100*groups[p][m]["survival_fraction"] for p in profiles],marker="o")
        axes[1,1].plot(x,[100*groups[p][m]["event_information_planned"] for p in profiles],marker="o")
    for ax,title in zip(axes.flat,("Collected packets / episode","Pooled AoI (s)","Full-horizon survival (%)","Planned event information availability (%)")):
        ax.set_title(title);ax.set_xticks(x,["Ref","Weak","Moderate","Severe","Extreme"]);ax.grid(alpha=.25)
    fig.legend(*axes[0,0].get_legend_handles_labels(),loc="outside lower center",ncol=3,fontsize=8)
    fig.savefig(output/"degradation.png",dpi=180);fig.savefig(output/"degradation.pdf");plt.close(fig)

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--run",required=True);parser.add_argument("--output",required=True)
    args=parser.parse_args();analyze(args.run,args.output)

if __name__=="__main__": main()
