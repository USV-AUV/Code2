"""Nonformal no-overlay trajectory equality, packet accounting and all models."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from .protocol import ROOT, METHODS, scenario
from .runner import load, bind, routing_decision, verify_package, write_json
from .disturbance import attach, channel_patch

def trajectory(policy,env,method,wrapped):
    import torch
    from usv_auv.learning import seed_all
    from usv_auv.train import json_safe
    from contextlib import nullcontext
    seed_all(42)
    obs,info=env.reset(seed=42);bind(policy,env)
    if wrapped: attach(env,scenario("reference",42,True))
    digest=hashlib.sha256();n=0
    with channel_patch() if wrapped else nullcontext(),torch.inference_mode():
        for i in range(1200):
            topo=routing_decision(method,policy,env);actions=policy.act(obs)
            obs,reward,term,trunc,info=env.step(actions,topology_action=topo)
            value=json_safe(dict(actions=actions,obs=obs,reward=reward,info=info,
                usv=env.usv_position,auv=env.auv_positions,nav=[v.position for v in env.nav],term=term,trunc=trunc))
            digest.update(json.dumps(value,sort_keys=True,allow_nan=False).encode())
            n+=1
            if term or trunc: break
    return digest.hexdigest(),n

def validate(output):
    import torch
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    output=Path(output).resolve()
    if not output.is_relative_to(ROOT/"verification") or output.exists(): raise ValueError("New verification output required")
    output.mkdir(parents=True)
    registry=verify_package();result=[]
    started=time.monotonic()
    for method in METHODS:
        policy,env,factory,checkpoint,path=load(method,"cpu")
        try:
            a=trajectory(policy,env,method,False);b=trajectory(policy,env,method,True)
            if a!=b: raise ValueError(f"Reference wrapper changes native trajectory: {method}")
            result.append(dict(method=method,steps=a[1],native_sha256=a[0],wrapped_sha256=b[0],equal=True))
            print(json.dumps(result[-1]),flush=True)
        finally: env.close()
    write_json(output/"readiness.json",dict(status="passed",experiment1_registry=registry,
        full_native_reference_equality=result,elapsed_s=time.monotonic()-started,training_steps=0,device="cpu"))

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--output",required=True)
    args=parser.parse_args();validate(args.output)

if __name__=="__main__": main()
