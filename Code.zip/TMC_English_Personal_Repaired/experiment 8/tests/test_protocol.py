import unittest
import math
import os
from types import SimpleNamespace
from exp8.runner import source_hashes
from exp8.protocol import METHODS, PROFILES, SEEDS, jobs, scenario, current_spec
from exp8.disturbance import JointChannel
from exp8.runtime import summary, memory
from exp8.analysis import paired

class Network:
    slot_duration=.2
    def __init__(self): self.faults=[]
    def add_fault(self,**event): self.faults.append(event)

class Tests(unittest.TestCase):
    def test_matrix(self):
        self.assertEqual(len(set(jobs())),1500)
        self.assertEqual(len(METHODS),5);self.assertEqual(len(PROFILES),10)
    def test_seeds(self):
        with self.assertRaises(ValueError): scenario("reference",42)
        with self.assertRaises(ValueError): scenario("bad",SEEDS[0])
    def test_reference(self):
        s=scenario("reference",SEEDS[0]);self.assertFalse(s["components"])
        self.assertEqual(s["current_peak_mps"],0);self.assertEqual(s["hard_events"],[])
    def test_balanced(self):
        specs=[scenario("joint_moderate",s) for s in SEEDS]
        self.assertEqual(sum(s["target"]==1 for s in specs),15)
        self.assertAlmostEqual(sum(s["direction_xy"][0] for s in specs),0,places=10)
        self.assertAlmostEqual(sum(s["direction_xy"][1] for s in specs),0,places=10)
    def test_single_components(self):
        for p in PROFILES[5:]: self.assertEqual(scenario(p,SEEDS[0])["components"],[p[5:]])
    def test_radio(self):
        s=scenario("only_radio",SEEDS[0]);self.assertEqual(len(s["hard_events"]),32)
        self.assertTrue(all(x["bidirectional"] and x["src"]==s["target"] for x in s["hard_events"]))
    def test_direct_partition(self):
        s=scenario("only_multi_link",SEEDS[0]);self.assertEqual({x["dst"] for x in s["hard_events"]},{1,2})
    def test_current(self):
        self.assertEqual(current_spec(scenario("joint_extreme",SEEDS[0]))["amplitude_mps"],.8)
    def test_hash_reproducible(self):
        a=JointChannel(scenario("joint_moderate",SEEDS[0]),Network())
        b=JointChannel(scenario("joint_moderate",SEEDS[0]),Network())
        self.assertEqual(a.burst,b.burst)
        a.burst[550]=b.burst[550]=True
        first=a.erased(3,1,550,551);a.erased(8,2,550.2,551)
        self.assertEqual(first,b.erased(3,1,550,551))
    def test_probability_nested(self):
        a=JointChannel(scenario("joint_weak",SEEDS[0]),Network())
        b=JointChannel(scenario("joint_extreme",SEEDS[0]),Network())
        self.assertEqual(a.burst,b.burst)
        for t in range(400,800):
            a.burst[t]=b.burst[t]=True
            self.assertFalse(a.erased(3,1,t,t+1) and not b.erased(3,1,t,t+1))
    def test_window(self):
        a=JointChannel(scenario("joint_extreme",SEEDS[0]),Network())
        self.assertFalse(a.erased(3,1,399,401));self.assertFalse(a.erased(3,1,800,801))
    def test_runtime_missing(self):
        self.assertIsNone(summary([],1000)["p95_ms"])
        s=summary([2000,1,2,3],1000,1);self.assertEqual(s["steady_calls"],3);self.assertEqual(s["misses"],0)
    @unittest.skipUnless(os.name == 'nt', 'Original private-memory measurement is Windows-specific')
    def test_memory(self):
        value=memory();self.assertGreater(value["rss_bytes"],0);self.assertGreater(value["private_bytes"],0)
    def test_bootstrap_pooled(self):
        a=[dict(seed=i,raw=dict(aoi_sum_s=n,aoi_n=d)) for i,(n,d) in enumerate(((10,1),(20,100)))]
        b=[dict(seed=i,raw=dict(aoi_sum_s=n,aoi_n=d)) for i,(n,d) in enumerate(((5,1),(10,100)))]
        s=paired(a,b,"pooled_aoi_s",4);self.assertAlmostEqual(s["difference"],15/101)
    def test_code_lock(self):
        self.assertGreater(len(source_hashes()),20)

if __name__=="__main__": unittest.main()
