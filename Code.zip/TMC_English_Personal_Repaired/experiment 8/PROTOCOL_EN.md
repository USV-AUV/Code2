# Experiment 8: Joint Stress and Runtime Protocol

This file is an English explanatory outline for the preserved Experiment 8 protocol implementation. The original historical protocol document was excluded from the personal reading package; the definitive experiment profiles and seeds are defined in `exp8/protocol.py`.

- Method definitions: five frozen policies using common mission and channel accounting.
- Profiles: 10 registered conditions (reference, four increasing joint-stress levels, and five single-factor controls).
- Scenarios: 30 seeds per method-condition cell; preserve early termination in summaries.
- Disturbances: combinations of added currents, burst packet loss, localization biases, root-link outages, and temporary AUV radio failures; values and time windows are taken from the corresponding protocol code.
- Metrics: unique accepted sensor payload, STATE age, navigation error, termination, and measured wall-clock latency.
- Memory instrumentation: the historical implementation uses Windows process counters. Host measurements from another operating system are not directly interchangeable.

The raw 1,200-episode mixed-stress/timing data referenced by the full manuscript are not included in this private subset, and cannot be reconstructed from the selected CSV tables.
