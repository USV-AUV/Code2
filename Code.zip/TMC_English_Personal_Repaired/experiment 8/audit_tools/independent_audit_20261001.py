"""Read-only independent reconciliation; never imports Torch or experiment runner."""
from collections import Counter, defaultdict
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import sys
import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
RUN = ROOT / "runs/formal_20261001"
REPORT = ROOT / "reports/formal_20261001"
OUT = ROOT / "orchestration/independent_audit_20261001.json"
PLAN_SHA = "c4f906b566645f0c613a43417b94cac415cc8321cc53a59912a318c365f9c255"
PROFILES = ["reference", "joint_weak", "joint_moderate", "joint_severe", "joint_extreme",
            "only_current", "only_burst", "only_multi_link", "only_bias", "only_radio"]
METHODS = ["full_v6", "usde_only_v6", "topology_only_v6", "synchronous_fim_rl", "communication_aware_tmc"]
METRICS = ["packets_per_episode", "pooled_aoi_s", "data_hop_nondelivery", "installed_connectivity",
           "local_mae_m", "event_information_planned", "survival_fraction", "control_bits_per_episode"]
KINDS = {"follower": 20, "topology": 5, "leader": 5, "end_to_end": 20}
checks = Counter()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def equal(a, b, label):
    if a is None or b is None:
        assert a is b, (label, a, b)
    elif isinstance(a, (int, float, bool)) and isinstance(b, (int, float, bool)):
        assert math.isfinite(a) and math.isfinite(b) and math.isclose(a, b, rel_tol=2e-10, abs_tol=1e-8), (label, a, b)
    else:
        assert a == b, (label, a, b)
    checks[label.split(":")[0]] += 1

def ratio(n, d):
    return n / d if d else None

def audit_trace(path, row):
    raw = Counter()
    times = {k: [] for k in KINDS}
    lost = risk = False
    recovery = None
    streak = count = requests = switches = 0
    parents = [0, 0]
    collected = 0
    counts = {"onset": None, "clear": None}
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        for line in stream:
            t = json.loads(line)
            count += 1
            equal(t["time_s"], count, "trace_time")
            phase = "before" if count <= 400 else "during" if count <= 800 else "after"
            equal(t["phase"], phase, "trace_phase")
            assert len(t["aoi_s"]) == len(t["information_available"]) == 2
            for age, available in zip(t["aoi_s"], t["information_available"]):
                assert not available or age <= 60
            vals = dict(aoi_sum_s=sum(t["aoi_s"]), aoi_n=2,
                        usable_n=sum(t["installed_usable"]), path_n=2,
                        available_n=sum(t["information_available"]), information_n=2,
                        collected_increment=t["collected_increment"])
            for prefix in ("", phase + "_"):
                for key, value in vals.items():
                    raw[prefix + key] += value
            raw["local_sum_m"] += sum(t["local_error_m"])
            raw["local_n"] += len(t["local_error_m"])
            raw["hold_sum_m"] += sum(v for v in t["hold_error_m"] if v is not None)
            raw["hold_n"] += sum(v is not None for v in t["hold_error_m"])
            raw["fim_sum"] += sum(t["fim_logdet"])
            raw["fim_n"] += len(t["fim_logdet"])
            raw["usv_path_m"] += t["usv_step_m"]
            for key in times:
                if t["timing_ms"][key] is not None:
                    times[key].append(t["timing_ms"][key])
            if phase == "during" and not all(t["information_available"]):
                lost = True
            if phase == "after" and lost and recovery is None:
                risk = True
                streak = streak + 1 if all(t["information_available"]) else 0
                if streak == 30:
                    recovery = count - 800
            requests += t["topology_request"] is not None
            switches += parents != t["root_parents"]
            parents = t["root_parents"]
            collected += t["collected_increment"]
            if count in (400, 800):
                counts["onset" if count == 400 else "clear"] = collected
            assert not (t["terminated"] or t["truncated"]) or count == row["steps"]
    equal(count, row["steps"], "trace_steps")
    equal(collected, row["collected_packets"], "trace_collection")
    equal(requests, row["topology_requests"], "trace_topology_requests")
    equal(switches, row["route_changes"], "trace_route_changes")
    for key in set(raw) | set(row["raw"]):
        equal(raw.get(key, 0), row["raw"].get(key, 0), "raw_trace:" + key)
    expected_recovery = dict(information_lost=lost, risk_observed=risk, recovered=recovery is not None,
                             time_s=recovery, right_censored=lost and recovery is None,
                             censor_time_s=max(0., count - 800.), counts=counts)
    equal(expected_recovery, row["recovery"], "recovery_trace")
    for key in times:
        equal(times[key], row["runtime_samples_ms"][key], "timing_trace:" + key)
    return count

def vectors(row):
    raw = row["raw"]
    hop = row["network"]["by_kind"].get("DATA", {}).get("hop_delivery", {}).get("completion_window", {})
    return [(row["collected_packets"], 1), (raw["aoi_sum_s"], raw["aoi_n"]),
            (hop.get("resolved_failures", 0), hop.get("resolved_trials", 0)),
            (raw["usable_n"], raw["path_n"]), (raw["local_sum_m"], raw["local_n"]),
            (raw.get("during_available_n", 0), 800), (int(row["survived_full_horizon"]), 1),
            (row["network"]["control_plane"]["transmitted_frame_bits"], 1)]

def audit_group(rows, saved):
    for k, metric in enumerate(METRICS):
        n = sum(vectors(r)[k][0] for r in rows)
        d = sum(vectors(r)[k][1] for r in rows)
        equal(n, saved["raw"][metric]["numerator"], "group_n:" + metric)
        equal(d, saved["raw"][metric]["denominator"], "group_d:" + metric)
        equal(ratio(n, d), saved[metric], "group_ratio:" + metric)
    equal(dict(Counter(r["termination_reason"] for r in rows)), saved["termination_reasons"], "group_failures")
    equal(sum(r["survived_full_horizon"] for r in rows), saved["survived"], "group_survived")
    equal(statistics.fmean(r["metrics_base"]["total_energy_j"] / 1000 for r in rows), saved["total_energy_kj"], "energy")
    equal(statistics.fmean(r["fixed_budget_goodput_bit_s"] for r in rows), saved["fixed_budget_goodput_bit_s"], "goodput")
    equal(statistics.fmean(r["event_exposure_s"] for r in rows), saved["event_exposure_mean_s"], "exposure")
    equal(ratio(sum(r["raw"].get("during_available_n", 0) for r in rows),
                sum(r["raw"].get("during_information_n", 0) for r in rows)), saved["event_information_actual"], "actual_information")
    for phase in ("before", "during", "after"):
        n = sum(r["raw"].get(phase + "_aoi_sum_s", 0) for r in rows)
        d = sum(r["raw"].get(phase + "_aoi_n", 0) for r in rows)
        equal(ratio(n, d), saved["phases"][phase]["aoi_s"], "phase_aoi")
        equal(d, saved["phases"][phase]["aoi_denominator"], "phase_denominator")
        equal(sum(r["raw"].get(phase + "_collected_increment", 0) for r in rows) / 30,
              saved["phases"][phase]["packets"], "phase_packets")
    rec = saved["recovery"]
    for key, source in (("episodes_information_lost", "information_lost"), ("recovered", "recovered"), ("right_censored", "right_censored")):
        equal(sum(r["recovery"][source] for r in rows), rec[key], "group_recovery:" + key)
    recovered = [r["recovery"]["time_s"] for r in rows if r["recovery"]["recovered"]]
    equal(statistics.fmean(recovered) if recovered else None, rec["recovered_only_mean_s"], "group_recovery_mean")
    for key, warmup in KINDS.items():
        values = [v for r in rows for v in r["runtime_samples_ms"][key][warmup:]]
        s = saved["runtime"][key]
        equal(len(values), s["steady_calls"], "runtime_count")
        if values:
            a = np.asarray(values)
            for q in (50, 95, 99):
                equal(float(np.quantile(a, q / 100)), s[f"p{q}_ms"], "runtime_quantile")
            equal(float(a.mean()), s["mean_ms"], "runtime_mean")
            equal(float(a.max()), s["max_ms"], "runtime_max")
            equal(sum(v > s["deadline_ms"] for v in values), s["misses"], "runtime_misses")
        else:
            equal(s["p95_ms"], None, "runtime_na")
    for memory_key, key in (("memory_peak_private_mib", "private_bytes"), ("memory_peak_rss_mib", "rss_bytes")):
        equal(max(r["memory"]["peak"][key] for r in rows) / 2**20, saved[memory_key], "memory")
    cp = [r["network"]["control_plane"] for r in rows]
    equal(sum(r["airtime_s"] for r in cp) / 30, saved["control_airtime_s_per_episode"], "control_airtime")
    equal(ratio(sum(r["airtime_s"] for r in cp), sum(r["duration_s"] for r in rows)), saved["control_airtime_fraction_actual"], "control_airtime_fraction")
    for key, item in saved["metrics75"].items():
        values = [r["metrics75"][key]["value"] for r in rows if r["metrics75"][key]["value"] is not None]
        equal(len(values), item["valid_episodes"], "metrics75_valid")
        equal(30 - len(values), item["missing_episodes"], "metrics75_missing")
        equal(statistics.fmean(values) if values else None, item["mean"], "metrics75_mean")
        equal(statistics.stdev(values) if len(values) > 1 else None, item["sd"], "metrics75_sd")

def audit_pair(left, right, result, seed):
    ids = np.random.default_rng(seed).integers(0, 30, size=(2000, 30))
    a, b = left[ids].sum(axis=1), right[ids].sum(axis=1)
    valid = (a[:, 1] > 0) & (b[:, 1] > 0)
    delta = a[valid, 0] / a[valid, 1] - b[valid, 0] / b[valid, 1]
    x, y = left.sum(axis=0), right.sum(axis=0)
    equal(x[0] / x[1] - y[0] / y[1], result["difference"], "paired_point")
    for a, b in zip(np.quantile(delta, [.025, .975]), result["ci95"]):
        equal(float(a), b, "paired_interval")
    equal(len(delta), result["valid_bootstrap"], "bootstrap_n")

def main():
    assert not OUT.exists(), "Never overwrite an independent audit"
    plan, analysis = read(RUN / "plan.json"), read(REPORT / "analysis.json")
    equal(digest(RUN / "plan.json"), PLAN_SHA, "plan_sha")
    expected_jobs = [[p, m, s] for p in PROFILES for m in METHODS for s in range(9690000, 9690030)]
    equal(plan["jobs"], expected_jobs, "plan_matrix")
    for rel, sha in plan["source_hashes"].items():
        equal(digest(PROJECT / rel), sha, "source_sha")
    exp1 = PROJECT / "experiment 1"
    equal(digest(exp1 / "checksums.sha256"), plan["experiment1_registry"]["registry_sha256"], "registry_sha")
    package_files = 0
    for line in (exp1 / "checksums.sha256").read_text(encoding="utf-8-sig").splitlines():
        sha, rel = line.split(" *", 1)
        equal(digest(exp1 / rel), sha, "package_sha")
        package_files += 1
    spec = importlib.util.spec_from_file_location("metric_schema", exp1 / "source/scripts/summarize_tmc_retest.py")
    schema = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(schema)
    getters = schema.selected_specs()
    indexed = {}
    trace_steps = 0
    retained_partials = []
    totals = Counter()
    seen = set()
    for pi, profile in enumerate(PROFILES):
        for method in METHODS:
            rows = []
            for seed in range(9690000, 9690030):
                base = RUN / profile / method / str(seed)
                candidates = [base] + sorted(base.parent.glob(base.name + "__attempt*"))
                completed = [p for p in candidates if (p / "complete.json").exists()]
                assert len(completed) == 1, (profile, method, seed, completed)
                path = completed[0]
                for p in candidates:
                    if p.exists() and p != path:
                        retained_partials.append(str(p.relative_to(RUN)))
                completion = read(path / "complete.json")
                equal(completion["status"], "completed", "episode_complete")
                equal(set(completion["sha256"]), {"episode.json", "network_evidence.json.gz", "trace.jsonl.gz"}, "evidence_set")
                for filename, sha in completion["sha256"].items():
                    equal(digest(path / filename), sha, "evidence_sha")
                row = read(path / "episode.json")
                key = (row["profile"], row["mode"], row["seed"])
                equal(key, (profile, method, seed), "identity")
                assert key not in seen
                seen.add(key)
                equal(row["model_step"], 450000, "model_step")
                equal(row["policy_sha256"], plan["experiment1_registry"]["policies_sha256"][method], "model_sha")
                assert row["terminated"] != row["truncated"]
                equal(row["survived_full_horizon"], not row["terminated"] and row["steps"] == 1200, "survival")
                equal(row["event_planned_auv_seconds"], 800, "planned_denominator")
                equal(row["event_exposure_s"], max(0, min(row["steps"], 800) - 400), "exposure_denominator")
                trace_steps += audit_trace(path / "trace.jsonl.gz", row)
                with gzip.open(path / "network_evidence.json.gz", "rt", encoding="utf-8") as stream:
                    network = json.load(stream)
                for name in row["network"]:
                    equal(row["network"][name], network[name], "network_reconciliation:" + name)
                hops = [h for h in network["hop_events"] if h["packet"]["kind"] == "DATA" and
                        0 <= h["time"] < row["duration_s"] and h["nominal_arrival_at"] <= row["duration_s"] and
                        h["outcome_at"] is not None and h["outcome_at"] <= row["duration_s"]]
                hop = network["by_kind"].get("DATA", {}).get("hop_delivery", {}).get("completion_window", {})
                equal(len(hops), hop.get("resolved_trials", 0), "DATA_trials")
                equal(sum(h["outcome"] != "arrived_accepted" for h in hops), hop.get("resolved_failures", 0), "DATA_failures")
                equal(network["logical"]["DATA"]["delivered_unique"], row["collected_packets"], "DATA_logical")
                full_record = dict(row, network=network)
                equal(len(row["metrics75"]), 75, "metrics75_schema")
                for name, label, unit, _, getter in getters:
                    expected = getter(full_record)
                    if name.startswith("environment.planner_horizon_prediction.") and not row["environment"]["planner_horizon_prediction"].get("applicable", True):
                        expected = None
                    equal(row["metrics75"][name]["value"], expected, "metrics75_value")
                    equal(row["metrics75"][name]["unit"], unit, "metrics75_unit")
                del full_record, hops, network
                row.pop("environment")
                row.pop("disturbance_evidence")
                rows.append(row)
                totals[row["termination_reason"]] += 1
            audit_group(rows, analysis["profiles"][profile][method])
            indexed[profile, method] = np.asarray([vectors(r) for r in rows], dtype=float)
            del rows
            print(f"Independently reconciled {profile}/{method}: {len(seen)}/1500", flush=True)
    for pi, profile in enumerate(PROFILES):
        for mi, method in enumerate(METHODS[1:]):
            for k, metric in enumerate(METRICS):
                audit_pair(indexed[profile, "full_v6"][:, k], indexed[profile, method][:, k],
                           analysis["full_minus_comparator"][profile][method][metric], 1102026 + pi * 1000 + mi * 20 + k)
        if profile.startswith("joint_"):
            for mi, method in enumerate(METHODS):
                for k, metric in enumerate(METRICS):
                    audit_pair(indexed[profile, method][:, k], indexed["reference", method][:, k],
                               analysis["level_minus_reference"][profile][method][metric], 1102026 + 20000 + pi * 100 + mi * 10 + k)
    for method in METHODS:
        first_failed = None
        for profile in PROFILES[1:5]:
            g, ref = analysis["profiles"][profile][method], analysis["profiles"]["reference"][method]
            failed = g["survival_fraction"] < .8 or g["packets_per_episode"] / ref["packets_per_episode"] < .7 or g["event_information_planned"] < .8
            if failed and first_failed is None:
                first_failed = profile
        equal(first_failed, analysis["engineering_thresholds"][method]["first_failed_level"], "engineering_threshold")
    progress = [json.loads(x) for x in (RUN / "progress.jsonl").read_text(encoding="utf-8").splitlines()]
    equal(len(progress), 1500, "progress_count")
    equal({(x["profile"], x["method"], x["seed"]) for x in progress}, seen, "progress_identities")
    result = dict(status="passed",unique_jobs=len(seen), package_files_verified=package_files,
                  source_files_verified=len(plan["source_hashes"]), evidence_files_verified=checks["evidence_sha"],
                  independently_reconstructed_trace_steps=trace_steps, metrics75_values_verified=checks["metrics75_value"],
                  paired_comparisons_verified=checks["paired_point"], failures_retained=dict(totals),
                  retained_incomplete_attempts=retained_partials, checks=dict(checks),
                  analysis_sha256=digest(REPORT / "analysis.json"), plan_sha256=PLAN_SHA,
                  note="No simulations/training; original results, sources and weights are read-only. 75 getters reuse the frozen definition; trace/raw, DATA events, grouped statistics and CIs are recomputed independently.")
    with OUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, allow_nan=False, indent=2)
    print(json.dumps(result, ensure_ascii=False), flush=True)

if __name__ == "__main__":
    main()
