$ErrorActionPreference = 'Stop'
$experimentRoot = Split-Path -Parent $PSScriptRoot
$pythonExecutable = 'C:\Users\admin\Desktop\USV-AUVresearch\USV-AUV-delay\.venv\Scripts\python.exe'
Set-Location -LiteralPath $experimentRoot
& $pythonExecutable -X utf8 -m exp8.pipeline --run runs/formal_20261001 --report reports/formal_20261001
if ($LASTEXITCODE -ne 0) { throw "Experiment 8 pipeline failed: $LASTEXITCODE" }
