# Experiment 8: Private English Review

Source: `exp8/`; 10 scenario profiles in `exp8/protocol.py` and tests in `tests/test_protocol.py`.

Run structural tests from this directory with:

```bash
PYTHONPATH="../experiment 1/source:." python -m unittest discover -s tests -v
```

The runtime memory test is intentionally skipped on non-Windows operating systems: the original measurement uses Windows private/process counters. No substitute measurements are silently substituted. Offline raw-episode reproduction requires separate experiment assets not shipped here.
