# Manuscript Alignment: Summary-Level Evidence Scope

## Summary-level evidence available

- Primary two-AUV aggregate: Full 63.90 and USDE-only 50.20 unique DATA packets; pooled STATE AoI 12.30 and 15.85 seconds. These are supplied summary entries, not newly reproduced experimental runs.
- Principal simulation configuration: 1 USV / 2 AUVs / 30 sensors, 200 x 200 m, 1200-s mission, 1-s/5-s decisions and 0.1-s physical integration.
- Saved model-weight bytes have not been changed by the English personal-release edits.

## Evidence not supplied in this subset

- Per-episode outcome and event traces are required to independently reproduce completion counts, pooled estimates and bootstrap statistics.
- The supplied 450k checkpoint metadata documents seed 7, but a complete independent multi-seed training record has not been supplied. Evaluation scenario variability is distinct from independent training-seed variability.
- Separate external raw-trace assets are needed for an independent audit of the manuscript's 5,760 episode-level experiments.

## Presentation and reproduction scope

The paired Experiment 2, 3 and 8 summaries include all recorded conditions without outcome-based screening. Fixed-scope convenience views do not replace the complete episode-level archive. The current release verifies the files as packaged and tests a limited inference interface; it does not certify manuscript-wide numerical reproduction.
