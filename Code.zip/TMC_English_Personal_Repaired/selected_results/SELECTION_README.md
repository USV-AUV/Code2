# Scenario-complete English results (legacy folder name)

**No post-hoc performance-based condition filtering is applied.** For Experiments 2, 3, and 8, the paired Full/USDE-only summary views include **all 11 acoustic-fault, 13 current-disturbance, and 10 combined-stress scenarios**, whether outcomes are favorable, mixed, or unfavorable.

The filenames containing `_selected.csv` are retained **only for backward-compatible file paths**. They do **not** imply that scenarios are eligible based on payload, AoI, mission completion, or other outcomes.

| File | Actual coverage |
|---|---|
| `primary_two_auv.csv` | Compact primary four-method reference view; all four reported methods, some metrics omitted in the compact view. |
| `acoustic_faults_selected.csv` | Full and USDE-only, **all 11 predefined acoustic-fault scenarios** (22 rows). |
| `currents_selected.csv` | Full and USDE-only, **all 13 predefined current conditions** (26 rows). |
| `joint_stress_selected.csv` | Full and USDE-only, **all 10 predefined combined-stress conditions** (20 rows). |
| `mechanism_reference_selected.csv` | Compact fixed-scope mechanism reference only; this convenience view does not include all intervention conditions. |
| `fleet_3auv_reference.csv` | Compact fixed-scope 3-AUV reference comparison only. |
| `highlight_metrics.csv` | A convenience summary of specific metrics, not an exhaustive statistical table. |
| `all_original_summary_tables/` | **Seven current-accepted aggregate CSV tables (legacy directory name)** (all recorded methods, available conditions and metrics), including fleet, mechanisms and scheduling. |

**Canonical checksum baseline:** `selection_manifest.json` → `packaged_table_sha256` refers to the **current user-confirmed CSV files**. Validate with `python release.py verify-summaries` from the project root, or with `sha256sum -c CURRENT_TABLE_CHECKSUMS.sha256` from this directory. The prior archive is a superseded data version; its hashes are recorded only in `table_version_history.json`, not used as expected hashes for this release. This update changes neither CSV bytes nor model weights. Hash agreement verifies file integrity, not original episode-level statistics.

**Important limits:** These are aggregate reports, not the original per-episode evidence, optimizer/replay snapshots, or proof of five independent training runs. Missing raw archives and evaluation scope are described in the root documentation. Do not present these summaries as full episode-level reproduction.
