"""Portable five-system 450k reporting using original 75-metric statistics."""
from pathlib import Path
import json,argparse,math
import release
release.install_paths()
from scripts.summarize_baseline_campaign import normalize_episode,summarize_rows,paired_bootstrap
from scripts.summarize_tmc_retest import selected_specs

def primary(rows):
    result={'collected_packets':[],'pooled_aoi_s':[],'data_hop_nondelivery':[]}
    for row in rows:
        aoi=row['environment']['state_aoi']['pooled']
        hop=row['network']['by_kind'].get('DATA',{}).get('hop_delivery',{}).get('completion_window',{})
        result['collected_packets'].append([row['collected_packets'],1.])
        result['pooled_aoi_s'].append([aoi['mean']*aoi['valid_samples'],aoi['valid_samples']])
        result['data_hop_nondelivery'].append([hop.get('resolved_failures',0),hop.get('resolved_trials',0)])
    return result

def pooled_pair(left,right):
    import numpy as np
    indexes=np.random.default_rng(934091).integers(0,30,size=(20000,30));out={}
    for key in left:
        a,b=np.asarray(left[key]),np.asarray(right[key])
        asum,bsum=a[indexes].sum(axis=1),b[indexes].sum(axis=1)
        valid=(asum[:,1]>0)&(bsum[:,1]>0)
        draws=bsum[valid,0]/bsum[valid,1]-asum[valid,0]/asum[valid,1]
        bounds=np.quantile(draws,[.025,.975]).tolist() if len(draws) else [None,None]
        av=float(a[:,0].sum()/a[:,1].sum()) if a[:,1].sum() else None
        bv=float(b[:,0].sum()/b[:,1].sum()) if b[:,1].sum() else None
        out[key]=dict(left=av,right=bv,difference=bv-av if av is not None and bv is not None else None,
            ci95_low=bounds[0],ci95_high=bounds[1],n_paired_scenes=30,resamples=20000,
            valid_resamples=int(valid.sum()),zero_denominator_resamples=int((~valid).sum()),
            bootstrap_seed=934091,left_raw=a.sum(axis=0).tolist(),right_raw=b.sum(axis=0).tolist())
    return out

def compare(inputs,output):
    release.verify();inputs=Path(inputs).resolve();output=Path(output).resolve()
    if output.exists():raise ValueError('New report directory required')
    datasets={};raw={};definitions={k:dict(label_zh=l,unit=u,section=s) for k,l,u,s,_ in selected_specs()}
    for method in release.METHODS:
        folder=inputs/(method+'_0450000')
        summary=release.read(folder/'evaluation_summary.json')
        if (summary['status'],summary['method_id'],summary['training_steps'],summary['config_fingerprint'])!=('completed',method,450000,'48caa5c4f5bf9627'):
            raise ValueError('Method/config/budget mismatch')
        rows=[normalize_episode(row,450000,method) for row in summary['episodes']]
        if [r['seed'] for r in rows]!=list(range(9300000,9300030)):raise ValueError('Missing paired scenes')
        raw[method]=primary(rows)
        datasets[method]=summarize_rows(rows,folder/'evaluation.jsonl',method)
        del rows,summary
    pairs={};pooled={}
    for method in release.METHODS[1:]:
        pairs[method]={k:paired_bootstrap(datasets[method]['selected_values_by_paired_seed'][k],
              datasets['full_v6']['selected_values_by_paired_seed'][k],20000,934091) for k in definitions}
        pooled[method]=pooled_pair(raw[method],raw['full_v6'])
    result=dict(status='completed',episodes=150,metric_definitions=definitions,datasets=datasets,
        full_minus_baseline=pairs,primary_pooled_comparisons=pooled,primary_raw_by_scene=raw,
        note='Failures retained. Single training seed and repeated development scenes; unadjusted pointwise intervals; external baselines not equal-protocol ablations.')
    output.mkdir(parents=True)
    (output/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    (output/'ALL_METRICS_AND_STATISTICS.txt').write_text('system450kcomplete75metric /statistics: \n'+json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(status='completed',output=str(output),episodes=150)))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();compare(a.input,a.output)
