"""Synthetic tests/compile only. Does not invoke training or formal evaluation."""
import ast
import argparse
import io
import json
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'verification'/'code_tests_five_systems.json')
    destination = parser.parse_args().output.resolve()
    if destination.exists():
        raise FileExistsError('Preserve the previous verification evidence')
    files = sorted(ROOT.rglob('*.py'))
    for path in files:
        text = path.read_text(encoding='utf-8')
        ast.parse(text, filename=str(path))
        compile(text, str(path), 'exec')
    log = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    result = unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    from exp2.runner import write_json, code_hashes, verify_package
    record = dict(status='passed' if result.wasSuccessful() else 'failed',
        tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        compiled_files=len(files), test_log=log.getvalue(), code_sha256=code_hashes(),
        frozen_inputs=verify_package(), formal_experiments_run=0, training_steps_run=0,
        actual_policy_environment_steps_run=0,
        scope='Synthetic network/statistics/plotting and syntax tests only; not scientific results')
    destination.parent.mkdir(parents=True,exist_ok=True)
    write_json(destination,record)
    print(json.dumps({k:v for k,v in record.items() if k not in ('test_log','code_sha256')},indent=2))
    if not result.wasSuccessful():
        print(log.getvalue())
        raise SystemExit(1)


if __name__ == '__main__':
    main()
