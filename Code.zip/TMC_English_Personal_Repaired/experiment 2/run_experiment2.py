"""Default is plan-only. No training entry points, no automatic evaluation."""
import argparse
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
from exp2.protocol import matrix, METHODS, FORMAT


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    plan = sub.add_parser('plan')
    plan.add_argument('--preset', choices=['core', 'stress', 'all'], default='core')
    check = sub.add_parser('validate', help='Model forward/schema and hash checks; zero env.step')
    check.add_argument('--output', type=Path, required=True)
    run = sub.add_parser('run', help='Future explicitly authorized formal experiments only')
    run.add_argument('--preset', choices=['core', 'stress', 'all'], default='core')
    run.add_argument('--output', type=Path, required=True)
    run.add_argument('--execute', action='store_true')
    analyze = sub.add_parser('analyze', help='Analyze completed runs; never executes an environment')
    analyze.add_argument('--input', type=Path, nargs='+', required=True)
    analyze.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'plan':
        jobs = matrix(args.preset)
        result = dict(status='plan_only', format=FORMAT, preset=args.preset, episodes=len(jobs),
                      training_steps=0, profiles=list(dict.fromkeys(p for p,s,n in jobs)), strategies=METHODS,
                      notes='No simulation started. Five systems only. Core=600; stress=1050; all=1650 episodes.')
    elif args.command == 'validate':
        from exp2.runner import validate, write_json
        if args.output.resolve().exists():
            raise FileExistsError('Validation output must not already exist')
        args.output.parent.mkdir(parents=True, exist_ok=True)
        result = validate()
        write_json(args.output, result)
    elif args.command == 'run':
        from exp2.runner import evaluate
        result = evaluate(args.preset, args.output, args.execute)
    else:
        from exp2.analysis import analyze_runs
        result = analyze_runs(args.input, args.output)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2))


if __name__ == '__main__':
    main()
