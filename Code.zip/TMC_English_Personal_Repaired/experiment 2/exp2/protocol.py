"""Predeclared experiment matrix; no outcome-dependent scenario selection."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT.parent / 'experiment 1'
SOURCE = PACKAGE / 'source'
METHODS = ('full_v6', 'usde_only_v6', 'topology_only_v6',
           'synchronous_fim_rl', 'communication_aware_tmc')
STRATEGIES = METHODS  # Five frozen systems only; no test-time routing replacement.
FORMAT = 'experiment2-five-systems-v2'
SEEDS = tuple(range(9620000, 9620030))
HORIZON = 1200
START, END = 500., 800.
CORE = ('reference', 'single_long', 'alternating', 'root_partition')
STRESS = ('single_short', 'iid_10', 'iid_30', 'burst', 'node_radio', 'snr_6', 'snr_12')
PROFILES = CORE + STRESS


def model_for(strategy):
    if strategy not in STRATEGIES:
        raise ValueError('Unknown strategy')
    return strategy


def scenario(profile, seed):
    if profile not in PROFILES or seed not in SEEDS:
        raise ValueError('Only predeclared experiment-2 profiles/seeds are allowed')
    target = 1 + (seed - SEEDS[0]) % 2
    other = 3 - target
    result = dict(profile=profile, seed=seed, target=target, onset_s=START,
                  clear_s=620. if profile == 'single_short' else END,
                  hard_events=[], erasure=None, snr_drop_db=0.,
                  snr_region_xy=[100., 100.], snr_radius_m=55.)
    def link(a, b, start, end):
        result['hard_events'].append(dict(src=a, dst=b, start=start, end=end,
                                          bidirectional=True))
    if profile in ('single_long', 'single_short'):
        link(0, target, START, result['clear_s'])
    elif profile == 'alternating':
        link(0, target, 500., 650.)
        link(0, other, 650., 800.)
    elif profile == 'root_partition':
        link(0, 1, START, END)
        link(0, 2, START, END)
    elif profile == 'node_radio':
        # Communication outage only; no physical removal, free data deletion,
        # movement change, or denominator change. All 32 incident links fail.
        for node in range(33):
            if node != target:
                link(target, node, START, END)
    elif profile.startswith('iid_'):
        result['erasure'] = dict(kind='iid', probability=int(profile[4:]) / 100.,
                                 scope='all_cooperative_directed_links')
    elif profile == 'burst':
        result['erasure'] = dict(kind='burst', probability=.7,
            scope='target_root_pair', good_to_bad=1/45., bad_to_good=1/15.)
    elif profile.startswith('snr_'):
        result['snr_drop_db'] = float(profile[4:])
    return result


def matrix(preset):
    if preset not in ('core', 'stress', 'all'):
        raise ValueError('Unknown preset')
    profiles = CORE if preset == 'core' else STRESS if preset == 'stress' else PROFILES
    return [(p, s, seed) for p in profiles
            for s in METHODS for seed in SEEDS]
