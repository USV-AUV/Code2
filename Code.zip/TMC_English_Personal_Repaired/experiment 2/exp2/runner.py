"""Read-only frozen-policy loader and explicitly gated evaluation runner."""
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

from .protocol import ROOT, PACKAGE, SOURCE, METHODS, FORMAT, model_for, matrix, scenario

sys.dont_write_bytecode = True
sys.path.insert(0, str(SOURCE))


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4*1024*1024), b''):
            result.update(chunk)
    return result.hexdigest()


def write_json(path, value):
    # New artifacts only. Existing evidence is never overwritten.
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write('\n')


def verify_package():
    expected = json.loads((ROOT/'asset_lock.json').read_text(encoding='utf-8'))
    if digest(PACKAGE/'checksums.sha256') != expected['experiment1_checksums_sha256']:
        raise ValueError('Experiment-1 checksum registry changed')
    count = 0
    for line in (PACKAGE/'checksums.sha256').read_text(encoding='utf-8-sig').splitlines():
        sha, rel = line.split(' *', 1)
        path = (PACKAGE/rel).resolve()
        if not path.is_relative_to(PACKAGE.resolve()) or digest(path) != sha:
            raise ValueError(f'Frozen package changed: {rel}')
        count += 1
    for method, sha in expected['policies_sha256'].items():
        if digest(PACKAGE/'models'/'45w'/method/'policy.pt') != sha:
            raise ValueError(f'Wrong 450k policy: {method}')
    return dict(verified_files=count, registry_sha256=expected['experiment1_checksums_sha256'])


def code_hashes():
    paths = (list((ROOT/'exp2').glob('*.py')) + list((ROOT/'tests').glob('*.py'))
             + [ROOT/'run_experiment2.py', ROOT/'verify_ready.py', ROOT/'asset_lock.json', ROOT/'PROTOCOL_ZH.md'])
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(paths)}


def load(strategy, device):
    from v6_campaigns.c07_1m_20260919.workflow import Policy, load_checkpoint, make_environment_observer
    from baselines.deploy import BaselinePolicy
    from baselines.environment import BaselineEnv
    from baselines.evaluate import make_environment_observer as baseline_observer
    method = model_for(strategy)
    path = PACKAGE/'models'/'45w'/method/'policy.pt'
    checkpoint = load_checkpoint(path)
    if checkpoint['global_step'] != 450000 or checkpoint['method_id'] != method:
        raise ValueError('Experiment 2 only accepts the five frozen 450000-step models')
    if method in METHODS[:3]:
        policy = Policy(checkpoint, device, method, verify=True)
        env = policy.make_environment()
        observer = make_environment_observer
    else:
        policy = BaselinePolicy(checkpoint, device, method, verify_sources=True)
        env = BaselineEnv(policy.cfg, method)
        policy.bind_environment(env)
        observer = baseline_observer
    if policy.cfg.fingerprint != '48caa5c4f5bf9627':
        raise ValueError('Physical configuration identity mismatch')
    return policy, env, observer, checkpoint, path


def validate():
    """No env.step, no episodes, no gradients, no experiment-seed observations."""
    import numpy as np
    import torch
    from .measurement import routing_decision
    from .protocol import PROFILES, SEEDS
    from .channel import Channel, channel_patch
    from scripts.tmc_network_observer import NetworkObserver
    before = verify_package()
    loaded = []
    for strategy in METHODS:
        policy, env, _, checkpoint, path = load(strategy, 'cpu')
        try:
            profiles = []
            for profile in PROFILES:
                obs, _ = env.reset(seed=42)  # synthetic interface check, not a formal scene
                if hasattr(policy, 'bind_environment'):
                    policy.bind_environment(env)
                else:
                    policy.validate_environment(env)
                config_before = env.cfg.to_dict()
                background_faults = len(env.network.faults)
                spec = scenario(profile, SEEDS[0])  # build fault description only
                Channel(spec, env.network)
                with channel_patch(profile != 'reference'), torch.inference_mode():
                    observer = NetworkObserver(env.network)
                    action = policy.act(obs)
                    topology = routing_decision(strategy, policy, env)
                    observer.detach()
                assert action.shape == (2, 2) and np.isfinite(action).all()
                assert env.time == 0 and env.step_count == 0 and env.network.time == 0
                assert env.cfg.to_dict() == config_before
                assert len(env.network.faults) == background_faults+2*len(spec['hard_events'])
                assert not any(p.requires_grad for actor in policy.actors for p in actor.parameters())
                profiles.append(dict(profile=profile, initialization_passed=True,
                    network_fault_records=len(env.network.faults), environment_steps_executed=0))
            loaded.append(dict(strategy=strategy, model_step=checkpoint['global_step'],
                policy_sha256=digest(path), observation_shape=list(obs.shape),
                action_shape=list(action.shape), topology_request=topology,
                profiles=profiles, environment_steps_executed=0))
        finally:
            env.close()
    after = verify_package()
    assert before == after
    return dict(status='interface_checks_passed', format=FORMAT, formal_experiment_executed=False,
                system_profile_combinations=sum(len(m['profiles']) for m in loaded),
                training_steps_executed=0, environment_steps_executed=0,
                torch_version=torch.__version__, models=loaded, package_verification=after,
                limitation='Synthetic network/unit tests plus frozen model interface checks; no end-to-end 1200s evaluation run')


def episode(policy, env, observer_factory, strategy, profile, seed, directory):
    from usv_auv.learning import seed_all
    from usv_auv.train import json_safe
    from scripts.tmc_network_observer import NetworkObserver
    from scripts.summarize_tmc_retest import selected_specs
    from .channel import Channel, channel_patch
    from .measurement import Timeline, routing_decision, summarize_event
    import torch
    spec = scenario(profile, seed)
    seed_all(seed)
    obs, info = env.reset(seed=seed)
    if hasattr(policy, 'bind_environment'):
        policy.bind_environment(env)
    else:
        policy.validate_environment(env)
    channel = Channel(spec, env.network)
    eo = observer_factory(env, info, policy.method)
    no = None
    timeline = Timeline(env, channel)
    total_reward = 0.
    started = time.monotonic()
    with gzip.open(directory/'trace.jsonl.gz', 'xt', encoding='utf-8') as trace:
        with channel_patch(profile != 'reference'), torch.inference_mode():
            # Install AFTER the channel context: base-only baseline networks
            # must not cache the unpatched bound transmit method.
            no = NetworkObserver(env.network)
            for index in range(1200):
                topo = routing_decision(strategy, policy, env)
                actions = policy.act(obs)
                obs, reward, terminated, truncated, info = env.step(actions, topology_action=topo)
                total_reward += float(reward)
                telemetry = eo.after_step(info)
                dynamics = timeline.sample(telemetry, topo)
                row = dict(seed=seed, step=index+1, actions=actions.tolist(), topology_request=topo,
                    reward=float(reward), info=info, terminated=bool(terminated), truncated=bool(truncated),
                    passive_environment=telemetry, experiment2=dynamics)
                trace.write(json.dumps(json_safe(row), ensure_ascii=False, allow_nan=False)+'\n')
                if terminated or truncated:
                    break
    duration = float(info['time'])
    metrics = json_safe(info['metrics'])
    record = dict(seed=seed, episode=seed-9620000, method_id=policy.method.method_id,
        strategy=strategy, profile=profile, model_step=450000, steps=index+1, duration_s=duration,
        terminated=bool(terminated), truncated=bool(truncated), termination_reason=info['termination_reason'],
        survived_full_horizon=not terminated and index+1 == 1200, **{'return': total_reward},
        metrics_base=metrics, environment=eo.finalize(), network=no.finalize(duration),
        collected_packets=metrics['collected_bits']/2048,
        ack_packets=metrics['ack_released_bits']/2048,
        collection_fraction=metrics['collected_bits']/(metrics['initial_bits']+metrics['arrival_bits']),
        goodput_bit_s=metrics['collected_bits']/duration, fixed_budget_goodput_bit_s=metrics['collected_bits']/1200,
        experiment2=summarize_event(timeline.rows, no, spec, duration), wall_time_s=time.monotonic()-started)
    assert record['network']['core_counter_reconciliation']['all_observed_counters_match_core']
    assert record['network']['logical']['DATA']['delivered_unique'] == len(env.collected)
    record['experiment2']['channel_exposure'] = dict(
        snr_receiver_trials=sum(e['type']=='snr_trial' for e in channel.events),
        extra_erasure_trials=sum(e['type']=='extra_erasure_trial' for e in channel.events),
        extra_erasures=sum(e.get('erased',False) for e in channel.events),
        extra_hard_fault_receiver_trials=sum(any(
            h['transmitter']==src and h['receiver']==dst and h['time'] < end
            and h['nominal_arrival_at'] > start for src,dst,start,end in channel.extra_hard)
            for h in no.hop_events),
        note='Receiver-expanded offered attempts; endogenous trajectory/traffic can change exposure')
    record['metrics75'] = {key: dict(label=label, unit=unit, value=getter(record))
                          for key, label, unit, _, getter in selected_specs()}
    # Match the old applicability convention: do not score an absent estimator
    # or an external non-5s forecast as an equivalent five-second prediction.
    if not record['environment']['planner_horizon_prediction'].get('applicable', True):
        for key, metric in record['metrics75'].items():
            if key.startswith('environment.planner_horizon_prediction.'):
                metric['value'] = None
    assert len(record['metrics75']) == 75
    with gzip.open(directory/'events.json.gz', 'xt', encoding='utf-8') as stream:
        json.dump(json_safe(dict(scenario=spec, native_background_faults=policy.cfg.faults,
            extra_channel_trials=channel.events, burst_bad_seconds=channel.burst,
            hop_events=no.hop_events, emissions=no.emissions, deliveries=no.delivery_events,
            protocol_events=no.protocol_events, queue_events=no.queue_events)),
            stream, ensure_ascii=False, allow_nan=False)
    write_json(directory/'episode.json', json_safe(record))
    write_json(directory/'complete.json', dict(status='completed',
        sha256={p.name: digest(p) for p in directory.iterdir() if p.is_file()}))
    no.detach()
    return record


def evaluate(preset, output, execute=False):
    if not execute:
        raise ValueError('Formal simulation disabled. Only an explicit --execute starts it.')
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError('Formal evaluation requires CUDA; no silent CPU fallback')
    output = Path(output).resolve()
    if output.exists() or output.is_relative_to(PACKAGE.resolve()):
        raise ValueError('Output must be a NEW directory outside frozen experiment 1')
    verified = verify_package()
    hashes = code_hashes()
    jobs = matrix(preset)
    output.mkdir(parents=True)
    write_json(output/'plan.json', dict(format=FORMAT, preset=preset, jobs=jobs,
        code_hashes=hashes, package=verified, device='cuda', training_steps_executed=0,
        completed_model_training_step=450000, failures_retained=True))
    completed = 0
    policy = env = loaded_strategy = None
    try:
        for profile, strategy, seed in jobs:
            if strategy != loaded_strategy:
                if env is not None:
                    env.close()
                policy, env, factory, _, path = load(strategy, 'cuda')
                loaded_strategy = strategy
            dest = output/profile/strategy/str(seed)
            dest.mkdir(parents=True, exist_ok=False)
            episode(policy, env, factory, strategy, profile, seed, dest)
            completed += 1
            # Append-only progress journal and per-episode completion manifests.
            with (output/'progress.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(dict(completed=completed, total=len(jobs),
                    profile=profile, strategy=strategy, seed=seed, time=time.time()))+'\n')
        if code_hashes() != hashes or verify_package() != verified:
            raise RuntimeError('Frozen source/model/protocol changed during evaluation')
        write_json(output/'complete.json', dict(status='completed', episodes=completed,
            package_unchanged=True, experiment_code_unchanged=True))
    except BaseException as exc:
        write_json(output/'interrupted.json', dict(error=repr(exc), completed=completed,
            note='Retain partial evidence; do not restart or overwrite this directory'))
        raise
    finally:
        if env is not None:
            env.close()
    return dict(status='completed', output=str(output), episodes=completed)
