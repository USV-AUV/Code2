"""Frozen 450k policies: evaluation-only communication fault experiment."""
