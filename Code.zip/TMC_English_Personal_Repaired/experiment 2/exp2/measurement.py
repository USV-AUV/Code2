"""Truth is passive scoring only; routing decisions never receive this module."""
import math
from .protocol import model_for


def ratio(a, b):
    return a / b if b else None


def routing_decision(strategy, policy, env):
    """Delegate only to the selected system's unchanged frozen policy."""
    method = model_for(strategy)
    if policy.method.method_id != method:
        raise ValueError('Routing policy does not match the selected frozen system')
    if env.step_count % env.cfg.slow_period:
        return None
    return policy.topology_action(*env.slow_state()) if policy.topology is not None else None


class Timeline:
    def __init__(self, env, channel):
        self.env, self.channel = env, channel
        self.rows = []
        self.previous_count = len(env.collected)

    def sample(self, telemetry, action):
        env, net = self.env, self.env.network
        now = float(env.time)
        positions = env._positions_3d()  # diagnostics only; no random sampling

        def edge(a, b):
            distance = math.dist(positions[a], positions[b])
            # Structural opportunity, NOT stochastic delivery probability.
            return distance <= net.max_range and not net._is_failed(a, b, now, now+1e-9)

        feasible, installed = [], []
        for source in (1, 2):
            relay = 3-source
            feasible.append(bool(edge(source, 0) or (edge(source, relay) and edge(relay, 0))))
            version = net.active_version[source]
            here, seen, ok = source, set(), True
            while here != 0:
                if here in seen or len(seen) >= 2:
                    ok = False
                    break
                seen.add(here)
                record = net.installed_routes.get(here, {}).get(version)
                if record is None or record[1] < now:
                    ok = False
                    break
                parent = record[0][here-1]
                if not edge(here, parent):
                    ok = False
                    break
                here = parent
            installed.append(ok)
        pending = net.pending
        count = len(env.collected)
        row = dict(time_s=now, topology_request=action, root_parents=list(net.root_parents),
            local_parents={str(k): v for k, v in net.local_parents.items()},
            local_versions={str(k): v for k, v in net.local_versions.items()},
            root_confirmed={str(k): v for k, v in net.root_confirmed.items()},
            pending_version=int(pending['version']) if pending else None,
            pending_parents=list(pending['parents']) if pending else None,
            config_requests=int(net.metrics['config_requests']),
            config_successes=int(net.metrics['config_successes']),
            structural_possible=feasible, installed_path_usable=installed,
            state_aoi_s=telemetry['state_aoi_s'],
            state_no_message=telemetry['state_no_message'],
            fresh30=[not absent and age <= 30. for age, absent in
                     zip(telemetry['state_aoi_s'], telemetry['state_no_message'])],
            collected_packets=count, new_packets=count-self.previous_count,
            positions_xyz=positions.tolist())
        self.previous_count = count
        self.rows.append(row)
        return row


def recovery(rows, origin, horizon, predicate, hold=30, require_disruption=False):
    """One-second grid, 30 consecutive observations; censored != zero latency."""
    selected = [r for r in rows if origin <= r['time_s'] < horizon]
    if not selected:
        return dict(status='not_exposed', recovered=False, latency_s=None, followup_s=0.)
    if require_disruption and all(predicate(r) for r in selected):
        return dict(status='not_disrupted', recovered=False, latency_s=None,
                    followup_s=selected[-1]['time_s']-origin)
    started = not require_disruption
    consecutive = 0
    for row in selected:
        good = predicate(row)
        if not good:
            started = True
        consecutive = consecutive+1 if good and started else 0
        if consecutive >= hold:
            return dict(status='recovered', recovered=True,
                latency_s=row['time_s']-hold+1-origin,
                confirmed_at_s=row['time_s'], followup_s=row['time_s']-origin)
    return dict(status='not_recovered_before_observation_end', recovered=False,
                latency_s=None, followup_s=selected[-1]['time_s']-origin)


def hop_window(hops, kind, start, end):
    # Cohort: actual emission in [start,end), nominal outcome due by end.
    # Inflight right-censoring stays explicit; no failed/censored zero delays.
    all_hops = [h for h in hops if start <= h['time'] < end and h['packet']['kind'] == kind]
    due = [h for h in all_hops if h['nominal_arrival_at'] <= end]
    resolved = [h for h in due if h['outcome_at'] is not None and h['outcome_at'] <= end]
    failures = sum(h['outcome'] != 'arrived_accepted' for h in resolved)
    return dict(started=len(all_hops), due=len(due), resolved=len(resolved), failed=failures,
                right_censored=len(all_hops)-len(resolved), nondelivery=ratio(failures, len(resolved)))


def summarize_event(rows, no, spec, duration):
    onset, clear = spec['onset_s'], spec['clear_s']
    windows = dict(pre=(380., 500.), fault=(onset, clear), post=(clear, 1200.), total=(0., 1200.))
    summary = {}
    for name, (start, end) in windows.items():
        # Endpoint samples cover [time-1,time); avoid assigning onset step's
        # preceding collection to the fault window.
        samples = [r for r in rows if start < r['time_s'] <= end]
        n = 2*len(samples)
        possibles = sum(sum(r['structural_possible']) for r in samples)
        installed = sum(sum(r['installed_path_usable']) for r in samples)
        ages = [a for r in samples for a in r['state_aoi_s']]
        packets = sum(r['new_packets'] for r in samples)
        summary[name] = dict(start_s=start, end_s=end, observed_seconds=len(samples),
            budget_seconds=end-start, collected_packets=packets,
            fixed_window_goodput_bit_s=packets*2048/(end-start),
            aoi_sum_s=sum(ages), aoi_n=len(ages), aoi_mean_s=ratio(sum(ages), len(ages)),
            fresh30_samples=sum(sum(r['fresh30']) for r in samples), auv_samples=n,
            structural_possible_samples=possibles, installed_usable_samples=installed,
            feasible_connectivity=ratio(possibles, n), installed_connectivity=ratio(installed, n),
            installed_given_feasible=ratio(installed, possibles),
            data=hop_window(no.hop_events, 'DATA', start, min(end, duration)),
            state=hop_window(no.hop_events, 'STATE', start, min(end, duration)))
    initial = [0, 0]
    switches = []
    local = {str(i): 0 for i in (1, 2)}
    local_changes = []
    for r in rows:
        if r['root_parents'] != initial:
            switches.append(dict(time_s=r['time_s'], before=initial, after=r['root_parents']))
            initial = r['root_parents']
        if r['local_parents'] != local:
            local_changes.append(dict(time_s=r['time_s'], before=local, after=r['local_parents']))
            local = r['local_parents']
    target = spec['target']-1
    fresh = lambda r: all(r['fresh30'])
    path = lambda r: all(r['installed_path_usable'])
    first_packet = next((r['time_s']-onset for r in rows
                         if r['time_s'] > onset and r['new_packets'] > 0), None)
    boundaries = sorted({onset} | {e['start'] for e in spec['hard_events']})
    events = []
    for i, begin in enumerate(boundaries):
        finish = boundaries[i+1] if i+1 < len(boundaries) else clear
        events.append(dict(onset_s=begin, end_s=finish,
            path_recovery=recovery(rows,begin,finish,path,require_disruption=True),
            fresh_recovery=recovery(rows,begin,finish,fresh,require_disruption=True)))
    return dict(windows=summary, root_parent_switches=switches, local_parent_changes=local_changes,
        fault_interval_recovery=events,
        root_parent_switch_count=len(switches), root_parent_switches_per_minute=60*len(switches)/duration,
        during_fault_path_recovery=recovery(rows, onset, clear, path, require_disruption=True),
        during_fault_fresh_recovery=recovery(rows, onset, clear, fresh, require_disruption=True),
        after_clear_path_recovery=recovery(rows, clear, 1201., path),
        after_clear_fresh_recovery=recovery(rows, clear, 1201., fresh),
        target_fresh_recovery=recovery(rows, onset, clear,
            lambda r: r['fresh30'][target], require_disruption=True),
        first_unique_data_after_onset_s=first_packet,
        fault_exposed=duration > onset, background_faults_retained=True,
        timeline_sampling_s=1., topology_recovery_is_not_fixed_time_guarantee=True)
