"""Offline analysis: whole seed blocks, pooled ratios, explicit missingness."""
import gzip
import json
from pathlib import Path
import statistics

import numpy as np

from .protocol import METHODS, PROFILES, SEEDS, FORMAT
from .runner import digest, write_json


def average(values):
    values = [v for v in values if v is not None]
    return statistics.fmean(values) if values else None


def pooled(rows, window='total'):
    windows = [r['experiment2']['windows'][window] for r in rows]
    def rate(num, den):
        a, b = sum(w[num] for w in windows), sum(w[den] for w in windows)
        return a/b if b else None
    failures = sum(w['data']['failed'] for w in windows)
    resolved = sum(w['data']['resolved'] for w in windows)
    return dict(collected_packets=average([w['collected_packets'] for w in windows]),
        pooled_aoi_s=rate('aoi_sum_s', 'aoi_n'),
        data_nondelivery=failures/resolved if resolved else None,
        data_failed=failures, data_resolved=resolved,
        installed_connectivity=rate('installed_usable_samples', 'auv_samples'),
        installed_given_feasible=rate('installed_usable_samples', 'structural_possible_samples'),
        fresh30_observed=rate('fresh30_samples', 'auv_samples'),
        fresh30_fixed_budget=sum(w['fresh30_samples'] for w in windows)/(2*sum(w['budget_seconds'] for w in windows)),
        aoi_samples=sum(w['aoi_n'] for w in windows),
        full_horizon=sum(r['survived_full_horizon'] for r in rows), episodes=len(rows))


def paired_bootstrap(left, right, window='total', repetitions=4000):
    l = {r['seed']: r for r in left}
    r = {r['seed']: r for r in right}
    if set(l) != set(r):
        raise ValueError('Unpaired scenario seeds; refuse to silently discard cases')
    seeds = sorted(l)
    keys = ('collected_packets', 'pooled_aoi_s', 'data_nondelivery',
            'fresh30_fixed_budget', 'installed_given_feasible')
    p, q = pooled(left, window), pooled(right, window)
    draws = {key: [] for key in keys}
    rng = np.random.default_rng(27092026)
    for _ in range(repetitions):
        selected = rng.choice(seeds, size=len(seeds), replace=True)
        a = pooled([l[int(s)] for s in selected], window)
        b = pooled([r[int(s)] for s in selected], window)
        for key in keys:
            if a[key] is not None and b[key] is not None:
                draws[key].append(a[key]-b[key])
    return {key: dict(difference=(p[key]-q[key] if p[key] is not None and q[key] is not None else None),
                     ci95=np.quantile(values, [.025, .975]).tolist() if values else None,
                     valid_bootstraps=len(values), requested_bootstraps=repetitions,
                     n_scene_pairs=len(seeds), multiplicity_corrected=False)
            for key, values in draws.items()}


def read_trace(directory):
    with gzip.open(directory/'trace.jsonl.gz', 'rt', encoding='utf-8') as stream:
        return [json.loads(line)['experiment2'] for line in stream]


def task_recovery(fault, reference, origin=500., limit=1200.):
    """First sustained, fully POST-origin 120s delivery window versus paired reference.

    Sparse reference (<3 packets in 120s) is not evidence of recovery. No
    zero-latency padding, no extrapolation after failure, and no oracle input.
    """
    f = {r['time_s']: r['collected_packets'] for r in fault}
    b = {r['time_s']: r['collected_packets'] for r in reference}
    f[0.] = b[0.] = 0
    streak = eligible = 0
    for t in sorted(set(f) & set(b)):
        if t < origin+120 or t > limit or t-120 not in f or t-120 not in b:
            continue
        expected = b[t]-b[t-120]
        if expected < 3:
            streak = 0
            continue
        eligible += 1
        streak = streak+1 if f[t]-f[t-120] >= .8*expected else 0
        if streak >= 30:
            return dict(status='recovered', latency_s=t-29-origin, confirmed_at_s=t,
                        eligible_windows=eligible, rolling_window_s=120, hold_s=30)
    return dict(status='not_recovered' if eligible else 'insufficient_common_reference_support',
                latency_s=None, eligible_windows=eligible, rolling_window_s=120, hold_s=30)


def draw_timeline(profile, groups, paths, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(4, 1, figsize=(11, 10), sharex=True)
    for strategy in METHODS:
        key = (profile, strategy)
        if key not in groups:
            continue
        seed = 9620000  # predeclared, never choose the most favorable run
        rows = read_trace(paths[(profile, strategy, seed)])
        t = [r['time_s'] for r in rows]
        axes[0].plot(t, [np.mean(r['state_aoi_s']) for r in rows], label=strategy, linewidth=1)
        axes[1].plot(t, [r['collected_packets']*2.048 for r in rows], linewidth=1)
        axes[2].plot(t, [sum(r['installed_path_usable'])/2 for r in rows], linewidth=.8)
        if strategy == 'full_v6':
            for node in (1, 2):
                axes[3].step(t, [r['local_parents'][str(node)] for r in rows], where='post', label=f'AUV{node} installed parent')
            axes[3].step(t, [r['root_parents'][0] for r in rows], where='post', linestyle='--', label='root confirmed parent of AUV1')
    clear = 620 if profile == 'single_short' else 800
    for axis in axes:
        if profile != 'reference':
            axis.axvspan(500, clear, color='red', alpha=.08)
        if profile == 'alternating':
            axis.axvline(650, color='red', linestyle=':', linewidth=.7)
        axis.grid(alpha=.2)
    for axis, label in zip(axes, ('Mean STATE AoI (s)', 'Unique payload (kbit)', 'Installed usable paths (fraction)', 'Full model parent node ID')):
        axis.set_ylabel(label)
    axes[0].legend(ncol=3, fontsize=7)
    axes[3].legend(fontsize=8)
    axes[3].set_xlabel('Time (s); no extrapolation beyond an early failure')
    fig.suptitle(f'{profile}; preselected scene 9620000; 450k frozen policies')
    fig.tight_layout()
    fig.savefig(output/(profile+'_timeline.png'), dpi=160)
    plt.close(fig)


def analyze_runs(inputs, output):
    output = Path(output).resolve()
    if output.exists():
        raise FileExistsError('Analysis output must be NEW')
    groups, paths, fingerprints = {}, {}, []
    for input_dir in inputs:
        input_dir = Path(input_dir).resolve()
        complete = json.loads((input_dir/'complete.json').read_text(encoding='utf-8'))
        plan = json.loads((input_dir/'plan.json').read_text(encoding='utf-8'))
        validate_jobs(plan)
        if complete['status'] != 'completed' or complete['episodes'] != len(plan['jobs']):
            raise ValueError('Incomplete campaign: preserve partials but do not report final comparisons')
        fingerprints.append((plan['code_hashes'], plan['package'], plan['device']))
        for profile, strategy, seed in plan['jobs']:
            key = (profile, strategy, seed)
            if key in paths:
                raise ValueError('Duplicate episode; do not double-count repeated scenarios')
            directory = input_dir/profile/strategy/str(seed)
            manifest = json.loads((directory/'complete.json').read_text(encoding='utf-8'))
            for name, sha in manifest['sha256'].items():
                if digest(directory/name) != sha:
                    raise ValueError('Episode evidence checksum mismatch')
            row = json.loads((directory/'episode.json').read_text(encoding='utf-8'))
            if (row['profile'], row['strategy'], row['seed']) != key or row['model_step'] != 450000:
                raise ValueError('Episode identity mismatch')
            groups.setdefault((profile, strategy), []).append(row)
            paths[key] = directory
    if not all(f == fingerprints[0] for f in fingerprints):
        raise ValueError('Cannot combine changed experiment versions or backends')
    if any(len(rows) != 30 for rows in groups.values()):
        raise ValueError('Only complete 30-scene groups are reportable')
    output.mkdir(parents=True)
    summaries, comparisons, retentions, recoveries = {}, {}, {}, {}
    for (profile, strategy), rows in groups.items():
        label = profile+'/'+strategy
        summaries[label] = dict(windows={w: pooled(rows, w) for w in ('pre','fault','post','total')},
            metrics75={key: dict(label=m['label'], unit=m['unit'],
                mean=average([r['metrics75'][key]['value'] for r in rows]),
                valid_n=sum(r['metrics75'][key]['value'] is not None for r in rows),
                sample_sd=(statistics.stdev(v) if len(v := [r['metrics75'][key]['value'] for r in rows
                                    if r['metrics75'][key]['value'] is not None]) > 1 else None))
                for key, m in rows[0]['metrics75'].items()},
            early_terminations=[dict(seed=r['seed'], time_s=r['duration_s'], reason=r['termination_reason'])
                                for r in rows if not r['survived_full_horizon']],
            recovery_events=[dict(seed=r['seed'], **r['experiment2']) for r in rows])
        reference = groups.get(('reference', strategy))
        if profile != 'reference' and reference:
            ref = {r['seed']: r for r in reference}
            pairs = [(r, ref[r['seed']]) for r in rows]
            fault_packets, ref_packets = sum(r['collected_packets'] for r in rows), sum(r['collected_packets'] for r in reference)
            retentions[label] = dict(aggregate_packet_retention=fault_packets/ref_packets if ref_packets else None,
                paired_packet_differences=[dict(seed=a['seed'], difference=a['collected_packets']-b['collected_packets']) for a,b in pairs])
            recoveries[label] = [dict(seed=r['seed'], task_recovery=task_recovery(
                read_trace(paths[(profile,strategy,r['seed'])]), read_trace(paths[('reference',strategy,r['seed'])]))) for r in rows]
        if strategy != 'full_v6' and (profile,'full_v6') in groups:
            comparisons[profile+'/full-minus-'+strategy] = {
                window: paired_bootstrap(groups[(profile,'full_v6')], rows, window)
                for window in ('total','fault')}
    write_json(output/'analysis.json', dict(status='completed', episodes=len(paths), groups=summaries,
        paired_differences=comparisons, within_method_fault_retention=retentions,
        paired_task_recovery=recoveries, statistical_scope='Single training seed; paired scene bootstrap; unadjusted pointwise 95% CIs; no automatic superiority verdict',
        input_fingerprint=fingerprints[0]))
    lines = ['# Experiment 2:  45outage', '',
        'pooled/ ; 75episode/standard deviation,  . non-deliveryPER. ', '',
        '|scenario|method|collection/ |pooled AoI/s|DATAnon-delivery/%| /30|', '|---|---|---:|---:|---:|---:|']
    def fmt(x):
        return 'N/A' if x is None else f'{x:.4f}'
    for label, item in summaries.items():
        p = item['windows']['total']
        profile, strategy = label.split('/')
        lines.append(f"|{profile}|{strategy}|{fmt(p['collected_packets'])}|{fmt(p['pooled_aoi_s'])}|{fmt(100*p['data_nondelivery'] if p['data_nondelivery'] is not None else None)}|{p['full_horizon']}|")
    lines += ['', ' ,  metric, failure,  75completemetric  analysis.json. ',
        'system; completeUSDE-only ,  . ',
        ' ; single training seedseedacross training seedsseed .  ,  . ']
    (output/'REPORT_ZH.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    for profile in sorted({p for p,s in groups}):
        draw_timeline(profile, groups, paths, output)
    return dict(status='completed', episodes=len(paths), output=str(output))


def validate_jobs(plan):
    """Reject superseded routing-rule runs and missing system/seed groups."""
    if plan.get('format') != FORMAT:
        raise ValueError('Expected the current five-system experiment format')
    jobs = [tuple(job) for job in plan['jobs']]
    if not jobs or len(set(jobs)) != len(jobs):
        raise ValueError('Missing or duplicate scheduled episodes')
    profiles = {p for p,s,n in jobs}
    if not profiles <= set(PROFILES):
        raise ValueError('Unknown fault profile')
    expected = {(p,s,n) for p in profiles for s in METHODS for n in SEEDS}
    if set(jobs) != expected:
        raise ValueError('Every included profile must contain exactly five systems and 30 paired seeds')
