"""Evaluation-only exogenous channel overlay. Never modifies a frozen file.

The base transmit function is copied into memory with exactly two AST insertions:
add an SNR loss before the existing burst model, and add independent erasures
after the existing hard fault/range test. Queues, airtime, ACK, power, native RNG,
arrival checks, and all MAC subclasses keep their original implementation.
The no-overlay path is the original function object, not a reimplementation.
"""
import ast
from contextlib import contextmanager
import hashlib
import inspect
import math
import textwrap


def uniform(seed, namespace, *key):
    value = '|'.join(map(str, (seed, namespace, *key))).encode('ascii')
    return int.from_bytes(hashlib.sha256(value).digest()[:8], 'big') / 2**64


class Channel:
    def __init__(self, spec, network):
        self.spec, self.network = spec, network
        self.events = []
        self.extra_hard = []
        self.burst = []
        bad = False
        for second in range(1201):
            u = uniform(spec['seed'], 'burst_state', second)
            if not spec['onset_s'] <= second < spec['clear_s']:
                bad = False
            else:
                bad = (u >= 1/15.) if bad else (u < 1/45.)
            self.burst.append(bad)
        for event in spec['hard_events']:
            network.add_fault(**event)
            self.extra_hard.extend([(event['src'], event['dst'], event['start'], event['end']),
                                    (event['dst'], event['src'], event['start'], event['end'])])
        network._experiment2_channel = self

    def erased(self, src, dst, start, finish):
        item = self.spec['erasure']
        if item is None or not self.spec['onset_s'] <= start < self.spec['clear_s']:
            return False
        if item['kind'] == 'iid':
            eligible = src < 3 and dst < 3
        else:
            eligible = {src, dst} == {0, self.spec['target']} and self.burst[int(start)]
        if not eligible:
            return False
        # Counterfactual link-time field, not traffic-count-indexed randomness.
        slot = int(math.floor(start / self.network.slot_duration + 1e-8))
        failed = uniform(self.spec['seed'], 'erasure', slot, src, dst) < item['probability']
        self.events.append(dict(type='extra_erasure_trial', time=start, src=src, dst=dst,
                                slot=slot, probability=item['probability'], erased=failed))
        return failed

    def adjust_per(self, original, src, dst, time, distance, bits, positions):
        drop = self.spec['snr_drop_db']
        if not drop or not self.spec['onset_s'] <= time < self.spec['clear_s']:
            return original
        center, radius = self.spec['snr_region_xy'], self.spec['snr_radius_m']
        # A fixed geographical attenuation zone; every method sees same zone.
        hit = any(math.hypot(float(positions[n, 0])-center[0],
                             float(positions[n, 1])-center[1]) <= radius for n in (src, dst))
        if not hit:
            return original
        net = self.network
        if net.snr_db_at_100m is None:
            raise ValueError('SNR experiment requires the frozen SNR channel model')
        snr = (net.snr_db_at_100m - net.spreading_db * math.log10(max(distance, 1.) / 100.)
               - net.absorption_db_per_km * (distance - 100.) / 1000. - drop)
        ber = .5 * math.erfc(math.sqrt(10.**(snr/10.) * net.bandwidth_hz / net.rate_bps))
        per = 1. - (1.-net.base_per) * (1.-ber)**bits
        self.events.append(dict(type='snr_trial', time=time, src=src, dst=dst,
            distance_m=distance, frame_bits=bits, attenuation_db=drop,
            original_model_per=original, attenuated_model_per=per))
        return per


@contextmanager
def channel_patch(enabled=True):
    from usv_auv.network import AcousticNetwork
    if not enabled:
        yield
        return
    original = AcousticNetwork._transmit_slot
    if getattr(original, '_experiment2_patch', False):
        raise RuntimeError('No nested channel patches or concurrent threaded runs')
    tree = ast.parse(textwrap.dedent(inspect.getsource(original)))
    function = tree.body[0]
    additions = [0, 0]

    class Inject(ast.NodeTransformer):
        def visit_If(self, node):
            self.generic_visit(node)
            if ast.unparse(node.test) == 'self._burst_bad[owner, receiver]':
                additions[0] += 1
                code = ('per = self._experiment2_channel.adjust_per(per, owner, receiver, '
                        'self.time, distance, p.size_bits, xy)')
                return [ast.parse(code).body[0], node]
            return node

        def visit_Assign(self, node):
            self.generic_visit(node)
            if (len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                    and node.targets[0].id == 'success' and '_is_failed' in ast.unparse(node.value)):
                additions[1] += 1
                code = ('extra_erased = self._experiment2_channel.erased(owner, receiver, self.time, arrival)\n'
                        'success = success and not extra_erased')
                return [node, *ast.parse(code).body]
            return node
    tree = Inject().visit(tree)
    if additions != [1, 1]:
        raise RuntimeError('Frozen transmit implementation incompatible: refuse to patch')
    ast.fix_missing_locations(tree)
    namespace = dict(original.__globals__)
    exec(compile(tree, '<experiment2_evaluation_channel>', 'exec'), namespace)
    replacement = namespace[function.name]
    replacement._experiment2_patch = True
    AcousticNetwork._transmit_slot = replacement
    try:
        yield
    finally:
        AcousticNetwork._transmit_slot = original
