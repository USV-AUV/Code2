"""Synthetic-only tests. Never advance a frozen model evaluation environment."""
import copy
import json
from pathlib import Path
import sys
import unittest
import gzip
import tempfile
from types import SimpleNamespace
from unittest.mock import patch, Mock

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from exp2.protocol import SOURCE, matrix, scenario, SEEDS, model_for, METHODS, FORMAT, PROFILES
sys.path.insert(0, str(SOURCE))
import numpy as np
from usv_auv.config import Config
from usv_auv.network import AcousticNetwork, Packet
from scripts.tmc_network_observer import NetworkObserver
from exp2.channel import Channel, channel_patch, uniform
from exp2.measurement import recovery, hop_window, summarize_event, Timeline, routing_decision
from exp2.analysis import pooled, paired_bootstrap, task_recovery
from exp2.runner import evaluate


def network():
    return AcousticNetwork(Config(faults=[]), seed=42)


def positions():
    points = np.zeros((33, 3))
    points[:, 0] = np.arange(33)*.1+100.
    points[:, 1] = 100.
    return points


def synthetic(spec, patched):
    net = network()
    Channel(spec, net)
    with channel_patch(patched):
        no = NetworkObserver(net)
        for node in (1,2):
            net.submit(Packet(node, 0, 'STATE', {'position': [0.,0.]}, size_bits=1536))
        for node in (3,4,5):
            net.submit(Packet(node, 1, 'DATA', {'data_seq':node}, size_bits=2304))
        net.advance(20., positions())
    return no.finalize(20.), copy.deepcopy(net.rng.bit_generator.state), no.hop_events


class ProtocolTests(unittest.TestCase):
    def test_counts_and_no_duplicates(self):
        self.assertEqual(len(matrix('core')), 600)
        self.assertEqual(len(matrix('stress')), 1050)
        self.assertEqual(len(set(matrix('all'))), 1650)
        self.assertEqual(set(matrix('core')) | set(matrix('stress')), set(matrix('all')))

    def test_balanced_targets(self):
        self.assertEqual(sum(scenario('single_long', s)['target']==1 for s in SEEDS), 15)

    def test_no_other_seeds(self):
        for seed in (7, 9570000, 9300000):
            with self.assertRaises(ValueError):
                scenario('single_long', seed)

    def test_weights_mapping(self):
        for name in METHODS:
            self.assertEqual(model_for(name), name)

    def test_removed_controls_are_rejected(self):
        for name in ('full_fixed','full_random','full_heuristic'):
            with self.assertRaises(ValueError):
                model_for(name)
            with self.assertRaises(ValueError):
                routing_decision(name,None,None)

    def test_exact_five_systems_in_every_profile(self):
        jobs = matrix('all')
        for profile in PROFILES:
            self.assertEqual({m for p,m,n in jobs if p==profile},set(METHODS))
            for method in METHODS:
                self.assertEqual([n for p,m,n in jobs if p==profile and m==method],list(SEEDS))

    def test_analysis_rejects_missing_groups_and_old_format(self):
        from exp2.analysis import validate_jobs
        jobs = matrix('core')
        validate_jobs(dict(format=FORMAT,jobs=jobs))
        for bad in (dict(format='experiment2-v1',jobs=jobs),
                    dict(format=FORMAT,jobs=jobs[:-1]),
                    dict(format=FORMAT,jobs=jobs+[jobs[0]]),
                    dict(format=FORMAT,jobs=[(p,'full_fixed' if m=='full_v6' else m,n) for p,m,n in jobs])):
            with self.assertRaises(ValueError):
                validate_jobs(bad)

    def test_run_requires_explicit_execute(self):
        with self.assertRaisesRegex(ValueError, '--execute'):
            evaluate('core', Path('MUST_NOT_BE_CREATED'), False)
        self.assertFalse(Path('MUST_NOT_BE_CREATED').exists())

    def test_all_profiles_valid(self):
        from exp2.protocol import PROFILES
        for profile in PROFILES:
            json.dumps(scenario(profile, SEEDS[0]), allow_nan=False)


class ChannelTests(unittest.TestCase):
    def test_noop_identical_native_counters_deliveries_rng(self):
        spec = scenario('reference', SEEDS[0])
        a, arng, ahops = synthetic(spec, False)
        b, brng, bhops = synthetic(spec, True)
        self.assertEqual(a, b)
        self.assertEqual(arng, brng)
        self.assertEqual(ahops, bhops)

    def test_future_fault_does_not_change_past(self):
        a = synthetic(scenario('reference', SEEDS[0]), False)
        for profile in ('single_long','iid_30','burst','node_radio','snr_12','alternating'):
            with self.subTest(profile=profile):
                self.assertEqual(a, synthetic(scenario(profile, SEEDS[0]), True))

    def test_hard_fault_boundaries_and_reverse(self):
        net = network()
        Channel(scenario('single_short', SEEDS[0]), net)
        self.assertFalse(net._is_failed(0,1,499,500))
        self.assertTrue(net._is_failed(0,1,499.9,500.1))
        self.assertTrue(net._is_failed(1,0,500,501))
        self.assertFalse(net._is_failed(0,1,620,621))
        self.assertFalse(net._is_failed(1,2,500,501))

    def test_node_radio_affects_sn_data_not_other_auv(self):
        net = network()
        Channel(scenario('node_radio', SEEDS[0]), net)
        self.assertTrue(net._is_failed(20,1,550,551))
        self.assertTrue(net._is_failed(1,20,550,551))
        self.assertFalse(net._is_failed(20,2,550,551))

    def test_alternation(self):
        net = network()
        Channel(scenario('alternating', SEEDS[0]), net)
        self.assertTrue(net._is_failed(0,1,600,601))
        self.assertFalse(net._is_failed(0,2,600,601))
        self.assertFalse(net._is_failed(0,1,650,651))
        self.assertTrue(net._is_failed(0,2,650,651))

    def test_extra_field_is_call_order_independent(self):
        a = Channel(scenario('iid_30', SEEDS[0]), network())
        b = Channel(scenario('iid_30', SEEDS[0]), network())
        times = [500+i*.6 for i in range(90)]
        expected = {t:a.erased(0,1,t,t+.2) for t in times}
        actual = {t:b.erased(0,1,t,t+.2) for t in reversed(times)}
        self.assertEqual(expected, actual)
        self.assertTrue(any(expected.values()))
        self.assertFalse(a.erased(3,1,550,551))

    def test_nested_severity(self):
        low = Channel(scenario('iid_10', SEEDS[0]), network())
        high = Channel(scenario('iid_30', SEEDS[0]), network())
        for t in range(500,800):
            self.assertFalse(low.erased(0,1,t,t+.2) and not high.erased(0,1,t,t+.2))

    def test_snr_formula_region_and_window(self):
        ch = Channel(scenario('snr_12', SEEDS[0]), network())
        xy = positions()
        self.assertEqual(ch.adjust_per(.02,0,1,499.,100.,1536,xy), .02)
        self.assertEqual(ch.adjust_per(.02,0,1,800.,100.,1536,xy), .02)
        per = ch.adjust_per(.02,0,1,600.,100.,1536,xy)
        self.assertGreater(per, .02)
        self.assertLessEqual(per, 1.)
        self.assertEqual(ch.adjust_per(.02,0,1,600.,100.,1536,xy+500.), .02)
        self.assertEqual(ch.network.snr_db_at_100m, 18.)

    def test_patch_restored_even_after_error(self):
        original = AcousticNetwork._transmit_slot
        with self.assertRaises(RuntimeError):
            with channel_patch():
                raise RuntimeError('synthetic interruption')
        self.assertIs(AcousticNetwork._transmit_slot, original)

    def test_no_nested_patch(self):
        with channel_patch():
            with self.assertRaises(RuntimeError):
                with channel_patch():
                    pass

    def test_paid_transmission_preserved_when_erased(self):
        net = network()
        ch = Channel(scenario('iid_30', SEEDS[0]), net)
        with patch.object(ch, 'erased', return_value=True), channel_patch():
            no = NetworkObserver(net)
            net.time = 500.
            net.submit(Packet(1,0,'DATA',{'data_seq':0},created_at=500.,size_bits=2304))
            net._transmit_slot(1, positions())
        self.assertEqual(net.metrics['transmissions'], 1)
        self.assertEqual(net.metrics['tx_bits'], 2304)
        self.assertEqual(net.metrics['failed_hops'], 1)
        self.assertGreater(len(net._radio_intervals), 0)
        self.assertEqual(no.hop_events[0]['outcome'], 'failed_at_start')


class MeasurementTests(unittest.TestCase):
    def test_recovery_censoring_and_hold(self):
        rows = [dict(time_s=float(t), good=t>=530) for t in range(500,800)]
        r = recovery(rows, 500.,800.,lambda x:x['good'], require_disruption=True)
        self.assertEqual(r['latency_s'], 30.)
        self.assertEqual(r['confirmed_at_s'], 559.)
        r = recovery(rows[:40], 500.,800.,lambda x:x['good'], require_disruption=True)
        self.assertIsNone(r['latency_s'])
        self.assertFalse(r['recovered'])

    def test_recovery_not_exposed_or_not_disrupted(self):
        self.assertEqual(recovery([],500,800,lambda x:True)['status'],'not_exposed')
        rows = [dict(time_s=float(t)) for t in range(500,800)]
        self.assertEqual(recovery(rows,500,800,lambda x:True,require_disruption=True)['status'],'not_disrupted')

    def test_completion_window_inflight_not_zero_success(self):
        hops = [dict(time=510.,nominal_arrival_at=511.,outcome_at=510.,outcome='failed_at_start',packet={'kind':'DATA'}),
                dict(time=510.,nominal_arrival_at=511.,outcome_at=511.,outcome='arrived_accepted',packet={'kind':'DATA'}),
                dict(time=799.9,nominal_arrival_at=800.2,outcome_at=None,outcome='in_flight',packet={'kind':'DATA'})]
        result = hop_window(hops,'DATA',500,800)
        self.assertEqual((result['failed'],result['resolved'],result['right_censored']),(1,2,1))
        self.assertEqual(result['nondelivery'],.5)
        self.assertIsNone(hop_window([], 'DATA',500,800)['nondelivery'])

    def test_structural_impossible_and_installed_distinction(self):
        net = network()
        ch = Channel(scenario('root_partition',SEEDS[0]),net)
        net.time = 550.
        env = SimpleNamespace(network=net,time=550.,collected=set(),_positions_3d=positions)
        row = Timeline(env,ch).sample({'state_aoi_s':[60.,60.],'state_no_message':[False,False]},None)
        self.assertEqual(row['structural_possible'],[False,False])
        self.assertEqual(row['installed_path_usable'],[False,False])

    def test_original_learned_policy_called_verbatim(self):
        for method in ('full_v6','topology_only_v6'):
            state, mask = np.zeros(4), np.array([True,False,True])
            env = SimpleNamespace(step_count=0,cfg=Config(),slow_state=Mock(return_value=(state,mask)))
            policy = SimpleNamespace(method=SimpleNamespace(method_id=method),topology=object(),
                                     topology_action=Mock(return_value=2))
            self.assertEqual(routing_decision(method,policy,env),2)
            policy.topology_action.assert_called_once_with(state,mask)
            env.step_count = 1
            self.assertIsNone(routing_decision(method,policy,env))
            self.assertEqual(policy.topology_action.call_count,1)

    def test_no_topology_systems_retain_original_none_action(self):
        for method in ('usde_only_v6','synchronous_fim_rl','communication_aware_tmc'):
            env = SimpleNamespace(step_count=0,cfg=Config(),slow_state=Mock(side_effect=AssertionError('not called')))
            policy = SimpleNamespace(method=SimpleNamespace(method_id=method),topology=None)
            self.assertIsNone(routing_decision(method,policy,env))

    def test_task_recovery_sparse_and_rolling(self):
        rows = [dict(time_s=float(t),collected_packets=t//20) for t in range(1,1201)]
        result = task_recovery(rows,rows)
        self.assertEqual(result['latency_s'],120.)
        self.assertEqual(result['confirmed_at_s'],649.)
        empty = [dict(time_s=float(t),collected_packets=0) for t in range(1,1201)]
        self.assertEqual(task_recovery(empty,empty)['status'],'insufficient_common_reference_support')

    def test_pooled_rate_not_mean_of_percentages(self):
        def row(seed, failed, resolved, n, total):
            window = dict(data=dict(failed=failed,resolved=resolved),aoi_sum_s=total,aoi_n=n,collected_packets=10,
                installed_usable_samples=n,auv_samples=n,structural_possible_samples=n,
                fresh30_samples=n,budget_seconds=1200.)
            return dict(seed=seed,collected_packets=10,survived_full_horizon=True,
                        experiment2={'windows':{'total':window}})
        rows = [row(1,1,2,2,2),row(2,0,8,8,24)]
        p = pooled(rows)
        self.assertAlmostEqual(p['data_nondelivery'],.1)
        self.assertAlmostEqual(p['pooled_aoi_s'],2.6)
        pair = paired_bootstrap(rows,rows,repetitions=20)
        self.assertEqual(pair['data_nondelivery']['ci95'],[0.,0.])
        with self.assertRaises(ValueError):
            paired_bootstrap(rows,rows[:1],repetitions=20)

    def test_snr_overlay_exercised_in_real_send_function(self):
        net = network()
        ch = Channel(scenario('snr_12',SEEDS[0]),net)
        with channel_patch():
            no = NetworkObserver(net)
            net.time = 500.
            xy = positions()
            xy[1] = [200.,100.,0.]
            net.submit(Packet(0,1,'TEST',{},created_at=500.,size_bits=1536))
            net._transmit_slot(0, xy)
        self.assertEqual(len(ch.events),1)
        self.assertEqual(ch.events[0]['type'],'snr_trial')
        self.assertGreater(ch.events[0]['attenuated_model_per'],ch.events[0]['original_model_per'])
        self.assertEqual(len(no.hop_events),1)

    def test_no_cross_method_policy_substitution(self):
        policy = SimpleNamespace(method=SimpleNamespace(method_id='full_v6'))
        with self.assertRaises(ValueError):
            routing_decision('usde_only_v6',policy,None)

    def test_short_early_failure_window_no_fabricated_aoi(self):
        net = network()
        spec = scenario('single_long',SEEDS[0])
        ch = Channel(spec,net)
        env = SimpleNamespace(network=net,time=1.,collected=set(),_positions_3d=positions)
        timeline = Timeline(env,ch)
        row = timeline.sample({'state_aoi_s':[1.,1.],'state_no_message':[True,True]},None)
        result = summarize_event([row],SimpleNamespace(hop_events=[]),spec,1.)
        self.assertFalse(result['fault_exposed'])
        self.assertIsNone(result['windows']['fault']['aoi_mean_s'])
        self.assertEqual(result['windows']['fault']['collected_packets'],0)
        self.assertEqual(result['during_fault_fresh_recovery']['status'],'not_exposed')

    def test_renewal_not_counted_as_topology_switch(self):
        net = network()
        spec = scenario('reference',SEEDS[0])
        ch = Channel(spec,net)
        env = SimpleNamespace(network=net,time=1.,collected=set(),_positions_3d=positions)
        timeline = Timeline(env,ch)
        a = timeline.sample({'state_aoi_s':[1.,1.],'state_no_message':[False,False]},0)
        b = copy.deepcopy(a)
        b['time_s'] = 2.
        b['local_versions'] = {'0':1,'1':1,'2':1}
        result = summarize_event([a,b],SimpleNamespace(hop_events=[]),spec,2.)
        self.assertEqual(result['root_parent_switch_count'],0)

    def test_metric_schema_is_original_75(self):
        from scripts.summarize_tmc_retest import selected_specs
        specs = selected_specs()
        self.assertEqual(len(specs),75)
        self.assertEqual(len({s[0] for s in specs}),75)

    def test_stage_collection_is_not_whole_episode_count(self):
        window = dict(collected_packets=3,data=dict(failed=1,resolved=4),aoi_sum_s=60,aoi_n=6,
            installed_usable_samples=6,auv_samples=6,structural_possible_samples=6,
            fresh30_samples=6,budget_seconds=300.)
        row = dict(collected_packets=50,survived_full_horizon=False,experiment2={'windows':{'fault':window}})
        self.assertEqual(pooled([row],'fault')['collected_packets'],3)

    def test_offline_reporting_pipeline_with_synthetic_fixtures(self):
        from exp2.runner import write_json, digest
        from exp2.analysis import analyze_runs
        from scripts.summarize_tmc_retest import selected_specs
        # Pure fabricated fixture, not environment rollout or research evidence.
        with tempfile.TemporaryDirectory(prefix='exp2_synthetic_test_') as temp:
            root = Path(temp)
            data = root/'synthetic_input'
            data.mkdir()
            jobs = [('reference',m,s) for m in METHODS for s in SEEDS]
            write_json(data/'plan.json',dict(format=FORMAT,jobs=jobs,code_hashes={},package={},device='synthetic'))
            for profile,strategy,seed in jobs:
                dest = data/profile/strategy/str(seed)
                dest.mkdir(parents=True)
                window = dict(collected_packets=0,data=dict(failed=0,resolved=0),aoi_sum_s=2,aoi_n=2,
                    installed_usable_samples=2,auv_samples=2,structural_possible_samples=2,
                    fresh30_samples=0,budget_seconds=1200.)
                record = dict(profile=profile,strategy=strategy,seed=seed,model_step=450000,
                    collected_packets=0,survived_full_horizon=False,duration_s=1,termination_reason='SYNTHETIC_ONLY',
                    experiment2={'windows':{w:window for w in ('pre','fault','post','total')}},
                    metrics75={key:dict(label=label,unit=unit,value=None) for key,label,unit,_,_ in selected_specs()})
                write_json(dest/'episode.json',record)
                with gzip.open(dest/'trace.jsonl.gz','xt',encoding='utf-8') as stream:
                    stream.write(json.dumps({'experiment2':dict(time_s=1.,state_aoi_s=[1.,1.],
                        collected_packets=0,installed_path_usable=[True,True],
                        local_parents={'1':0,'2':0},root_parents=[0,0])})+'\n')
                write_json(dest/'complete.json',dict(status='completed',sha256={
                    p.name:digest(p) for p in dest.iterdir()}))
            write_json(data/'complete.json',dict(status='completed',episodes=150))
            with patch('exp2.analysis.paired_bootstrap', side_effect=lambda a,b,w: paired_bootstrap(a,b,w,repetitions=10)):
                result = analyze_runs([data],root/'synthetic_report')
            self.assertEqual(result['episodes'],150)
            self.assertTrue((root/'synthetic_report'/'reference_timeline.png').is_file())
            report = json.loads((root/'synthetic_report'/'analysis.json').read_text(encoding='utf-8'))
            self.assertEqual(len(report['groups']['reference/full_v6']['metrics75']),75)
            self.assertEqual(set(report['groups']),{'reference/'+m for m in METHODS})


if __name__ == '__main__':
    unittest.main()
