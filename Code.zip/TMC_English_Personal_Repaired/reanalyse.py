"""Replay the original statistics without changing archived plans or samples.

The compact release has a new registry. Historical plan registries are provenance,
not a claim that all 500 original files are shipped. Verify the new global registry,
unchanged analysis/environment Python, original plan SHA and all policy SHAs first;
then supply historical provenance to the ORIGINAL analyzer. Every original episode
SHA/identity/denominator check remains active. New simulations never use this bridge.
"""
from pathlib import Path
import argparse
import importlib
import json
import release

ROOT=Path(__file__).resolve().parent
RUNS={2:['core_five_systems_v2_formal_20260920','stress_five_systems_v2_formal_20260920'],
      3:[f'{p}_formal_20260925' for p in ('reference','constant','time_varying','cross_gust','random')],
      5:['formal_20260930'],6:['formal_20260930'],8:['formal_20261001']}

def guard(number):
    manifest=release.verify()
    root=ROOT/f'experiment {number}'
    inputs=[root/'runs'/name for name in RUNS[number]]
    plans=[]
    verified=set()
    for run in inputs:
        rel=(run/'plan.json').relative_to(ROOT).as_posix()
        if release.digest(run/'plan.json')!=manifest['asset_files'][rel]:
            raise ValueError('Archived plan changed')
        plan=release.read(run/'plan.json');plans.append(plan)
        hashes=plan.get('source_hashes',plan.get('code_hashes'))
        for name,sha in hashes.items():
            if not name.endswith('.py'): continue
            name=name.replace('\\','/')
            path=(ROOT if name.startswith('experiment ') else root)/name
            if release.digest(path)!=sha: raise ValueError(f'Original algorithm changed: {name}')
            verified.add(path.relative_to(ROOT).as_posix())
        package=plan.get('experiment1_registry',plan.get('package'))
        for method,sha in package['policies_sha256'].items():
            path=ROOT/'experiment 1'/'models'/'45w'/method/'policy.pt'
            if release.digest(path)!=sha: raise ValueError('Archived model identity changed')
    return inputs,plans,verified

def replay(number,output):
    inputs,plans,verified=guard(number)
    output=Path(output).resolve()
    if output.exists(): raise ValueError('New analysis directory required')
    release.install_paths()
    analysis=importlib.import_module(f'exp{number}.analysis')
    plan=plans[0]
    package=plan.get('experiment1_registry',plan.get('package'))
    hashes=plan.get('source_hashes',plan.get('code_hashes'))
    # Historical provenance only, after the separate release/algorithm guard.
    if hasattr(analysis,'verify_package'): analysis.verify_package=lambda:package
    if hasattr(analysis,'source_hashes'): analysis.source_hashes=lambda:hashes
    if hasattr(analysis,'code_hashes'): analysis.code_hashes=lambda:hashes
    if number==3:
        import compact_exp3
        compact_exp3.verify_package=lambda:package
        compact_exp3.code_hashes=lambda:hashes
        analysis._load_inputs=compact_exp3.compact_load_inputs
    result=analysis.analyze_runs(inputs,output) if number in (2,3) else analysis.analyze(inputs[0],output)
    note=dict(status='passed',unchanged_algorithm_files=len(verified),
              note='Historical 500-file registry is provenance only; new release manifest and unchanged algorithm/models verified separately. Original per-episode SHA and statistics remain active.',
              original_plans=[release.digest(run/'plan.json') for run in inputs], result=result)
    (output/'PORTABILITY_AUDIT.json').write_text(json.dumps(note,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(note,ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--number',type=int,choices=RUNS,required=True)
    parser.add_argument('--output',required=True)
    args=parser.parse_args();replay(args.number,args.output)
