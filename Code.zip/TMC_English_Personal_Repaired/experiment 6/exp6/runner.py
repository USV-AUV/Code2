"""Immutable, resumable evidence runner for frozen-policy mechanism ablation."""
from __future__ import annotations
import argparse
from collections import Counter
import gzip
import json
from pathlib import Path
import sys
import time

from .protocol import (ROOT, EXP1, EXP3, EXP5, SOURCE, FORMAT, HORIZON,
                       MODES, PROFILES, MODEL_FOR, jobs, fault_declaration)

sys.dont_write_bytecode = True
for path in (SOURCE, EXP3, EXP5):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from exp3.runner import digest, verify_package, load, bind
from exp3.measurement import PassiveNetworkObserver
from exp5.runner import sample, verified_complete
from .ablate import make_environment, topology_decision


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def source_hashes():
    paths = sorted((ROOT / "exp6").glob("*.py")) + [ROOT / "PROTOCOL_ZH.md"]
    return {str(path.relative_to(ROOT)): digest(path) for path in paths}


def episode(policy, env, observer_factory, mode, profile, seed, directory, smoke=False):
    import torch
    from usv_auv.learning import seed_all
    from usv_auv.train import json_safe
    from scripts.summarize_tmc_retest import selected_specs

    seed_all(seed)
    observations, info = env.reset(seed=seed)
    bind(policy, env)
    if env.cfg.fingerprint != "48caa5c4f5bf9627":
        raise ValueError("Frozen physical configuration changed")
    for fault in fault_declaration(profile):
        env.network.add_fault(**fault)
    environment_observer = observer_factory(env, info, policy.method)
    network_observer = PassiveNetworkObserver(env.network)
    stats = Counter()
    previous_usv = env.usv_position.copy()
    previous_collected = len(env.collected)
    previous_parents = tuple(env.network.root_parents)
    route_changes = topology_requests = 0
    max_steps = 40 if smoke else HORIZON
    try:
        with gzip.open(directory / "trace.jsonl.gz", "xt", encoding="utf-8") as stream:
            with torch.inference_mode():
                for index in range(max_steps):
                    topology = topology_decision(policy, env, mode)
                    if topology is not None:
                        topology_requests += 1
                    actions = policy.act(observations)
                    observations, reward, terminated, truncated, info = env.step(
                        actions, topology_action=topology)
                    environment_observer.after_step(info)
                    row = sample(env, previous_usv, previous_collected,
                                 env.step_count % env.cfg.slow_period == 0)
                    stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                    stats["aoi_sum_s"] += sum(row["aoi_s"])
                    stats["aoi_n"] += len(row["aoi_s"])
                    stats["local_sum_m"] += sum(row["local_error_m"])
                    stats["local_n"] += len(row["local_error_m"])
                    stats["hold_sum_m"] += sum(x for x in row["hold_error_m"] if x is not None)
                    stats["hold_n"] += sum(x is not None for x in row["hold_error_m"])
                    stats["usable_n"] += sum(row["installed_usable"])
                    stats["path_n"] += len(row["installed_usable"])
                    stats["fim_sum"] += sum(row["fim_logdet"])
                    stats["fim_n"] += len(row["fim_logdet"])
                    stats["usv_path_m"] += row["usv_step_m"]
                    parents = tuple(row["root_parents"])
                    route_changes += parents != previous_parents
                    previous_parents = parents
                    previous_usv = env.usv_position.copy()
                    previous_collected = len(env.collected)
                    if terminated or truncated:
                        break
        duration = float(info["time"])
        metrics = json_safe(info["metrics"])
        network = json_safe(network_observer.finalize(duration))
        if not network["core_counter_reconciliation"]["all_observed_counters_match_core"]:
            raise ValueError("Passive network observer disagrees with core counters")
        if network["logical"]["DATA"]["delivered_unique"] != len(env.collected):
            raise ValueError("Unique collected DATA disagrees with network evidence")
        if mode == "no_route_request" and (topology_requests or
                env.network.metrics.get("config_requests", 0)):
            raise ValueError("No-route intervention emitted a topology request")
        if mode == "no_dynamic_slot_decision" and any(
                env.mac_scheduler_metrics.get(key, 0) for key in
                ("leases_requested", "child_leases_requested")):
            raise ValueError("No-dynamic-slot intervention requested a lease")
        environment = json_safe(environment_observer.finalize())
        packet_bits = env.cfg.data_packet_bits
        record = dict(format=FORMAT, profile=profile, mode=mode, seed=seed,
                      policy_method=MODEL_FOR[mode], model_step=450000,
                      policy_sha256=digest(EXP1 / "models" / "45w" / MODEL_FOR[mode] / "policy.pt"),
                      faults=fault_declaration(profile), steps=index + 1,
                      duration_s=duration, terminated=bool(terminated),
                      truncated=bool(truncated), termination_reason=info["termination_reason"],
                      survived_full_horizon=bool(not terminated and index + 1 == HORIZON),
                      collected_packets=metrics["collected_bits"] / packet_bits,
                      ack_packets=metrics["ack_released_bits"] / packet_bits,
                      collection_fraction=metrics["collected_bits"] /
                          (metrics["initial_bits"] + metrics["arrival_bits"]),
                      goodput_bit_s=metrics["collected_bits"] / duration,
                      fixed_budget_goodput_bit_s=metrics["collected_bits"] / HORIZON,
                      metrics_base=metrics, environment=environment,
                      network={key: value for key, value in network.items() if key not in
                               ("hop_events", "emissions", "generation_events", "delivery_events",
                                "protocol_events", "queue_events")},
                      raw=dict(stats), root_view_route_changes=route_changes,
                      route_changes=route_changes,  # legacy 75-metric/aggregate field: root view only
                      topology_requests=topology_requests,
                      mechanism_diagnostics={key: dict(getattr(env, key)) for key in
                          ("c04_task_metrics", "c06_task_metrics", "c07_task_metrics",
                           "mac_scheduler_metrics") if hasattr(env, key)},
                      formal_experiment=not smoke)
        full_record = dict(record, network=network)
        record["metrics75"] = {key: dict(label=label, unit=unit, value=getter(full_record))
                               for key, label, unit, _, getter in selected_specs()}
        if len(record["metrics75"]) != 75:
            raise ValueError("Established 75-metric schema changed")
        with gzip.open(directory / "network_evidence.json.gz", "xt", encoding="utf-8") as stream:
            json.dump(network, stream, ensure_ascii=False, allow_nan=False)
        write_json(directory / "episode.json", json_safe(record))
        write_json(directory / "complete.json", dict(status="completed", sha256={
            path.name: digest(path) for path in directory.iterdir() if path.is_file()}))
        return record
    finally:
        network_observer.detach()


def run(output, smoke=False, pilot=False):
    import torch
    if smoke and pilot:
        raise ValueError("Select either smoke or pilot")
    if not torch.cuda.is_available():
        raise RuntimeError("Experiment 6 execution requires CUDA")
    output = Path(output).resolve()
    allowed = (ROOT / ("verification" if smoke or pilot else "runs")).resolve()
    if output == allowed or not output.is_relative_to(allowed):
        raise ValueError("Run output must stay in its Experiment 6 category")
    registry, hashes = verify_package(), source_hashes()
    selected_jobs = ([(PROFILES[0], mode, 42) for mode in MODES] if smoke else
                     [(profile, mode, 42) for profile in PROFILES for mode in MODES] if pilot else jobs())
    plan = dict(format=FORMAT, jobs=selected_jobs,
                smoke=smoke, pilot=pilot, source_hashes=hashes, experiment1_registry=registry,
                model_steps=450000, training_steps=0,
                failure_policy="all early terminations retained")
    output.mkdir(parents=True, exist_ok=True)
    plan_path = output / "plan.json"
    if plan_path.exists():
        if json.loads(plan_path.read_text(encoding="utf-8")) != plan:
            raise ValueError("Existing run plan differs; refuse overwrite")
    elif any(output.iterdir()):
        raise ValueError("Nonempty run directory has no plan")
    else:
        write_json(plan_path, plan)
    progress = output / "progress.jsonl"
    policy = env = observer_factory = loaded = None
    try:
        for profile, mode, seed in plan["jobs"]:
            base = output / profile / mode / str(seed)
            attempts = sorted(base.parent.glob(base.name + "__attempt*")) if base.parent.exists() else []
            valid = [path for path in [base] + attempts if verified_complete(path)]
            if len(valid) > 1:
                raise ValueError(f"Duplicate completed job {profile}/{mode}/{seed}")
            if valid:
                continue
            destination = base if not base.exists() else base.parent / (base.name + f"__attempt{len(attempts)+1}")
            if destination.exists():
                raise ValueError("Attempt destination collision")
            required = MODEL_FOR[mode]
            if loaded != required:
                if env is not None:
                    env.close()
                if policy is not None:
                    del policy
                policy, original, observer_factory, checkpoint, path = load(required, "cuda")
                if mode in MODES[:5]:
                    original.close()
                    env = None
                else:
                    env = original
                loaded = required
            if mode in MODES[:5]:
                if env is not None:
                    env.close()
                env = make_environment(policy, mode)
            destination.mkdir(parents=True)
            started = time.monotonic()
            record = episode(policy, env, observer_factory, mode, profile, seed, destination, smoke)
            with progress.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(dict(profile=profile, mode=mode, seed=seed,
                                             destination=str(destination.relative_to(output)),
                                             steps=record["steps"], seconds=time.monotonic()-started),
                                        ensure_ascii=False) + "\n")
        if verify_package() != registry or source_hashes() != hashes:
            raise ValueError("Frozen assets or protocol source changed during run")
        write_json(output / "complete.json", dict(status="completed", count=len(plan["jobs"]),
                   plan_sha256=digest(plan_path)))
    finally:
        if env is not None:
            env.close()


def check(output):
    path = Path(output)
    plan = json.loads((path / "plan.json").read_text(encoding="utf-8"))
    done = 0
    for profile, mode, seed in plan["jobs"]:
        base = path / profile / mode / str(seed)
        if verified_complete(base) or (base.parent.exists() and any(
                verified_complete(attempt) for attempt in base.parent.glob(base.name + "__attempt*"))):
            done += 1
    return dict(done=done, total=len(plan["jobs"]), complete=(path / "complete.json").exists())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("run", "check"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--pilot", action="store_true")
    args = parser.parse_args()
    if args.command == "run":
        run(args.output, args.smoke, args.pilot)
    else:
        print(json.dumps(check(args.output), ensure_ascii=False))


if __name__ == "__main__":
    main()
