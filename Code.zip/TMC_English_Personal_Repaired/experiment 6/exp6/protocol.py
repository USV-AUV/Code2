"""Predeclared Experiment 6 profiles, modes and frozen-policy identities."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
EXP1 = PROJECT / "experiment 1"
EXP3 = PROJECT / "experiment 3"
EXP5 = PROJECT / "experiment 5"
SOURCE = EXP1 / "source"
FORMAT = "experiment6-v6c07-frozen450k-mechanisms-v1"
SEEDS = tuple(range(9660000, 9660030))
PROFILES = ("reference", "direct1_outage", "direct2_outage")
MODES = ("full", "no_c07_admission", "no_peer_intent_use",
         "no_dynamic_slot_decision", "no_route_request",
         "trained_no_usde", "trained_usde_only")
MODEL_FOR = {mode: "full_v6" for mode in MODES[:5]} | {
    "trained_no_usde": "topology_only_v6", "trained_usde_only": "usde_only_v6",
}
HORIZON = 1200
FAULT_START, FAULT_END = 400., 800.


def jobs():
    return [(profile, mode, seed) for profile in PROFILES for mode in MODES for seed in SEEDS]


def fault_declaration(profile):
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    if profile == "reference":
        return []
    node = 1 if profile == "direct1_outage" else 2
    return [dict(src=node, dst=0, start=FAULT_START, end=FAULT_END, bidirectional=True)]
