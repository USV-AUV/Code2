"""Narrow runtime interventions on the frozen full V6-C07 environment."""
from .protocol import MODES


def make_environment(policy, mode):
    if mode not in MODES[:5] or policy.method.method_id != "full_v6":
        raise ValueError("Runtime intervention requires frozen full V6-C07 policy")
    from v6_candidates.c07.environment import TaskV4Env, MethodOptions
    from v6_candidates.c07.routing import RoutingOptions

    class AblatedEnvironment(TaskV4Env):
        def _admission_active(self):
            if mode == "no_c07_admission":
                return False
            return super()._admission_active()

        def _peer_reservations(self, i, distances):
            if mode == "no_peer_intent_use":
                return set()
            return super()._peer_reservations(i, distances)

        def _received_peer_targets(self, i):
            if mode == "no_peer_intent_use":
                return set()
            return super()._received_peer_targets(i)

        def _mac_tick(self):
            if mode == "no_dynamic_slot_decision":
                return  # Initial static TDMA ownership and all traffic remain.
            return super()._mac_tick()

    env = AblatedEnvironment(policy.cfg, policy.method.method_id,
                            MethodOptions(**policy.checkpoint["method_options"]),
                            RoutingOptions(**policy.checkpoint["routing_options"]))
    policy.validate_environment(env)
    return env


def topology_decision(policy, env, mode):
    if env.step_count % env.cfg.slow_period or mode == "no_route_request":
        return None
    return policy.topology_action(*env.slow_state()) if policy.topology is not None else None
