"""Frozen V6-C07 mechanism ablations; no training code."""
