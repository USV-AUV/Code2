"""SHA-verified, paired analysis of all Experiment 6 mechanisms."""
from __future__ import annotations
import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import sys

from .protocol import ROOT, EXP5, EXP3, SOURCE, FORMAT, MODES, PROFILES, MODEL_FOR, jobs

for path in (SOURCE, EXP3, EXP5):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from exp5.analysis import aggregate, paired_ci
from .runner import digest, source_hashes, verified_complete, verify_package, write_json

LABELS = {
    "full": "Full V6-C07",
    "no_c07_admission": "Disable C07 admission and local yielding",
    "no_peer_intent_use": "Ignore received peer task intents",
    "no_dynamic_slot_decision": "Disable new dynamic slot leases",
    "no_route_request": "Disable dynamic topology requests",
    "trained_no_usde": "Trained no-USDE, full coordination",
    "trained_usde_only": "Trained USDE-only with static direct routes",
}
METRICS = ("packets_per_episode", "pooled_aoi_s", "data_hop_nondelivery",
           "installed_connectivity", "local_mae_m", "usv_cache_mae_m")
BOOTSTRAP_SEED = 30092026


def read_rows(run):
    plan = json.loads((run / "plan.json").read_text(encoding="utf-8"))
    if plan.get("format") != FORMAT or plan.get("smoke") or plan["jobs"] != [list(x) for x in jobs()]:
        raise ValueError("Wrong formal run plan")
    if plan["source_hashes"] != source_hashes() or plan["experiment1_registry"] != verify_package():
        raise ValueError("Frozen code or model registry changed")
    complete = json.loads((run / "complete.json").read_text(encoding="utf-8"))
    if complete != dict(status="completed", count=len(jobs()), plan_sha256=digest(run / "plan.json")):
        raise ValueError("Run completion marker disagrees")
    rows = []
    for profile, mode, seed in jobs():
        base = run / profile / mode / str(seed)
        candidates = [base] + sorted(base.parent.glob(base.name + "__attempt*"))
        valid = [path for path in candidates if verified_complete(path)]
        if len(valid) != 1:
            raise ValueError(f"Expected one completed episode: {profile}/{mode}/{seed}")
        row = json.loads((valid[0] / "episode.json").read_text(encoding="utf-8"))
        if (row["format"], row["profile"], row["mode"], row["seed"],
                row["model_step"], row["policy_method"]) != (
                FORMAT, profile, mode, seed, 450000, MODEL_FOR[mode]):
            raise ValueError("Episode/model identity mismatch")
        if len(row["metrics75"]) != 75 or row["terminated"] == row["truncated"]:
            raise ValueError("Metric schema or termination record invalid")
        if not math.isclose(row["raw"]["aoi_n"], 2 * row["steps"]):
            raise ValueError("AoI denominator does not match actual AUV-seconds")
        if row["raw"]["path_n"] != 2 * row["steps"]:
            raise ValueError("Installed-path denominator mismatch")
        if row["network"]["logical"]["DATA"]["delivered_unique"] != row["collected_packets"]:
            raise ValueError("DATA collection reconciliation failed")
        rows.append(row)
    if len({tuple(sorted(row["metrics75"])) for row in rows}) != 1:
        raise ValueError("75-metric keys not identical across groups")
    return rows, plan


def fmt(value, digits=2):
    return "N/A" if value is None else f"{value:.{digits}f}"


def interval(item, scale=1., digits=2):
    if item["difference"] is None:
        return "N/A"
    lo, hi = item["ci95"]
    return f"{fmt(scale*item['difference'], digits)} [{fmt(scale*lo, digits)}, {fmt(scale*hi, digits)}]"


def analyze(run, output):
    run, output = Path(run).resolve(), Path(output).resolve()
    allowed = (ROOT / "reports").resolve()
    if output == allowed or not output.is_relative_to(allowed) or output.exists():
        raise ValueError("Report must use a NEW Experiment 6 report directory")
    rows, plan = read_rows(run)
    indexed = defaultdict(list)
    for row in rows:
        indexed[(row["profile"], row["mode"])].append(row)
    groups = {profile: {mode: aggregate(indexed[profile, mode]) for mode in MODES}
              for profile in PROFILES}
    paired = {}
    for p, profile in enumerate(PROFILES):
        paired[profile] = {}
        for i, mode in enumerate(MODES[1:]):
            paired[profile][mode] = {
                metric: paired_ci(indexed[profile, "full"], indexed[profile, mode],
                                  metric, BOOTSTRAP_SEED + p*1000 + i*20 + j)
                for j, metric in enumerate(METRICS)}
    output.mkdir(parents=True)
    write_json(output / "analysis.json", dict(format=FORMAT, rows=len(rows),
               profiles=groups, full_minus_ablation=paired,
               bootstrap_repetitions=3000, bootstrap_seed=BOOTSTRAP_SEED))
    write_json(output / "audit.json", dict(status="passed", unique_jobs=len(rows),
               distinct_keys=len({(r["profile"], r["mode"], r["seed"]) for r in rows}),
               every_episode_sha_verified=True, all_failures_retained=True,
               model_steps=sorted({r["model_step"] for r in rows}),
               policy_sha256={mode: next(r["policy_sha256"] for r in rows if r["mode"] == mode)
                              for mode in MODES},
               source_hashes=plan["source_hashes"], plan_sha256=digest(run / "plan.json")))
    lines = [
        "#  : V6-C07  ", "",
        " ×scenario×30  ,   630 episode; failure,   45  , training. ", "",
        "complete,  ; training system,  . ",
        "DATA non-delivery ratio, outage,   PER. ", "",
    ]
    for profile in PROFILES:
        lines += [f"## {profile}", "",
            "|   |  /episode↑ | pooled AoI/s↓ | DATAnon-delivery↓ |  ↑ | local localizationMAE/m↓ | USV MAE/m↓ | USV /m↓ | energy/kJ↓ | topology/episode |  /30 |",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for mode in MODES:
            g = groups[profile][mode]
            lines.append("| " + " | ".join((LABELS[mode], fmt(g["packets_per_episode"]),
                fmt(g["pooled_aoi_s"]),
                f"{fmt(100*g['data_hop_nondelivery'] if g['data_hop_nondelivery'] is not None else None)}% ({g['raw']['data_failed']}/{g['raw']['data_resolved']})",
                fmt(100*g["installed_connectivity"]), fmt(g["local_mae_m"]),
                fmt(g["usv_cache_mae_m"]), fmt(g["usv_path_m"]),
                fmt(g["total_energy_kj"]), fmt(g["actual_route_changes"]),
                str(g["survived"]))) + " |")
        lines += ["", "complete;   95%   ( ): ", "",
                  "|   | collection/  | pooled AoI /s | DATAnon-delivery/  |",
                  "|---|---:|---:|---:|"]
        for mode in MODES[1:]:
            c = paired[profile][mode]
            lines.append("| " + " | ".join((LABELS[mode],
                interval(c["packets_per_episode"]),
                interval(c["pooled_aoi_s"]),
                interval(c["data_hop_nondelivery"], 100.))) + " |")
        lines.append("")
    lines += [
        "complete, localization analysis.json;   75  metriccomplete runs. ", "",
        " : single training seed;  , training method. ",
        "  Fixed-Time  ;  . ",
        "topologynodelocal;  . ",
        " , scenariometric. ", ""
    ]
    (output / "REPORT_ZH.md").write_text("\n".join(lines), encoding="utf-8")
    return len(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(dict(episodes=analyze(args.run, args.output)), ensure_ascii=False))


if __name__ == "__main__":
    main()
