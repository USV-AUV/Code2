import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT, ROOT.parent / "experiment 1" / "source"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from exp6.protocol import MODES, MODEL_FOR, PROFILES, SEEDS, jobs, fault_declaration


class ProtocolTest(unittest.TestCase):
    def test_matrix_is_complete_and_unique(self):
        self.assertEqual(len(MODES), 7)
        self.assertEqual(len(PROFILES), 3)
        self.assertEqual(len(SEEDS), 30)
        self.assertEqual(len(jobs()), 630)
        self.assertEqual(len(set(jobs())), 630)
        self.assertEqual({MODEL_FOR[m] for m in MODES},
                         {"full_v6", "topology_only_v6", "usde_only_v6"})

    def test_faults_are_paired_and_bounded(self):
        self.assertEqual(fault_declaration("reference"), [])
        one = fault_declaration("direct1_outage")
        two = fault_declaration("direct2_outage")
        self.assertEqual(one[0]["src"], 1)
        self.assertEqual(two[0]["src"], 2)
        self.assertEqual((one[0]["start"], one[0]["end"]), (400., 800.))
        with self.assertRaises(ValueError):
            fault_declaration("unknown")

    def test_no_fixed_time_pseudomode(self):
        self.assertFalse(any("fixed_time" in mode for mode in MODES))


if __name__ == "__main__":
    unittest.main()
