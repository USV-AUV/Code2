# Repairs and changes

- Eliminated the corrupted `archived result note` fragments left by an earlier automatic English localization in report-generating scripts.
- Replaced the two most visible legacy result-report renderers with coherent English summaries, retaining their underlying numerical calculations.
- Added a strict, byte-exact compatibility registry to explain and validate English-source translations used alongside original model checkpoints.
- Fixed the main CPU smoke path to work with approved source translations, without editing the trained model weights.
- Changed the no-data `audit-data` result from a misleading empty PASS to `not_included`.
- Made the training seed an explicit command-line option; no historical multi-seed runs were invented.
- Added a manuscript evidence-scope note to distinguish supplied aggregates from independently reconstructed raw-trial statistics.
- Retained fixed-scope convenience views. Experiments 2, 3 and 8 now include all their recorded scenarios without a performance-based predicate.

## Scenario-complete result tables (2026-11-10)

- Removed the former post-hoc three-way performance predicate from `selected_results/selection_manifest.json`.
- Restored all 11 acoustic-fault and all 10 combined-stress conditions in the paired summary CSVs; all 13 current scenarios were already present.
- Included seven available aggregate tables with current-package checksum registrations.
- Updated documentation and release file hashes. Scientific code, trained weights, and the current CSVs remain unchanged by this documentation-only edit.
- Legacy `_selected.csv` file names were retained to avoid disrupting previously referenced paths.

## Current aggregate hash baseline reconciliation (2026-11-10)

- Accepted all existing aggregate CSV values as the current authoritative snapshot on explicit user confirmation; no CSV, checkpoint, or scientific simulator bytes were edited.
- Set the current upload `Code(20261110-124257).zip` as the active version source in `selected_results/selection_manifest.json`. `packaged_table_sha256` is the current-only checksum reference.
- Moved the older archive hash identifiers out of the active selection manifest into `selected_results/table_version_history.json`. They remain available for historical provenance and are not falsely described as matching the current CSVs.
- Added `CURRENT_TABLE_CHECKSUMS.sha256` and `python release.py verify-summaries`, and integrated canonical summary checks into `python release.py verify`.
- Regenerated the top-level release file hashes for the changed metadata, documentation, and verifier. Old-version differences do not trigger current integrity failures. This does not constitute independent episode-level data validation.
