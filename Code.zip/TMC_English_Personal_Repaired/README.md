# USV–AUV Research Code: English Personal Review Edition (Repaired)

**Scope:** a private English study edition with all recorded Experiment 2, 3 and 8 scenarios in the paired Full/USDE views, regardless of performance. Complete available source-derived aggregate tables are also included. This is not a full per-episode experimental archive or a replacement for the original reproducibility release; summary-level values have not been independently reconstructed from raw episodes.

## Included components

- Two-AUV simulator, TD3 and masked Double DQN, receiver-local routing and service/resource allocation (`experiment 1/source/`).
- Five frozen 450k-step policies plus the archived Experiment 7 models; model-weight bytes have not been modified.
- Experiment-specific acoustic-link, current, schedule, ablation, fleet and joint-stress modules.
- Unfiltered, scenario-complete Full/USDE paired summary tables and all seven current accepted aggregate reports (legacy directory name) in `selected_results/all_original_summary_tables/`. See `selected_results/SELECTION_README.md` for exact coverage.
- A narrowly scoped source-translation compatibility registry in `experiment 1/source/source_translation_registry.json`.

## Start here

From the extracted project directory:

```bash
python release.py verify
python release.py verify-summaries
python release.py smoke
python release.py audit-data --category all
python "experiment 7/latest.py" verify
```

`verify` checks the release files, current canonical seven-table hashes, and the source translation registry. `verify-summaries` checks the current user-confirmed aggregate table hashes only. The older original-source checksums are preserved as superseded version history in `selected_results/table_version_history.json` and must not be compared to current files. `smoke` performs a short CPU policy/simulation interface check (seed 42, not an official experiment). The former model/source byte-hash mismatch from English translation is reconciled only for exact hash-registered files; it does **not** mean the translated source is byte-identical to the historical training source. Other code modifications still fail validation. This is a functional interface check, not a reproduction of 450,000 training steps or 5,760 formal episodes.

`audit-data` returns `not_included` because the separate raw-data asset archives were not provided inside this ZIP. It does not return a misleading zero-file success.

Use `python release.py train --help` to see the optional `--seed` argument. Adding this option does not create missing historical multi-seed training runs, checkpoints, or results. Some older experiment entry points still require external archived data, legacy protocol documents and GPU resources; their full reproduction is outside this personal review package.

## Manuscript correspondence

The compact main comparison lists **63.90 vs 50.20** accepted sensor packets and **12.30 vs 15.85 s** pooled STATE AoI at the summary level. These are supplied aggregates, not independently reconstructed raw-trial statistics.

The available training artifacts identify seed 7; independent training-run claims require their corresponding external training records. See `MANUSCRIPT_ALIGNMENT.md` for the evidence scope.

The paired Experiment 2/3/8 views now include **all recorded conditions**, without performance-based outcome filtering; available aggregate tables include the other methods and metrics. Smaller convenience tables for mechanisms, fleet and highlight metrics remain fixed-scope. The supplied package lacks full per-episode raw data, so do not present aggregate tables as independently reproduced trials or as proof of universal superiority. For publication-grade reproducibility, retain and release the original code, per-episode data and provenance.

## Code localization note

Original checkpoint metadata contains hashes of historical byte-exact sources. Some old human-facing report strings were translated into English, changing those bytes. Instead of removing the provenance check, a registry records the exact pair of original and localized hashes and maps them only for checkpoint compatibility. The scientific model weights, actor/critic architectures and packet-level dynamics were not modified here. Only a short interface smoke test was performed; complete experimental replication requires the historical research release and external assets.

## Experiment 7 test scope

Run `cd "experiment 7" && python -m unittest test_portability -v`. The independent raw-300-episode test is **skipped** (not falsely passed) when the external `results/` archives are absent. The isolation import test runs in a fresh interpreter so host-preloaded scientific libraries do not produce a false failure.

## Additional historical tests

The large Experiment 7 source-level suite is not covered by the completed portability smoke. Its earlier fixture issues and an incomplete long-running test attempt are described in `VERIFICATION_REPORT.md`; do not describe that entire historical suite as passing.
