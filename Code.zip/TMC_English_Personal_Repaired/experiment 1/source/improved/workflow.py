"""Versioned CUDA training and frozen evaluation; never overwrite old runs.

No runtime controller: actors output final normalized speed and heading.
--steps is additional on resume; a resume always starts a NEW physical episode.
"""
from __future__ import annotations
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time
import uuid
import numpy as np
import torch

from usv_auv.config import Config
from usv_auv.deploy import environment_schema, load_checkpoint
from usv_auv.actions import action_encoding
from usv_auv.observations import observation_fields, root_observation_fields
from usv_auv.learning import LearningConfig, MaskedDoubleDQN, mlp, resolve_device, seed_all, rng_state, restore_rng
from usv_auv.train import atomic_json, atomic_save, require_finite, file_digest, store_completed_macro
from baselines.train import gpu_diagnostics, parameter_digests
from .environment import ImprovedEnv, MethodOptions, SERVICE_FIELDS
from .routing import RoutingOptions, root_feature_names
from .learning import ImprovedTD3Agent, RevisionLearningOptions

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / 'runs/research_collection_v2_1m_20260909/frozen_config.json'


def sources():
    return {str(p.relative_to(ROOT)).replace('\\', '/'): file_digest(p)['sha256']
            for package in ('usv_auv', 'baselines', 'improved')
            for p in sorted((ROOT / package).glob('*.py'))}


def new_output(path):
    output = Path(path).resolve()
    output.mkdir(parents=True, exist_ok=False)
    return output


def export(checkpoint):
    result = {key: value for key, value in checkpoint.items()
              if key not in ('agents', 'topology', 'rng', 'exploration_rng')}
    result['format'] = 'collection-v3-inference-v1'
    result['agents'] = [{'actor': a['actor']} for a in checkpoint['agents']]
    result['topology'] = {'online': checkpoint['topology']['online']}
    return result


def save_bundle(checkpoint, output, milestone=False):
    if not milestone:
        atomic_save(checkpoint, output / 'checkpoint_latest.pt')
        atomic_save(export(checkpoint), output / 'policy_inference.pt')
        return
    import os
    import tempfile
    destination = output / 'milestones' / f"step_{checkpoint['global_step']:07d}"
    destination.parent.mkdir(exist_ok=True)
    if destination.exists():
        raise FileExistsError('Refusing to overwrite a revision milestone')
    with tempfile.TemporaryDirectory(prefix='.stage_', dir=destination.parent) as directory:
        staging = Path(directory)
        atomic_save(checkpoint, staging / 'checkpoint.pt')
        atomic_save(export(checkpoint), staging / 'policy.pt')
        atomic_json({key: checkpoint[key] for key in ('run_id', 'global_step', 'config_fingerprint',
                    'method_options', 'routing_options', 'revision_learning_options', 'source_hashes', 'observation_schema')}
                    | {'files': {name: file_digest(staging / name) for name in ('checkpoint.pt', 'policy.pt')}},
                    staging / 'metadata.json')
        os.rename(staging, destination)


class Policy:
    def __init__(self, checkpoint, device='cuda', verify=True):
        if checkpoint['format'] not in ('collection-v3-training-v1', 'collection-v3-inference-v1'):
            raise ValueError('Not a revision checkpoint')
        self.checkpoint = checkpoint
        if verify and checkpoint['source_hashes'] != sources():
            raise ValueError('Frozen revision source hashes differ')
        self.cfg = Config.from_dict(checkpoint['environment_config'])
        if self.cfg.fingerprint != checkpoint['config_fingerprint']:
            raise ValueError('Config fingerprint mismatch')
        self.device = resolve_device(device)
        self.schema = checkpoint['observation_schema']
        if len(checkpoint['agents']) != self.cfg.n_auv or self.schema['n_auv'] != self.cfg.n_auv:
            raise ValueError('Checkpoint AUV count mismatch')
        expected_local = observation_fields(self.cfg.n_auv) + list(SERVICE_FIELDS)
        expected_root = root_observation_fields(self.cfg.n_auv) + list(root_feature_names(self.cfg.n_auv))
        if (self.schema['version'] != ImprovedEnv.observation_schema_version or
            self.schema['fields'] != expected_local or self.schema['slow_fields'] != expected_root or
            self.schema['observation_dim'] != len(expected_local) or self.schema['slow_observation_dim'] != len(expected_root) or
            self.schema['action_encoding'] != action_encoding(self.cfg.action_frame)):
            raise ValueError('Revision checkpoint schema/action encoding mismatch')
        for saved in checkpoint['agents']:
            require_finite('actor weights', saved['actor'])
        require_finite('topology weights', checkpoint['topology']['online'])
        hidden = checkpoint['learning_config']['hidden_dim']
        self.actors = [mlp(self.schema['observation_dim'], 2, hidden, True).to(self.device)
                       for _ in range(self.cfg.n_auv)]
        for actor, state in zip(self.actors, checkpoint['agents']):
            actor.load_state_dict(state['actor']); actor.eval().requires_grad_(False)
        self.topology = mlp(self.schema['slow_observation_dim'], self.schema['topology_actions'], hidden).to(self.device)
        self.topology.load_state_dict(checkpoint['topology']['online'])
        self.topology.eval().requires_grad_(False)

    def make_environment(self):
        env = ImprovedEnv(self.cfg, MethodOptions(**self.checkpoint['method_options']),
                          RoutingOptions(**self.checkpoint['routing_options']))
        if environment_schema(env) != self.schema:
            raise ValueError('Revision schema mismatch')
        return env

    def act(self, observations):
        values = np.asarray(observations, np.float32)
        if values.shape != (len(self.actors), self.schema['observation_dim']) or not np.isfinite(values).all():
            raise ValueError('Bad inference observations')
        with torch.inference_mode():
            return np.stack([a(torch.as_tensor(values[i], device=self.device)).cpu().numpy()
                             for i, a in enumerate(self.actors)])

    def topology_action(self, state, mask):
        state, mask = np.asarray(state, np.float32), np.asarray(mask, bool)
        if state.shape != (self.schema['slow_observation_dim'],) or not np.isfinite(state).all():
            raise ValueError('Bad slow state')
        if mask.shape != (self.schema['topology_actions'],) or not mask.any():
            raise ValueError('Bad routing mask')
        with torch.inference_mode():
            q = self.topology(torch.as_tensor(state, device=self.device))
            return int(q.masked_fill(~torch.as_tensor(mask, device=self.device), -torch.inf).argmax().item())


def train(args):
    if args.steps < 1 or (args.steps > 200 and not args.allow_long_run):
        raise ValueError('Long training needs --allow-long-run')
    if args.checkpoint_every < 1 or args.log_every < 1:
        raise ValueError('Logging and checkpoints must be positive')
    device = resolve_device(args.device)
    if device.type != 'cuda':
        raise ValueError('Research training requires CUDA')
    saved = load_checkpoint(args.resume) if args.resume else None
    frozen = sources()
    if saved and (saved['format'] != 'collection-v3-training-v1' or saved['source_hashes'] != frozen):
        raise ValueError('Resume requires matching full revision checkpoint/source')
    cfg = Config.load(args.config)
    start_step = int(saved['global_step']) if saved else 0
    requested = list(args.milestones)
    if (len(requested) != len(set(requested)) or
        any(type(s) is not int or not start_step < s <= start_step + args.steps for s in requested)):
        raise ValueError('Milestones must be unique and within the additional training interval')
    if saved and len(saved['agents']) != cfg.n_auv:
        raise ValueError('Resume checkpoint AUV count mismatch')
    smoke = bool(getattr(args, 'smoke', False))
    if smoke and (args.steps > 200 or saved):
        raise ValueError('Smoke overrides only allowed for a fresh <=200-step run')
    if saved and cfg.to_dict() != saved['environment_config']:
        raise ValueError('Cannot change physical config on resume')
    method = MethodOptions(**saved['method_options']) if saved else MethodOptions()
    routing = RoutingOptions(**saved['routing_options']) if saved else RoutingOptions()
    options = RevisionLearningOptions(**saved['revision_learning_options']) if saved else RevisionLearningOptions(
        area_size=cfg.area_size, max_speed=cfg.max_speed, dt=cfg.dt, action_frame=cfg.action_frame)
    learning = LearningConfig(**saved['learning_config']) if saved else LearningConfig(
        hidden_dim=cfg.hidden_dim, gamma=cfg.gamma, tau=cfg.tau, batch_size=cfg.batch_size,
        replay_capacity=cfg.replay_size, topology_capacity=20000, topology_batch_size=32,
        actor_lr=cfg.learning_rate, critic_lr=cfg.learning_rate, topology_lr=cfg.learning_rate,
        policy_noise=cfg.policy_noise, noise_clip=cfg.noise_clip, policy_delay=cfg.policy_delay)
    seed = int(saved['seed']) if saved else (7 if args.seed is None else args.seed)
    seed_all(seed)
    env = ImprovedEnv(cfg, method, routing)
    episode = int(saved['episode']) + 1 if saved else 0
    obs, info = env.reset(seed + episode)
    agents = [ImprovedTD3Agent(env.observation_dim, 2, learning, str(device), seed + 101 * (i + 1), options=options)
              for i in range(cfg.n_auv)]
    topology = MaskedDoubleDQN(env.slow_observation_dim, env.network.n_actions, learning, str(device), seed + 10001)
    exploration = np.random.default_rng(seed + 33333)
    if saved:
        for state in saved['agents']:
            for name in ('actor','critic','actor_target','critic_target'):
                require_finite('saved learning weights', state[name])
        for name in ('online','target'): require_finite('saved topology weights', saved['topology'][name])
        for agent, state in zip(agents, saved['agents']): agent.load_state_dict(state)
        topology.load_state_dict(saved['topology']); restore_rng(saved['rng'])
        exploration.bit_generator.state = saved['exploration_rng']
    output = new_output(args.output)
    cfg.save(output / 'frozen_config.json')
    step = int(saved['global_step']) if saved else 0
    stop = step + args.steps
    run_id = saved['run_id'] if saved else str(uuid.uuid4())
    started = time.monotonic()
    previous_elapsed = saved.get('elapsed_seconds', 0.) if saved else 0.
    milestones = sorted(requested)
    manifest = dict(format='collection-v3-training-v1', run_id=run_id, seed=seed,
                    config_fingerprint=cfg.fingerprint, environment_config=cfg.to_dict(),
                    method_options=asdict(method), routing_options=asdict(routing),
                    revision_learning_options=asdict(options), learning_config=asdict(learning),
                    observation_schema=environment_schema(env), source_hashes=frozen,
                    parent_checkpoint=str(Path(args.resume).resolve()) if saved else None,
                    resume_mode='new_physical_episode_learning_resume' if saved else 'fresh',
                    training_protocol={'td3_every_fast_step': True, 'replay_reset': False,
                        'smoke_overrides': smoke, 'warmup_steps': 16 if smoke else cfg.warmup_steps,
                        'topology_warmup_steps': 40 if smoke else 20000, 'topology_task_weight': .2,
                        'topology_age_weight': .1, 'topology_request_cost': .1},
                    device=str(device), gpu=torch.cuda.get_device_name(device), target_step=stop)
    initial_digest = parameter_digests(agents, topology)
    atomic_json(manifest, output / 'manifest.json')
    if saved and saved['training_protocol'] != manifest['training_protocol']:
        raise ValueError('Cannot change training protocol on resume')
    warmup = manifest['training_protocol']['warmup_steps']
    topology_warmup = manifest['training_protocol']['topology_warmup_steps']
    pending = None
    losses, episode_return = {}, 0.

    def payload():
        return manifest | dict(global_step=step, episode=episode,
            elapsed_seconds=previous_elapsed + time.monotonic() - started,
            agents=[a.state_dict() for a in agents], topology=topology.state_dict(),
            rng=rng_state(), exploration_rng=exploration.bit_generator.state)

    def progress(status='running'):
        return dict(status=status, run_id=run_id, global_step=step, target_step=stop,
                    elapsed_seconds=previous_elapsed + time.monotonic() - started,
                    td3_updates=[a.updates for a in agents], ddqn_updates=topology.updates,
                    losses=losses, info=info)

    atomic_json(progress(), output / 'progress.json')
    try:
        with (output / 'training.jsonl').open('x', encoding='utf-8') as log:
            while step < stop:
                action_topo = None
                if pending is None:
                    slow, mask = env.slow_state()
                    epsilon = max(.03, .25 * math_exp(-max(0, step - 20000) / 100000))
                    action_topo = 0 if step < topology_warmup else topology.act(slow, mask, epsilon)
                    pending = dict(state=slow.copy(), mask=mask.copy(), action=action_topo, reward=0., duration=0)
                noise = max(.03, cfg.exploration_noise * (1. - min(step / 500000., 1.)))
                actions = (exploration.uniform(-1, 1, (cfg.n_auv, 2)).astype(np.float32) if step < warmup
                           else np.stack([a.act(obs[i], noise) for i, a in enumerate(agents)]))
                requests = env.network.metrics.get('config_requests', 0)
                next_obs, reward, term, trunc, info = env.step(actions.copy(), action_topo)
                require_finite('transition', [reward, *next_obs.ravel()])
                for i, agent in enumerate(agents):
                    agent.replay.add(obs[i], actions[i].copy(), reward, next_obs[i], term, trunc)
                    if step >= warmup:
                        result = agent.update(); require_finite('TD3 losses', result)
                        losses.update({f'auv_{i}_{k}': v for k, v in result.items()})
                # Central training reward uses received-state AoI and real
                # CONFIG requests, NOT instantaneous true connectivity.
                topo_reward = (.2 * reward - .1 * min(info['metrics']['mean_aoi_s'] / cfg.state_ttl, 3.)
                               - .1 * (env.network.metrics.get('config_requests', 0) - requests))
                pending['reward'] += cfg.gamma ** pending['duration'] * topo_reward
                pending['duration'] += 1
                step += 1; episode_return += reward; obs = next_obs
                if pending['duration'] == cfg.slow_period or term or trunc:
                    if store_completed_macro(pending['duration'], cfg.slow_period, term, trunc):
                        slow, mask = env.slow_state()
                        topology.replay.add(pending['state'], pending['mask'], pending['action'], pending['reward'],
                            slow, mask, pending['duration'], cfg.gamma, term, trunc)
                        if step >= topology_warmup:
                            result = topology.update(); require_finite('DDQN losses', result); losses.update(result)
                    pending = None
                if term or trunc:
                    log.write(json.dumps(dict(event='episode_end', global_step=step, episode=episode,
                        episode_return=episode_return, info=info), allow_nan=False) + '\n')
                    episode += 1; obs, _ = env.reset(seed + episode); episode_return = 0.
                if step % args.log_every == 0 or step == stop:
                    record = progress(); atomic_json(record, output / 'progress.json')
                    log.write(json.dumps(record, allow_nan=False) + '\n'); log.flush()
                    print(json.dumps({k:v for k,v in record.items() if k != 'info'}), flush=True)
                if step in milestones or step % args.checkpoint_every == 0:
                    checkpoint = payload()
                    if step in milestones: save_bundle(checkpoint, output, True)
                    if step % args.checkpoint_every == 0: save_bundle(checkpoint, output)
        if sources() != frozen: raise RuntimeError('Source changed during training')
        save_bundle(payload(), output)
        summary = progress('completed') | dict(source_unchanged=True,
             gpu_diagnostics=gpu_diagnostics(agents, topology, device),
             initial_parameter_digests=initial_digest, final_parameter_digests=parameter_digests(agents, topology))
        atomic_json(summary, output / 'summary.json'); atomic_json(summary, output / 'progress.json')
        return summary
    except Exception as exc:
        record = progress('failed'); record['error'] = repr(exc)
        # A NaN loss must not stop failure-state publication.
        record['losses'] = {}; record['info'] = {}
        atomic_json(record, output / 'progress.json'); raise
    finally:
        env.close()


def math_exp(value):
    import math
    return math.exp(value)


def evaluate(args):
    from scripts.tmc_environment_observer import EnvironmentObserver
    from scripts.tmc_network_observer import NetworkObserver
    if not 1 <= args.episodes <= 30 or not 1 <= args.steps <= 1200:
        raise ValueError('Evaluation is bounded to 30 episodes of 1200 steps')
    if args.seed is None:
        raise ValueError('Evaluation requires an explicit, separately declared seed range')
    checkpoint = load_checkpoint(args.checkpoint)
    policy = Policy(checkpoint, args.device)
    env = policy.make_environment()
    output = new_output(args.output)
    seed_all(args.seed)
    records = []
    with (output / 'evaluation.jsonl').open('x', encoding='utf-8') as log:
        for episode in range(args.episodes):
            obs, info = env.reset(args.seed + episode)
            eo, no = EnvironmentObserver(env, info), NetworkObserver(env.network)
            total = 0.
            for index in range(args.steps):
                topo = policy.topology_action(*env.slow_state()) if env.step_count % env.cfg.slow_period == 0 else None
                actions = policy.act(obs)
                obs, reward, term, trunc, info = env.step(actions, topo)
                total += reward
                log.write(json.dumps(dict(episode=episode, seed=args.seed+episode, step=index+1, time=info['time'],
                    reward=reward, actions=actions.tolist(), topology_request=topo, terminated=term, truncated=trunc,
                    info=info, passive_environment=eo.after_step(info)), allow_nan=False) + '\n')
                if term or trunc: break
            records.append(dict(episode=episode, seed=args.seed+episode, model_step=checkpoint['global_step'],
                steps=index+1, duration_s=info['time'], terminated=term, truncated=trunc,
                evaluation_limit_reached=not(term or trunc), termination_reason=info['termination_reason'],
                metrics_base=info['metrics'], environment=eo.finalize(), network=no.finalize(info['time']),
                **{'return': total}))
            atomic_json(dict(status='evaluating', completed_episodes=len(records)), output/'progress.json')
    if sources() != checkpoint['source_hashes']: raise RuntimeError('Source changed during evaluation')
    result = dict(status='completed', method_id='improved_full_v3', training_steps=checkpoint['global_step'],
        checkpoint=str(Path(args.checkpoint).resolve()), checkpoint_sha256=file_digest(args.checkpoint)['sha256'],
        config_fingerprint=policy.cfg.fingerprint, source_hashes=sources(), episodes=records)
    atomic_json(result, output/'evaluation_summary.json')
    atomic_json(dict(status='completed', completed_episodes=len(records)), output/'progress.json')
    return {'status':'completed', 'episodes':len(records), 'output':str(output)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['train','evaluate'])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    parser.add_argument('--steps', type=int, default=160)
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--seed', type=int, help='Training default 7; evaluation must explicitly specify its split')
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--episodes', type=int, default=1)
    parser.add_argument('--milestones', type=int, nargs='*', default=[])
    parser.add_argument('--allow-long-run', action='store_true')
    parser.add_argument('--smoke', action='store_true', help='Fresh <=200-step GPU integration check only')
    parser.add_argument('--log-every', type=int, default=1000)
    parser.add_argument('--checkpoint-every', type=int, default=10000)
    args = parser.parse_args()
    print(json.dumps(train(args) if args.mode=='train' else evaluate(args), ensure_ascii=True), flush=True)


if __name__ == '__main__': main()
