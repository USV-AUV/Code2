"""TD3 with a training-only, observation-based kinematic actor regularizer.

The twin-Q Bellman target, target smoothing, policy delay, and replay semantics
are unchanged. The extra loss is a *biased auxiliary training objective*, not
an optimality guarantee, behavioral cloning, controller, or action correction.
Inference inherits TD3Agent.act unchanged and produces the final normalized
water-relative speed/heading command directly.
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Any

import torch
from torch import nn
from torch.nn import functional as F

from usv_auv.learning import LearningConfig, TD3Agent, _finite_loss, _soft_update


REVISION_LEARNING_VERSION = "observed-one-step-kinematic-v1"


@dataclass(frozen=True)
class RevisionLearningOptions:
    """Physical scales must match the observation/action schema in the run.

    The bounded waypoint has radius ``waypoint_horizon_steps * max_speed * dt``
    in metres. The prediction lasts exactly one ``dt``. Squared errors are
    normalized by ``(max_speed * dt)**2``; the objective is dimensionless.
    Weight annealing counts completed critic updates, not environment steps.
    """

    area_size: float = 200.0
    max_speed: float = 2.2
    dt: float = 1.0
    action_frame: str = "target"
    aux_initial_weight: float = 0.2
    aux_final_weight: float = 0.02
    aux_anneal_updates: int = 100_000
    waypoint_horizon_steps: float = 2.0
    command_penalty: float = 0.02

    def __post_init__(self) -> None:
        for name in ("area_size", "max_speed", "dt", "waypoint_horizon_steps"):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) <= 0:
                raise ValueError(f"{name} must be finite and positive")
        for name in ("aux_initial_weight", "aux_final_weight", "command_penalty"):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) < 0:
                raise ValueError(f"{name} must be finite and nonnegative")
        if isinstance(self.aux_anneal_updates, bool) or not isinstance(self.aux_anneal_updates, int) or self.aux_anneal_updates < 1:
            raise ValueError("aux_anneal_updates must be a positive integer")
        if self.aux_final_weight > self.aux_initial_weight:
            raise ValueError("aux_final_weight must not exceed aux_initial_weight")
        if self.action_frame not in ("global", "target"):
            raise ValueError("action_frame must be 'global' or 'target'")

    @classmethod
    def from_dict(cls, values: dict[str, Any]) -> "RevisionLearningOptions":
        return cls(**values)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def weight_at(self, updates: int) -> float:
        if updates < 0:
            raise ValueError("updates must be nonnegative")
        fraction = min(float(updates) / self.aux_anneal_updates, 1.0)
        return self.aux_initial_weight + fraction * (self.aux_final_weight - self.aux_initial_weight)


def _validate_inputs(observations: torch.Tensor, actions: torch.Tensor) -> None:
    if observations.ndim != 2 or observations.shape[1] < 12 or observations.shape[0] == 0:
        raise ValueError("Auxiliary loss requires a nonempty batch with the original first 12 observation fields")
    if actions.shape != (observations.shape[0], 2):
        raise ValueError("Actions must have shape (batch, 2)")
    if not observations.is_floating_point() or not actions.is_floating_point():
        raise ValueError("Observations and actions must be floating-point tensors")
    if observations.device != actions.device or observations.dtype != actions.dtype:
        raise ValueError("Observations and actions must share dtype and device")
    if not torch.isfinite(observations).all() or not torch.isfinite(actions).all():
        raise ValueError("Observations and actions must be finite")
    if torch.any(actions.abs() > 1.000001):
        raise ValueError("Actions must retain the normalized [-1, 1] encoding")


def differentiable_water_velocity(observations: torch.Tensor, actions: torch.Tensor,
                                  options: RevisionLearningOptions) -> torch.Tensor:
    """The original decoder, differentiable with respect to actor actions only.

    No simulator values are accepted. The reference bearing is obtained from
    the goal that the actor actually observed, including for replay samples.
    """
    _validate_inputs(observations, actions)
    speed = (actions[:, 0] + 1.0) * (0.5 * options.max_speed)
    if options.action_frame == "target":
        goal = observations[:, 2:4].detach()
        bearing = torch.atan2(goal[:, 1], goal[:, 0])
        bearing = torch.where(torch.all(goal == 0, dim=1), torch.zeros_like(bearing), bearing)
    else:
        bearing = torch.zeros_like(speed)
    heading = bearing + math.pi * actions[:, 1]
    return speed.unsqueeze(1) * torch.stack((heading.cos(), heading.sin()), dim=1)


def kinematic_auxiliary_loss(observations: torch.Tensor, actions: torch.Tensor,
                             options: RevisionLearningOptions) -> torch.Tensor:
    """One-step observed-motion objective; it never changes executed actions.

    A bounded local waypoint avoids scaling the gradient with distant targets.
    Drift is a causal *estimate*, included only after estimator initialization.
    The model assumes this estimate remains constant for one step. Navigation
    error, rapidly changing currents, obstacles, and protocol timing can make
    that approximation imperfect: task Q-values remain the main actor loss.
    """
    velocity = differentiable_water_velocity(observations, actions, options)
    observed = observations.detach()
    goal = observed[:, 2:4] * options.area_size
    distance = torch.linalg.vector_norm(goal, dim=1, keepdim=True)
    one_step_distance = options.max_speed * options.dt
    radius = options.waypoint_horizon_steps * one_step_distance
    waypoint = goal * (radius / distance.clamp_min(torch.finfo(goal.dtype).eps)).clamp(max=1.0)
    initialized = (observed[:, 11:12] >= 0.5).to(observed.dtype)
    drift = observed[:, 8:10] * options.max_speed * initialized
    next_error = waypoint - options.dt * (velocity + drift)
    position_cost = (next_error / one_step_distance).square().sum(dim=1)
    command_cost = (velocity / options.max_speed).square().sum(dim=1)
    return (position_cost + options.command_penalty * command_cost).mean()


class ImprovedTD3Agent(TD3Agent):
    """Base-compatible constructor plus explicit auxiliary-objective options."""

    def __init__(self, observation_dim: int, action_dim: int = 2,
                 config: LearningConfig | None = None, device: str = "cuda", seed: int = 0,
                 *, options: RevisionLearningOptions) -> None:
        if observation_dim < 12 or action_dim != 2:
            raise ValueError("Improved TD3 requires the original observation prefix and two speed/heading actions")
        if not isinstance(options, RevisionLearningOptions):
            raise TypeError("options must be RevisionLearningOptions")
        self.options = options
        super().__init__(observation_dim, action_dim, config, device, seed)

    def update(self) -> dict[str, float]:
        c = self.config
        if len(self.replay) < c.batch_size:
            return {}
        batch = self.replay.sample(c.batch_size, self.device)
        # This is the unchanged TD3 target, including true-terminal-only masking.
        with torch.no_grad():
            noise = (torch.randn_like(batch["actions"]) * c.policy_noise).clamp(-c.noise_clip, c.noise_clip)
            next_actions = (self.actor_target(batch["next_observations"]) + noise).clamp(-1, 1)
            q1, q2 = self.critic_target(batch["next_observations"], next_actions)
            target = batch["rewards"] + (1 - batch["terminated"]) * c.gamma * torch.minimum(q1, q2)
        q1, q2 = self.critic(batch["observations"], batch["actions"])
        critic_loss = F.mse_loss(q1, target) + F.mse_loss(q2, target)
        _finite_loss(critic_loss)
        self.critic_optimizer.zero_grad(set_to_none=True)
        critic_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), c.gradient_clip)
        self.critic_optimizer.step()
        self.updates += 1
        result = {"critic_loss": float(critic_loss.detach().cpu())}
        if self.updates % c.policy_delay == 0:
            self.critic.requires_grad_(False)
            try:
                actions = self.actor(batch["observations"])
                td3_loss = -self.critic.q1(torch.cat((batch["observations"], actions), -1)).mean()
                weight = self.options.weight_at(self.updates)
                # At zero weight, execute exactly the original actor objective.
                auxiliary = kinematic_auxiliary_loss(batch["observations"], actions, self.options) if weight else td3_loss.new_zeros(())
                actor_loss = td3_loss + weight * auxiliary if weight else td3_loss
                _finite_loss(actor_loss)
                self.actor_optimizer.zero_grad(set_to_none=True)
                actor_loss.backward()
                nn.utils.clip_grad_norm_(self.actor.parameters(), c.gradient_clip)
                self.actor_optimizer.step()
            finally:
                self.critic.requires_grad_(True)
            _soft_update(self.actor, self.actor_target, c.tau)
            _soft_update(self.critic, self.critic_target, c.tau)
            result.update(actor_loss=float(actor_loss.detach().cpu()),
                          actor_td3_loss=float(td3_loss.detach().cpu()),
                          actor_auxiliary_loss=float(auxiliary.detach().cpu()),
                          auxiliary_weight=weight)
        return result

    def state_dict(self, include_replay: bool = True) -> dict[str, Any]:
        state = super().state_dict(include_replay)
        state["revision_learning_version"] = REVISION_LEARNING_VERSION
        state["revision_learning_options"] = self.options.to_dict()
        return state

    def load_state_dict(self, state: dict[str, Any], load_replay: bool = True) -> None:
        if state.get("revision_learning_version") != REVISION_LEARNING_VERSION:
            raise ValueError("Missing or incompatible improved TD3 learning version")
        if state.get("revision_learning_options") != self.options.to_dict():
            raise ValueError("Improved TD3 auxiliary options differ from checkpoint")
        super().load_state_dict(state, load_replay)
