"""Versioned method improvements over the immutable CollectionV2 simulator."""
