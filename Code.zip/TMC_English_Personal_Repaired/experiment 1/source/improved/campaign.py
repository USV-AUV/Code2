"""Fail-stop, preregistered revision pilot and one-shot held-out campaign.

``prepare`` only probes CUDA and freezes the protocol; it does not train or
evaluate. ``run`` owns the sequential learner/evaluator queue; ``evaluate-old``
is its CUDA legacy-policy evaluation helper. Importing, checking and CPU
summarizing never train or evaluate. A prepared campaign is immutable and runs
once. The 100k development gate is a continuation rule, not baseline wins.
"""
from __future__ import annotations

import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import traceback
import uuid

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CAMPAIGN = ROOT / "runs/improved_full_v3_20260910"
OLD_CAMPAIGN = ROOT / "runs/baselines_campaign_1m_20260909"
FULL_RUN = ROOT / "runs/research_collection_v2_1m_20260909"
CONFIG = FULL_RUN / "frozen_config.json"
REVISION = "improved_full_v3"
OLD_FULL = "old_full"
BASELINES = ("synchronous_fim_rl", "communication_aware_tmc", "topology_only", "usde_only")
BUDGETS = (450000, 1000000)
SPLITS = {
    "development": {"seed": 9510000, "episodes": 8, "steps": 1200},
    "heldout": {"seed": 9520000, "episodes": 30, "steps": 1200},
}
GATE = {
    "candidate_step": 100000, "reference_method": OLD_FULL, "reference_step": 1000000,
    "goodput_metric": "fixed_budget_goodput_bit_s", "goodput_ratio_strictly_greater_than": 1.10,
    "survived_horizon_count_must_not_decrease": True,
    "aoi_metric": "environment.state_aoi.pooled.mean", "mean_aoi_must_not_increase": True,
    "use_confidence_interval_as_gate": False, "all_failures_included": True,
    "meaning": "Continuation gate only, not superiority over all baselines or a held-out claim",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(value, path):
    """Atomic publication; caller owns the new output tree, not old evidence."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n"
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix=".publish_", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def pipeline_hashes():
    files = ("scripts/summarize_baseline_campaign.py", "scripts/summarize_tmc_retest.py",
             "scripts/tmc_environment_observer.py", "scripts/tmc_network_observer.py")
    return {name: sha(ROOT / name) for name in files}


def verify_files(entries):
    for path, expected in entries.items():
        require(Path(path).is_file() and sha(path) == expected, f"Frozen evidence changed: {path}")


def checkpoint_identity(directory, budget, config_fp, method=None):
    directory = Path(directory).resolve()
    metadata = read(directory / "metadata.json")
    require(metadata["global_step"] == budget, "Checkpoint step mismatch")
    require(metadata["config_fingerprint"] == config_fp, "Checkpoint environment mismatch")
    if method in BASELINES:
        from baselines.methods import get_method
        spec = get_method(method)
        require(metadata["method_id"] == method and metadata["method_fingerprint"] == spec.fingerprint,
                "Checkpoint baseline identity mismatch")
        require(metadata["method_spec"] == spec.to_dict(), "Checkpoint baseline specification mismatch")
    for name in ("checkpoint.pt", "policy.pt"):
        expected = metadata["files"][name]
        path = directory / name
        require(path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"],
                f"Checkpoint checksum mismatch: {path}")
    return {"checkpoint": str(directory / "policy.pt"), "metadata_path": str(directory / "metadata.json"),
            "checkpoint_sha256": metadata["files"]["policy.pt"]["sha256"], "metadata": metadata}


def dataset_descriptors(campaign, protocol, split):
    require(split in SPLITS, "Unknown evaluation split")
    campaign = Path(campaign).resolve()
    pairs = ([(REVISION, 100000), (OLD_FULL, 1000000), ("usde_only", 450000), ("usde_only", 1000000)]
             if split == "development" else [(method, budget) for method in (REVISION, OLD_FULL, *BASELINES)
                                               for budget in BUDGETS])
    result = []
    for method, budget in pairs:
        if method == REVISION:
            train = campaign / ("pilot_train" if budget == 100000 else "continuation_train")
            checkpoint = train / "milestones" / f"step_{budget:07d}" / "policy.pt"
        else:
            checkpoint = Path(protocol["old_models"][method][str(budget)]["checkpoint"])
        label = f"{method}_{budget:07d}"
        result.append({"label": label, "method": method, "budget": budget,
                       "checkpoint": str(checkpoint), "output": str(campaign / split / label)})
    return result


def training_command(campaign, continuation=False):
    campaign = Path(campaign).resolve()
    result = ["-m", "improved.workflow", "train", "--config", str(campaign / "frozen_config.json"),
              "--device", "cuda", "--seed", "7", "--allow-long-run", "--steps",
              "900000" if continuation else "100000", "--output",
              str(campaign / ("continuation_train" if continuation else "pilot_train")),
              "--checkpoint-every", "10000", "--log-every", "1000", "--milestones"]
    result += ["450000", "1000000"] if continuation else ["100000"]
    if continuation:
        result += ["--resume", str(campaign / "pilot_train/checkpoint_latest.pt")]
    return result


def evaluation_command(campaign, descriptor, split):
    settings = SPLITS[split]
    if descriptor["method"] == OLD_FULL:
        return ["-m", "improved.campaign", "evaluate-old", "--campaign", str(Path(campaign).resolve()),
                "--split", split, "--budget", str(descriptor["budget"])]
    prefix = (["-m", "improved.workflow", "evaluate"] if descriptor["method"] == REVISION
              else ["-m", "baselines.evaluate", "--method", descriptor["method"],
                    "--verify-sources", "--tmc-metrics"])
    return prefix + ["--checkpoint", descriptor["checkpoint"], "--output", descriptor["output"],
                     "--device", "cuda", "--episodes", str(settings["episodes"]), "--steps", "1200",
                     "--seed", str(settings["seed"])]


def prepare(campaign):
    from dataclasses import asdict
    import torch
    from baselines.deploy import source_hashes
    from improved.workflow import sources
    from improved.environment import MethodOptions
    from improved.routing import RoutingOptions
    from usv_auv.config import Config
    from scripts.summarize_baseline_campaign import Evidence, validate_protocol

    campaign = Path(campaign).resolve()
    require(not campaign.exists(), "Require a NEW campaign directory; no overwrite or implicit restart")
    require(campaign.parent.is_dir(), "Campaign parent directory must exist")
    require(torch.cuda.is_available(), "CUDA required")
    sample = torch.ones(8, device="cuda", requires_grad=True)
    sample.square().sum().backward()
    require(bool(torch.isfinite(sample.grad).all()), "CUDA preflight failed")
    require(shutil.disk_usage(campaign.parent).free >= 15 * 1024 ** 3, "Require 15 GiB free disk")
    cfg = read(CONFIG)
    require(Config.from_dict(cfg).to_dict() == cfg and Config.from_dict(cfg).fingerprint == "48caa5c4f5bf9627",
            "Wrong or incomplete frozen CollectionV2 environment")
    require(read(OLD_CAMPAIGN / "campaign_status.json")["status"] == "complete", "Old campaign incomplete")
    evidence = Evidence()
    old = validate_protocol(OLD_CAMPAIGN, evidence)
    require(source_hashes() == old["source_hashes"] and old["environment_config"] == cfg,
            "Frozen old baseline/core/config identity changed")
    for path in (OLD_CAMPAIGN / "comparison/comparison.json", OLD_CAMPAIGN / "comparison/REPORT_ZH.md",
                 OLD_CAMPAIGN / "campaign_status.json"):
        evidence.check(path)
    models = {}
    for method in (OLD_FULL, *BASELINES):
        models[method] = {}
        train = FULL_RUN if method == OLD_FULL else OLD_CAMPAIGN / method / "train"
        for budget in BUDGETS:
            identity = checkpoint_identity(train / "milestones" / f"step_{budget:07d}", budget,
                                           old["config_fingerprint"], method)
            models[method][str(budget)] = identity
            for path in (identity["metadata_path"], identity["checkpoint"]):
                evidence.check(path)
            evidence.check(Path(identity["checkpoint"]).with_name("checkpoint.pt"))
        require(read(train / "frozen_config.json") == cfg, "Old training physical config differs")
        evidence.check(train / "frozen_config.json")
        if method != OLD_FULL:
            manifest = read(train / "manifest.json")
            require(manifest["seed"] == 7 and manifest["environment_config"] == cfg, "Wrong old training seed/config")
            evidence.check(train / "manifest.json")
    protocol = {"format": "collection-v3-preregistered-campaign-v1", "campaign_id": str(uuid.uuid4()),
        "created_at": now(), "environment_config": cfg, "config_fingerprint": old["config_fingerprint"],
        "training_seed": 7, "pilot_steps": 100000, "continuation_additional_steps": 900000,
        "final_global_step": 1000000, "milestones": list(BUDGETS), "device": "cuda",
        "python": sys.executable, "gpu": torch.cuda.get_device_name(0), "torch": torch.__version__,
        "source_hashes": sources(), "baseline_source_hashes": source_hashes(),
        "pipeline_source_hashes": pipeline_hashes(), "protected_files": evidence.files,
        "old_models": models, "old_campaign": str(OLD_CAMPAIGN), "old_full_run": str(FULL_RUN),
        "splits": SPLITS, "continuation_gate": GATE, "method_options": asdict(MethodOptions()),
        "routing_options": asdict(RoutingOptions()), "bootstrap_resamples": 20000,
        "control": {"parallel_children": 1, "retry": False, "autotune": False,
                    "gate_failure": "needs_review; stop without changing code or launching held-out evaluation",
                    "heldout_policy": "All training finishes before 12 frozen groups are evaluated once",
                    "check_interval_minutes": 20, "resume_mode": "new physical episode, preserved learning state"},
        "limitations": ["One training seed; paired scene intervals do not measure training-seed variation",
                        "Development scenes select continuation; never report them as held-out performance",
                        "Equal environment steps do not imply equal gradient/compute budgets",
                        "No guarantee of improvement; failures retained and unavailable measurements are not zeros"]}
    campaign.mkdir()
    write_json(protocol, campaign / "protocol.json")
    write_json(cfg, campaign / "frozen_config.json")
    write_json({"status": "prepared", "campaign_id": protocol["campaign_id"], "prepared_at": now(),
                "protocol_sha256": sha(campaign / "protocol.json")}, campaign / "campaign_status.json")
    return {"status": "prepared", "campaign": str(campaign), "campaign_id": protocol["campaign_id"]}


def validate_frozen(campaign, protocol, expected_protocol_sha=None):
    from improved.workflow import sources
    from baselines.deploy import source_hashes
    campaign = Path(campaign).resolve()
    if expected_protocol_sha is not None:
        require(sha(campaign / "protocol.json") == expected_protocol_sha, "Preregistered protocol changed")
    require(protocol["splits"] == SPLITS and protocol["continuation_gate"] == GATE, "Preregistered split/gate changed")
    require(protocol["training_seed"] == 7 and protocol["pilot_steps"] == 100000
            and protocol["continuation_additional_steps"] == 900000 and protocol["final_global_step"] == 1000000,
            "Training budget changed")
    require(sources() == protocol["source_hashes"], "Revision/core/baseline source changed after preregistration")
    require(source_hashes() == protocol["baseline_source_hashes"], "Old method sources changed")
    require(pipeline_hashes() == protocol["pipeline_source_hashes"], "Telemetry/summary source changed")
    require(read(CONFIG) == read(campaign / "frozen_config.json") == protocol["environment_config"], "Physical config changed")
    verify_files(protocol["protected_files"])


def verify_training(campaign, protocol, continuation=False):
    directory = Path(campaign) / ("continuation_train" if continuation else "pilot_train")
    summary, manifest = read(directory / "summary.json"), read(directory / "manifest.json")
    target = 1000000 if continuation else 100000
    require(summary["status"] == "completed" and summary["global_step"] == target, "Incomplete/wrong training budget")
    require(manifest["seed"] == 7 and manifest["environment_config"] == protocol["environment_config"], "Training seed/config changed")
    require(manifest["source_hashes"] == protocol["source_hashes"] and summary["source_unchanged"], "Training source identity mismatch")
    require(not manifest["training_protocol"]["smoke_overrides"], "Smoke learning overrides forbidden in campaign")
    require(manifest["method_options"] == protocol["method_options"] and manifest["routing_options"] == protocol["routing_options"],
            "Method/routing options differ from protocol")
    require(all(value > 0 for value in summary["td3_updates"]) and summary["ddqn_updates"] > 0, "Missing learning updates")
    before, after = summary["initial_parameter_digests"], summary["final_parameter_digests"]
    for key in ("actors", "critics"):
        require(len(before[key]) == len(after[key]) == protocol["environment_config"]["n_auv"]
                and all(a != b for a, b in zip(before[key], after[key])), f"Some {key} did not change")
    require(before["topology_online"] != after["topology_online"], "Topology learner did not change")
    gpu = summary["gpu_diagnostics"]
    require(gpu["parameter_devices"] == ["cuda:0"] and gpu["optimizer_moment_devices"] == ["cuda:0"]
            and gpu["populated_optimizers"] == gpu["optimizer_count"], "CUDA optimizer diagnostics invalid")
    if continuation:
        prior = read(Path(campaign) / "pilot_train/manifest.json")
        require(manifest["run_id"] == prior["run_id"] and manifest["resume_mode"] == "new_physical_episode_learning_resume",
                "Continuation did not preserve training run identity")
        require(Path(manifest["parent_checkpoint"]).resolve() == (Path(campaign) / "pilot_train/checkpoint_latest.pt").resolve(),
                "Continuation uses wrong pilot checkpoint")
    for budget in BUDGETS if continuation else (100000,):
        identity = checkpoint_identity(directory / "milestones" / f"step_{budget:07d}", budget,
                                       protocol["config_fingerprint"], REVISION)
        metadata = identity["metadata"]
        require(metadata["source_hashes"] == protocol["source_hashes"] and metadata["run_id"] == manifest["run_id"],
                "Milestone identity mismatch")
    return {"summary": summary, "manifest": manifest}


def evaluate_old(campaign, split, budget):
    """Frozen legacy policy, new scenes, unchanged simulator and passive metrics."""
    from usv_auv.deploy import DeploymentPolicy, load_checkpoint
    from usv_auv.environment import CooperativeEnv
    from usv_auv.config import Config
    from usv_auv.learning import seed_all
    from scripts.tmc_environment_observer import EnvironmentObserver
    from scripts.tmc_network_observer import NetworkObserver

    campaign = Path(campaign).resolve()
    protocol = read(campaign / "protocol.json")
    protocol_sha = sha(campaign / "protocol.json")
    validate_frozen(campaign, protocol, protocol_sha)
    descriptors = [item for item in dataset_descriptors(campaign, protocol, split)
                   if item["method"] == OLD_FULL and item["budget"] == budget]
    require(len(descriptors) == 1, "Old-full evaluation not in preregistered split")
    descriptor, settings = descriptors[0], SPLITS[split]
    output, checkpoint_path = Path(descriptor["output"]), Path(descriptor["checkpoint"])
    require(not output.exists(), "Old-full evaluation requires a new output directory")
    expected = protocol["old_models"][OLD_FULL][str(budget)]
    require(sha(checkpoint_path) == expected["checkpoint_sha256"], "Old full policy changed")
    saved = load_checkpoint(checkpoint_path)
    require(saved["global_step"] == budget and saved["environment_config"] == protocol["environment_config"],
            "Old full checkpoint config/step differs")
    policy = DeploymentPolicy(saved, "cuda")
    env = CooperativeEnv(Config.from_dict(saved["environment_config"]))
    policy.validate_environment(env)
    seed_all(settings["seed"])
    output.mkdir(parents=True)
    records = []
    try:
        with (output / "evaluation.jsonl").open("x", encoding="utf-8") as log:
            for episode in range(settings["episodes"]):
                seed = settings["seed"] + episode
                observations, info = env.reset(seed)
                eo, no = EnvironmentObserver(env, info), NetworkObserver(env.network)
                total = 0.
                for index in range(settings["steps"]):
                    topology = policy.topology_action(*env.slow_state()) if env.step_count % env.cfg.slow_period == 0 else None
                    actions = policy.act(observations)
                    observations, reward, term, trunc, info = env.step(actions, topology)
                    total += float(reward)
                    log.write(json.dumps({"episode": episode, "seed": seed, "step": index + 1,
                        "time": info["time"], "reward": float(reward), "actions": actions.tolist(),
                        "topology_request": topology, "terminated": term, "truncated": trunc,
                        "info": info, "passive_environment": eo.after_step(info)}, allow_nan=False) + "\n")
                    if term or trunc:
                        break
                records.append({"episode": episode, "seed": seed, "method_id": OLD_FULL,
                    "model_step": budget, "steps": index + 1, "duration_s": info["time"],
                    "terminated": term, "truncated": trunc, "evaluation_limit_reached": not (term or trunc),
                    "termination_reason": info["termination_reason"], "return": total,
                    "metrics_base": info["metrics"], "environment": eo.finalize(), "network": no.finalize(info["time"])})
                write_json({"status": "evaluating", "completed_episodes": len(records), "total_episodes": settings["episodes"]},
                           output / "progress.json")
        validate_frozen(campaign, protocol, protocol_sha)
        result = {"status": "completed", "method_id": OLD_FULL, "training_steps": budget,
                  "checkpoint": str(checkpoint_path), "checkpoint_sha256": sha(checkpoint_path),
                  "config_fingerprint": protocol["config_fingerprint"], "source_hashes": protocol["source_hashes"],
                  "device": str(policy.device), "tmc_metrics": True, "episodes": records}
        write_json(result, output / "evaluation_summary.json")
        write_json({"status": "completed", "completed_episodes": len(records)}, output / "progress.json")
        return {"status": "completed", "output": str(output), "episodes": len(records)}
    except BaseException as error:
        write_json({"status": "failed", "error": repr(error), "completed_episodes": len(records)}, output / "progress.json")
        raise
    finally:
        env.close()


def validate_episode_set(rows, split):
    settings = SPLITS[split]
    require(len(rows) == settings["episodes"], "Incomplete episode set; do not filter failures")
    require([row["episode"] for row in rows] == list(range(settings["episodes"])), "Episode order/identity mismatch")
    require([row["seed"] for row in rows] == list(range(settings["seed"], settings["seed"] + settings["episodes"])),
            "Scene seeds differ from preregistered split")


def load_dataset(descriptor, protocol, split):
    from scripts.summarize_baseline_campaign import normalize_episode, summarize_rows
    output, checkpoint = Path(descriptor["output"]), Path(descriptor["checkpoint"])
    result = read(output / "evaluation_summary.json")
    method, budget = descriptor["method"], descriptor["budget"]
    require(result["status"] == "completed" and result["method_id"] == method
            and result["training_steps"] == budget, "Evaluation identity/status mismatch")
    require(result["config_fingerprint"] == protocol["config_fingerprint"], "Evaluation config mismatch")
    require(Path(result["checkpoint"]).resolve() == checkpoint.resolve(), "Wrong policy was evaluated")
    identity = checkpoint_identity(checkpoint.parent, budget, protocol["config_fingerprint"], method)
    if method in BASELINES:
        expected = protocol["old_models"][method][str(budget)]
        require(identity == expected, "Old baseline milestone changed")
        require(result["source_hashes"] == protocol["baseline_source_hashes"]
                and result["core_source_files_unchanged"] and result["baseline_sources_unchanged"]
                and result["tmc_metrics"] and result["device"].startswith("cuda"), "Baseline evaluation source/device mismatch")
        require(result["method_fingerprint"] == identity["metadata"]["method_fingerprint"]
                and result["method_spec"] == identity["metadata"]["method_spec"], "Baseline evaluation specification mismatch")
    else:
        require(result["checkpoint_sha256"] == identity["checkpoint_sha256"], "Evaluation checkpoint SHA mismatch")
        require(result["source_hashes"] == protocol["source_hashes"], "Full method source mismatch")
        if method == OLD_FULL:
            require(identity == protocol["old_models"][method][str(budget)], "Old full milestone changed")
        else:
            require(identity["metadata"]["source_hashes"] == protocol["source_hashes"], "Revision checkpoint source mismatch")
            manifest = read(checkpoint.parents[2] / "manifest.json")
            require(manifest["seed"] == 7 and manifest["environment_config"] == protocol["environment_config"],
                    "Revision training seed/config mismatch")
            require(manifest["run_id"] == identity["metadata"]["run_id"], "Revision checkpoint run mismatch")
    validate_episode_set(result["episodes"], split)
    rows = [normalize_episode(row, budget, method) for row in result["episodes"]]
    trace = output / "evaluation.jsonl"
    dataset = summarize_rows(rows, trace, method)
    dataset["seed_order"] = [row["seed"] for row in rows]
    dataset["raw_episode_metrics_base"] = [{"seed": row["seed"], "duration_s": row["duration_s"],
        "terminated": row["terminated"], "termination_reason": row["termination_reason"],
        "metrics_base": row["metrics_base"]} for row in rows]
    dataset["checkpoint_identity"] = identity
    files = {str(path.resolve()): sha(path) for path in (output / "evaluation_summary.json", trace,
                                                       checkpoint, checkpoint.parent / "metadata.json")}
    return dataset, files


def continuation_gate(candidate, reference):
    """Strict preregistered >10% mean improvement, no post-hoc rule changes."""
    require(candidate["seed_order"] == reference["seed_order"] == list(range(9510000, 9510008)), "Gate requires paired development seeds")
    require(candidate["total_episodes"] == reference["total_episodes"] == 8, "Gate needs all eight scenes")
    def complete_mean(dataset, metric):
        values = dataset["selected_metrics"][metric]
        require(values["n"] == 8 and values["missing_n"] == 0
                and values["mean"] is not None and math.isfinite(values["mean"]), "Missing/nonfinite gate metric")
        return values["mean"]
    goodput = [complete_mean(row, GATE["goodput_metric"]) for row in (candidate, reference)]
    aoi = [complete_mean(row, GATE["aoi_metric"]) for row in (candidate, reference)]
    survived = [row["full_horizon_episodes"] for row in (candidate, reference)]
    checks = {"fixed_budget_goodput_strictly_over_10_percent": goodput[0] > 1.10 * goodput[1],
              "survived_count_not_lower": survived[0] >= survived[1], "mean_aoi_not_higher": aoi[0] <= aoi[1]}
    return {"passed": all(checks.values()), "checks": checks, "definition": GATE,
            "candidate": {"goodput": goodput[0], "aoi": aoi[0], "survived": survived[0]},
            "reference": {"goodput": goodput[1], "aoi": aoi[1], "survived": survived[1]},
            "relative_goodput_improvement": goodput[0] / goodput[1] - 1 if goodput[1] else None,
            "reference_zero_goodput": goodput[1] == 0,
            "decision": "continue_to_exactly_1m" if all(checks.values()) else "needs_review_stop"}


def paired_comparisons(datasets, split, resamples):
    from scripts.summarize_baseline_campaign import paired_bootstrap
    from scripts.summarize_tmc_retest import selected_specs
    pairs = []
    if split == "development":
        candidate = f"{REVISION}_0100000"
        pairs = [(key, candidate) for key in datasets if key != candidate]
    else:
        pairs = [(f"{method}_{budget:07d}", f"{REVISION}_{budget:07d}")
                 for method in (OLD_FULL, *BASELINES) for budget in BUDGETS]
    pairs += [(f"{method}_0450000", f"{method}_1000000")
              for method in (("usde_only",) if split == "development" else (REVISION, OLD_FULL, *BASELINES))]
    result = {}
    for left, right in pairs:
        require(datasets[left]["seed_order"] == datasets[right]["seed_order"], "Unpaired comparison")
        a, b = (datasets[key]["selected_values_by_paired_seed"] for key in (left, right))
        result[f"{right}_minus_{left}"] = {"left": left, "right": right,
            "metrics": {key: paired_bootstrap(a[key], b[key], resamples, 959091) for key, *_ in selected_specs()}}
    return result


def render_report(summary):
    """Render the 75 registered metrics without changing the underlying summaries."""
    from scripts.summarize_tmc_retest import mean_sd
    data = summary["datasets"]
    lines = [
        "# Revised Full Method: Prespecified Trial Comparison", "",
        f"Split: {summary['split']}; status: {summary['status']}.", "",
        "All methods share the same physical scenario. TD3 supplies the motion action directly; no fixed-time controller is added. Terminated episodes remain included, and missing values are N/A rather than zero.",
        "Development scenarios inform selection; held-out scenarios are not evidence of independence unless unused during tuning. One training seed is documented per method in this workflow; paired scenario bootstrap does not measure training-seed variability. Multiple metric intervals are descriptive.",
        "Equal environment steps need not imply equal gradient updates or compute. Comparisons between 100k exploratory runs and historical 1M checkpoints are continuation checks, not matched-budget tests.",
        "", "## Primary Mission and Communication Metrics", "",
        "| Method / steps | Completed / total | Fixed 1200-s goodput (bit/s) | Executed-time goodput (bit/s) | AoI (s) | Sensors served / 30 |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for label, row in data.items():
        values = [mean_sd(row["selected_metrics"][key]) for key in (
            "fixed_budget_goodput_bit_s", "goodput_bit_s",
            "environment.state_aoi.pooled.mean", "environment.collection.distinct_served_sensors")]
        lines.append(f"| {label} | {row['full_horizon_episodes']}/{row['total_episodes']} | {' | '.join(values)} |")
    if summary.get("gate"):
        gate = summary["gate"]
        lines.extend(["", "## Prespecified Continuation Gate", "",
            "Status: passed for continuation." if gate["passed"] else "Status: not passed; review before continuation.",
            "The 1200-s goodput mean must exceed 110% of the historical Full 1M reference, with no fewer completions or higher episode-mean AoI.",
            "This gate authorizes additional training only; it is not evidence that every baseline was surpassed."])
    lines.extend(["", "## All 75 Prespecified Metrics: Episode Mean and Sample SD", ""])
    for section in dict.fromkeys(item["section"] for item in summary["metric_definitions"].values()):
        lines.extend([f"### {section}", "", "| Metric | Method / steps | Mean and SD | Valid / missing episodes |", "|---|---|---:|---:|"])
        for key, definition in summary["metric_definitions"].items():
            if definition["section"] != section: continue
            for label, row in data.items():
                value = row["selected_metrics"][key]
                lines.append(f"| {definition.get('label_en', definition.get('label_zh', key))} ({definition['unit']}) | {label} | {mean_sd(value)} | {value['n']}/{value['missing_n']} |")
        lines.append("")
    lines.extend(["## Pooled Metrics and Interpretation", "",
        "| Method / steps | AUV-time AoI P95 (s) | AoI > 90 s fraction | All-hop non-delivery | DATA-hop non-delivery | STATE-hop non-delivery |",
        "|---|---:|---:|---:|---:|---:|"])
    for label, row in data.items():
        values = [row["pooled"][key]["value"] for key in (
            "aoi_true_pooled_p95_s", "aoi_gt90_fraction", "hop_ALL_completion_nondelivery",
            "hop_DATA_completion_nondelivery", "hop_STATE_completion_nondelivery")]
        lines.append(f"| {label} | " + " | ".join("N/A" if value is None else f"{value:.6g}" for value in values) + " |")
    lines.extend(["",
        "Pooled JSON metrics are computed from pooled numerators and denominators. AUV-time AoI P95 uses all observed AUV/step samples, not the mean of per-episode P95 values.",
        "Local navigation error, USV-cached position error, and five-second planner-prediction error are distinct and must report coverage. Unavailable estimates are not imputed as zero.",
        "Hop-level non-delivery, logical STATE/DATA delivery, and successful-packet latency use different denominators; unresolved packets at the window boundary are right-censored.",
        "Control-packet count, control-bit share, actual on-air time, and reserved-slot time have different denominators; packet percentages are not channel-utilization percentages.",
        "Early failure changes energy, motion and transmission exposure; interpret energy alongside duration and fixed-budget goodput. Credited payload requires a unique accepted sensor-to-AUV DATA packet.",
        "", "## Paired Differences and 95% Intervals", "",
        "All registered metrics and missing-pair counts remain in comparison.json. The displayed difference is right minus left.", "",
        "| Right minus left | Metric | Mean difference | 95% interval | Pairs |", "|---|---|---:|---:|---:|"])
    for label, pair in summary["comparisons"].items():
        for key in ("fixed_budget_goodput_bit_s", "environment.state_aoi.pooled.mean",
                    "environment.collection.distinct_served_sensors"):
            item = pair["metrics"][key]
            fmt = lambda x: "N/A" if x is None else f"{x:.6g}"
            name = summary["metric_definitions"][key].get("label_en", summary["metric_definitions"][key].get("label_zh", key))
            lines.append(f"| {label} | {name} | {fmt(item['mean_difference'])} | [{fmt(item['ci95_low'])}, {fmt(item['ci95_high'])}] | {item['n_pairs']} |")
    lines.extend(["", "Unsuccessful trials are retained. No automatic retuning or outcome-based model selection follows failed gates. Raw episode files, trajectories and their SHA-256 identities must be supplied separately for full reproduction.", ""])
    return "\n".join(lines)

def summarize(campaign, split):
    from scripts.summarize_tmc_retest import selected_specs
    campaign = Path(campaign).resolve()
    protocol, protocol_sha = read(campaign / "protocol.json"), sha(campaign / "protocol.json")
    validate_frozen(campaign, protocol, protocol_sha)
    output = campaign / ("pilot_comparison" if split == "development" else "comparison")
    require(not output.exists(), "Comparison requires a NEW output directory; no re-selection")
    datasets, files = {}, {str(campaign / "protocol.json"): protocol_sha}
    for descriptor in dataset_descriptors(campaign, protocol, split):
        dataset, evidence = load_dataset(descriptor, protocol, split)
        datasets[descriptor["label"]] = dataset
        files.update(evidence)
    result = {"format": "collection-v3-campaign-comparison-v1", "status": "completed", "split": split,
        "campaign_id": protocol["campaign_id"], "config_fingerprint": protocol["config_fingerprint"],
        "training_seed": 7, "evaluation": SPLITS[split], "datasets": datasets,
        "metric_definitions": {key: {"label_zh": label, "unit": unit, "section": section}
                               for key, label, unit, section, _ in selected_specs()},
        "comparisons": paired_comparisons(datasets, split, protocol["bootstrap_resamples"]),
        "evidence_sha256": files, "limitations": protocol["limitations"]}
    if split == "development":
        result["gate"] = continuation_gate(datasets[f"{REVISION}_0100000"], datasets[f"{OLD_FULL}_1000000"])
    verify_files(files)
    validate_frozen(campaign, protocol, protocol_sha)
    output.mkdir()
    write_json(result, output / "comparison.json")
    (output / "REPORT_ZH.md").write_text(render_report(result), encoding="utf-8")
    require(read(output / "comparison.json")["status"] == "completed" and (output / "REPORT_ZH.md").stat().st_size > 0,
            "Final report verification failed")
    return {"status": "completed", "split": split, "datasets": len(datasets), "output": str(output),
            "gate": result.get("gate")}


def run(campaign):
    campaign = Path(campaign).resolve()
    protocol, initial = read(campaign / "protocol.json"), read(campaign / "campaign_status.json")
    require(initial["status"] == "prepared", "Campaign must be prepared and never started")
    protocol_sha = initial["protocol_sha256"]
    validate_frozen(campaign, protocol, protocol_sha)
    with (campaign / "runner_claim.json").open("x", encoding="utf-8") as stream:
        json.dump({"pid": os.getpid(), "claimed_at": now(), "protocol_sha256": protocol_sha}, stream)
    status = {"status": "running", "campaign_id": protocol["campaign_id"], "runner_pid": os.getpid(),
              "started_at": now(), "protocol_sha256": protocol_sha, "completed_stages": [], "child_pid": None}
    awake = os.name == "nt" and bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))

    def publish(**values):
        status.update(values, updated_at=now())
        write_json(status, campaign / "campaign_status.json")

    def child(label, arguments, progress):
        validate_frozen(campaign, protocol, protocol_sha)
        logs = campaign / "process_logs"
        logs.mkdir(exist_ok=True)
        stdout, stderr = logs / f"{label}.stdout.log", logs / f"{label}.stderr.log"
        command = [protocol["python"], "-u", *arguments]
        publish(stage=label, command=command, active_progress_path=str(progress), active_stdout=str(stdout), active_stderr=str(stderr))
        environment = os.environ.copy()
        environment.update(PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
        with stdout.open("xb") as out, stderr.open("xb") as err:
            process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err, stdin=subprocess.DEVNULL,
                env=environment, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            publish(child_pid=process.pid)
            try:
                code = process.wait()
            except BaseException:
                # Kill only this exact directly owned child, never another learner.
                process.terminate()
                process.wait(timeout=30)
                raise
        publish(child_pid=None, child_returncode=code)
        require(code == 0, f"Stage {label} failed ({code}); no automatic retry; inspect {stderr}")
        validate_frozen(campaign, protocol, protocol_sha)
        status["completed_stages"].append(label)
        publish()

    def evaluate_split(split):
        for descriptor in dataset_descriptors(campaign, protocol, split):
            child(f"{split}_{descriptor['label']}", evaluation_command(campaign, descriptor, split),
                  Path(descriptor["output"]) / "progress.json")
            summary = read(Path(descriptor["output"]) / "evaluation_summary.json")
            require(summary["status"] == "completed", "Evaluation did not finish")
            validate_episode_set(summary["episodes"], split)
        out = "pilot_comparison" if split == "development" else "comparison"
        child(f"summarize_{split}", ["-m", "improved.campaign", "summarize", "--campaign", str(campaign), "--split", split],
              campaign / out / "progress.json")
        return read(campaign / out / "comparison.json")

    try:
        publish(prevent_idle_sleep_while_running=awake)
        child("train_pilot", training_command(campaign), campaign / "pilot_train/progress.json")
        verify_training(campaign, protocol)
        pilot_checkpoint = campaign / "pilot_train/checkpoint_latest.pt"
        # Bind continuation to the exact completed 100k latest checkpoint.
        pilot_policy = campaign / "pilot_train/milestones/step_0100000/checkpoint.pt"
        from usv_auv.deploy import load_checkpoint
        saved = load_checkpoint(pilot_checkpoint)
        require(saved["global_step"] == 100000 and saved["source_hashes"] == protocol["source_hashes"]
                and saved["environment_config"] == protocol["environment_config"], "Pilot latest is not the completed 100k checkpoint")
        del saved
        pilot_identity = {str(path): sha(path) for path in (pilot_checkpoint, pilot_policy)}
        pilot = evaluate_split("development")
        publish(pilot_gate=pilot["gate"], pilot_report=str(campaign / "pilot_comparison/REPORT_ZH.md"))
        if not pilot["gate"]["passed"]:
            publish(status="needs_review", stage="pilot_gate_failed", finished_at=now(),
                    reason="Preregistered gate failed; no continuation, no held-out use, no autotune")
            return status
        verify_files(pilot_identity)
        publish(pilot_checkpoint_identity=pilot_identity)
        child("train_continuation", training_command(campaign, True), campaign / "continuation_train/progress.json")
        verify_training(campaign, protocol, True)
        result = evaluate_split("heldout")
        require(result["status"] == "completed" and len(result["datasets"]) == 12, "Final comparison incomplete")
        require(len(result["metric_definitions"]) == 75, "Missing planned communication metrics")
        verify_files(result["evidence_sha256"])
        validate_frozen(campaign, protocol, protocol_sha)
        publish(status="complete", stage="complete", finished_at=now(), report=str(campaign / "comparison/REPORT_ZH.md"),
                final_comparison_sha256=sha(campaign / "comparison/comparison.json"))
        return status
    except BaseException as error:
        publish(status="failed", error=repr(error), traceback=traceback.format_exc(), failed_at=now())
        raise
    finally:
        if awake:
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


def check(campaign):
    campaign = Path(campaign).resolve()
    status = read(campaign / "campaign_status.json")
    progress = status.get("active_progress_path")
    if progress and Path(progress).is_file():
        status["active_progress"] = read(progress)
    status["runner_alive"] = pid_alive(status.get("runner_pid"))
    status["child_alive"] = pid_alive(status.get("child_pid"))
    return status


def pid_alive(pid):
    """Read-only PID liveness; null is unassigned, not evidence of failure."""
    if pid is None:
        return None
    if os.name == "nt":
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, int(pid))
        if not handle:
            return None if ctypes.get_last_error() == 5 else False
        try:
            code = wintypes.DWORD()
            return bool(code.value == 259) if kernel.GetExitCodeProcess(handle, ctypes.byref(code)) else None
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "run", "check", "summarize", "evaluate-old"))
    parser.add_argument("--campaign", type=Path, default=DEFAULT_CAMPAIGN)
    parser.add_argument("--split", choices=tuple(SPLITS), default="development")
    parser.add_argument("--budget", type=int, choices=BUDGETS, default=1000000)
    args = parser.parse_args()
    if args.mode == "prepare": result = prepare(args.campaign)
    elif args.mode == "run": result = run(args.campaign)
    elif args.mode == "check": result = check(args.campaign)
    elif args.mode == "summarize": result = summarize(args.campaign, args.split)
    else: result = evaluate_old(args.campaign, args.split, args.budget)
    print(json.dumps(result, ensure_ascii=True, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
