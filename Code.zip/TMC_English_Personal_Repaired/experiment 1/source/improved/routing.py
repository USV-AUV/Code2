"""Causal, event-triggered topology admissibility and charged lease renewal.

Only root-local reports, received STATE timestamps, root's own installed route,
and acknowledgements inform decisions. Physical channels, slots, queue service,
packet sizes, leases, and CONFIG/ACK transport are inherited without alteration.
This is a disclosed method/protocol change, not a modification of the old core.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math

import numpy as np

from usv_auv.network import AcousticNetwork


@dataclass(frozen=True)
class RoutingOptions:
    decision_dwell_s: float = 60.0
    renewal_margin_s: float = 60.0
    direct_recovery_s: float = 30.0
    state_stale_s: float | None = None  # None means the unchanged cfg.state_ttl.
    keep_renews: bool = True

    def __post_init__(self):
        for field in ("decision_dwell_s", "renewal_margin_s", "direct_recovery_s"):
            value = getattr(self, field)
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"{field} must be finite and nonnegative")
        if self.state_stale_s is not None and (not math.isfinite(self.state_stale_s) or self.state_stale_s <= 0):
            raise ValueError("state_stale_s must be positive or None")
        if type(self.keep_renews) is not bool:
            raise ValueError("keep_renews must be boolean")

    def to_dict(self):
        return asdict(self)


ROOT_ROUTING_FIELDS = (
    "root_lease_remaining_fraction", "root_lease_expired", "root_lease_infinite",
    "request_dwell_elapsed_fraction", "root_ack_consistent", "repair_uncertainty",
)
NODE_ROUTING_FIELDS = (
    "direct_report_good", "direct_report_failed", "state_age_fraction", "state_stale",
    "state_received", "direct_recovery_progress",
)


def root_routing_fields(n_auv):
    return ROOT_ROUTING_FIELDS + tuple(f"auv_{node}_{name}" for node in range(1, n_auv + 1)
                                       for name in NODE_ROUTING_FIELDS)


root_feature_names = root_routing_fields


def _options(network):
    return getattr(network, "routing_options", RoutingOptions())


def _now(network, now):
    value = float(now)
    if not math.isfinite(value) or not math.isclose(value, float(network.time), abs_tol=1e-8, rel_tol=0.):
        raise ValueError("Routing decisions must use the root's current network time")
    return value


def _root_route(network):
    version = network.active_version[0]
    # Never inspect another node's installed_routes or active_version.
    own = network.installed_routes[0].get(version)
    if own is None:
        raise ValueError("Root's active route record is missing")
    parents, expires = own
    return int(version), tuple(parents), float(expires)


def _ack_consistent(network):
    root_version = network.active_version[0]
    return all(network.confirmed_versions.get(node, -1) == root_version
               for node in range(1, network.n_auvs + 1))


def _repair_required(network):
    uncertain_version = getattr(network, "_routing_uncertain_version", None)
    if uncertain_version is not None and network.active_version[0] > uncertain_version and _ack_consistent(network):
        network._routing_uncertain_version = None
        uncertain_version = None
    return uncertain_version is not None or not _ack_consistent(network)


def _incident_status(network, node, now):
    good = True
    failed = False
    for edge in ((0, node), (node, 0)):
        report = network._root_edges.get(edge)
        valid = (report is not None and 0. <= now - report[0] <= network.report_max_age)
        good = good and valid and report[1] > 0
        failed = failed or (valid and report[1] <= 0)
    return bool(good), bool(failed)


def _evidence(network, now):
    """Update root-local healthy-report dwell memory; no physical observations."""
    options = _options(network)
    stale_after = network.state_ttl if options.state_stale_s is None else options.state_stale_s
    if not hasattr(network, "_routing_healthy_since"):
        network._routing_healthy_since = {}
    values = {}
    for node in range(1, network.n_auvs + 1):
        good, failed = _incident_status(network, node, now)
        if good:
            network._routing_healthy_since.setdefault(node, now)
        else:
            network._routing_healthy_since.pop(node, None)
        received = network.received_states.get(node)
        stamp = received.packet.created_at if received is not None else 0.
        if stamp > now + 1e-8:
            raise ValueError("Received STATE generation time is in the future")
        age = max(0., now - stamp)
        duration = now - network._routing_healthy_since[node] if good else 0.
        values[node] = {"good": good, "failed": failed, "age": age,
                        "stale": age > stale_after, "received": received is not None,
                        "healthy_duration": duration,
                        "recovered": good and duration >= options.direct_recovery_s}
    return values


def root_features(network, now):
    """Stable ordered dict; root_routing_fields(n) is its explicit schema."""
    now = _now(network, now)
    options = _options(network)
    _, _, expires = _root_route(network)
    evidence = _evidence(network, now)
    ttl = network.state_ttl if options.state_stale_s is None else options.state_stale_s
    lease = network.route_lease
    elapsed = now - network._last_switch
    values = {
        "root_lease_remaining_fraction": 1. if math.isinf(expires) else np.clip((expires - now) / lease, 0., 1.),
        "root_lease_expired": float(expires < now), "root_lease_infinite": float(math.isinf(expires)),
        "request_dwell_elapsed_fraction": 1. if options.decision_dwell_s == 0 else min(1., elapsed / options.decision_dwell_s),
        "root_ack_consistent": float(_ack_consistent(network)), "repair_uncertainty": float(_repair_required(network)),
    }
    for node, item in evidence.items():
        fields = (float(item["good"]), float(item["failed"]), min(item["age"] / ttl, 1.),
                  float(item["stale"]), float(item["received"]),
                  (float(item["good"]) if options.direct_recovery_s == 0
                   else min(1., item["healthy_duration"] / options.direct_recovery_s)))
        for name, value in zip(NODE_ROUTING_FIELDS, fields):
            values[f"auv_{node}_{name}"] = float(value)
    if tuple(values) != root_routing_fields(network.n_auvs):
        raise AssertionError("Root routing feature ordering changed")
    return {key: float(value) for key, value in values.items()}


def _renewal_due(network, now):
    _, _, expires = _root_route(network)
    return _repair_required(network) or expires - now <= _options(network).renewal_margin_s


def routing_mask(network, now, base_mask):
    """Subset of existing physical-report admissibility plus KEEP.

    A relay is permitted only for a source whose direct exchange failed or
    STATE is stale, and only along candidate edges already supported by fresh
    bidirectional reports. No fault timetable, true positions or remote queues
    enter this decision. Direct recovery requires sustained positive reports.
    """
    now = _now(network, now)
    mask = np.asarray(base_mask, dtype=bool)
    if mask.shape != (network.n_actions,) or not mask[0]:
        raise ValueError("Base action mask must include KEEP and match candidates")
    result = np.zeros_like(mask)
    result[0] = True
    options = _options(network)
    evidence = _evidence(network, now)
    if network.pending is not None or now - network._last_switch < max(network.switch_dwell, options.decision_dwell_s):
        return result
    _, active, _ = _root_route(network)
    for action, parents in enumerate(network.topologies, 1):
        if not mask[action]:
            continue
        parents = tuple(parents)
        if parents == active:
            result[action] = _renewal_due(network, now)
            continue
        admissible = True
        for node, parent in enumerate(parents, 1):
            if parent:
                # Keep an existing detour during its direct-link recovery dwell;
                # a *new* detour needs source-specific impairment evidence.
                if active[node - 1] != parent:
                    admissible &= evidence[node]["failed"] or evidence[node]["stale"]
                # Candidate is depth two; its relay must retain a usable direct
                # root link. Base mask supplies all candidate bidirectional edges.
                admissible &= evidence[parent]["good"]
            elif active[node - 1]:
                admissible &= evidence[node]["recovered"]
        result[action] = bool(admissible)
    return result


class HysteresisRoutingNetwork(AcousticNetwork):
    """The original charged CONFIG transport with root-local policy decisions.

    Local nodes still activate a received version before all ACKs reach root:
    this is NOT atomic two-phase commit and temporary partial installation is
    still possible. Expired/failed transactions create uncertainty; recovery
    rolls forward with a new charged version, never a free remote rollback.
    """

    def __init__(self, cfg, seed=0, routing_options=None):
        self.routing_options = (routing_options if isinstance(routing_options, RoutingOptions)
                                else RoutingOptions(**(routing_options or {})))
        self._routing_healthy_since = {}
        self._routing_uncertain_version = None
        super().__init__(cfg, seed)
        if self.routing_options.renewal_margin_s >= self.route_lease:
            raise ValueError("Renewal margin must be smaller than unchanged physical lease")

    def _maintenance(self):
        # Sample only root's reports as time advances. Detect recovery continuity
        # even when the DDQN is not called at every physical network event.
        _evidence(self, self.time)
        if self.pending is not None and self.pending["expires"] <= self.time:
            self._routing_uncertain_version = max(self._routing_uncertain_version or -1, self.pending["version"])
            self.metrics["routing_expired_transactions_abandoned"] += 1
            self.pending = None
        before = self.pending
        old_timeouts = self.metrics.get("config_timeouts", 0)
        super()._maintenance()
        if before is not None and self.pending is None and self.metrics.get("config_timeouts", 0) > old_timeouts:
            self._routing_uncertain_version = max(self._routing_uncertain_version or -1, before["version"])
            self.metrics["routing_timed_out_transactions_uncertain"] += 1
        _evidence(self, self.time)

    def action_mask(self, time=None):
        now = self.time if time is None else time
        return routing_mask(self, now, super().action_mask(now))

    def request_topology(self, parents, time=None):
        now = _now(self, self.time if time is None else time)
        _, active, _ = _root_route(self)
        keep_requested = isinstance(parents, (int, np.integer)) and int(parents) == 0
        admissible = self.action_mask(now)
        if keep_requested:
            if not self.routing_options.keep_renews or not _renewal_due(self, now):
                return True
            action = self.topologies.index(active) + 1
            if not admissible[action]:
                self.metrics["routing_renewal_deferred"] += 1
                return True  # KEEP cannot manufacture a feasible route or ACK.
            parents = active
        elif isinstance(parents, (int, np.integer)):
            action = int(parents)
            if not 1 <= action < self.n_actions:
                raise ValueError("Invalid topology action")
            parents = self.topologies[action - 1]
        else:
            parents = tuple(int(value) for value in parents)
            if parents not in self.topologies:
                raise ValueError("Topology must be a supported rooted depth-two tree")
            action = self.topologies.index(parents) + 1
        parents = tuple(parents)
        if not admissible[action]:
            # Root-local no-op for a fully acknowledged healthy active version.
            # Crucially, no remote installed route is consulted here.
            if parents == active and self.pending is None and not _renewal_due(self, now):
                return True
            self.metrics["routing_inadmissible_requests"] += 1
            return False
        renewal = parents == active
        self._version_counter += 1
        version = self._version_counter
        expires = now + self.route_lease
        self.installed_routes[0][version] = (parents, expires)
        self.pending = {"version": version, "parents": parents, "expires": expires,
                        "deadline": now + self.config_timeout, "requested_at": now,
                        "retries": 0, "acks": set()}
        self.metrics["config_requests"] += 1
        self.metrics["routing_same_parent_transactions" if renewal else "routing_parent_change_transactions"] += 1
        if renewal and keep_requested:
            self.metrics["routing_keep_triggered_renewals"] += 1
        self._last_switch = now
        self._send_config_roots()  # Unchanged queued, serialized, fallible CONFIG.
        return True
