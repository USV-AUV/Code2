"""Method-only revision: causal fusion, bounded forecasts, service observations.

Physical integration, currents, faults, TDMA, payload collection, safety limits
and metric accounting are inherited without changes. No simulation truth is
used by the added observation/planning functions. TD3 still emits final actions.
"""
from dataclasses import dataclass, asdict
import math
import numpy as np

from usv_auv.environment import CooperativeEnv
from usv_auv.planner import PlannerConfig, PlanResult, reachable_candidates, usbl_position_fim
from usv_auv.observations import observation_fields, root_observation_fields
from .estimation import CausalNavigation
from .routing import HysteresisRoutingNetwork, RoutingOptions, root_features


SERVICE_FIELDS = ('grant_valid', 'grant_lease_left', 'grant_age', 'request_pending',
                  'request_age', 'sensor_slot_phase_sin', 'sensor_slot_phase_cos',
                  'navigation_sigma', 'target_dwell')


@dataclass(frozen=True)
class MethodOptions:
    prediction_tau_s: float = 3.0
    navigation_fix_sigma: float = 3.0
    missing_velocity_sigma: float = 0.25

    def __post_init__(self):
        if any(not math.isfinite(x) or x <= 0 for x in asdict(self).values()):
            raise ValueError('Method options must be finite and positive')


def bounded_prediction(payload, now, horizon=0., tau=3.):
    """Damped velocity persistence, not a claim to know future actor actions.

The damping applies to ground velocity (command + estimated current), so a
station-keeping command does not create a fictitious long-term drift.
Packets and their original timestamps are never rewritten.
"""
    age = now + horizon - float(payload['source_time'])
    if age < 0 or not math.isfinite(age) or tau <= 0:
        raise ValueError('Invalid source timestamp or damping scale')
    drift = np.asarray(payload['disturbance']) if payload.get('disturbance_valid', False) else np.zeros(2)
    velocity = np.asarray(payload['velocity']) + drift
    return np.asarray(payload['position']) + (-tau * math.expm1(-age / tau)) * velocity


class ImprovedEnv(CooperativeEnv):
    observation_schema_version = 'collection-v3-fused-service-damped-routing-v1'

    def __init__(self, cfg=None, method_options=None, routing_options=None):
        self.method_options = method_options or MethodOptions()
        self.routing_options = routing_options or RoutingOptions()
        self._revision_ready = False
        super().__init__(cfg)
        self.observation_schema = observation_fields(self.cfg.n_auv) + list(SERVICE_FIELDS)
        self.observation_dim = len(self.observation_schema)
        self.slow_observation_schema = root_observation_fields(self.cfg.n_auv) + list(root_features(self.network, self.time))
        self.slow_observation_dim = len(self.slow_observation_schema)
        self.last_observations = self._observations()

    def reset(self, seed=None):
        self._revision_ready = False
        super().reset(seed)
        c, m = self.cfg, self.method_options
        # Use exactly the noisy deployment positions already sampled by base.
        initial_positions = [nav.position for nav in self.nav]
        self.nav = [CausalNavigation(p, history_seconds=c.navigation_history_seconds,
                    measurement_sigma=c.displacement_sigma, initial_sigma=c.initial_position_sigma,
                    fix_sigma=m.navigation_fix_sigma, missing_velocity_sigma=m.missing_velocity_sigma)
                    for p in initial_positions]
        self.network = HysteresisRoutingNetwork(c, self.seed, routing_options=self.routing_options)
        self.network.application_link_filter = self._data_in_range
        self.network.on_transmit_payload = self._physical_localization
        self._revision_ready = True
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _observations(self):
        base = super()._observations()
        if not self._revision_ready:
            return base
        c = self.cfg
        rows = []
        for i in range(c.n_auv):
            # Rebuild only peer predictions, using the same received packets.
            coord = self.coord_cache[i]
            if coord and coord.get('source_time', math.inf) <= self.time:
                offset = 28
                for peer in range(1, c.n_auv + 1):
                    if peer == i + 1:
                        continue
                    payload = coord.get('states', {}).get(str(peer))
                    if payload is not None and payload['source_time'] <= self.time:
                        age = self.time - payload['source_time']
                        if age <= c.state_ttl:
                            xy = bounded_prediction(payload, self.time, tau=self.method_options.prediction_tau_s)
                            base[i, offset:offset + 2] = (xy - self.nav[i].position) / c.area_size
                        else:
                            base[i, offset:offset + 4] = [0., 0., 1., 0.]
                    offset += 4
            target = int(self.targets[i])
            grant = self.received_service_grants[i].get(target)
            valid = grant is not None and grant['expires_at'] > self.time
            request = self.service_request_times[i].get(target, -math.inf)
            pending = math.isfinite(request) and (grant is None or grant['source_time'] < request)
            # Preinstalled TDMA calendar is known locally, not a live queue peek.
            owner = c.n_auv + 1 + target
            slot = self.network.slot_owners.index(owner)
            frame = len(self.network.slot_owners) * c.slot_duration
            phase = 2 * math.pi * ((self.time - slot * c.slot_duration) % frame) / frame
            variance = float(self.nav[i].position_variance)
            extras = [float(valid), max(0., grant['expires_at'] - self.time) / c.grant_ttl if valid else 0.,
                      min((self.time - grant['source_time']) / c.state_ttl, 1.) if grant else 1.,
                      float(pending), min((self.time - request) / self.service_retry_interval, 1.) if pending else 1.,
                      math.sin(phase), math.cos(phase), math.sqrt(max(variance, 0.)) / c.collection_radius,
                      min(max(self.time - self.target_since[i], 0.) / c.target_max_dwell, 1.)]
            rows.append(np.r_[base[i], extras])
        result = np.asarray(rows, np.float32)
        if not np.isfinite(result).all():
            raise ValueError('Nonfinite revision observations')
        return result

    def _state_payload(self, i):
        payload = super()._state_payload(i)
        if self._revision_ready:
            # Same wire field, interpreted as nominal position uncertainty.
            payload['uncertainty'] = math.sqrt(max(self.nav[i].position_variance, 0.))
        return payload

    def _plan_usv(self):
        c = self.cfg
        horizon = c.dt * c.slow_period
        pc = PlannerConfig(bounds=((0., c.area_size), (0., c.area_size)), usv_max_speed=c.usv_speed)
        candidates = reachable_candidates(self.usv_position, horizon, pc)
        payloads = {node: d.packet.payload for node, d in self.network.received_states.items()
                    if 1 <= node <= c.n_auv and 0 <= self.time - d.packet.payload['source_time'] <= c.state_ttl}
        predicted = {node: bounded_prediction(p, self.time, horizon, self.method_options.prediction_tau_s)
                     for node, p in payloads.items()}
        reports = self.network.link_reports
        def quality(a, b):
            report = reports.get((a, b))
            if report is None or not 0 <= self.time - report[0] <= c.report_ttl:
                return 0.
            return float(report[1]) * math.exp(-(self.time - report[0]) / c.report_ttl)
        scores, components = [], []
        for point in candidates:
            localization, route = 0., 0.
            for node, xy in predicted.items():
                uncertainty = payloads[node].get('uncertainty', 0.) + .2 * (self.time + horizon - payloads[node]['source_time'])
                weight = math.exp(-uncertainty / c.area_size) / max(1, len(predicted))
                fim = usbl_position_fim(xy, point, c.auv_depth, max(c.usbl_sigma, 1e-6), max(c.usbl_bearing_sigma, 1e-6))
                success = quality(node, 0) * quality(0, node)
                localization -= weight * np.linalg.slogdet(np.eye(2) + success * fim)[1]
                # Move toward the actual USV-facing relay endpoints, not every
                # remote child as if every link were a direct localization fix.
                if self.network.root_parents[node - 1] == 0:
                    route += weight * quality(node, 0) * np.linalg.norm(point - xy) / c.area_size
            movement = np.sum((point - self.usv_position) ** 2) / c.area_size**2
            parts = dict(localization=float(localization), route=float(route), movement=float(movement))
            components.append(parts)
            scores.append(localization + .2 * route + .1 * movement)
        best = int(np.argmin(scores))
        self.last_plan = PlanResult(candidates[best].copy(), float(scores[best]), components[best],
                                    predicted, candidates, np.asarray(scores))
        self.usv_target = self.last_plan.target.copy()

    def slow_state(self):
        state, mask = super().slow_state()
        return np.r_[state, list(root_features(self.network, self.time).values())].astype(np.float32), mask

    def step(self, actions, topology_action=None):
        commands = self.decode_actions(actions, self.cfg.max_speed, self.cfg.action_frame, self.last_observations)
        for i, nav in enumerate(self.nav):
            old = self.usde[i].snapshot()
            nav.set_motion_prior(commands[i], old.estimate, old.initialized, old.age)
        return super().step(actions, topology_action)
