"""Causal method-only navigation fusion; the physical sensors stay unchanged.

Only measured motion, known executed commands, a *previous* local disturbance
estimate and actually arrived fixes may enter this module.  Imputed increments
are navigation priors, never replacement measurements for USDE.  Covariances
are an isotropic nominal filter model, not truth-based or calibrated bounds.
In particular fix_sigma=3 m is NOT a conservative bound at every USBL geometry.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Sequence

import numpy as np


def _xy(value: Sequence[float], name: str) -> np.ndarray:
    result = np.array(value, dtype=float, copy=True)
    if result.shape != (2,) or not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be a finite two-vector")
    return result


@dataclass(frozen=True)
class _Sample:
    time: float
    integral: np.ndarray
    process_variance: float


class CausalNavigation:
    """Increment odometry with uncertain gap prediction and delayed fix fusion.

    ``measurement_sigma`` is the displacement standard deviation per valid
    advance call, in metres.  ``initial_sigma`` and ``fix_sigma`` are per-axis
    position standard deviations.  Missing intervals use a one-shot prior
    with nominal velocity sigma ``missing_velocity_sigma`` (m/s), increased
    with estimate age.  Those process errors are modeled independently; an
    uncertain held drift can in reality be temporally correlated.

    A source-time fix is fused only after arrival.  For an in-order source time
    tau, the nominal random-walk model gives P_tau=P_now-(Q_now-Q_tau),
    K=P_tau/(P_tau+R), and P_now_new=P_now-K*P_tau.  Thus uncertainty accumulated
    *after* tau is not falsely removed.  History stores the motion integral and
    cumulative Q; previous accepted fixes alter their common position offset,
    not their increments.  Fractional timestamps use linear interpolation of
    motion and Q, a nominal continuous-diffusion approximation within a step.

    Strict source-time ordering rejects duplicate/out-of-order fixes.  Distinct
    accepted fixes are assumed independent by this model: repeated correlated
    physical biases are not eliminated merely by averaging more fixes.
    """

    def __init__(self, initial_position, timestamp=0., history_seconds=600.,
                 measurement_sigma=.025, initial_sigma=.5, fix_sigma=3.,
                 missing_velocity_sigma=.25, prior_age_scale=30.):
        for name, value, positive in (
            ("history_seconds", history_seconds, True),
            ("measurement_sigma", measurement_sigma, False),
            ("initial_sigma", initial_sigma, False),
            ("fix_sigma", fix_sigma, True),
            ("missing_velocity_sigma", missing_velocity_sigma, True),
            ("prior_age_scale", prior_age_scale, True),
        ):
            if not math.isfinite(value) or (value <= 0 if positive else value < 0):
                raise ValueError(f"Invalid {name}")
            setattr(self, name, float(value))
        self.reset(initial_position, timestamp)

    def reset(self, initial_position, timestamp=0.):
        if not math.isfinite(timestamp):
            raise ValueError("timestamp must be finite")
        self._position = _xy(initial_position, "initial_position")
        self._time = float(timestamp)
        self._start_time = self._time
        self._integral = np.zeros(2)
        self._process_variance = 0.
        self._position_variance = self.initial_sigma ** 2
        self._history = [_Sample(self._time, self._integral.copy(), 0.)]
        self._last_correction_time = None
        self._prior = None
        self.measurement_valid = True
        self.last_increment_predicted = False
        self.last_motion_prior_used = False
        self.last_fix_gain = None
        return self.position

    @property
    def position(self):
        return self._position.copy()

    @property
    def time(self):
        return self._time

    @property
    def last_correction_time(self):
        return self._last_correction_time

    @property
    def position_variance(self):
        """Nominal per-axis variance (m^2), not squared Euclidean RMSE."""
        return float(self._position_variance)

    @property
    def position_covariance(self):
        return np.eye(2) * self._position_variance

    def set_motion_prior(self, command, estimate=None, valid=True, age=0.):
        """Set the next interval's known command and past disturbance prior.

        ``valid`` means an initialized usable disturbance estimate, not the
        validity of the upcoming sensor interval.  The command must be the
        water-relative velocity actually held over that upcoming interval.
        Call before advancing physical time, never after seeing that interval.
        A prior is consumed even if the actual displacement turns out valid.
        """
        if not math.isfinite(age) or age < 0:
            raise ValueError("age must be finite and nonnegative")
        water_velocity = _xy(command, "command")
        disturbance = _xy(estimate, "estimate") if valid else np.zeros(2)
        self._prior = (water_velocity + disturbance, bool(valid), float(age))

    def advance(self, displacement, elapsed, valid=True):
        if not math.isfinite(elapsed) or elapsed <= 0:
            raise ValueError("elapsed must be finite and positive")
        prior = self._prior
        if valid:
            increment = _xy(displacement, "displacement")
            process_variance = self.measurement_sigma ** 2
        else:
            # Do not inspect invalid raw measurements.  Only the previously
            # declared prior may provide a navigation-only missing increment.
            velocity, initialized, age = prior if prior is not None else (np.zeros(2), False, 0.)
            increment = elapsed * velocity
            nominal_velocity_sigma = self.missing_velocity_sigma * (
                (1. if initialized else 2.) + age / self.prior_age_scale)
            process_variance = (elapsed * nominal_velocity_sigma) ** 2
        new_time = self._time + float(elapsed)
        if not math.isfinite(new_time) or not np.isfinite(increment).all() or not math.isfinite(process_variance):
            raise ValueError("Motion interval overflowed the navigation model")
        self._position += increment
        self._integral += increment
        self._time = new_time
        self._position_variance += process_variance
        self._process_variance += process_variance
        self._history.append(_Sample(self._time, self._integral.copy(), self._process_variance))
        cutoff = self._time - self.history_seconds
        # Keep one endpoint before the window for fractional-time interpolation.
        while len(self._history) > 2 and self._history[1].time <= cutoff:
            self._history.pop(0)
        self._prior = None
        self.measurement_valid = bool(valid)
        self.last_increment_predicted = not bool(valid)
        self.last_motion_prior_used = not bool(valid) and prior is not None
        return self.position

    def _history_at(self, source_time):
        tolerance = 1e-9
        lower = max(self._start_time, self._time - self.history_seconds)
        if source_time < lower - tolerance or source_time > self._time + tolerance:
            return None
        source_time = min(max(source_time, lower), self._time)
        for index, sample in enumerate(self._history):
            if abs(source_time - sample.time) <= tolerance:
                return sample.integral.copy(), sample.process_variance
            if sample.time > source_time:
                if index == 0:
                    return None
                previous = self._history[index - 1]
                fraction = (source_time - previous.time) / (sample.time - previous.time)
                return (previous.integral + fraction * (sample.integral - previous.integral),
                        previous.process_variance + fraction * (sample.process_variance - previous.process_variance))
        return None

    def correct_absolute(self, position, source_time):
        """Fuse an actually arrived fix; reject old/future/unretained sources.

        Predicted missing intervals can be propagated, with their explicitly
        increased uncertainty.  They never acquire a valid-measurement flag.
        The caller must not re-deliver the same physical fix with a new stamp.
        """
        measurement = _xy(position, "position")
        if not math.isfinite(source_time):
            raise ValueError("source_time must be finite")
        if self._last_correction_time is not None and source_time <= self._last_correction_time:
            return False
        history = self._history_at(float(source_time))
        if history is None:
            return False
        source_integral, source_q = history
        future_q = max(0., self._process_variance - source_q)
        source_p = max(0., self._position_variance - future_q)
        gain = source_p / (source_p + self.fix_sigma ** 2)
        source_prediction = self._position - (self._integral - source_integral)
        correction = gain * (measurement - source_prediction)
        if not np.isfinite(correction).all():
            raise ValueError("Localization innovation overflowed the navigation model")
        self._position += correction
        self._position_variance = max(0., self._position_variance - gain * source_p)
        self._last_correction_time = min(float(source_time), self._time)
        self.last_fix_gain = float(gain)
        return True
