"""Strict module identities for the new task-coupled V4, not historical V4."""
from dataclasses import asdict, dataclass
import hashlib
import json


@dataclass(frozen=True)
class MethodSpec:
    method_id: str
    name: str
    use_usde: bool
    use_topology: bool
    base_method_id: str = 'full_v4'
    adapter_version: str = 'task-v4-20260917-r2'

    def to_dict(self):
        return asdict(self)

    @property
    def fingerprint(self):
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True).encode()).hexdigest()[:16]


_METHODS = {
    'full_v4': MethodSpec('full_v4', 'Task V4 complete topology and USDE', True, True),
    'topology_only_v4': MethodSpec('topology_only_v4', 'Task V4 topology without USDE', False, True),
    'usde_only_v4': MethodSpec('usde_only_v4', 'Task V4 USDE without topology', True, False),
}
METHOD_IDS = tuple(_METHODS)


def get_method(method_id):
    try:
        return _METHODS[method_id]
    except (KeyError, TypeError) as exc:
        raise ValueError(f'Unknown task V4 method: {method_id!r}; expected one of {METHOD_IDS}') from exc
