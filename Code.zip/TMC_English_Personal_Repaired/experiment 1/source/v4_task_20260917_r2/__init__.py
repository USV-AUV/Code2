"""R2: R1 task method with exact V3 local sensor queue selection restored."""
