"""CPU-only, provenance-checked comparison of five methods at two budgets.

Consumes a finished campaign; never trains, evaluates policies, imports torch,
or changes existing evidence. Writes a NEW campaign/comparison directory.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from baselines.methods import METHOD_IDS, get_method
from scripts.summarize_tmc_retest import (
    dig, kind_summary, mean_sd, numeric, pooled_summary, selected_specs, stats,
    trace_pool,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
BUDGETS = (450000, 1000000)
TEST_SEEDS = list(range(9300000, 9300030))
FULL = "full_method"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fingerprint(config):
    return hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:16]


def paired_bootstrap(left, right, resamples=20000, seed=934091):
    """Right minus left; missing pairs excluded explicitly, failures retained."""
    require(len(left) == len(right), "Paired vectors differ in length")
    require(type(resamples) is int and resamples >= 100, "Need at least 100 bootstrap resamples")
    values = [numeric(b) - numeric(a) for a, b in zip(left, right) if a is not None and b is not None]
    count = len(values)
    result = {"n_pairs": count, "missing_pairs": len(left) - count,
              "mean_difference": float(np.mean(values)) if values else None,
              "ci95_low": None, "ci95_high": None,
              "resamples": resamples, "bootstrap_seed": seed,
              "method": "paired scene percentile bootstrap; right minus left; no multiple-comparison correction"}
    if count >= 2:
        delta = np.asarray(values, dtype=np.float64)
        rng = np.random.default_rng(seed)
        draws = delta[rng.integers(0, count, size=(resamples, count))].mean(axis=1)
        result["ci95_low"], result["ci95_high"] = map(float, np.quantile(draws, [.025, .975]))
    return result


def normalize_episode(row, model_step, method_id):
    """Only derived reporting fields; never change physical or stored metrics."""
    result = dict(row)
    metrics = result["metrics_base"]
    duration = numeric(result["duration_s"])
    require(duration > 0, "Episode duration must be positive")
    require(result["model_step"] == model_step, "Unexpected per-episode model budget")
    if "method_id" in result:
        require(result["method_id"] == method_id, "Episode method ID mismatch")
    require(not result.get("evaluation_limit_reached", False), "Evaluation ended before a physical termination or 1200-step horizon")
    result["survived_full_horizon"] = bool(not result["terminated"] and result["steps"] == 1200)
    require(result["terminated"] or (result["truncated"] and result["steps"] == 1200), "Unexpected stopping criterion")
    require(result["environment"]["collection"]["n_sensors"] == 30, "Expected 30 sensors")
    require(result["environment"]["state_aoi"]["ttl_s"] == 90., "Expected 90 s AoI threshold")
    require(result["network"]["core_counter_reconciliation"]["all_observed_counters_match_core"], "Passive network counters do not reconcile")
    require(result["environment"]["sampling"]["post_step_samples"] == result["steps"], "Observer steps mismatch")
    require(math.isclose(duration, float(result["steps"]), abs_tol=1e-7), "Expected dt=1 second")
    framing = result["network"]["data_framing"]
    packet_bits = framing["declared_payload_bits"]
    require(packet_bits > 0, "Missing DATA payload size")
    data = numeric(metrics["collected_bits"])
    available = metrics["initial_bits"] + metrics["arrival_bits"]
    result.update(goodput_bit_s=data / duration, fixed_budget_goodput_bit_s=data / 1200.,
                  collected_packets=data / packet_bits, ack_packets=metrics["ack_released_bits"] / packet_bits,
                  collection_fraction=data / available if available else None,
                  bits_per_joule=data / metrics["total_energy_j"] if metrics["total_energy_j"] else None,
                  time_mean_aoi_s=result["environment"]["state_aoi"]["pooled"]["mean"])
    return result


def numeric_fields(value, prefix=""):
    """All scalar metrics, excluding event arrays and identity strings."""
    result = {}
    if isinstance(value, dict):
        for key, child in value.items():
            result.update(numeric_fields(child, f"{prefix}.{key}" if prefix else key))
    elif value is None or isinstance(value, (bool, int, float)):
        result[prefix] = numeric(value)
    return result


class Evidence:
    def __init__(self):
        self.files = {}

    def check(self, path, expected=None, expected_bytes=None):
        path = Path(path).resolve()
        require(path.is_file(), f"Required evidence missing: {path}")
        if expected_bytes is not None:
            require(path.stat().st_size == expected_bytes, f"File size mismatch: {path}")
        actual = self.files.get(str(path)) or sha256(path)
        self.files[str(path)] = actual
        if expected is not None:
            require(actual == expected, f"SHA256 mismatch: {path}")
        return actual


def validate_protocol(campaign, evidence):
    path = campaign / "protocol.json"
    protocol = read_json(path)
    evidence.check(path)
    require(protocol["method_order"] == list(METHOD_IDS), "Unexpected four-method order")
    require(protocol["milestones"] == list(BUDGETS) and protocol["train_steps"] == 1000000, "Wrong campaign budgets")
    require(protocol["training_seed"] == 7, "Expected declared training seed 7")
    require(protocol["device"].startswith("cuda"), "Campaign is not CUDA training/evaluation")
    evaluation = protocol["evaluation"]
    require(evaluation["episodes"] == 30 and evaluation["steps"] == 1200, "Wrong evaluation budget")
    require(evaluation["seed"] == TEST_SEEDS[0] and evaluation["test_seeds"] == TEST_SEEDS, "Wrong scene seeds")
    require(fingerprint(protocol["environment_config"]) == protocol["config_fingerprint"], "Protocol config fingerprint mismatch")
    for config_path in (campaign / "frozen_config.json", Path(protocol["full_method_run_dir"]) / "frozen_config.json"):
        require(read_json(config_path) == protocol["environment_config"], "Current/campaign frozen environment config differs")
        evidence.check(config_path)
    require(set(protocol["source_hashes"]) == {"usv_auv", "baselines"}, "Missing core or baseline source identity")
    for method_id in METHOD_IDS:
        entry = protocol["methods"][method_id]
        method = get_method(method_id)
        require(entry["spec"] == method.to_dict() and entry["fingerprint"] == method.fingerprint, "Method definition changed")
    for package, hashes in protocol["source_hashes"].items():
        current_paths = {path.name for path in (PROJECT_ROOT / package).glob("*.py")}
        require(current_paths == set(hashes), f"Source set changed for {package}")
        for name, expected in hashes.items():
            evidence.check(PROJECT_ROOT / package / name, expected)
    for name, expected in protocol["pipeline_source_hashes"].items():
        path = (PROJECT_ROOT / name).resolve()
        require(path.is_relative_to(PROJECT_ROOT), "Pipeline source path escapes project")
        evidence.check(path, expected)
    for name, expected in protocol["protected_files"].items():
        evidence.check(Path(name), expected)
    return protocol


def verify_milestone(directory, budget, config_fp, evidence, method_id=None, method_fp=None):
    directory = Path(directory).resolve()
    metadata_path = directory / "metadata.json"
    metadata = read_json(metadata_path)
    evidence.check(metadata_path)
    require(metadata["global_step"] == budget, "Milestone metadata budget mismatch")
    require(metadata["config_fingerprint"] == config_fp, "Milestone config fingerprint mismatch")
    if method_id is not None:
        require(metadata["method_id"] == method_id and metadata["method_fingerprint"] == method_fp, "Milestone method mismatch")
    for name in ("checkpoint.pt", "policy.pt"):
        record = metadata["files"][name]
        evidence.check(directory / name, record["sha256"], record["bytes"])
    return metadata


def verify_episode_set(rows):
    require(len(rows) == 30, "Every model/budget needs all 30 evaluated scenes")
    require([row["seed"] for row in rows] == TEST_SEEDS, "Evaluation scene/order mismatch")
    require([row["episode"] for row in rows] == list(range(30)), "Episode numbering mismatch")


def load_baseline(campaign, protocol, method_id, budget, evidence):
    root = campaign / method_id
    train = root / "train"
    manifest = read_json(train / "manifest.json")
    require(manifest["environment_config"] == protocol["environment_config"], "Training changed environment configuration")
    require(manifest["source_hashes"] == protocol["source_hashes"], "Baseline training source snapshot mismatch")
    require(manifest["config_fingerprint"] == protocol["config_fingerprint"], "Training config fingerprint mismatch")
    require(manifest["method_id"] == method_id and manifest["method_spec"] == protocol["methods"][method_id]["spec"], "Training method mismatch")
    require(manifest["seed"] == protocol["training_seed"], "Training seed mismatch")
    evidence.check(train / "manifest.json")
    require(read_json(train / "frozen_config.json") == protocol["environment_config"], "Saved baseline config changed")
    evidence.check(train / "frozen_config.json")
    require(read_json(train / "source_hashes.json") == protocol["source_hashes"], "Saved source hashes mismatch")
    evidence.check(train / "source_hashes.json")
    training_summary = read_json(train / "summary.json")
    evidence.check(train / "summary.json")
    require(training_summary["status"] == "completed" and training_summary["global_step"] == 1000000, "Baseline training incomplete")
    require(all(value > 0 for value in training_summary["td3_updates"]), "A baseline TD3 network was never updated")
    if get_method(method_id).use_topology:
        require(training_summary["ddqn_updates"] > 0, "Topology baseline DDQN never updated")
    directory = train / "milestones" / f"step_{budget:07d}"
    metadata = verify_milestone(directory, budget, protocol["config_fingerprint"], evidence,
                                method_id, protocol["methods"][method_id]["fingerprint"])
    require(metadata["method_spec"] == protocol["methods"][method_id]["spec"], "Milestone method specification differs")
    require(metadata["run_id"] == manifest["run_id"], "Milestone belongs to another training run")
    output = root / f"evaluation_{budget:07d}"
    path = output / "evaluation_summary.json"
    result = read_json(path)
    evidence.check(path)
    require(result["status"] == "completed" and result["training_steps"] == budget, "Baseline evaluation incomplete or wrong budget")
    require(result["method_id"] == method_id and result["method_fingerprint"] == protocol["methods"][method_id]["fingerprint"], "Evaluation method mismatch")
    require(result["method_spec"] == protocol["methods"][method_id]["spec"], "Evaluation method spec mismatch")
    require(result["config_fingerprint"] == protocol["config_fingerprint"], "Evaluation config mismatch")
    require(result["source_hashes"] == protocol["source_hashes"], "Evaluation source hashes mismatch")
    require(result["core_source_files_unchanged"] and result["baseline_sources_unchanged"], "Sources changed during evaluation")
    require(result["tmc_metrics"] and result["device"].startswith("cuda"), "Missing telemetry or non-CUDA evaluation")
    require(Path(result["checkpoint"]).resolve() == (directory / "policy.pt").resolve(), "Evaluation did not use the exact milestone policy")
    verify_episode_set(result["episodes"])
    rows = [normalize_episode(row, budget, method_id) for row in result["episodes"]]
    trace = output / "evaluation.jsonl"
    evidence.check(trace)
    return rows, trace, {"manifest": manifest, "milestone_metadata": metadata,
                         "training_gradient_budget": {key: training_summary.get(key) for key in (
                             "td3_updates", "actor_updates", "ddqn_updates", "elapsed_seconds", "budget_semantics")}}


def load_full(campaign, protocol, budget, evidence):
    root = campaign / "full_method_evaluation"
    result = read_json(root / "results.json")
    provenance = read_json(root / "provenance.json")
    evidence.check(root / "results.json")
    evidence.check(root / "provenance.json")
    require(result["status"] == "completed" and result["all_original_transitions_identical"], "Full-method retest is incomplete or differs from reference")
    require(result["core_and_previous_files_unchanged"] and result["evaluation_scripts_unchanged"], "Full-method evidence changed")
    require(result["protocol"]["test_seeds"] == TEST_SEEDS and result["protocol"]["episodes"] == 30
            and result["protocol"]["max_steps"] == 1200, "Full-method retest protocol mismatch")
    require(provenance["environment_config"] == protocol["environment_config"], "Full-method environment differs")
    require(provenance["core_sha256"] == protocol["source_hashes"]["usv_auv"], "Full-method core differs")
    group = "early" if budget == 450000 else "late"
    original = Path(protocol["full_method_run_dir"]).resolve()
    directory = original / "milestones" / f"step_{budget:07d}"
    metadata = verify_milestone(directory, budget, protocol["config_fingerprint"], evidence)
    model = provenance["models"][group]
    require(Path(model["path"]).resolve() == (directory / "policy.pt").resolve(), "Wrong full-method policy path")
    require(model["metadata"] == metadata and model["sha256"] == metadata["files"]["policy.pt"]["sha256"], "Full-method policy identity mismatch")
    require(metadata["seed"] == protocol["training_seed"], "Full-method training seed differs")
    rows = result[group + "_episodes"]
    verify_episode_set(rows)
    trace = root / group / "evaluation.jsonl"
    evidence.check(trace)
    return [normalize_episode(row, budget, FULL) for row in rows], trace, {"milestone_metadata": metadata}


def summarize_rows(rows, trace_path, method_id):
    traces = trace_pool(trace_path, rows)
    specs = selected_specs()
    by_episode = {key: [] for key, *_ in specs}
    for row in rows:
        for key, _, _, _, getter in specs:
            value = getter(row)
            if key.startswith("environment.planner_horizon_prediction") and not row["environment"]["planner_horizon_prediction"].get("applicable", True):
                value = None
            by_episode[key].append(numeric(value))
    # All non-event scalar telemetry remains available as per-episode summaries.
    flattened = [numeric_fields({"metrics_base": row["metrics_base"], "environment": row["environment"],
                                 "network": {key: value for key, value in row["network"].items()
                                             if key not in ("emissions", "hop_events", "generation_events", "queue_events", "protocol_events", "delivery_events")}}) for row in rows]
    all_keys = sorted(set().union(*(item.keys() for item in flattened)))
    all_metrics = {key: stats([item.get(key) for item in flattened]) for key in all_keys}
    pooled = pooled_summary({"early": rows}, {"early": traces})["early"]
    if not rows[0]["environment"]["planner_horizon_prediction"].get("applicable", True):
        for key in list(pooled):
            if key.startswith("planner_5s_forecast"):
                pooled[key].update(value=None, applicable=False)
    kinds = kind_summary({"early": rows})
    per_kind = {kind: item["early"] for kind, item in kinds.items()}
    return {"method_id": method_id, "budget": rows[0]["model_step"],
            "selected_metrics": {key: stats(values) for key, values in by_episode.items()},
            "selected_values_by_paired_seed": by_episode, "all_scalar_metrics": all_metrics,
            "pooled": pooled, "trace_pooled": traces, "by_kind": per_kind,
            "termination_reasons": dict(Counter(row["termination_reason"] for row in rows)),
            "failed_episodes": sum(bool(row["terminated"]) for row in rows),
            "full_horizon_episodes": sum(row["survived_full_horizon"] for row in rows),
            "total_episodes": len(rows), "all_failures_included": True,
            "planner_5s_applicable": rows[0]["environment"]["planner_horizon_prediction"].get("applicable", True),
            "usde_accuracy_applicable": rows[0]["environment"]["usde"].get("applicable", True)}


def comparisons(datasets, resamples=20000):
    result = {"full_minus_baseline": {}, "one_million_minus_450k": {}}
    keys = [item[0] for item in selected_specs()]
    for budget in BUDGETS:
        full = datasets[FULL][str(budget)]["selected_values_by_paired_seed"]
        result["full_minus_baseline"][str(budget)] = {}
        for method_id in METHOD_IDS:
            base = datasets[method_id][str(budget)]["selected_values_by_paired_seed"]
            result["full_minus_baseline"][str(budget)][method_id] = {
                key: paired_bootstrap(base[key], full[key], resamples, 934091 + budget) for key in keys}
    for method_id in (FULL, *METHOD_IDS):
        early = datasets[method_id]["450000"]["selected_values_by_paired_seed"]
        late = datasets[method_id]["1000000"]["selected_values_by_paired_seed"]
        result["one_million_minus_450k"][method_id] = {
            key: paired_bootstrap(early[key], late[key], resamples, 934101) for key in keys}
    return result


def fmt(value):
    return "N/A" if value is None else f"{value:.6g}"


def render_markdown(summary):
    specs = selected_specs()
    labels = {key: (label, unit) for key, label, unit, _, _ in specs}
    names = {FULL: "Full proposed method", **{method_id: get_method(method_id).name for method_id in METHOD_IDS}}
    data = summary["datasets"]
    lines = ["# method × training: environmenttaskmetric", "",
             "##  ", "",
             " 30same scenario,  1200 ; 45 100 .  /failure,  . episode± SD; N/A ,  . ",
             " ,  ; environment. method trainingseed,  30scenario, across training seedsseedindependent. ",
             "topologywarmup TD3; complete method topologyTD3/DDQN.  ,  .  JSONtraining. ", "",
             "## taskservice", "",
             "| method | training |  /30 | collectionbit |   |  goodput(bit/s) |  1200s goodput(bit/s) | serviceSN /30 | Jain |",
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    keys = ["metrics_base.collected_bits", "collected_packets", "goodput_bit_s", "fixed_budget_goodput_bit_s",
            "environment.collection.distinct_served_sensors", "environment.collection.jain_collected_packets_all_sensors"]
    for method_id in (FULL, *METHOD_IDS):
        for budget in BUDGETS:
            row = data[method_id][str(budget)]
            values = " | ".join(mean_sd(row["selected_metrics"][key]) for key in keys)
            lines.append(f"| {names[method_id]} | {budget} | {row['full_horizon_episodes']}/30 | {values} |")
    lines += ["", "## AoI  (pooled )", "",
              "| method |   | episodeAoI ±SD(s) |  AUV-time pooled p95(s) | pooled AoI>90s | poolednon-delivery | pooled DATAnon-delivery | pooled STATEnon-delivery |",
              "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for method_id in (FULL, *METHOD_IDS):
        for budget in BUDGETS:
            row = data[method_id][str(budget)]
            pooled = row["pooled"]
            values = [fmt(pooled[key]["value"]) for key in ("aoi_true_pooled_p95_s", "aoi_gt90_fraction",
                      "hop_ALL_completion_nondelivery", "hop_DATA_completion_nondelivery", "hop_STATE_completion_nondelivery")]
            lines.append(f"| {names[method_id]} | {budget} | {mean_sd(row['selected_metrics']['environment.state_aoi.pooled.mean'])} | {' | '.join(values)} |")
    lines += ["", "## allmetric: episode±SD", ""]
    for section in dict.fromkeys(spec[3] for spec in specs):
        lines += ["### " + section, "", "| metric | method | 45  | 100  |", "|---|---|---:|---:|"]
        for key, label, unit, category, _ in specs:
            if category != section:
                continue
            for method_id in (FULL, *METHOD_IDS):
                early = data[method_id]["450000"]["selected_metrics"][key]
                late = data[method_id]["1000000"]["selected_metrics"][key]
                lines.append(f"| {label} ({unit}) | {names[method_id]} | {mean_sd(early)} | {mean_sd(late)} |")
        lines.append("")
    primary_keys = ["metrics_base.collected_bits", "fixed_budget_goodput_bit_s", "environment.collection.distinct_served_sensors",
                    "environment.state_aoi.pooled.mean", "hop.ALL.effective_nondelivery_ratio",
                    "energy_efficiency.total_energy_j", "network.control_plane.airtime_fraction_of_episode",
                    "environment.local_navigation.pooled.mean", "environment.usv_received_hold.pooled.mean"]
    lines += ["## scenario95% bootstrap ", "",
              " ; complete100 45 .  metric : data/coverage, error/AoI/non-delivery. scenario, trainingseed;  metric ,  .  JSON . ", "",
              "| metric |   | complete method |   [95% ] |   |", "|---|---:|---|---:|---:|"]
    for budget in BUDGETS:
        for method_id in METHOD_IDS:
            result = summary["comparisons"]["full_minus_baseline"][str(budget)][method_id]
            for key in primary_keys:
                item = result[key]
                lines.append(f"| {labels[key][0]} | {budget} | {names[method_id]} | {fmt(item['mean_difference'])} [{fmt(item['ci95_low'])}, {fmt(item['ci95_high'])}] | {item['n_pairs']} |")
    lines += ["", "| metric | method | 100 45 :   [95% ] |   |", "|---|---|---:|---:|"]
    for method_id in (FULL, *METHOD_IDS):
        for key in primary_keys:
            item = summary["comparisons"]["one_million_minus_450k"][method_id][key]
            lines.append(f"| {labels[key][0]} | {names[method_id]} | {fmt(item['mean_difference'])} [{fmt(item['ci95_low'])}, {fmt(item['ci95_high'])}] | {item['n_pairs']} |")
    lines += ["", "##  ", "",
        "- complete method,  100 metric 45 . collection, service coverage, safety,  ,  ,  . ",
        "- failure low energy,  ,  AoI .  ;  1200 goodput goodput. ",
        "- collection sensorpayload AUV ,  USV; ACK . Jainscenario30 SN ,  N/A; scenarioSNphysicalnode . ",
        "- local error, USVerror,  5prediction error. method/ actor-responsesame5prediction,  N/A;  USDE . prediction. ",
        "- AoIenvironmenttime , no-message . pooled p95all allAUV , episodep95mean; 1 . ",
        "- non-deliverycompletion-windowfailure/ ,  ;  ,  ,  ,  PER.  TTL/ / . ",
        "- STATE USVreceived; DATA DATA AUVreceived, data. successful statistics; window/non-delivery state,  . ",
        "-  non-DATA ,  STATE, COORD, localization, service.  , completebit ,  / , time slot/ ,  96% 96%time. DATA header , windowheader/payloadbounds. ",
        "- JSONall statistics, 75 metricall,  kind , pooled / , coverage, failure, scenariometric SHA256.  CSVtraining/ . ", ""]
    return "\n".join(lines)


def summarize(campaign, bootstrap_samples=20000):
    campaign = Path(campaign).resolve()
    output = campaign / "comparison"
    require(not output.exists(), "Campaign comparison output must be a new directory")
    evidence = Evidence()
    protocol = validate_protocol(campaign, evidence)
    datasets, training = {}, {}
    for method_id in (FULL, *METHOD_IDS):
        datasets[method_id], training[method_id] = {}, {}
        for budget in BUDGETS:
            if method_id == FULL:
                rows, trace, proof = load_full(campaign, protocol, budget, evidence)
            else:
                rows, trace, proof = load_baseline(campaign, protocol, method_id, budget, evidence)
            datasets[method_id][str(budget)] = summarize_rows(rows, trace, method_id)
            training[method_id][str(budget)] = proof
            print(json.dumps({"event": "dataset_summarized", "method_id": method_id, "budget": budget}, ensure_ascii=True), flush=True)
    result = {"format": "five-method-two-budget-baseline-campaign-comparison-v1", "status": "completed",
              "campaign_id": protocol["campaign_id"], "environment_config": protocol["environment_config"],
              "config_fingerprint": protocol["config_fingerprint"], "training_seed": protocol["training_seed"],
              "test_seeds": TEST_SEEDS, "method_order": [FULL, *METHOD_IDS], "budgets": list(BUDGETS),
              "metric_definitions": {key: {"label_zh": label, "unit": unit, "section": section}
                                     for key, label, unit, section, _ in selected_specs()},
              "datasets": datasets, "training_evidence": training,
              "comparisons": comparisons(datasets, bootstrap_samples),
              "evidence_sha256": evidence.files,
              "limitations": ["one training seed per method", "same previously used evaluation scene seeds",
                              "equal environment steps do not imply equal gradient/compute budget",
                              "paired scene bootstrap only; exploratory intervals not corrected for multiple comparisons",
                              "all safety failures retained; missing/not-applicable errors never replaced with zero"],
              "scope": "CPU-only aggregation of completed frozen evaluations; not additional training or simulation"}
    # Inputs and frozen code must remain unchanged through aggregation itself.
    for path, expected in evidence.files.items():
        require(sha256(path) == expected, f"Evidence changed during CPU summarization: {path}")
    serialized = json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2)
    report = render_markdown(result)
    output.mkdir()
    (output / "comparison.json").write_text(serialized + "\n", encoding="utf-8")
    (output / "REPORT_ZH.md").write_text(report, encoding="utf-8")
    return {"status": "completed", "output": str(output), "datasets": 10, "episodes_per_dataset": 30}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=20000)
    args = parser.parse_args()
    print(json.dumps(summarize(args.campaign, args.bootstrap_samples), ensure_ascii=True), flush=True)


if __name__ == "__main__":
    main()
