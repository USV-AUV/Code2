"""Supplement completed checkpoint comparisons from existing logs only.

No model loading, environment replay, training, CUDA or new evaluation. Existing
successful outputs are reused only when all source/output hashes still agree.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path

import numpy as np

FORMAT = "usv-auv-long-training-additional-metrics-v1"
NETWORK_COUNTERS = (
    "network_transmissions", "network_tx_bits", "network_received_hops", "network_failed_hops",
    "network_management_transmissions", "network_application_transmissions", "network_queue_replaced",
    "network_queue_dropped", "network_expired_packets", "network_expired_arrivals", "network_no_route_dropped",
    "network_ttl_dropped", "network_unknown_version_dropped", "network_application_range_dropped",
    "network_probe_timeouts", "network_config_requests", "network_config_successes", "network_config_timeouts",
)
ENERGY_KEYS = ("propulsion_energy_j", "usv_energy_j", "communication_energy_j")
RMSE_KEYS = {"disturbance_rmse_mps": "usde_time_rmse_mps", "position_rmse_m": "position_time_rmse_m"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def close(left, right):
    if left is None or right is None:
        return left is right
    return math.isclose(float(left), float(right), rel_tol=1e-9, abs_tol=1e-7)


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_json(text):
    def invalid(value):
        raise ValueError(f"Nonfinite JSON constant: {value}")
    result = json.loads(text, parse_constant=invalid)
    require(isinstance(result, dict), "Expected a JSON object")
    return result


def read_json(path):
    return parse_json(Path(path).read_text(encoding="utf-8-sig"))


def number(value, name, *, negative=False):
    require(type(value) in (int, float) and math.isfinite(value) and (negative or value >= 0), f"Invalid {name}")
    return float(value)


def source_paths(comparison):
    return {"comparison": comparison / "comparison.json", "provenance": comparison / "provenance.json",
            "early_trace": comparison / "early" / "evaluation.jsonl", "late_trace": comparison / "late" / "evaluation.jsonl"}


def validate_comparison(report, provenance):
    require(report.get("format") == "usv-auv-paired-checkpoint-comparison-v1" and bool(report.get("completed_at")), "Comparison is not a completed checkpoint report")
    require(report.get("source_files_unchanged") is True and report.get("workflow_milestone_evidence_valid") is True, "Original comparison evidence is not valid/frozen")
    protocol, metadata = report["protocol"], report["checkpoints"]
    require(canonical(protocol) == canonical(provenance["protocol"]) and canonical(metadata) == canonical(provenance["checkpoints"]), "Report and provenance disagree")
    require(protocol["configuration_override"] is False, "This summary requires the unchanged checkpoint environment")
    require(metadata["same_training_run_verified"] is True and metadata["requested_milestones_match"] is True, "Unverified training lineage/milestones")
    require(protocol["primary_relative_threshold_percent"] == 5.0, "Do not redefine the original +5% primary criterion")
    config = provenance["environment_config"]
    fingerprint = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:16]
    require(fingerprint == metadata["config_fingerprint"], "Environment configuration fingerprint mismatch")
    require(type(protocol["episodes"]) is int and protocol["episodes"] > 0 and type(protocol["steps"]) is int and protocol["steps"] > 0, "Invalid evaluation dimensions")
    require(type(protocol["seed"]) is int and protocol["test_seeds"] == list(range(protocol["seed"], protocol["seed"] + protocol["episodes"])), "Protocol seeds are inconsistent")
    require(protocol["steps"] == config["episode_steps"], "Full configured task horizon is required")
    require(protocol["seed"] > metadata["training_seed"] + metadata["late_training_steps"], "Evaluation seeds overlap the conservative training range")
    require(type(config["data_packet_bits"]) is int and config["data_packet_bits"] > 0 and number(config["dt"], "dt") > 0, "Invalid packet/time units")
    for label in ("early", "late"):
        rows = report[f"{label}_episodes"]
        require(len(rows) == protocol["episodes"] and [row["seed"] for row in rows] == protocol["test_seeds"], f"{label} episode seeds/order/count disagree")
        for index, row in enumerate(rows):
            require(row["episode"] == index and type(row["steps"]) is int and 0 < row["steps"] <= protocol["steps"], "Invalid episode ID or length")
            for key in ("terminated", "truncated", "survived_full_horizon"):
                require(type(row[key]) is bool, f"Episode {key} must be Boolean")
            require(not (row["terminated"] and row["truncated"]), "Conflicting final flags")
            require(row["survived_full_horizon"] == (not row["terminated"] and row["steps"] == protocol["steps"]), "Full-horizon survival flag disagrees")
            require(row["terminated"] or (row["truncated"] and row["steps"] == protocol["steps"]), "Nonterminal or incomplete final episode")
        artifact = provenance[label]
        require(isinstance(artifact["sha256"], str) and len(artifact["sha256"]) == 64, "Missing recorded model SHA256")
        saved = artifact.get("verified_milestone_metadata")
        if saved is not None:
            require(saved["global_step"] == metadata[f"{label}_training_steps"] and saved["run_id"] == metadata["training_run_id"], "Recorded milestone identity differs")
            require(saved["config_fingerprint"] == fingerprint and saved["seed"] == metadata["training_seed"], "Recorded milestone configuration/seed differs")
            require(saved["files"][Path(artifact["path"]).name]["sha256"] == artifact["sha256"], "Recorded milestone hash differs")
    return config


def stream_episodes(path, expected_rows, config, label):
    """One pass; require every expected step exactly once in episode order."""
    packet = config["data_packet_bits"]
    expected_initial = config["initial_packets"] * config["n_sensors"] * packet
    buffer_capacity = config["buffer_packets"] * config["n_sensors"] * packet
    results, digest = [], hashlib.sha256()
    episode_index = step_index = 0
    previous_time = reward_sum = aoi_sum = 0.0
    error_squares, error_times, previous_cumulative = {}, {}, {}
    before = path.stat()
    with path.open("rb") as stream:
        for line_number, raw in enumerate(stream, 1):
            digest.update(raw)
            if not raw.strip():
                continue
            row = parse_json(raw.decode("utf-8-sig"))
            require(episode_index < len(expected_rows), f"Extra trace rows at {path}:{line_number}")
            expected = expected_rows[episode_index]
            require(type(row.get("episode")) is int and row["episode"] == episode_index and row.get("seed") == expected["seed"], f"Episode/seed order differs at line {line_number}")
            require(type(row.get("step")) is int and row["step"] == step_index + 1, f"Duplicate/missing/reordered step at line {line_number}")
            step_index += 1
            info, metrics = row["info"], row["info"]["metrics"]
            now = number(row["time"], "time")
            interval = now - previous_time
            require(interval > 0 and interval <= config["dt"] + 1e-7 and close(now, info["time"]) and info["step"] == step_index, "Invalid actual time interval/info alignment")
            for key in ("terminated", "truncated"):
                require(type(row[key]) is bool, f"Trace {key} must be Boolean")
            if not row["terminated"]:
                require(close(interval, config["dt"]), "Missing simulation time within a nonterminal fast step")
            final = step_index == expected["steps"]
            require(not (row["terminated"] or row["truncated"]) if not final else
                    row["terminated"] == expected["terminated"] and row["truncated"] == expected["truncated"], "Trace termination does not align with final record")
            for key in ("initial_bits", "arrival_bits", "overflow_bits", "collected_bits", "ack_released_bits", "buffer_bits", "total_energy_j", "mean_aoi_s"):
                number(metrics[key], key)
            initial, arrivals, overflow, collected, ack, buffered = (metrics[key] for key in
                ("initial_bits", "arrival_bits", "overflow_bits", "collected_bits", "ack_released_bits", "buffer_bits"))
            require(close(initial, expected_initial), "Initial data amount changed")
            require(close(initial + arrivals, overflow + ack + buffered), "Data conservation violated: initial+arrival != overflow+ACK+buffer")
            require(ack <= collected <= initial + arrivals and buffered <= buffer_capacity, "Invalid ACK/unique data/buffer accounting")
            require(all(close(value / packet, round(value / packet)) for value in (initial, arrivals, overflow, collected, ack, buffered)), "Data counters are not complete packets")
            cumulative_keys = ("arrival_bits", "overflow_bits", "collected_bits", "ack_released_bits", "total_energy_j", *ENERGY_KEYS, *NETWORK_COUNTERS, "network_config_total_latency")
            for key in cumulative_keys:
                if key in metrics:
                    value = number(metrics[key], key)
                    require(value + 1e-7 >= previous_cumulative.get(key, 0.), f"Cumulative metric decreased: {key}")
                    previous_cumulative[key] = value
            if all(key in metrics for key in ENERGY_KEYS):
                require(close(metrics["total_energy_j"], sum(metrics[key] for key in ENERGY_KEYS)), "Total energy does not equal its recorded components")
            reward_sum += number(row["reward"], "reward", negative=True)
            aoi_sum += interval * metrics["mean_aoi_s"]
            for metric in RMSE_KEYS:
                if metric in metrics:
                    value = number(metrics[metric], metric)
                    error_squares[metric] = error_squares.get(metric, 0.) + interval * value * value
                    error_times[metric] = error_times.get(metric, 0.) + interval
            previous_time = now
            if not final:
                continue
            require(close(now, expected["duration_s"]), "Trace duration differs from episode summary")
            require(info.get("termination_reason", "") == expected["termination_reason"], "Final termination reason differs")
            for key in ("collected_bits", "ack_released_bits", "overflow_bits", "total_energy_j"):
                require(close(metrics[key], expected[key]), f"Final trace/episode mismatch: {key}")
            require(close(reward_sum, expected["return"]), "Accumulated reward differs from original report")
            require(close(aoi_sum / now, expected["time_mean_aoi_s"]) and close(metrics["mean_aoi_s"], expected["final_mean_aoi_s"]), "Time-averaged/final AoI differs from original report")
            require(close(metrics.get("network_config_successes", 0.), expected["config_successes"]), "Topology success count differs")
            energy, available = metrics["total_energy_j"], initial + arrivals
            result = {"policy": label, "episode": episode_index, "seed": expected["seed"], "steps": step_index,
                      "duration_s": now, "terminated": expected["terminated"], "truncated": expected["truncated"],
                      "survived_full_horizon": expected["survived_full_horizon"], "termination_reason": expected["termination_reason"],
                      "collected_packets": collected / packet, "acknowledged_packets": ack / packet,
                      "overflow_packets": overflow / packet, "initial_packets": initial / packet,
                      "arrival_packets": arrivals / packet, "available_packets": available / packet,
                      "buffer_packets": buffered / packet, "collected_bits": collected, "ack_released_bits": ack,
                      "overflow_bits": overflow, "zero_collection": collected == 0,
                      "collection_fraction": collected / available if available else None,
                      "ack_fraction_of_collected": ack / collected if collected else None,
                      "total_energy_j": energy, "bits_per_joule": collected / energy if energy else None,
                      "time_mean_state_aoi_s": expected["time_mean_aoi_s"], "final_state_aoi_s": expected["final_mean_aoi_s"]}
            require(close(result["bits_per_joule"], expected["bits_per_joule"]), "Bits/J differs from original episode summary")
            for key in ENERGY_KEYS:
                result[key] = metrics.get(key)  # Missing components are unknown, not zero.
            for metric, name in RMSE_KEYS.items():
                covered = error_times.get(metric, 0.)
                result[name] = math.sqrt(error_squares[metric] / now) if close(covered, now) else None
                result[name + "_coverage_fraction"] = covered / now
            for key in NETWORK_COUNTERS:
                result[key] = float(metrics.get(key, 0.))  # Audited Counter event keys omit never-triggered zeros.
            successes = result["network_config_successes"]
            latency_sum = float(metrics.get("network_config_total_latency", 0.))
            require(latency_sum == 0 or successes > 0, "Configuration latency exists without successful configurations")
            result["network_config_total_latency_s"] = latency_sum
            result["mean_successful_config_latency_s"] = latency_sum / successes if successes else None
            for key in ("collection_attempts", "localization_fixes"):
                result[key] = float(metrics[key]) if key in metrics else None
            results.append(result)
            episode_index += 1
            step_index = 0
            previous_time = reward_sum = aoi_sum = 0.0
            error_squares, error_times, previous_cumulative = {}, {}, {}
    after = path.stat()
    require(episode_index == len(expected_rows) and step_index == 0, "Trace ends before all declared episodes/steps are complete")
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), "Trace changed during streaming")
    return results, {"path": str(path.resolve()), "sha256": digest.hexdigest(), "bytes": after.st_size}


def primary_from_records(report, early, late):
    protocol = report["protocol"]
    left, right = np.asarray([row["collected_bits"] for row in early]), np.asarray([row["collected_bits"] for row in late])
    differences = right - left
    count = protocol["bootstrap_samples"]
    require(type(count) is int and count == 20000, "Unexpected bootstrap sample count")
    rng, samples = np.random.default_rng(protocol["bootstrap_seed"]), np.empty(count)
    for start in range(0, count, 500):
        indices = rng.integers(0, len(left), size=(min(500, count - start), len(left)))
        samples[start:start + len(indices)] = differences[indices].mean(axis=1)
    interval = np.quantile(samples, [.025, .975]).tolist()
    relative = 100 * float(right.mean() - left.mean()) / float(left.mean()) if left.mean() > 0 else None
    recorded = report["comparison"]["primary_endpoint"]
    stats = recorded["statistics"]
    require(recorded["metric"] == "collected_bits" and recorded["minimum_relative_percent"] == 5.0 and recorded["requires_absolute_ci_lower_above_zero"] is True, "Original primary definition changed")
    for key, value in (("n_pairs", len(left)), ("early_mean", float(left.mean())), ("late_mean", float(right.mean())),
                       ("absolute_difference", float(differences.mean())), ("relative_percent", relative)):
        require(close(stats[key], value), f"Original primary statistic disagrees with complete traces: {key}")
    require(len(stats["ci95"]) == 2 and all(close(a, b) for a, b in zip(stats["ci95"], interval)), "Original paired CI disagrees with complete traces")
    criterion = len(left) >= 2 and relative is not None and relative >= 5.0 and interval[0] > 0
    require(recorded["criterion_met"] is criterion, "Original primary decision is inconsistent")
    return recorded


def aggregate(rows):
    fields = [key for key, value in rows[0].items() if type(value) in (int, float) or value is None]
    excluded = {"episode", "seed"}
    means = {}
    for key in fields:
        if key in excluded:
            continue
        values = [row[key] for row in rows if row[key] is not None]
        means[key] = {"mean": sum(values) / len(values) if values else None, "defined_episodes": len(values), "missing_episodes": len(rows) - len(values)}
    duration = sum(row["duration_s"] for row in rows)
    pooled = {}
    for name in RMSE_KEYS.values():
        pooled[name] = math.sqrt(sum(row[name] ** 2 * row["duration_s"] for row in rows) / duration) if all(row[name] is not None for row in rows) else None
    successes = sum(row["network_config_successes"] for row in rows)
    return {"episodes": len(rows), "zero_collection_episodes": sum(row["zero_collection"] for row in rows),
            "safety_failure_episodes": sum(row["terminated"] for row in rows),
            "full_horizon_episodes": sum(row["survived_full_horizon"] for row in rows),
            "total_collected_packets": sum(row["collected_packets"] for row in rows), "means": means,
            "pooled_time_weighted_rmse": pooled,
            "pooled_successful_config_latency_s": sum(row["network_config_total_latency_s"] for row in rows) / successes if successes else None}


def csv_text(result):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(result["episodes"][0]))
    writer.writeheader()
    writer.writerows(result["episodes"])
    return stream.getvalue()


def markdown_text(result):
    def value(item):
        return " /N/A" if item is None else f"{item:.6g}"
    early, late = result["groups"]["early"], result["groups"]["late"]
    steps = result["training_steps"]
    lines = [f"# {steps['early']} → {steps['late']}  :  metric", "",
             " ;  , environment training. ", "",
             f"  +5%  95%CIlower bound>0;  : {result['primary_endpoint']['criterion_met']}. ",
             " 20 /+50% . ", "",
             "| metric |   |   |", "| --- | ---: | ---: |"]
    labels = {"collected_packets": "mean collection /  ", "acknowledged_packets": "meanACKacknowledged /  ", "overflow_packets": "mean /  ",
              "available_packets": "mean data /  ", "collection_fraction": "mean episode collection ratio (0–1)", "duration_s": "mean / s",
              "total_energy_j": "mean energy / J", "propulsion_energy_j": "meanAUVenergy / J", "usv_energy_j": "meanUSVenergy / J",
              "communication_energy_j": "mean energy / J", "time_mean_state_aoi_s": "mean state time meanAoI / s", "bits_per_joule": "episode collectionbit/J ",
              "network_transmissions": "mean", "network_received_hops": "mean successful", "network_failed_hops": "mean failure",
              "network_config_successes": "mean topology successful", "network_config_timeouts": "mean topology"}
    for key, label in labels.items():
        lines.append(f"| {label} | {value(early['means'][key]['mean'])} | {value(late['means'][key]['mean'])} |")
    for key, label in (("zero_collection_episodes", "collection episode"), ("safety_failure_episodes", "safety failure episode"), ("full_horizon_episodes", "complete episode")):
        lines.append(f"| {label} | {early[key]}/{early['episodes']} | {late[key]}/{late['episodes']} |")
    for key, label in (("usde_time_rmse_mps", " USDE RMSE / m/s"), ("position_time_rmse_m", "local localizationRMSE / m")):
        lines.append(f"| {label} | {value(early['pooled_time_weighted_rmse'][key])} | {value(late['pooled_time_weighted_rmse'][key])} |")
    lines.append(f"| successful topology mean / s | {value(early['pooled_successful_config_latency_s'])} | {value(late['pooled_successful_config_latency_s'])} |")
    lines.extend(["", " :  , 6m , DATA/ACKmean.  AoI . ", ""])
    lines.extend(f"- {warning}" for warning in result["limitations"])
    return "\n".join(lines) + "\n"


def summarize_long_training_metrics(comparison, output):
    comparison, output = Path(comparison).resolve(), Path(output).resolve()
    paths = source_paths(comparison)
    if output.exists() and any(output.iterdir()):
        saved = read_json(output / "additional_metrics.json")
        require(saved.get("format") == FORMAT and saved.get("status") == "completed", "Existing output is not a successful compatible summary")
        for key, path in paths.items():
            require(saved["sources"][key]["path"] == str(path) and sha256(path) == saved["sources"][key]["sha256"], "Inputs changed; refuse to overwrite/reuse previous summary")
        for filename, digest in saved["output_sha256"].items():
            require(sha256(output / filename) == digest, "Existing summary output is missing or changed")
        require((output / "additional_metrics.md").read_text(encoding="utf-8") == markdown_text(saved), "Cached Markdown no longer matches summary JSON")
        return saved
    report, provenance = read_json(paths["comparison"]), read_json(paths["provenance"])
    config = validate_comparison(report, provenance)
    sources = {key: {"path": str(path), "sha256": sha256(path), "bytes": path.stat().st_size}
               for key, path in paths.items() if key in ("comparison", "provenance")}
    records = {}
    for label in ("early", "late"):
        records[label], sources[f"{label}_trace"] = stream_episodes(paths[f"{label}_trace"], report[f"{label}_episodes"], config, label)
    primary = primary_from_records(report, records["early"], records["late"])
    for key in ("comparison", "provenance"):
        require(sha256(paths[key]) == sources[key]["sha256"], "Comparison metadata changed during summarization")
    result = {"format": FORMAT, "status": "completed", "comparison_directory": str(comparison), "sources": sources,
              "training_steps": {label: report["checkpoints"][f"{label}_training_steps"] for label in ("early", "late")},
              "protocol": report["protocol"], "recorded_model_sha256": {label: provenance[label]["sha256"] for label in ("early", "late")},
              "primary_endpoint": primary, "original_interpretation": report["comparison"]["interpretation"],
              "groups": {label: aggregate(records[label]) for label in records}, "episodes": records["early"] + records["late"],
              "unavailable_metrics": {"true_target_distance": "not recorded", "true_6m_residence": "not recorded",
                                      "data_ack_end_to_end_latency": "not recorded", "valid_only_per_auv_usde_rmse": "validity/per-AUV errors not recorded"},
              "limitations": [
                  "episode collection ratio=collection/( +episode); failure,  . ",
                  "errorΔt RMSE²,  ;  ,  RMSEmean. ",
                  "USDE ,  / ; errorAUVlocal error,  USVprediction error. ",
                  "AoI ,  USVreceivedAUVstate, sensor data. ",
                  "error; complete coverage episodeRMSE, CSVcoverage ratio. energy. ",
                  " Counter ; successful successfulN/A,  DATA . ",
                  " ;  ,  . ",
                  "energy,  JcollectionAoI . single training seed scenariobootstrapacross training seeds. ",
                  " ,  ;  SHA provenance,  . "],
              "environment_replayed": False, "models_executed": False}
    csv_data, markdown = csv_text(result).encode("utf-8-sig"), markdown_text(result).encode("utf-8")
    result["output_sha256"] = {"additional_metrics.csv": hashlib.sha256(csv_data).hexdigest(), "additional_metrics.md": hashlib.sha256(markdown).hexdigest()}
    json_data = json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False)
    output.mkdir(parents=True, exist_ok=True)
    (output / "additional_metrics.csv").write_bytes(csv_data)
    (output / "additional_metrics.md").write_bytes(markdown)
    # JSON is the completion marker; interrupted partial output is never replaced automatically.
    (output / "additional_metrics.json").write_text(json_data, encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comparison", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    reused = (args.output / "additional_metrics.json").exists()
    result = summarize_long_training_metrics(args.comparison, args.output)
    print(json.dumps({"status": result["status"], "reused_existing": reused, "output": str(args.output.resolve()),
                      "primary_criterion_met": result["primary_endpoint"]["criterion_met"]}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
