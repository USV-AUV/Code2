"""CPU-only descriptive summary of a completed passive frozen TMC retest.

Reads results.json and both original retest evaluation.jsonl files. Never loads
models, imports torch, changes simulation code, or filters out failed episodes.
Writes REPORT_ZH.md, selected_metrics.csv, and selected_metrics.json only.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics


DEFAULT_INPUT = Path("runs/research_collection_v2_1m_20260909/tmc_metrics_retest_20260909")
GROUPS = ("early", "late")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def dig(row, path, default=None):
    for key in path.split("."):
        if not isinstance(row, dict) or key not in row:
            return default
        row = row[key]
    return row


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def mean(values):
    return statistics.fmean(values) if values else None


def percentile(values, fraction=.95):
    """Linear empirical quantile matching numpy's default, without numpy."""
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * fraction
    lower = math.floor(index)
    upper = math.ceil(index)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (index - lower)


def numeric(value):
    if value is None:
        return None
    result = float(value)
    require(math.isfinite(result), "Nonfinite summary input")
    return result


def stats(values):
    valid = [numeric(value) for value in values if value is not None]
    return {"n": len(valid), "missing_n": len(values) - len(valid),
            "mean": mean(valid), "sample_sd": statistics.stdev(valid) if len(valid) > 1 else None}


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def logical(row, kind):
    return row["network"]["logical"][kind]


def hop(row, kind):
    if kind == "ALL":
        return row["network"]["hop_delivery"]["completion_window"]
    return dig(row, f"network.by_kind.{kind}.hop_delivery.completion_window", {})


def censored_count(row, kind):
    statuses = logical(row, kind)["statuses"]
    return sum(statuses.get(key, 0) for key in (
        "undelivered_with_inflight_copy", "undelivered_with_queued_unexpired_copy"))


def trace_pool(path, episodes):
    """Read every fast-step/AUV sample; no mean-of-p95 approximation."""
    expected = {int(row["episode"]): row for row in episodes}
    counts = Counter()
    durations = Counter()
    aois, local, held, forecasts, usde = [], [], [], [], []
    no_message = stale = unavailable = forecast_opportunities = 0
    prior_time = {}
    per_episode_aoi = {key: [] for key in expected}
    per_node_aoi = {}
    for line_number, line in enumerate(path.open(encoding="utf-8"), 1):
        row = json.loads(line)
        episode = int(row["episode"])
        require(episode in expected, f"Unexpected episode at {path}:{line_number}")
        require(int(row["seed"]) == expected[episode]["seed"], "Trace seed mismatch")
        counts[episode] += 1
        require(int(row["step"]) == counts[episode], "Nonconsecutive trace steps")
        dt = numeric(row["time"]) - prior_time.get(episode, 0.)
        declared_dt = expected[episode]["environment"]["sampling"]["dt_s"]
        require(math.isclose(dt, declared_dt, rel_tol=1e-9, abs_tol=1e-8), "Unequal fast-step dt")
        require(math.isclose(dt, 1., abs_tol=1e-8), "This TMC retest summary expects dt=1 s")
        durations[episode] += dt
        prior_time[episode] = numeric(row["time"])
        extra = row["passive_environment"]
        sample_aois = [numeric(value) for value in extra["state_aoi_s"]]
        aois.extend(sample_aois)
        per_episode_aoi[episode].extend(sample_aois)
        for node, value in enumerate(sample_aois, 1):
            per_node_aoi.setdefault(str(node), []).append(value)
        local.extend(numeric(value) for value in extra["local_navigation_error_m"])
        held.extend(numeric(value) for value in extra["usv_received_hold_error_m"] if value is not None)
        no_message += sum(extra["state_no_message"])
        stale += sum(extra["state_aoi_gt_ttl"])
        unavailable += sum(extra["state_fresh_unavailable"])
        for forecast in extra["matured_planner_predictions"]:
            forecast_opportunities += len(forecast["error_m"])
            forecasts.extend(numeric(value) for value in forecast["error_m"].values() if value is not None)
        if extra["usde_cross_auv_rmse_mps"] is not None:
            usde.append(numeric(extra["usde_cross_auv_rmse_mps"]))
    for episode, row in expected.items():
        require(counts[episode] == row["steps"], "Trace/episode step count mismatch")
        require(math.isclose(durations[episode], row["duration_s"], abs_tol=1e-7), "Trace/episode duration mismatch")
        # Check the independently reconstructed mean against the saved observer.
        require(math.isclose(mean(per_episode_aoi[episode]), row["environment"]["state_aoi"]["pooled"]["mean"],
                             rel_tol=1e-10, abs_tol=1e-8), "AoI reconstruction mismatch")
    def errors(values, opportunities):
        return {"valid_samples": len(values), "opportunities": opportunities,
                "coverage": ratio(len(values), opportunities), "mae_m": mean(values),
                "rmse_m": math.sqrt(statistics.fmean(v * v for v in values)) if values else None,
                "sum_error_m": sum(values), "sum_squared_error_m2": sum(v * v for v in values)}
    return {
        "trace_steps": sum(counts.values()), "actual_episode_seconds": sum(durations.values()),
        "auv_time_samples": len(aois), "aoi_mean_s": mean(aois), "aoi_p95_s": percentile(aois),
        "aoi_max_s": max(aois) if aois else None, "aoi_sum_s": sum(aois),
        "aoi_no_message_samples": no_message, "aoi_gt_ttl_samples": stale,
        "fresh_unavailable_samples": unavailable,
        "per_auv_aoi": {node: {"n": len(values), "mean_s": mean(values), "p95_s": percentile(values),
                                "max_s": max(values)} for node, values in per_node_aoi.items()},
        "local_navigation": errors(local, len(aois)),
        "usv_received_hold": errors(held, len(aois)),
        "planner_5s_forecast": errors(forecasts, forecast_opportunities),
        "usde_pooled_rmse_mps": math.sqrt(statistics.fmean(v * v for v in usde)) if usde else None,
        "per_episode_aoi_p95_s": {str(ep): percentile(values) for ep, values in per_episode_aoi.items()},
    }


def selected_specs():
    """key, Chinese label, units, section, getter; ratios are raw 0..1."""
    specs = []
    def add(key, label, unit, section, getter=None):
        specs.append((key, label, unit, section, getter or (lambda row, p=key: dig(row, p))))
    add("duration_s", "episode", "s", "Mission and delivered payload")
    add("survived_full_horizon", "safety complete1200metric label", "fraction", "Mission and delivered payload")
    add("collected_packets", "collection (sensor→AUV)", "packet", "Mission and delivered payload")
    add("metrics_base.collected_bits", "collection", "bit", "Mission and delivered payload")
    add("ack_packets", "ACKacknowledged", "packet", "Mission and delivered payload")
    add("goodput_bit_s", "episodegoodput", "bit/s", "Mission and delivered payload")
    add("fixed_budget_goodput_bit_s", "metric label1200metric labelgoodput", "bit/s", "Mission and delivered payload")
    add("collection_fraction", "collection/data", "fraction", "Mission and delivered payload")
    for key, label, unit in (
        ("distinct_served_sensors", "received1 SN  (total 30)", "sensor"),
        ("distinct_acknowledged_sensors", " 1 ACK SN ", "sensor"),
        ("service_coverage_fraction", " SNservice coverage", "fraction"),
        ("jain_collected_packets_all_sensors", "30 sensorscollectionJain ", "index"),
        ("jain_acknowledged_packets_all_sensors", "30 sensorsACKmetric labelJain ", "index"),
    ):
        add("environment.collection." + key, label, unit, "Service coverage and fairness")
    for key, label in (("total_energy_j", "system energy"), ("propulsion_energy_j", "AUVenergy"),
                       ("usv_energy_j", "USVenergy"), ("communication_energy_j", "energy")):
        add("metrics_base." + key, label, "J", "Energy and mobility")
        add("energy_efficiency." + key, "collectionbit/" + label, "bit/J", "Energy and mobility",
            lambda row, k=key: ratio(row["metrics_base"]["collected_bits"], row["metrics_base"][k]))
    add("environment.usv_motion.path_length_m", "USVmetric label", "m", "Energy and mobility")
    add("environment.usv_motion.nonzero_movement_steps", "USVmetric label", "step", "Energy and mobility")
    add("environment.usv_motion.max_abs_energy_consistency_residual_j", "USVenergy", "J", "Energy and mobility")
    for prefix, label in (("local_navigation", "AUVlocal localization"), ("usv_received_hold", "USVstate"),
                          ("planner_horizon_prediction", " 5prediction")):
        for suffix, name, unit in (("mean", "mean errorMAE", "m"), ("rmse", " RMSE", "m"),
                                   ("coverage", "coverage", "fraction")):
            add(f"environment.{prefix}.pooled.{suffix}", label + name, unit, "Three distinct position errors")
    add("environment.planner_horizon_prediction.right_censored_plans", "episode prediction", "plan", "Three distinct position errors")
    add("environment.state_aoi.pooled.mean", "episodeAUV-timemeanAoI", "s", "Information age and staleness")
    add("environment.state_aoi.pooled.aoi_gt_ttl_fraction", "AoI>90  (metric label)", "fraction", "Information age and staleness")
    add("environment.state_aoi.pooled.no_message_fraction", "state", "fraction", "Information age and staleness")
    add("environment.state_aoi.pooled.fresh_unavailable_fraction", " AoI>90 ", "fraction", "Information age and staleness")
    add("environment.state_aoi.pooled.longest_fresh_unavailable_any_auv_s", "time (1 )", "s", "Information age and staleness")
    for kind in ("ALL", "DATA", "STATE"):
        add(f"hop.{kind}.effective_nondelivery_ratio", f"{kind} completion-windownon-delivery", "fraction", "Hop and logical delivery",
            lambda row, k=kind: hop(row, k).get("effective_nondelivery_ratio"))
        add(f"hop.{kind}.resolved_trials", f"{kind} completion-window ", "hop", "Hop and logical delivery",
            lambda row, k=kind: hop(row, k).get("resolved_trials", 0))
    for kind in ("DATA", "STATE"):
        for key, label, unit in (("generated_unique", " ", "packet"),
                                  ("delivered_unique", " ", "packet"),
                                  ("delivery_ratio", "window", "fraction"),
                                  ("mean_delivery_delay_s", "mean", "s"),
                                  ("undelivered_unique", "window non-delivery", "packet")):
            add(f"network.logical.{kind}.{key}", f"{kind} {label}", unit, "Hop and logical delivery")
        add(f"logical.{kind}.right_censored_pending", f"{kind} window/ ", "packet", "Hop and logical delivery",
            lambda row, k=kind: censored_count(row, k))
    for key, label, unit in (
        ("transmissions", " DATA ", "transmission"),
        ("transmitted_frame_bits", " DATAcompletebit ", "bit"),
        ("serialized_bits_within_horizon", " DATAwindow sequencebit", "bit"),
        ("airtime_s", " DATAwindow", "s"),
        ("reserved_slot_time_s", " DATAwindow time slot", "s"),
        ("transmission_fraction", " DATAall ratio", "fraction"),
        ("frame_bit_fraction", " DATAallbitratio", "fraction"),
        ("airtime_fraction_of_episode", " DATA /episode", "fraction"),
        ("airtime_fraction_of_used_airtime", " DATA /all", "fraction"),
        ("reserved_slot_fraction_of_episode", " DATAtime slot/episode", "fraction"),
    ):
        add("network.control_plane." + key, label, unit, "Non-DATA control overhead")
    add("control.slot_fraction_of_used_slots", " DATAtime slot/all time slot", "fraction", "Non-DATA control overhead",
        lambda row: ratio(row["network"]["control_plane"]["reserved_slot_time_s"], row["network"]["totals"]["reserved_slot_time_s"]))
    for key, label, unit in (("started_header_bits", "DATA header bit", "bit"),
                              ("started_payload_bits", "DATA payload bit", "bit"),
                              ("completely_serialized_frames", "window complete sequenceDATA ", "frame"),
                              ("completely_serialized_header_bits", "complete sequenceDATA header bit", "bit"),
                              ("unknown_split_transmissions", "metric labelDATA ", "frame")):
        add("network.data_framing." + key, label, unit, "DATA frame header")
    for index, suffix in ((0, "lower"), (1, "upper")):
        add("data_header.clipped_" + suffix, "windowDATA header bit" + ("lower bound" if index == 0 else "upper bound"), "bit", "DATA frame header",
            lambda row, i=index: row["network"]["data_framing"]["clipped_header_bits_bounds"][i])
    return specs


def metric_rows(groups, specs):
    rows, individual = [], {group: [] for group in GROUPS}
    for group in GROUPS:
        for episode in groups[group]:
            individual[group].append({"seed": episode["seed"], "episode": episode["episode"],
                                      "termination_reason": episode["termination_reason"],
                                      **{key: numeric(getter(episode)) for key, _, _, _, getter in specs}})
    for key, label, unit, section, _getter in specs:
        values = {group: [row[key] for row in individual[group]] for group in GROUPS}
        paired = [late - early for early, late in zip(values["early"], values["late"])
                  if early is not None and late is not None]
        rows.append({"key": key, "label_zh": label, "unit": unit, "section": section,
                     **{group: stats(values[group]) for group in GROUPS}, "paired_difference": stats(paired)})
    return rows, individual


def pooled_summary(groups, traces):
    result = {group: {} for group in GROUPS}
    for group, rows in groups.items():
        out = result[group]
        def total(path):
            return sum(numeric(dig(row, path, 0)) or 0 for row in rows)
        def put(key, numerator, denominator, unit="fraction", note="sum(numerator)/sum(denominator)"):
            out[key] = {"value": ratio(numerator, denominator), "numerator": numerator,
                        "denominator": denominator, "unit": unit, "definition": note}
        bits = total("metrics_base.collected_bits")
        put("goodput_actual_bit_s", bits, total("duration_s"), "bit/s")
        put("goodput_fixed1200_bit_s", bits, len(rows) * 1200., "bit/s")
        put("collection_fraction", bits, total("metrics_base.initial_bits") + total("metrics_base.arrival_bits"))
        for energy in ("total_energy_j", "propulsion_energy_j", "usv_energy_j", "communication_energy_j"):
            put("bits_per_" + energy, bits, total("metrics_base." + energy), "bit/J")
        put("sensor_episode_coverage", total("environment.collection.distinct_served_sensors"),
            total("environment.collection.n_sensors"))
        # Node indices are different random physical locations across seeds;
        # a Jain index over seed-aggregated node-index counts is intentionally omitted.
        for kind in ("ALL", "DATA", "STATE"):
            put("hop_" + kind + "_completion_nondelivery", sum(hop(row, kind).get("resolved_failures", 0) for row in rows),
                sum(hop(row, kind).get("resolved_trials", 0) for row in rows))
        for kind in ("DATA", "STATE"):
            put("logical_" + kind + "_delivery", total(f"network.logical.{kind}.delivered_unique"),
                total(f"network.logical.{kind}.generated_unique"))
            records = [record for row in rows for record in logical(row, kind)["records"]]
            delay_key = "first_attempt_to_delivery_delay_s" if kind == "DATA" else "source_to_delivery_delay_s"
            delays = [numeric(record[delay_key]) for record in records if record["status"] == "delivered"]
            put("logical_" + kind + "_delivered_delay_mean_s", sum(delays), len(delays), "s",
                "mean over delivered unique logical packets only; no zero imputation for undelivered")
            out["logical_" + kind + "_delivered_delay_p95_s"] = {
                "value": percentile(delays), "samples": len(delays), "unit": "s",
                "definition": "pooled empirical p95 over delivered packets, conditional on delivery"}
            out["logical_" + kind + "_window_end_status_counts"] = dict(Counter(record["status"] for record in records))
        control, totals = "network.control_plane.", "network.totals."
        for key, numerator, denominator in (
            ("control_transmission_fraction", "transmissions", "transmissions"),
            ("control_started_frame_bit_fraction", "transmitted_frame_bits", "transmitted_frame_bits"),
            ("control_used_airtime_fraction", "airtime_s", "airtime_s"),
            ("control_used_slot_fraction", "reserved_slot_time_s", "reserved_slot_time_s")):
            put(key, total(control + numerator), total(totals + denominator))
        put("control_airtime_fraction_episode", total(control + "airtime_s"), total("duration_s"))
        put("control_slot_fraction_episode", total(control + "reserved_slot_time_s"), total("duration_s"))
        trace = traces[group]
        for name, count in (("aoi_gt90_fraction", "aoi_gt_ttl_samples"), ("no_state_message_fraction", "aoi_no_message_samples"),
                            ("fresh_unavailable_fraction", "fresh_unavailable_samples")):
            put(name, trace[count], trace["auv_time_samples"])
        put("aoi_mean_s", trace["aoi_sum_s"], trace["auv_time_samples"], "s")
        out["aoi_true_pooled_p95_s"] = {"value": trace["aoi_p95_s"], "samples": trace["auv_time_samples"], "unit": "s",
                                            "definition": "p95 of every post-step AUV-time AoI sample from both AUVs and all episodes; not average of episode p95"}
        for name in ("local_navigation", "usv_received_hold", "planner_5s_forecast"):
            error = trace[name]
            put(name + "_mae_m", error["sum_error_m"], error["valid_samples"], "m")
            put(name + "_coverage", error["valid_samples"], error["opportunities"])
            out[name + "_rmse_m"] = {"value": error["rmse_m"], "sum_squared_error_m2": error["sum_squared_error_m2"],
                                      "valid_samples": error["valid_samples"], "unit": "m", "definition": "sqrt(sum squared Euclidean errors / valid samples)"}
    return result


def kind_summary(groups):
    kinds = sorted({kind for rows in groups.values() for row in rows for kind in row["network"]["by_kind"]})
    fields = ("generated_packets", "transmissions", "transmitted_frame_bits", "serialized_bits_within_horizon",
              "airtime_s", "reserved_slot_time_s", "receiver_hop_trials")
    result = {}
    for kind in kinds:
        result[kind] = {}
        for group, rows in groups.items():
            item = {field: stats([dig(row, f"network.by_kind.{kind}.{field}", 0) for row in rows]) for field in fields}
            resolved = sum(hop(row, kind).get("resolved_trials", 0) for row in rows)
            failures = sum(hop(row, kind).get("resolved_failures", 0) for row in rows)
            item["pooled_completion_window_nondelivery"] = {"value": ratio(failures, resolved),
                                                            "failures": failures, "resolved_trials": resolved}
            result[kind][group] = item
    return result


def appendix(groups):
    result = {}
    for group, rows in groups.items():
        queues, protocol, hop_outcomes = Counter(), Counter(), Counter()
        statuses = Counter(row["termination_reason"] for row in rows)
        for row in rows:
            queues.update(row["network"]["totals"]["queue_events"])
            hop_outcomes.update(row["network"]["hop_delivery"]["outcomes"])
            for event in row["network"]["protocol_events"]:
                protocol[event["outcome"]] += event.get("count", 1)
        result[group] = {
            "termination_reasons": dict(statuses), "failed_episodes": sum(row["terminated"] for row in rows),
            "full_horizon_episodes": sum(row["survived_full_horizon"] for row in rows),
            "queue_event_totals": dict(queues), "protocol_event_totals": dict(protocol),
            "all_started_hop_outcomes": dict(hop_outcomes),
            "core_config_successes": stats([row["metrics_base"].get("network_config_successes", 0) for row in rows]),
            "core_config_requests": stats([row["metrics_base"].get("network_config_requests", 0) for row in rows]),
            "overflow_bits": stats([row["metrics_base"]["overflow_bits"] for row in rows]),
            "per_sensor_packet_counts_by_episode": [{"seed": row["seed"],
                "collected": row["environment"]["collection"]["collected_packets_per_sensor"],
                "acknowledged": row["environment"]["collection"]["acknowledged_packets_per_sensor"]} for row in rows],
            "data_frame_split_declarations": sorted({(row["network"]["data_framing"]["declared_payload_bits"],
                                                       row["network"]["data_framing"]["declared_header_bits"]) for row in rows}),
            "hop_windows": {kind: {"started_trials": sum(dig(row, "network.hop_delivery.receiver_hop_trials", 0) if kind == "ALL"
                else dig(row, f"network.by_kind.{kind}.hop_delivery.receiver_hop_trials", 0) for row in rows),
                "completion_window_trials": sum(hop(row, kind).get("receiver_hop_trials", 0) for row in rows),
                "resolved_completion_trials": sum(hop(row, kind).get("resolved_trials", 0) for row in rows),
                "completion_window_failures": sum(hop(row, kind).get("resolved_failures", 0) for row in rows)} for kind in ("ALL", "DATA", "STATE")},
        }
    return result


def fmt(value):
    if value is None:
        return "N/A"
    if abs(value) >= 10000:
        return f"{value:,.2f}"
    return f"{value:.6g}"


def mean_sd(item):
    return fmt(item["mean"]) + " ± " + fmt(item["sample_sd"]) + f" (n={item['n']})"


def build_report(summary):
    rows = summary["metrics"]
    by_key = {row["key"]: row for row in rows}
    n = summary["episodes_per_model"]
    lines = ["# 45 100 : TMC metric ", "",
        "##  ", "",
        f"  {n} same scenario; safety failure, failure episode. episode1200 . ",
        "training,  TMCcomparator. training, trainingseed; scenario, independent across training seedsseed . ",
        "episodemetric ±standard deviation (SD, ddof=1);  95% .  ,  ,  N/A, n .  seed 100 45 ,  ,  . ",
        "pooledall/all, episode. AoI pooled p95allAUV-time , mean episodep95. ", ""]
    if not summary["formal_30_scenario_retest"]:
        lines += ["** / ,  30scenario. **", ""]
    lines += ["##  ", ""]
    for key, name in (("metrics_base.collected_bits", "mean collection"),
                       ("duration_s", "mean"),
                       ("fixed_budget_goodput_bit_s", " 1200 goodput"),
                       ("environment.state_aoi.pooled.mean", "episode meanAoI"),
                       ("environment.collection.distinct_served_sensors", "mean servicenode  (30 sensors)"),
                       ("metrics_base.total_energy_j", "mean system energy"),
                       ("network.control_plane.transmitted_frame_bits", " DATA bit ")):
        row = by_key[key]
        lines.append(f"- {name}: 45  {fmt(row['early']['mean'])} → 100  {fmt(row['late']['mean'])} {row['unit']}. ")
    for key, name, scale, unit in (
            ("aoi_true_pooled_p95_s", " AUV-time AoI 95 ", 1, "s"),
            ("hop_STATE_completion_nondelivery", "STATEnon-delivery ( )", 100, "%"),
            ("logical_STATE_delivery", "STATEratio", 100, "%")):
        early = summary["pooled"]["early"][key]["value"]
        late = summary["pooled"]["late"][key]["value"]
        lines.append(f"- {name}: 45  {fmt(early * scale)} → 100  {fmt(late * scale)} {unit}. ")
    lines += ["", " metric . collection, safety service, AoI,  ;  metric . ",
              "low energy,  ,  ,  AoI ;  .  1200 goodputfailure episode,  goodput. ", ""]
    lines += ["STATE , statistics,  .  ,  ;  . meanAoI AoI node metric.  ,  . ", ""]
    sections = list(dict.fromkeys(row["section"] for row in rows))
    for section in sections:
        lines += ["## " + section, "", "| metric ( ) | 45 :   ± SD | 100 :   ± SD |   |",
                  "|---|---:|---:|---:|"]
        for row in rows:
            if row["section"] == section:
                lines.append(f"| {row['label_zh']} ({row['unit']}) | {mean_sd(row['early'])} | {mean_sd(row['late'])} | {fmt(row['paired_difference']['mean'])} |")
        lines.append("")
    lines += ["##  pooledmetric: episode", "",
              " / ; p95 RMSE ,  . fraction 0—1 . ", "",
              "|  metric | 45  | 100  |  /  |", "|---|---:|---:|---|"]
    for key, early in summary["pooled"]["early"].items():
        if "value" not in early:
            continue
        late = summary["pooled"]["late"][key]
        def pooled_cell(item):
            value = fmt(item["value"])
            if "numerator" in item:
                value += f" ({fmt(item['numerator'])}/{fmt(item['denominator'])})"
            return value
        lines.append(f"| {key} | {pooled_cell(early)} | {pooled_cell(late)} | {early.get('definition', '')} |")
    lines += ["", "##  kind ", "",
              " , completebit, window time slot;  .  kind 0episode statistics. ", "",
              "| kind |   |  ±SD | completebit ±SD |  ±SD | time slot±SD | completion-window poolednon-delivery (failure/ ) |",
              "|---|---|---:|---:|---:|---:|---:|"]
    for kind, groups in summary["by_kind"].items():
        for group in GROUPS:
            item = groups[group]
            hop_stats = item["pooled_completion_window_nondelivery"]
            lines.append(f"| {kind} | {'45 ' if group == 'early' else '100 '} | {mean_sd(item['transmissions'])} | {mean_sd(item['transmitted_frame_bits'])} | {mean_sd(item['airtime_s'])} | {mean_sd(item['reserved_slot_time_s'])} | {fmt(hop_stats['value'])} ({hop_stats['failures']}/{hop_stats['resolved_trials']}) |")
    lines += ["", "##  ", "",
        "- collection sensorDATA AUVsensor/ payload;  , dataUSV. ACKacknowledgedSN ,  . DATA ,  /data. ",
        "- AUVlocal error, USVerror,  5prediction error, reference error.  ; prediction, predictionnode ; errorcoverage .  t0,  including_t0mean. ",
        "- AoIenvironmenttime ; ratio,  AoIreceived. 90 >,  1 . ",
        "- completion-window , failure/non-delivery,  ,  ,  / , physicalPER. successfulTTL,  . ",
        "- STATE STATE USVreceived; DATA (sensor,seq) DATAtimeAUVreceived,  . statistics; window non-delivery0, all. ",
        "-  DATA ,  STATE, COORD, service, localization;  . completebitwindow sequencebit ; time slot, time slot/ . ",
        "- DATA header ,  DATA .  bit , header/payloadbounds,  header .  node JainN/A,  1; scenario sameSNphysicalnode, scenarioJain. ",
        "-  bit/Jenergy, AUV , USV ,  ;  , independent system. ", "",
        "##  , non-delivery,  ", ""]
    for group in GROUPS:
        item = summary["appendix"][group]
        lines += ["### " + ("45 " if group == "early" else "100 "), "",
                  f"- complete1200episode: {item['full_horizon_episodes']}/{n}; failure: {item['failed_episodes']}/{n}.  : `{json.dumps(item['termination_reasons'], ensure_ascii=False)}`. ",
                  f"-  : `{json.dumps(item['queue_event_totals'], ensure_ascii=False)}`. ",
                  f"-  : `{json.dumps(item['protocol_event_totals'], ensure_ascii=False)}`. ",
                  f"- topology successful/episode: {mean_sd(item['core_config_successes'])};  /episode: {mean_sd(item['core_config_requests'])}.  tasksuccessful. ",
                  f"-  bit/episode: {mean_sd(item['overflow_bits'])}.  ,  . "]
        for kind in ("STATE", "DATA"):
            status_counts = summary["pooled"][group]["logical_" + kind + "_window_end_status_counts"]
            lines.append(f"- {kind}window state: `{json.dumps(status_counts, ensure_ascii=False)}`. ")
        for kind, window in item["hop_windows"].items():
            lines.append(f"- {kind}window:  {window['started_trials']},  {window['completion_window_trials']},  {window['resolved_completion_trials']}, failure{window['completion_window_failures']}. ")
        lines.append("")
    lines += ["##  ", "", "- selected_metrics.csv: episode statistics. ", "- selected_metrics.json:  , pooled , statistics,  kind SN . ",
              "-  CPU ;  , environment,  ,  3 .  SHA256 JSON . ", ""]
    return "\n".join(lines)


def summarize(input_dir):
    input_dir = Path(input_dir).resolve()
    results_path = input_dir / "results.json"
    data = json.loads(results_path.read_text(encoding="utf-8"))
    require(data["status"] == "completed", "Retest is not complete; do not summarize partial results")
    groups = {group: data[group + "_episodes"] for group in GROUPS}
    require(groups["early"] and len(groups["early"]) == len(groups["late"]), "Missing/unbalanced model results")
    require([row["seed"] for row in groups["early"]] == [row["seed"] for row in groups["late"]], "Unpaired scene seeds")
    for group, rows in groups.items():
        for row in rows:
            require(row["model_step"] == (450000 if group == "early" else 1000000), "Unexpected checkpoint step")
            require(row["environment"]["collection"]["n_sensors"] == 30, "Summary assumes 30 sensors")
            require(row["environment"]["state_aoi"]["ttl_s"] == 90., "Summary assumes 90 s freshness threshold")
            require(row["environment"]["planner_horizon_prediction"]["horizon_s"] == 5., "Summary assumes 5 s planner horizon")
            require(row["network"]["core_counter_reconciliation"]["all_observed_counters_match_core"], "Network observer reconciliation failed")
            require(math.isclose(row["fixed_budget_goodput_bit_s"], row["metrics_base"]["collected_bits"] / 1200.,
                                 rel_tol=1e-12, abs_tol=1e-12), "Fixed budget is not 1200 s")
    traces = {group: trace_pool(input_dir / group / "evaluation.jsonl", rows) for group, rows in groups.items()}
    rows, episodes = metric_rows(groups, selected_specs())
    source_paths = [results_path] + [input_dir / group / "evaluation.jsonl" for group in GROUPS]
    summary = {"format": "tmc-selected-cpu-summary-v1", "input_directory": str(input_dir),
        "episodes_per_model": len(groups["early"]), "test_seeds": [row["seed"] for row in groups["early"]],
        "formal_30_scenario_retest": bool(data["protocol"].get("formal_30_scenario_retest", False)),
        "source_sha256": {str(path): digest(path) for path in source_paths},
        "evaluated_prefix_transitions_identical": data.get("evaluated_prefix_transitions_identical"),
        "all_original_transitions_identical": data.get("all_original_transitions_identical"),
        "statistics": "per-episode mean and sample SD; pooled rates use summed numerator/denominator; failures retained; descriptive single-training-seed repeated test scenes",
        "metrics": rows, "episode_selected_metrics": episodes, "trace_pooled": traces,
        "pooled": pooled_summary(groups, traces), "by_kind": kind_summary(groups), "appendix": appendix(groups)}
    report = build_report(summary)
    serialized = json.dumps(summary, ensure_ascii=False, allow_nan=False, indent=2)
    # Only the three declared derived outputs are written, never source evidence.
    (input_dir / "selected_metrics.json").write_text(serialized + "\n", encoding="utf-8")
    (input_dir / "REPORT_ZH.md").write_text(report, encoding="utf-8")
    fields = ["key", "label_zh", "unit", "section", "early_n", "early_missing_n", "early_mean", "early_sample_sd",
              "late_n", "late_missing_n", "late_mean", "late_sample_sd", "paired_n", "paired_mean_difference", "paired_difference_sd"]
    with (input_dir / "selected_metrics.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            record = {key: row[key] for key in ("key", "label_zh", "unit", "section")}
            for group in GROUPS:
                record.update({group + "_" + key: value for key, value in row[group].items()})
            record.update(paired_n=row["paired_difference"]["n"], paired_mean_difference=row["paired_difference"]["mean"],
                          paired_difference_sd=row["paired_difference"]["sample_sd"])
            writer.writerow(record)
    return {"status": "completed", "input": str(input_dir), "episodes_per_model": len(groups["early"]),
            "metrics": len(rows), "outputs": [str(input_dir / name) for name in ("REPORT_ZH.md", "selected_metrics.csv", "selected_metrics.json")]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    args = parser.parse_args()
    print(json.dumps(summarize(args.input), ensure_ascii=True, allow_nan=False))


if __name__ == "__main__":
    main()
