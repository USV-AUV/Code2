"""Passive, episode-local observation of the existing acoustic simulator.

Install immediately after reset. No network algorithm, queue, packet, position
provider, filter or RNG is replaced/replayed. Each wrapped bound method executes
exactly once; wrappers only read its arguments, result and counter deltas.

``observer = NetworkObserver(env.network)``; run the unmodified environment;
``observer.finalize(env.time)`` returns JSON-safe event evidence and statistics.
Generation below means creation/submission of a *network packet*, NOT birth of
sensor data. DATA retries are distinct network packets with one logical data ID.
"""
from __future__ import annotations

from collections import Counter
from functools import wraps
import math
from typing import Any, Mapping


_MANAGEMENT = frozenset({"HELLO", "HELLO_ACK", "REPORT", "CONFIG", "CONFIG_ACK"})
_MISSING = object()


def _packet(p: Any) -> dict[str, Any]:
    payload = p.payload if isinstance(p.payload, Mapping) else {}
    data_id = payload.get("data_seq", payload.get("sensor_data_id"))
    logical = None
    if p.kind == "DATA" and data_id is not None:
        logical = [int(p.src), int(data_id)]
    elif p.kind == "STATE":
        logical = [int(p.src), int(p.seq)]
    return dict(kind=str(p.kind), src=int(p.src), dst=int(p.dst), seq=int(p.seq),
                created_at=float(p.created_at), size_bits=int(p.size_bits),
                expires_at=float(p.expires_at) if math.isfinite(p.expires_at) else None,
                logical_key=logical)


def _identity(p: Mapping[str, Any]) -> tuple[str, int, int]:
    return p["kind"], p["src"], p["seq"]


def _ratio(numerator: float, denominator: float) -> float | None:
    return numerator / denominator if denominator else None


def _overlap(start: float, finish: float, horizon: float) -> float:
    return max(0.0, min(finish, horizon) - max(0.0, start))


class NetworkObserver:
    """Observer for an empty reset AcousticNetwork; one observer per instance."""

    _HOOKS = ("_enqueue", "_pop_queue", "_positions_at", "_next_hop",
              "_push_event", "_transmit_slot", "_receive")

    def __init__(self, network: Any):
        if getattr(network, "_tmc_network_observer", None) is not None:
            raise ValueError("network already has a passive observer")
        if (network.time != 0 or network._slot_index != 0 or network._events
                or any(network._queues.values())):
            raise ValueError("install immediately after reset, before any packet is submitted")
        self.network = network
        self.generation_events: list[dict] = []
        self.queue_events: list[dict] = []
        self.emissions: list[dict] = []
        self.hop_events: list[dict] = []
        self.delivery_events: list[dict] = []
        self.protocol_events: list[dict] = []
        self._generated: set[tuple] = set()
        self._queue_tokens: dict[int, int] = {}
        self._next_queue_token = 0
        self._event_to_hop: dict[tuple[int, int, int], dict] = {}
        self._tx: dict | None = None
        self._originals = {name: getattr(network, name) for name in self._HOOKS}
        self._previous_attributes = {name: network.__dict__.get(name, _MISSING)
                                     for name in self._HOOKS}
        for name in self._HOOKS:
            setattr(network, name, self._wrapper(name))
        network._tmc_network_observer = self

    def detach(self) -> None:
        """Restore exactly the instance's pre-install method lookup state."""
        if getattr(self.network, "_tmc_network_observer", None) is not self:
            return
        for name, previous in self._previous_attributes.items():
            if previous is _MISSING:
                delattr(self.network, name)
            else:
                setattr(self.network, name, previous)
        delattr(self.network, "_tmc_network_observer")

    def _wrapper(self, name: str):
        original = self._originals[name]
        handler = getattr(self, "_observe" + name)

        @wraps(original)
        def wrapped(*args, **kwargs):
            return handler(original, *args, **kwargs)
        return wrapped

    def _queue_event(self, q: Any, owner: int, outcome: str) -> None:
        self.queue_events.append(dict(time=float(self.network.time), owner=int(owner),
                                      queue_token=self._queue_tokens.pop(id(q), None),
                                      outcome=outcome, packet=_packet(q.packet)))

    def _observe_enqueue(self, original, owner, packet, *args, **kwargs):
        meta = _packet(packet)
        key = _identity(meta)
        if key not in self._generated:
            self._generated.add(key)
            self.generation_events.append(dict(time=float(self.network.time), packet=meta))
        before = list(self.network._queues[owner])
        result = original(owner, packet, *args, **kwargs)
        after = list(self.network._queues[owner])
        after_ids = {id(q) for q in after}
        before_ids = {id(q) for q in before}
        for q in before:
            if id(q) not in after_ids:
                self._queue_event(q, owner, "replaced")
        new = [q for q in after if id(q) not in before_ids]
        for q in new:
            self._next_queue_token += 1
            self._queue_tokens[id(q)] = self._next_queue_token
            self.queue_events.append(dict(time=float(self.network.time), owner=int(owner),
                                          queue_token=self._next_queue_token,
                                          outcome="enqueued", packet=_packet(q.packet)))
        if not new:
            self.queue_events.append(dict(time=float(self.network.time), owner=int(owner),
                                          queue_token=None, outcome="queue_limit_dropped", packet=meta))
        return result

    def _observe_pop_queue(self, original, owner):
        before = list(self.network._queues[owner])
        result = original(owner)
        after_ids = {id(q) for q in self.network._queues[owner]}
        for q in before:
            if id(q) not in after_ids:
                self._queue_event(q, owner, "selected" if q is result else "expired")
        if self._tx is not None:
            self._tx["item"] = result
        return result

    def _observe_positions_at(self, original, *args, **kwargs):
        result = original(*args, **kwargs)
        if self._tx is not None:
            # Copy a value the original method already obtained; do not call a
            # possibly stateful position provider a second time.
            self._tx["positions"] = result.copy()
        return result

    def _observe_next_hop(self, original, *args, **kwargs):
        result = original(*args, **kwargs)
        if self._tx is not None:
            self._tx["next_hop"] = result
        return result

    def _observe_push_event(self, original, at, kind, value):
        result = original(at, kind, value)
        if self._tx is not None and kind == "arrival":
            self._tx["arrivals"].append((float(at), value))
        return result

    def _observe_transmit_slot(self, original, owner, positions):
        if self._tx is not None:
            raise RuntimeError("unsupported recursive network transmission")
        tx = dict(time=float(self.network.time), item=None, arrivals=[])
        before = self.network.metrics.get("transmissions", 0)
        self._tx = tx
        try:
            result = original(owner, positions)
        finally:
            self._tx = None
        item = tx["item"]
        delta = self.network.metrics.get("transmissions", 0) - before
        if not delta:
            if item is not None:
                self.protocol_events.append(dict(time=tx["time"], kind=item.packet.kind,
                                                 outcome="no_route_dropped", count=1))
            return result
        if delta != 1 or item is None or "positions" not in tx:
            raise RuntimeError("network transmission contract changed")
        p = item.packet
        if item.routed:
            recipients = [tx["next_hop"]]
        elif item.next_hop == -1 or (item.next_hop is None and p.dst == -1):
            recipients = [i for i in self.network.cooperative_nodes if i != owner]
        else:
            recipients = [item.next_hop if item.next_hop is not None else p.dst]
        duration = p.size_bits / self.network.rate_bps
        emission_id = len(self.emissions)
        self.emissions.append(dict(emission_id=emission_id, time=tx["time"],
                                   transmitter=int(owner), recipients=[int(i) for i in recipients],
                                   duration_s=float(duration), slot_duration_s=float(self.network.slot_duration),
                                   packet=_packet(p)))
        successful = {int(value[1]): (at, value) for at, value in tx["arrivals"]}
        for receiver in recipients:
            if receiver in successful:
                at, value = successful[receiver]
                emitted = value[0]
                status = "in_flight"
            else:
                xy = tx["positions"]
                distance = math.sqrt(sum(float(v)**2 for v in (xy[owner] - xy[receiver])))
                at = tx["time"] + duration + distance / self.network.sound_speed + self.network.processing_delay
                emitted = p
                status = "failed_at_start"
            hop = dict(hop_id=len(self.hop_events), emission_id=emission_id,
                       time=tx["time"], transmitter=int(owner), receiver=int(receiver),
                       nominal_arrival_at=float(at), packet=_packet(emitted),
                       outcome=status, outcome_at=tx["time"] if status == "failed_at_start" else None)
            self.hop_events.append(hop)
            if status == "in_flight":
                self._event_to_hop[(id(emitted), int(receiver), int(owner))] = hop
        return result

    def _observe_receive(self, original, packet, receiver, transmitter):
        keys = ("expired_arrivals", "application_range_dropped", "received_hops",
                "ttl_dropped", "unknown_version_dropped", "stale_configs")
        before = {key: self.network.metrics.get(key, 0) for key in keys}
        outbox_start = len(self.network._outbox)
        result = original(packet, receiver, transmitter)
        delta = {key: self.network.metrics.get(key, 0) - before[key] for key in keys}
        if delta["expired_arrivals"]:
            outcome = "expired_arrival"
        elif delta["application_range_dropped"]:
            outcome = "arrival_range_rejected"
        elif delta["received_hops"]:
            outcome = "arrived_accepted"
        else:
            outcome = "other_arrival_rejection"
        hop = self._event_to_hop.pop((id(packet), int(receiver), int(transmitter)), None)
        if hop is None:
            raise RuntimeError("arrival was not observed at its original transmission")
        hop["outcome"], hop["outcome_at"] = outcome, float(self.network.time)
        for key in ("ttl_dropped", "unknown_version_dropped", "stale_configs"):
            if delta[key]:
                self.protocol_events.append(dict(time=float(self.network.time), kind=packet.kind,
                                                 outcome=key, count=int(delta[key])))
        for delivery in self.network._outbox[outbox_start:]:
            if delivery.packet.kind in {"DATA", "STATE"}:
                self.delivery_events.append(dict(time=float(delivery.arrived_at),
                                                 receiver=int(delivery.receiver),
                                                 transmitter=int(delivery.transmitter),
                                                 packet=_packet(delivery.packet)))
        return result

    def finalize(self, horizon_s: float) -> dict[str, Any]:
        """Snapshot [0,T) starts and arrivals through T; does not advance time.

        RF bits are complete frames whose emission started in the window.
        Serialized bits/airtime and reserved slot time are clipped to [0,T].
        Pure BER/PER is not inferred from mixed physical/protocol failures.
        """
        horizon = float(horizon_s)
        if not math.isfinite(horizon) or horizon < 0 or horizon > self.network.time + 1e-9:
            raise ValueError("horizon must be finite and between zero and observed network time")
        generations = [event for event in self.generation_events if event["time"] < horizon]
        emissions = [event for event in self.emissions if event["time"] < horizon]
        emission_ids = {event["emission_id"] for event in emissions}
        queues = [event for event in self.queue_events if event["time"] < horizon]
        protocol = [event for event in self.protocol_events if event["time"] <= horizon]
        deliveries = [event for event in self.delivery_events if event["time"] <= horizon]
        hops = []
        for event in self.hop_events:
            if event["emission_id"] not in emission_ids:
                continue
            event = dict(event)
            if event["outcome_at"] is None or event["outcome_at"] > horizon:
                event["outcome"], event["outcome_at"] = "in_flight", None
            expiry = event["packet"]["expires_at"]
            event["deadline_expired_at_horizon"] = expiry is not None and expiry < horizon
            hops.append(event)
        kinds = sorted({e["packet"]["kind"] for e in generations + emissions + hops})

        def statistics(selected: set[str]) -> dict[str, Any]:
            sent = [e for e in emissions if e["packet"]["kind"] in selected]
            gen = [e for e in generations if e["packet"]["kind"] in selected]
            hop = [e for e in hops if e["packet"]["kind"] in selected]
            airtime = sum(_overlap(e["time"], e["time"] + e["duration_s"], horizon) for e in sent)
            reserved = sum(_overlap(e["time"], e["time"] + e["slot_duration_s"], horizon) for e in sent)
            outcomes = dict(Counter(e["outcome"] for e in hop))
            queue_counts = dict(Counter(e["outcome"] for e in queues if e["packet"]["kind"] in selected))
            return dict(generated_packets=len(gen), generated_frame_bits=sum(e["packet"]["size_bits"] for e in gen),
                        transmissions=len(sent), transmitted_frame_bits=sum(e["packet"]["size_bits"] for e in sent),
                        serialized_bits_within_horizon=float(airtime * self.network.rate_bps),
                        airtime_s=float(airtime), reserved_slot_starts=len(sent),
                        reserved_slot_time_s=float(reserved), receiver_hop_trials=len(hop),
                        hop_outcomes=outcomes, queue_events=queue_counts)

        by_kind = {kind: statistics({kind}) for kind in kinds}
        totals = statistics(set(kinds))
        control = statistics(set(kinds) - {"DATA"})
        control.update(definition="all emitted non-DATA frames; includes management, STATE, COORD, service handshake and localization",
                       kinds=[kind for kind in kinds if kind != "DATA"],
                       transmission_fraction=_ratio(control["transmissions"], totals["transmissions"]),
                       frame_bit_fraction=_ratio(control["transmitted_frame_bits"], totals["transmitted_frame_bits"]),
                       airtime_fraction_of_episode=_ratio(control["airtime_s"], horizon),
                       airtime_fraction_of_used_airtime=_ratio(control["airtime_s"], totals["airtime_s"]),
                       reserved_slot_fraction_of_episode=_ratio(control["reserved_slot_time_s"], horizon))
        management = statistics(set(kinds) & _MANAGEMENT)

        def hop_summary(events):
            counts = Counter(e["outcome"] for e in events)
            resolved = len(events) - counts["in_flight"]
            failures = resolved - counts["arrived_accepted"]
            return dict(receiver_hop_trials=len(events), outcomes=dict(counts), resolved_trials=resolved,
                        resolved_failures=failures, effective_nondelivery_ratio=_ratio(failures, resolved))

        hop_delivery = hop_summary(hops)
        hop_delivery["completion_window"] = hop_summary([e for e in hops if e["nominal_arrival_at"] <= horizon])
        hop_delivery["definition"] = ("receiver-expanded hop trials, not emission counts; effective nondelivery includes range, faults, "
                                      "random channel rejection and receive-time expiry/range rejection; not pure channel PER. "
                                      "TTL/version forwarding drops follow a successful hop and are separate protocol events. "
                                      "Completion window excludes trials with nominal arrival after the horizon.")
        for kind, stats in by_kind.items():
            kind_hops = [e for e in hops if e["packet"]["kind"] == kind]
            stats["hop_delivery"] = hop_summary(kind_hops)
            stats["hop_delivery"]["completion_window"] = hop_summary(
                [e for e in kind_hops if e["nominal_arrival_at"] <= horizon])

        def declared(name):
            config = self.network.cfg
            value = config.get(name) if isinstance(config, Mapping) else getattr(config, name, None)
            return int(value) if value is not None else None

        payload_bits, header_bits = declared("data_packet_bits"), declared("data_header_bits")
        split_declared = payload_bits is not None and header_bits is not None and payload_bits > 0 and header_bits >= 0
        data_frames = [e for e in emissions if e["packet"]["kind"] == "DATA"]
        known = [e for e in data_frames if split_declared and e["packet"]["size_bits"] == payload_bits + header_bits]
        unknown = [e for e in data_frames if e not in known]
        # Core models frame serialization but no bit order within that frame.
        # For a boundary-truncated frame, exact payload/header allocations are
        # therefore unidentifiable; report tight bounds rather than inventing
        # an on-wire header-first protocol.
        payload_lower = payload_upper = header_lower = header_upper = 0.
        completed = 0
        for event in known:
            serialized = min(float(event["packet"]["size_bits"]),
                             _overlap(event["time"], event["time"] + event["duration_s"], horizon) * self.network.rate_bps)
            payload_lower += max(0., serialized - header_bits)
            payload_upper += min(float(payload_bits), serialized)
            header_lower += max(0., serialized - payload_bits)
            header_upper += min(float(header_bits), serialized)
            completed += event["time"] + event["duration_s"] <= horizon
        data_framing = dict(
            declared_payload_bits=payload_bits, declared_header_bits=header_bits,
            known_split_transmissions=len(known), unknown_split_transmissions=len(unknown),
            started_payload_bits=len(known) * payload_bits if split_declared else None,
            started_header_bits=len(known) * header_bits if split_declared else None,
            completely_serialized_frames=completed,
            completely_serialized_payload_bits=completed * payload_bits if split_declared else None,
            completely_serialized_header_bits=completed * header_bits if split_declared else None,
            clipped_payload_bits_bounds=[payload_lower, payload_upper] if split_declared else None,
            clipped_header_bits_bounds=[header_lower, header_upper] if split_declared else None,
            clipped_header_airtime_s_bounds=[header_lower / self.network.rate_bps, header_upper / self.network.rate_bps] if split_declared else None,
            unknown_split_frame_bits=sum(e["packet"]["size_bits"] for e in unknown),
            definition="DATA-only declared payload/header split, only for frames matching their sum; excludes non-DATA control frames. No within-frame bit order is modeled, so boundary-truncated split uses bounds.")
        all_counts = Counter(e["outcome"] for e in self.hop_events)
        core_map = dict(transmissions=len(self.emissions), tx_bits=sum(e["packet"]["size_bits"] for e in self.emissions),
                        failed_hops=all_counts["failed_at_start"], received_hops=all_counts["arrived_accepted"],
                        expired_arrivals=all_counts["expired_arrival"], application_range_dropped=all_counts["arrival_range_rejected"])
        reconciliation = dict(
            observed_network_time=float(self.network.time),
            core_counters={key: int(self.network.metrics.get(key, 0)) for key in core_map},
            all_observed_counters=core_map,
            all_observed_counters_match_core=all(int(self.network.metrics.get(key, 0)) == value for key, value in core_map.items()),
            emission_starts_excluded_at_or_after_horizon=len(self.emissions) - len(emissions),
            emission_starts_exactly_at_horizon=sum(e["time"] == horizon for e in self.emissions),
            horizon_hop_trial_identity_valid=sum(hop_delivery["outcomes"].values()) == hop_delivery["receiver_hop_trials"])
        active_queues = {}
        for event in queues:
            token = event["queue_token"]
            if event["outcome"] == "enqueued":
                active_queues[token] = event
            elif token is not None:
                active_queues.pop(token, None)

        logical = {}
        for kind in ("DATA", "STATE"):
            generated = {}
            for event in generations:
                p = event["packet"]
                if p["kind"] == kind and p["logical_key"] is not None:
                    generated.setdefault(tuple(p["logical_key"]), []).append(p)
            first_arrivals = {}
            for event in deliveries:
                p = event["packet"]
                if p["kind"] == kind and p["logical_key"] is not None:
                    key = tuple(p["logical_key"])
                    if key in generated and (key not in first_arrivals or event["time"] < first_arrivals[key]["time"]):
                        first_arrivals[key] = event
            pending_keys = {tuple(e["packet"]["logical_key"]) for e in hops
                            if e["outcome"] == "in_flight" and e["packet"]["kind"] == kind
                            and e["packet"]["logical_key"] is not None}
            queued_keys = {tuple(e["packet"]["logical_key"]) for e in active_queues.values()
                           if e["packet"]["kind"] == kind and e["packet"]["logical_key"] is not None
                           and (e["packet"]["expires_at"] is None or e["packet"]["expires_at"] >= horizon)}
            records = []
            for key, packets in sorted(generated.items()):
                created = min(p["created_at"] for p in packets)
                arrival = first_arrivals.get(key)
                if arrival is not None:
                    status = "delivered"
                elif key in pending_keys:
                    status = "undelivered_with_inflight_copy"
                elif key in queued_keys:
                    status = "undelivered_with_queued_unexpired_copy"
                elif all(p["expires_at"] is not None and p["expires_at"] < horizon for p in packets):
                    status = "undelivered_all_submitted_copies_expired"
                else:
                    status = "undelivered_no_pending_copy"
                delay_name = "first_attempt_to_delivery_delay_s" if kind == "DATA" else "source_to_delivery_delay_s"
                record = dict(logical_key=list(key), first_packet_created_at=created, network_packet_copies=len(packets),
                              status=status, first_arrived_at=arrival["time"] if arrival else None,
                              receiver=arrival["receiver"] if arrival else None,
                              **{delay_name: arrival["time"] - created if arrival else None})
                record["delivered_copy_created_at"] = arrival["packet"]["created_at"] if arrival else None
                record["delivered_copy_delay_s"] = arrival["time"] - arrival["packet"]["created_at"] if arrival else None
                records.append(record)
            delays = [r["first_attempt_to_delivery_delay_s" if kind == "DATA" else "source_to_delivery_delay_s"]
                      for r in records if r["status"] == "delivered"]
            logical[kind] = dict(generated_unique=len(generated), delivered_unique=len(first_arrivals),
                                 undelivered_unique=len(generated) - len(first_arrivals),
                                 delivery_ratio=_ratio(len(first_arrivals), len(generated)),
                                 mean_delivery_delay_s=sum(delays) / len(delays) if delays else None,
                                 statuses=dict(Counter(r["status"] for r in records)), records=records)
            if kind == "DATA":
                logical[kind]["distinct_delivered_sensor_source_ids"] = sorted({key[0] for key in first_arrivals})
                logical[kind]["distinct_delivered_sensors"] = len(logical[kind]["distinct_delivered_sensor_source_ids"])
                logical[kind]["delay_origin"] = "earliest observed DATA network-packet created_at for (src,data_seq), NOT original sensor data birth"
            else:
                logical[kind]["delay_origin"] = "original STATE packet.created_at for (src,seq), preserved across relay hops"
        return dict(schema_version=1, horizon_s=horizon, by_kind=by_kind, totals=totals,
                    control_plane=control, legacy_management_subset=management, hop_delivery=hop_delivery,
                    data_framing=data_framing, core_counter_reconciliation=reconciliation,
                    logical=logical, emissions=emissions, hop_events=hops, generation_events=generations,
                    queue_events=queues, protocol_events=protocol, delivery_events=deliveries,
                    boundary_convention="emission/generation/queue starts in [0,T); observed arrivals through T; airtime and slot reservations clipped to [0,T]",
                    data_generation_time_available=False)


def install(network: Any) -> NetworkObserver:
    return NetworkObserver(network)
