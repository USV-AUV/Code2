"""Passive, endpoint-sampled diagnostics for frozen-policy TMC-style evaluation.

This observer never changes an environment, policy, cache, random generator, or
reward. Construct immediately after reset and call ``after_step(info)`` exactly
once after each successful environment step. Supplying the step's existing info
is necessary for USDE diagnostics: no physical measurement is sampled here.
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np


def _finite(value: Any) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("Observer received a non-finite diagnostic")
    return result


def _summary(values: list[float | None], error: bool = False) -> dict[str, Any]:
    finite = np.asarray([_finite(v) for v in values if v is not None], dtype=float)
    result = {
        "valid_samples": int(finite.size), "total_samples": len(values),
        "coverage": float(finite.size / len(values)) if values else None,
        "mean": float(finite.mean()) if finite.size else None,
        "p95": float(np.percentile(finite, 95)) if finite.size else None,
        "max": float(finite.max()) if finite.size else None,
    }
    if error:
        result["rmse"] = float(np.sqrt(np.mean(finite ** 2))) if finite.size else None
    return result


def _longest(flags: list[bool], dt: float) -> float:
    longest = current = 0
    for flag in flags:
        current = current + 1 if flag else 0
        longest = max(longest, current)
    return float(longest * dt)


def _jain(counts: list[int]) -> float | None:
    denominator = len(counts) * sum(value * value for value in counts)
    return float(sum(counts) ** 2 / denominator) if denominator else None


class EnvironmentObserver:
    """Read-only evaluator; truth is diagnostic-only and never an actor input."""

    def __init__(self, env: Any, initial_info: dict | None = None):
        if int(env.step_count) != 0:
            raise ValueError("Construct EnvironmentObserver immediately after reset")
        self.env = env
        self.n_auv = int(env.cfg.n_auv)
        self.n_sensors = int(env.cfg.n_sensors)
        self.dt = _finite(env.cfg.dt)
        self.start_time = self.previous_time = _finite(env.time)
        self.previous_step = int(env.step_count)
        self.previous_usv = np.asarray(env.usv_position, dtype=float).copy()
        self.initial_usv_energy = self.previous_usv_energy = _finite(env.metrics["usv_energy_j"])
        self.initial = self._snapshot(initial_info)
        self.records: list[dict] = []
        self.plans: list[dict] = []
        self.pending: list[dict] = []
        self.completed_predictions: list[dict] = []
        self.path_length = 0.0
        self.moving_steps = 0
        self.significant_moving_steps = 0
        self.energy_residuals: list[float] = []

    def _snapshot(self, info: dict | None) -> dict:
        env = self.env
        now = _finite(env.time)
        local_errors, hold_errors, ages, missing = [], [], [], []
        received_source_times = []
        for i in range(self.n_auv):
            truth = np.asarray(env.auv_positions[i], dtype=float)
            local_errors.append(_finite(np.linalg.norm(np.asarray(env.nav[i].position) - truth)))
            delivery = env.network.received_states.get(i + 1)
            if delivery is None:
                hold_errors.append(None)
                ages.append(now)  # Same explicit no-message convention as env._info().
                missing.append(True)
                received_source_times.append(None)
                continue
            payload = delivery.packet.payload
            position = np.asarray(payload["position"], dtype=float)
            if position.shape != (2,):
                raise ValueError("Received STATE position is not a two-vector")
            hold_errors.append(_finite(np.linalg.norm(position - truth)))
            age = _finite(now - delivery.packet.created_at)
            if age < -1e-8:
                raise ValueError("Received STATE has a future generation timestamp")
            ages.append(max(0.0, age))
            missing.append(False)
            received_source_times.append(_finite(payload["source_time"]))
        usde_rmse = None
        if info is not None:
            if not math.isclose(_finite(info["time"]), now, abs_tol=1e-8):
                raise ValueError("Supplied info is not from the current environment time")
            if int(info["step"]) != int(env.step_count):
                raise ValueError("Supplied info is not from the current step")
            value = info.get("metrics", {}).get("disturbance_rmse_mps")
            usde_rmse = _finite(value) if value is not None else None
        return {
            "time_s": now, "step": int(env.step_count),
            "local_navigation_error_m": local_errors,
            "usv_received_hold_error_m": hold_errors,
            "received_source_times_s": received_source_times,
            "state_aoi_s": ages, "state_no_message": missing,
            "state_aoi_gt_ttl": [age > env.cfg.state_ttl for age in ages],
            "state_fresh_unavailable": [absent or age > env.cfg.state_ttl for absent, age in zip(missing, ages)],
            "usde_cross_auv_rmse_mps": usde_rmse,
        }

    def _observe_new_plan(self, old_step: int, old_time: float) -> None:
        if old_step % int(self.env.cfg.slow_period):
            return
        plan = self.env.last_plan
        positions = {} if plan is None else plan.predicted_positions
        prediction = {
            "issued_at_s": old_time,
            "due_at_s": old_time + self.dt * int(self.env.cfg.slow_period),
            "issued_at_step": old_step,
            "predicted_positions": {},
        }
        for node, position in positions.items():
            if int(node) != node or not 1 <= int(node) <= self.n_auv:
                raise ValueError("Planner returned an unsupported node ID")
            xy = np.asarray(position, dtype=float)
            if xy.shape != (2,) or not np.all(np.isfinite(xy)):
                raise ValueError("Planner prediction must be a finite two-vector")
            prediction["predicted_positions"][str(int(node))] = xy.tolist()
        self.plans.append(prediction)
        self.pending.append(prediction)

    def after_step(self, info: dict | None = None) -> dict:
        """Record one completed fast step; optional info supplies existing USDE RMSE."""
        env = self.env
        if int(env.step_count) != self.previous_step + 1:
            raise ValueError("after_step must be called exactly once per consecutive step")
        now = _finite(env.time)
        if not math.isclose(now - self.previous_time, self.dt, rel_tol=1e-8, abs_tol=1e-8):
            raise ValueError("Observer requires the configured constant fast-step interval")
        record = self._snapshot(info)
        self._observe_new_plan(self.previous_step, self.previous_time)
        current_usv = np.asarray(env.usv_position, dtype=float)
        travelled = _finite(np.linalg.norm(current_usv - self.previous_usv))
        self.path_length += travelled
        self.moving_steps += int(travelled > 0.0)
        self.significant_moving_steps += int(travelled > 1e-10)
        record["usv_step_distance_m"] = travelled
        record["usv_path_length_m"] = self.path_length
        # Independent consistency check, not an inversion of energy into distance.
        # A fixed target makes all physical substeps collinear during a fast step.
        h = self.dt / int(env.cfg.substeps)
        distance_to_target = _finite(np.linalg.norm(np.asarray(env.usv_target) - self.previous_usv))
        substep_limit = _finite(env.cfg.usv_speed) * h
        movement = [min(substep_limit, max(0.0, distance_to_target - j * substep_limit))
                    for j in range(int(env.cfg.substeps))]
        expected_energy = _finite(env.cfg.usv_idle_w) * self.dt + 2.0 * sum(d * d for d in movement) / h
        energy = _finite(env.metrics["usv_energy_j"])
        residual = energy - self.previous_usv_energy - expected_energy
        self.energy_residuals.append(residual)
        record["usv_energy_check_residual_j"] = residual
        matured = []
        waiting = []
        for prediction in self.pending:
            if prediction["due_at_s"] > now + 1e-8:
                waiting.append(prediction)
                continue
            if not math.isclose(prediction["due_at_s"], now, rel_tol=0.0, abs_tol=1e-8):
                raise ValueError("Missed exact planner forecast verification time")
            errors = {}
            for i in range(self.n_auv):
                point = prediction["predicted_positions"].get(str(i + 1))
                errors[str(i + 1)] = (_finite(np.linalg.norm(np.asarray(point) - env.auv_positions[i]))
                                      if point is not None else None)
            completed = {**prediction, "observed_at_s": now, "error_m": errors}
            matured.append(completed)
            self.completed_predictions.append(completed)
        self.pending = waiting
        record["matured_planner_predictions"] = matured
        record["collected_packets_per_sensor"] = self._packet_counts(env.collected)
        record["acknowledged_packets_per_sensor"] = self._packet_counts(env.acknowledged)
        self.records.append(record)
        self.previous_time = now
        self.previous_step = int(env.step_count)
        self.previous_usv = current_usv.copy()
        self.previous_usv_energy = energy
        return record

    def _packet_counts(self, unique_packets) -> list[int]:
        counts = [0] * self.n_sensors
        for node, _sequence in unique_packets:
            if not 0 <= int(node) < self.n_sensors:
                raise ValueError("Data packet refers to an invalid sensor index")
            counts[int(node)] += 1
        return counts

    def _vector_statistics(self, key: str, include_initial: bool = False) -> dict:
        records = ([self.initial] if include_initial else []) + self.records
        return {
            "per_auv": {str(i + 1): _summary([record[key][i] for record in records], error=True)
                        for i in range(self.n_auv)},
            "pooled": _summary([value for record in records for value in record[key]], error=True),
        }

    def _aoi_statistics(self, include_initial: bool = False) -> dict:
        records = ([self.initial] if include_initial else []) + self.records
        per_auv = {}
        for i in range(self.n_auv):
            ages = [record["state_aoi_s"][i] for record in records]
            missing = [record["state_no_message"][i] for record in records]
            stale = [record["state_aoi_gt_ttl"][i] for record in records]
            unavailable = [record["state_fresh_unavailable"][i] for record in records]
            n = len(records)
            received_stale = [old and not absent for old, absent in zip(stale, missing)]
            present = n - sum(missing)
            # Durations use post-step observations only, even for the optional
            # including-t0 arithmetic means: t0 is not an extra time interval.
            post_missing = [record["state_no_message"][i] for record in self.records]
            post_stale = [record["state_aoi_gt_ttl"][i] for record in self.records]
            post_unavailable = [record["state_fresh_unavailable"][i] for record in self.records]
            per_auv[str(i + 1)] = {
                **_summary(ages),
                "no_message_fraction": sum(missing) / n if n else None,
                "aoi_gt_ttl_fraction": sum(stale) / n if n else None,
                "received_stale_fraction_all_samples": sum(received_stale) / n if n else None,
                "received_stale_fraction_when_present": sum(received_stale) / present if present else None,
                "fresh_unavailable_fraction": sum(unavailable) / n if n else None,
                "longest_no_message_sampled_duration_s": _longest(post_missing, self.dt),
                "longest_aoi_gt_ttl_sampled_duration_s": _longest(post_stale, self.dt),
                "longest_fresh_unavailable_sampled_duration_s": _longest(post_unavailable, self.dt),
            }
        n_pooled = len(records) * self.n_auv
        pooled = _summary([age for record in records for age in record["state_aoi_s"]])
        for source, dest in (("state_no_message", "no_message_fraction"),
                             ("state_aoi_gt_ttl", "aoi_gt_ttl_fraction"),
                             ("state_fresh_unavailable", "fresh_unavailable_fraction")):
            pooled[dest] = sum(sum(record[source]) for record in records) / n_pooled if n_pooled else None
        pooled["longest_fresh_unavailable_any_auv_s"] = max(
            (v["longest_fresh_unavailable_sampled_duration_s"] for v in per_auv.values()), default=0.0)
        return {"per_auv": per_auv, "pooled": pooled}

    def finalize(self) -> dict:
        """Return JSON-safe summaries; undefined metrics stay null, never fake zero."""
        env = self.env
        if int(env.step_count) != self.previous_step:
            raise ValueError("The final environment step has not been observed")
        collected = self._packet_counts(env.collected)
        acknowledged = self._packet_counts(env.acknowledged)
        bits = int(env.cfg.data_packet_bits)
        metric_collected = int(env.metrics["collected_bits"])
        metric_ack = int(env.metrics["ack_released_bits"])
        if sum(collected) * bits != metric_collected or sum(acknowledged) * bits != metric_ack:
            raise ValueError("Observed unique packets disagree with environment data counters")
        if not env.acknowledged <= env.collected:
            raise ValueError("ACK set must be a subset of uniquely collected packets")
        prediction_per_auv = {}
        for i in range(self.n_auv):
            key = str(i + 1)
            prediction_per_auv[key] = {
                **_summary([p["error_m"][key] for p in self.completed_predictions], error=True),
                "issued_opportunities": len(self.plans),
                "issued_predictions": sum(key in p["predicted_positions"] for p in self.plans),
                "unavailable_at_issue": sum(key not in p["predicted_positions"] for p in self.plans),
                "right_censored_opportunities": len(self.pending),
                "right_censored_predictions": sum(key in p["predicted_positions"] for p in self.pending),
            }
        usde = [r["usde_cross_auv_rmse_mps"] for r in self.records]
        available_bits = int(env.metrics["initial_bits"] + env.metrics["arrival_bits"])
        abs_residuals = [abs(v) for v in self.energy_residuals]
        return {
            "schema_version": "tmc_environment_observer_v1",
            "sampling": {
                "dt_s": self.dt, "post_step_samples": len(self.records),
                "start_time_s": self.start_time, "end_time_s": self.previous_time,
                "duration_s": self.previous_time - self.start_time,
                "primary_average": "uniform fast-step endpoints excluding t0; equal dt gives time-sampled means",
                "including_t0_average": "optional arithmetic sample average, not an added dt of duration",
                "no_measurement_or_rng_calls": True,
                "duration_accuracy": "AoI outage run durations are sampled at dt resolution, not exact packet-event intervals",
            },
            "collection": {
                "sensor_indices": list(range(self.n_sensors)), "n_sensors": self.n_sensors,
                "collected_packets_per_sensor": collected, "acknowledged_packets_per_sensor": acknowledged,
                "collected_bits_per_sensor": [v * bits for v in collected],
                "acknowledged_bits_per_sensor": [v * bits for v in acknowledged],
                "distinct_served_sensors": sum(v > 0 for v in collected),
                "distinct_acknowledged_sensors": sum(v > 0 for v in acknowledged),
                "service_coverage_fraction": sum(v > 0 for v in collected) / self.n_sensors,
                "jain_collected_packets_all_sensors": _jain(collected),
                "jain_acknowledged_packets_all_sensors": _jain(acknowledged),
                "collected_bits": metric_collected, "ack_released_bits": metric_ack,
                "initial_bits": int(env.metrics["initial_bits"]), "arrival_bits": int(env.metrics["arrival_bits"]),
                "available_generated_bits": available_bits,
                "collected_fraction_of_generated": metric_collected / available_bits if available_bits else None,
                "overflow_bits": int(env.metrics["overflow_bits"]),
                "buffer_bits": int(sum(map(len, env.buffers)) * bits),
                "definition": "unique (zero-based sensor index, sequence) DATA received by an AUV; not bulk delivery to USV",
                "jain_zero_total": "undefined (null), not perfectly fair",
            },
            "usv_motion": {
                "path_length_m": self.path_length, "nonzero_movement_steps": self.moving_steps,
                "movement_steps_above_1e_10_m": self.significant_moving_steps,
                "usv_energy_j": self.previous_usv_energy - self.initial_usv_energy,
                "max_abs_energy_consistency_residual_j": max(abs_residuals, default=0.0),
                "sum_energy_consistency_residual_j": float(sum(self.energy_residuals)),
                "method": "sum true USV endpoint displacement norms; target is constant during each fast step so motion is collinear",
            },
            "local_navigation": {
                "definition": "Euclidean horizontal distance between AUV local navigation position and truth; RMSE=sqrt(mean(distance^2))",
                **self._vector_statistics("local_navigation_error_m"),
                "including_t0": self._vector_statistics("local_navigation_error_m", True),
            },
            "usv_received_hold": {
                "definition": "latest actually received STATE payload position held without extrapolation versus current AUV truth; no message is null",
                **self._vector_statistics("usv_received_hold_error_m"),
                "including_t0": self._vector_statistics("usv_received_hold_error_m", True),
            },
            "usde": {
                "cross_auv_rmse_time_statistics": _summary(usde, error=True),
                "including_t0": _summary([self.initial["usde_cross_auv_rmse_mps"]] + usde, error=True),
                "definition": "uses already-computed info.metrics.disturbance_rmse_mps; mean is mean instantaneous cross-AUV RMSE; rmse pools squared norms over time and AUVs",
            },
            "planner_horizon_prediction": {
                "horizon_s": self.dt * int(env.cfg.slow_period),
                "issued_plans": len(self.plans), "matured_plans": len(self.completed_predictions),
                "right_censored_plans": len(self.pending),
                "per_auv": prediction_per_auv,
                "pooled": _summary([value for p in self.completed_predictions for value in p["error_m"].values()], error=True),
                "right_censored": self.pending,
                "definition": "actual env.last_plan.predicted_positions saved after its issuing fast step; checked only against truth at issue time + configured slow horizon; unavailable predictions stay null",
            },
            "state_aoi": {
                "ttl_s": _finite(env.cfg.state_ttl),
                "definition": "time minus received packet.created_at; before first message use env time, exactly as env._info; no-message is reported separately",
                **self._aoi_statistics(), "including_t0": self._aoi_statistics(True),
            },
        }
