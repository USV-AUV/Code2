"""Explicit compatibility for documented English-only source translations.

Only known, byte-exact translated source files may be mapped back to the hashes
captured by the original model metadata. This does NOT establish bitwise identity.
The registry records both source hashes; unknown code changes still fail closed.
"""
from __future__ import annotations
import json
from pathlib import Path

REGISTRY = Path(__file__).with_name('source_translation_registry.json')

def _registry():
    return json.loads(REGISTRY.read_text(encoding='utf-8'))['mapped_source_files']

def project_flat_source_hashes(actual):
    mapped = dict(actual)
    for name, entry in _registry().items():
        if name not in mapped: continue
        if mapped[name] == entry['localized_sha256']:
            mapped[name] = entry['checkpoint_original_sha256']
        elif mapped[name] != entry['checkpoint_original_sha256']:
            raise ValueError('Unexpected modification of tracked source: ' + name)
    return mapped

def project_baseline_source_hashes(actual):
    mapped = {pkg: dict(files) for pkg, files in actual.items()}
    for name, entry in _registry().items():
        if '/' not in name: continue
        pkg, filename = name.split('/', 1)
        if '/' in filename or pkg not in mapped or filename not in mapped[pkg]:
            continue
        sha = mapped[pkg][filename]
        if sha == entry['localized_sha256']:
            mapped[pkg][filename] = entry['checkpoint_original_sha256']
        elif sha != entry['checkpoint_original_sha256']:
            raise ValueError('Unexpected modification of tracked baseline source: ' + name)
    return mapped

def verify_registry(source_root):
    import hashlib
    root = Path(source_root)
    entries = _registry()
    for name, entry in entries.items():
        p = root / name
        if not p.is_file():raise ValueError('Missing tracked source: ' + name)
        actual = hashlib.sha256(p.read_bytes()).hexdigest()
        if actual != entry['localized_sha256']:
            raise ValueError('Unregistered source modification: ' + name)
    return {'verified_localized_files': len(entries), 'scope': 'approved-source-localization-only'}
