"""Separately authorized long-run campaigns; frozen pilot packages stay unchanged."""
