"""Task-aware local queue service on V3's unchanged physical network.

Only application STATE/COORD use the existing tree. DATA, its service
handshake, and LOCALIZATION_FIX remain direct. Management discovery and paid
CONFIG/ACK installation are inherited. No remote queue, physical fault, or
true position is consulted by this scheduler.

The positive weighted flow ages are unbounded; deadline bonuses are bounded.
This prevents a permanently backlogged application flow being systematically
ignored by this finite-flow selector. It is not a guarantee of delivery or a
bounded end-to-end delay under faults, drops, expiry, or offered overload.
"""
from dataclasses import asdict, dataclass
import math

import numpy as np

from improved.routing import HysteresisRoutingNetwork, RoutingOptions
from usv_auv.network import MANAGEMENT, ROUTED


def routing_defaults():
    """Method trigger settings, not a change to the physical packet TTL."""
    return RoutingOptions(decision_dwell_s=45., renewal_margin_s=60.,
                          direct_recovery_s=30., state_stale_s=25.)


@dataclass(frozen=True)
class QueueOptions:
    management_burst: int = 1
    management_rescue_burst: int = 2
    hello_ack_rescue_fraction: float = .5
    state_service_s: float = 6.
    coord_service_s: float = 8.
    ack_service_s: float = 3.
    request_service_s: float = 6.
    localization_service_s: float = 12.
    data_service_s: float = 6.
    other_service_s: float = 12.
    deadline_weight: float = .5
    deadline_bonus_cap: float = 2.

    def __post_init__(self):
        for name in ('management_burst', 'management_rescue_burst'):
            if type(getattr(self, name)) is not int or getattr(self, name) < 1:
                raise ValueError(f'{name} must be a positive integer')
        if self.management_rescue_burst < self.management_burst:
            raise ValueError('Rescue burst must not be smaller than normal management burst')
        if (not math.isfinite(self.hello_ack_rescue_fraction)
                or not 0 < self.hello_ack_rescue_fraction < 1):
            raise ValueError('HELLO_ACK rescue fraction must be strictly between zero and one')
        for name, value in asdict(self).items():
            if name.endswith('_s') and (not math.isfinite(value) or value <= 0):
                raise ValueError(f'{name} must be finite and positive')
        for name in ('deadline_weight', 'deadline_bonus_cap'):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) < 0:
                raise ValueError(f'{name} must be finite and nonnegative')

    def to_dict(self):
        return asdict(self)


class TaskNetwork(HysteresisRoutingNetwork):
    """Common MAC for full V4 and both strict ablations; no extra slots."""

    def __init__(self, cfg, seed=0, routing_options=None, queue_options=None):
        self.queue_options = (queue_options if isinstance(queue_options, QueueOptions)
                              else QueueOptions(**(queue_options or {})))
        # Entries exist only while this owner's application flow is queued.
        self._flow_wait_since = {}
        super().__init__(cfg, seed, routing_options or routing_defaults())

    @staticmethod
    def _flow(owner, packet):
        return int(owner), packet.kind, int(packet.src), int(packet.dst)

    def _service_interval(self, kind):
        q = self.queue_options
        return {'STATE': q.state_service_s, 'COORD': q.coord_service_s,
                'DATA_ACK': q.ack_service_s, 'DATA_GRANT': q.ack_service_s,
                'DATA_REQUEST': q.request_service_s,
                'LOCALIZATION': q.localization_service_s,
                'LOCALIZATION_FIX': q.localization_service_s,
                'LOCALIZATION_PING': q.localization_service_s,
                'DATA': q.data_service_s}.get(kind, q.other_service_s)

    def _sync_flows(self, owner):
        """Only the transmitting node's own live local queue is consulted."""
        active = {self._flow(owner, item.packet) for item in self._queues[owner]
                  if item.packet.kind not in MANAGEMENT and item.packet.expires_at >= self.time}
        for key in list(self._flow_wait_since):
            if key[0] == owner and key not in active:
                del self._flow_wait_since[key]
        for key in active:
            self._flow_wait_since.setdefault(key, float(self.time))

    def _enqueue(self, owner, packet, next_hop=None, routed=False):
        if packet.kind not in MANAGEMENT and packet.kind not in ROUTED:
            if routed or (owner != packet.src and owner != packet.dst):
                self.metrics['task_v4_nonroutable_application_rejected'] += 1
                return
        # Prune expired/inactive clocks before replacement can create a new flow.
        # Source creation time is NOT this forwarding queue's activation time.
        self._sync_flows(owner)
        result = super()._enqueue(owner, packet, next_hop, routed)
        self._sync_flows(owner)
        return result

    def _application_rank(self, owner, index):
        packet = self._queues[owner][index].packet
        activated = self._flow_wait_since[self._flow(owner, packet)]
        age = max(0., self.time - activated)
        gap = self.cooperative_slot_gap
        urgency = (age + gap) / self._service_interval(packet.kind)
        if math.isfinite(packet.expires_at):
            remaining = max(0., packet.expires_at - self.time)
            # Bounded bonus, computed from an actual local packet's deadline.
            urgency += self.queue_options.deadline_weight * min(
                self.queue_options.deadline_bonus_cap, gap / max(remaining, gap / 4.))
        return urgency, -packet.created_at, -index

    def _pop_queue(self, owner):
        queue = self._queues[owner]
        kept = [item for item in queue if item.packet.expires_at >= self.time]
        self.metrics['expired_packets'] += len(queue) - len(kept)
        queue.clear()
        queue.extend(kept)
        self._sync_flows(owner)
        if not queue:
            return None
        apps = [i for i, item in enumerate(queue) if item.packet.kind not in MANAGEMENT]
        management = [i for i, item in enumerate(queue) if item.packet.kind in MANAGEMENT]
        app_turn = apps and (not management or self._management_run[owner] >= self.queue_options.management_burst)
        rescue = [i for i in management if queue[i].packet.kind == 'HELLO_ACK'
                  and self.time - queue[i].packet.created_at >=
                  self.queue_options.hello_ack_rescue_fraction * self.probe_timeout]
        if (app_turn and rescue
                and self._management_run[owner] < self.queue_options.management_rescue_burst):
            index = min(rescue, key=lambda i: queue[i].packet.created_at)
            self._management_run[owner] += 1
            self.metrics['task_v4_hello_ack_deadline_rescues'] += 1
        elif app_turn:
            index = max(apps, key=lambda i: self._application_rank(owner, i))
            packet = queue[index].packet
            self._flow_wait_since[self._flow(owner, packet)] = float(self.time)
            self._last_application_flow[owner] = (packet.kind, packet.src, packet.dst)
            self._management_run[owner] = 0
            self.metrics['task_v4_application_queue_services'] += 1
        else:
            # Preserve V3's management class ordering; only the burst is changed.
            urgent = [i for i in management if queue[i].packet.kind in {'CONFIG', 'CONFIG_ACK'}]
            index = urgent[0] if urgent else None
            cycle = ['HELLO_ACK'] * self.n_auvs + ['HELLO', 'REPORT']
            if index is None:
                for _ in range(len(cycle)):
                    kind = cycle[self._management_cursor[owner] % len(cycle)]
                    self._management_cursor[owner] += 1
                    choices = [i for i in management if queue[i].packet.kind == kind]
                    if choices:
                        index = choices[0]
                        break
            if index is None:
                index = (management or apps)[0]
            self._management_run[owner] += 1
        item = queue[index]
        del queue[index]
        self._sync_flows(owner)
        return item


class FixedStarTaskNetwork(TaskNetwork):
    """Same local scheduling, fixed star, and no free physical connectivity."""

    def _enumerate_topologies(self):
        return [tuple(0 for _ in range(self.n_auvs))]

    @property
    def star(self):
        return tuple(0 for _ in range(self.n_auvs))

    def request_topology(self, parents=None, time=None):
        if parents is None:
            parents = 0
        if isinstance(parents, (bool, np.bool_)):
            raise ValueError('Fixed-star maintenance action must not be boolean')
        if isinstance(parents, (int, np.integer)):
            if int(parents) not in (0, 1):
                raise ValueError('Fixed star allows KEEP or same-parent maintenance only')
        else:
            try:
                parents = tuple(parents)
            except TypeError as exc:
                raise ValueError('Invalid fixed-star maintenance action') from exc
            if parents != self.star:
                raise ValueError('Fixed star cannot select an AUV relay')
        return super().request_topology(parents, time)

    def _install_config(self, packet, receiver):
        if tuple(packet.payload.get('parents', ())) != self.star:
            self.metrics['task_v4_fixed_star_nonstar_config_dropped'] += 1
            return
        return super()._install_config(packet, receiver)

    def _enqueue(self, owner, packet, next_hop=None, routed=False):
        if 1 <= owner <= self.n_auvs and owner != packet.src and owner != packet.dst:
            self.metrics['task_v4_fixed_star_relay_dropped'] += 1
            return
        return super()._enqueue(owner, packet, next_hop, routed)

    def _next_hop(self, owner, dst, version):
        record = self.installed_routes.get(owner, {}).get(version)
        if record is not None and tuple(record[0]) != self.star:
            self.metrics['task_v4_fixed_star_nonstar_route_dropped'] += 1
            return None
        return super()._next_hop(owner, dst, version)
