"""V3-preserving, causal task-information integration on unchanged physics.

All three methods share the same local scheduler and transmitted task records.
Missing coordination NEVER prevents autonomous local requests/collection.
Only STATE/COORD use relay routing; DATA remains the original SN->AUV flow.
"""
from dataclasses import dataclass, asdict
from collections import Counter
import copy
import math
import struct
import numpy as np

from improved.environment import ImprovedEnv, SERVICE_FIELDS
from improved.routing import root_feature_names
from usv_auv.observations import observation_fields, root_observation_fields
from baselines.environment import NoDisturbanceEstimate
from ablations_v3.environment import _strip_disturbance
from .methods import get_method
from .routing import TaskNetwork, FixedStarTaskNetwork, routing_defaults


TASK_FIELDS = ('task_queue', 'grant_remaining', 'service_phase',
               'coord_ack_age', 'application_load', 'collected_packets')
# Binary budget: base compact peer record 48B + service block 35B +
# two records (uint16 SN, float32 packets, float64 original stamp =14B)
# + 1B record count. Python JSON is logging, NOT radio encoding.
TASK_EXTENSION_BYTES = 64
PEER_RECORD_BYTES = 48 + TASK_EXTENSION_BYTES


def pack_task_extension(payload):
    """Executable 64-byte wire budget; NaN/future semantics checked by callers."""
    service = payload['service']
    records = payload['task_reports']
    if len(records) > 2:
        raise ValueError('Only two timestamped task records fit the declared extension')
    block = struct.pack('<BfdddHI', service['phase'], service['queue_packets'],
        service['grant_expires'], service['coord_source_time'], service['last_data_time'],
        service['queued_applications'], service['collected_packets'])
    block += struct.pack('<B', len(records))
    for j, value, stamp in records:
        block += struct.pack('<Hfd', j, value, stamp)
    block += bytes(14 * (2 - len(records)))
    if len(block) != TASK_EXTENSION_BYTES:
        raise AssertionError('Task extension differs from charged wire size')
    return block


def local_fields(n_auv):
    return observation_fields(n_auv) + list(SERVICE_FIELDS)


def slow_fields(n_auv):
    return (root_observation_fields(n_auv) + list(root_feature_names(n_auv)) +
            [f'auv_{i}_{f}' for i in range(1, n_auv + 1) for f in TASK_FIELDS])


@dataclass(frozen=True)
class MethodOptions:
    # V3 navigation/forecast parameters unchanged.
    prediction_tau_s: float = 3.
    navigation_fix_sigma: float = 3.
    missing_velocity_sigma: float = .25
    task_report_ttl_s: float = 180.
    conflict_age_s: float = 30.
    conflict_distance_margin_m: float = 3.
    peer_reserved_priority: float = .10
    queue_empty_packets: float = .5

    def __post_init__(self):
        if any(not math.isfinite(v) or v <= 0 for v in asdict(self).values()):
            raise ValueError('Task V4 options must be positive and finite')
        if self.peer_reserved_priority > 1:
            raise ValueError('Reservation priority multiplier must be at most one')


class TaskV4Env(ImprovedEnv):
    observation_schema_version = 'task-v4-20260917-r1-v3-local-task-root'

    def __init__(self, cfg=None, method_id='full_v4', method_options=None, routing_options=None):
        self.method = get_method(method_id)
        self._task_ready = False
        super().__init__(cfg, method_options or MethodOptions(), routing_options or routing_defaults())
        # This experiment uses two vehicles. Do not silently truncate a larger
        # COORD packet to fit the physical slot when scaling the experiment.
        if self.cfg.n_auv != 2:
            raise ValueError('This frozen task-message prototype supports exactly two AUVs')
        if self.cfg.state_packet_bits < 8 * (128 + TASK_EXTENSION_BYTES):
            raise ValueError('STATE lacks the reserved base128B + task64B budget')
        self.observation_schema = local_fields(self.cfg.n_auv)
        self.observation_dim = len(self.observation_schema)
        self.slow_observation_schema = slow_fields(self.cfg.n_auv)
        self.slow_observation_dim = len(self.slow_observation_schema)
        self.last_observations = self._observations()

    def reset(self, seed=None):
        self._task_ready = False
        super().reset(seed)
        c = self.cfg
        if not self.method.use_usde:
            self.usde = [NoDisturbanceEstimate(2) for _ in self.nav]
        network_cls = TaskNetwork if self.method.use_topology else FixedStarTaskNetwork
        self.network = network_cls(c, self.seed, routing_options=self.routing_options)
        self.network.application_link_filter = self._data_in_range
        self.network.on_transmit_payload = self._physical_localization
        self.local_data_receipts = [dict() for _ in self.nav]
        self.local_task_reports = [dict() for _ in self.nav]
        self.last_local_data = np.full(c.n_auv, -1.)
        self.task_metrics = Counter()
        self._task_ready = True
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _clear_disabled_received_information(self):
        if not self._task_ready or self.method.use_usde:
            return
        for cache in self.network.receive_cache.values():
            for delivery in cache.values():
                _strip_disturbance(delivery.packet.payload)
        for payload in self.coord_cache:
            _strip_disturbance(payload)

    def _observations(self):
        self._clear_disabled_received_information()
        result = super()._observations()
        if not self.method.use_usde:
            result[:, 8:10] = 0.
            result[:, 11] = 0.
        return result

    def _state_payload(self, i):
        payload = super()._state_payload(i)
        if not self.method.use_usde:
            _strip_disturbance(payload)
        if not self._task_ready:
            return payload
        target = int(self.targets[i])
        grant = self.received_service_grants[i].get(target)
        valid = grant is not None and grant['expires_at'] > self.time
        near = np.linalg.norm(self.nav[i].position - self.sensor_positions[target]) <= self.cfg.collection_radius
        phase = 2 if valid and near else 1 if near else 0
        coord = self.coord_cache[i]
        records = sorted(self.local_task_reports[i].items(), key=lambda kv: (-kv[1][1], kv[0]))[:2]
        payload['task_reports'] = [[int(j), float(value[0]), float(value[1])] for j, value in records]
        payload['service'] = dict(phase=phase,
            queue_packets=float(self._queue_forecast(i)[target] / self.cfg.data_packet_bits),
            grant_expires=float(grant['expires_at']) if valid else -1.,
            coord_source_time=float(coord['source_time']) if coord else -1.,
            last_data_time=float(self.last_local_data[i]),
            queued_applications=sum(q.packet.kind not in {'HELLO', 'HELLO_ACK', 'REPORT', 'CONFIG', 'CONFIG_ACK'}
                                    for q in self.network._queues[i + 1]),
            collected_packets=len(self.local_data_receipts[i]))
        pack_task_extension(payload)
        return payload

    def _publish_coord(self):
        self._clear_disabled_received_information()
        if not self._task_ready:
            return super()._publish_coord()
        c = self.cfg
        if self.time - self.last_coord_sent < c.state_period - 1e-9:
            return
        states = {str(n): copy.deepcopy(d.packet.payload) for n, d in self.network.received_states.items()
                  if 1 <= n <= c.n_auv and 'position' in d.packet.payload}
        for p in states.values():
            p.pop('localization_time', None)
        bits = 8 * (40 + PEER_RECORD_BYTES * len(states))
        if bits > self.network.max_packet_bits:
            raise ValueError('Task COORD does not fit a physical TDMA slot')
        for i in range(c.n_auv):
            self._send(0, i + 1, 'COORD', dict(source_time=self.time,
                usv_position=self.usv_position.tolist(), states=states), bits)
        self.last_coord_sent = self.time

    def _deliver(self, deliveries):
        # Base delivery continues to own the physical buffer, grants, ACK and
        # globally unique goodput counters. Public scheduling never reads them.
        if not self._task_ready:
            return super()._deliver(deliveries)
        for d in deliveries:
            p = d.packet
            local_prior = None
            if p.kind == 'DATA' and 1 <= d.receiver <= self.cfg.n_auv:
                i, j = d.receiver - 1, int(p.payload['sensor'])
                key = (j, int(p.payload['data_seq']))
                if key not in self.local_data_receipts[i]:
                    local_prior = min(self.cfg.buffer_packets * self.cfg.data_packet_bits,
                        self.queue_estimates[i, j] + max(0., self.network.time - self.queue_stamps[i, j]) *
                        self.cfg.arrival_rate * self.cfg.data_packet_bits)
            super()._deliver([d])
            if p.kind not in ('DATA', 'DATA_GRANT') or not 1 <= d.receiver <= self.cfg.n_auv:
                continue
            i, j = d.receiver - 1, int(p.payload['sensor'])
            stamp = float(self.network.time)
            if p.kind == 'DATA':
                key = (j, int(p.payload['data_seq']))
                if key in self.local_data_receipts[i]:
                    continue
                # Global goodput dedup and per-AUV evidence are distinct. A
                # first LOCAL receipt updates this AUV even if a different
                # vehicle previously received that DATA. No global-set query.
                self.queue_estimates[i, j] = max(0., local_prior - self.cfg.data_packet_bits)
                self.queue_stamps[i, j] = stamp
                self.local_data_receipts[i][key] = stamp
                self.last_local_data[i] = stamp
                # The received packet is a local observation, not a query of
                # sensor buffers or the simulator's globally collected set.
                value = self.queue_estimates[i, j] / self.cfg.data_packet_bits
                self.local_task_reports[i][j] = (float(value), stamp)
            else:
                source_stamp = float(p.payload['source_time'])
                # Do not advertise a stale grant as newly measured at receive.
                # Account only for DATA this AUV actually received afterwards.
                later = sum(sn == j and t > source_stamp
                            for (sn, _), t in self.local_data_receipts[i].items())
                value = max(0., p.payload['buffer_bits'] / self.cfg.data_packet_bits - later)
                old = self.local_task_reports[i].get(j)
                if old is None or source_stamp > old[1]:
                    self.local_task_reports[i][j] = (float(value), source_stamp)
        self._clear_disabled_received_information()

    def _ingest_task_reports(self, i):
        coord = self.coord_cache[i]
        if not coord or coord['source_time'] > self.time:
            return
        c = self.cfg
        for peer_id, payload in coord.get('states', {}).items():
            if int(peer_id) == i + 1:
                continue
            for record in payload.get('task_reports', []):
                j, packets, stamp = record
                if (not isinstance(j, int) or not 0 <= j < c.n_sensors or
                        not all(math.isfinite(x) for x in (packets, stamp)) or packets < 0 or
                        not 0 <= self.time - stamp <= self.method_options.task_report_ttl_s or
                        stamp > payload['source_time'] or stamp <= self.queue_stamps[i, j]):
                    continue
                later = sum(sn == j and t > stamp for (sn, _), t in self.local_data_receipts[i].items())
                self.queue_estimates[i, j] = min(c.buffer_packets, max(0., packets - later)) * c.data_packet_bits
                self.queue_stamps[i, j] = stamp
                self.task_metrics['received_queue_evidence_updates'] += 1
        # Received evidence is not re-advertised with this node's timestamp.

    def _peer_reservations(self, i, distances):
        coord = self.coord_cache[i]
        result = set()
        if not coord:
            return result
        c, m = self.cfg, self.method_options
        for peer_id, p in coord.get('states', {}).items():
            peer_id = int(peer_id)
            if peer_id == i + 1 or not 0 <= self.time - p['source_time'] <= m.conflict_age_s:
                continue
            j = p.get('target')
            if not isinstance(j, int) or not 0 <= j < c.n_sensors:
                continue
            service = p.get('service', {})
            grant_live = service.get('grant_expires', -1.) > self.time
            # These are received navigation estimates, not true peer position.
            peer_distance = np.linalg.norm(np.asarray(p['position']) - self.sensor_positions[j])
            peer_wins = (grant_live or peer_distance + m.conflict_distance_margin_m < distances[j] or
                (abs(peer_distance - distances[j]) <= m.conflict_distance_margin_m and peer_id < i + 1))
            if peer_wins:
                result.add(j)
        return result

    def _select_targets(self, force=False):
        if not self._task_ready:
            return super()._select_targets(force)
        c = self.cfg
        for i in range(c.n_auv):
            self._ingest_task_reports(i)
            target = int(self.targets[i])
            elapsed = self.time - self.target_since[i]
            estimate = self._queue_forecast(i)
            distance = np.linalg.norm(self.sensor_positions - self.nav[i].position, axis=1)
            reservations = self._peer_reservations(i, distance)
            grant = self.received_service_grants[i].get(target)
            valid_grant = grant is not None and grant['expires_at'] > self.time
            empty = estimate[target] < self.method_options.queue_empty_packets * c.data_packet_bits
            conflict = target in reservations and not valid_grant
            if not (force or elapsed >= c.target_max_dwell or
                    (elapsed >= c.target_min_dwell and (empty or conflict))):
                continue
            # Preserve the V3 local task utility and fully autonomous fallback.
            priority = estimate / (distance + 10.)
            for j in reservations:
                priority[j] *= self.method_options.peer_reserved_priority
            if conflict and not force:
                priority[target] = -1.
            new = int(np.argmax(priority))
            if new != target or force:
                if not force and conflict:
                    self.task_metrics['received_information_conflict_retargets'] += 1
                self.targets[i] = new
                self.target_since[i] = self.time

    def _root_task_features(self):
        values = []
        c = self.cfg
        for node in range(1, c.n_auv + 1):
            delivery = self.network.received_states.get(node)
            p = delivery.packet.payload if delivery else {}
            s = p.get('service', {})
            coord_stamp = s.get('coord_source_time', -1.)
            age = self.time - coord_stamp if coord_stamp >= 0 else c.state_ttl
            values.extend([min(max(s.get('queue_packets', 0.), 0.) / c.buffer_packets, 1.),
                np.clip((s.get('grant_expires', -1.) - self.time) / c.grant_ttl, 0., 1.),
                s.get('phase', 0.) / 2., min(max(age, 0.) / c.state_ttl, 3.),
                min(s.get('queued_applications', 0.) / c.queue_limit, 1.),
                min(s.get('collected_packets', 0.) / 100., 1.)])
        return np.asarray(values, np.float32)

    def slow_state(self):
        self._clear_disabled_received_information()
        state, mask = super().slow_state()
        extras = self._root_task_features() if self._task_ready else np.zeros(6 * self.cfg.n_auv)
        return np.r_[state, extras].astype(np.float32), mask

    def topology_reward(self, task_reward, config_requests_delta):
        """CTDE task reward + root-received uplink/downlink freshness costs.

        Downlink age is conservative: root only knows COORD reception via a
        later STATE acknowledgement. It never reads current remote caches.
        This is an explicitly biased objective, not a potential-invariance claim.
        """
        up, down, weights = [], [], []
        for node in range(1, self.cfg.n_auv + 1):
            delivery = self.network.received_states.get(node)
            p = delivery.packet.payload if delivery else {}
            service = p.get('service', {})
            age = self.time - p.get('source_time', 0.)
            ack = service.get('coord_source_time', -1.)
            down_age = self.time - ack if ack >= 0 else self.time
            weight = 1. + .5 * min(service.get('queue_packets', 0.) / 4., 1.)
            up.append(min(max(age, 0.) / self.cfg.state_ttl, 3.))
            down.append(min(max(down_age, 0.) / self.cfg.state_ttl, 3.))
            weights.append(weight)
        return float(.2 * task_reward - .08 * np.average(up, weights=weights)
                     - .04 * np.average(down, weights=weights) - .1 * config_requests_delta)

    def _root_states(self):
        self._clear_disabled_received_information()
        return super()._root_states()

    def _plan_usv(self):
        self._clear_disabled_received_information()
        return super()._plan_usv()

    def step(self, actions, topology_action=None):
        if not self.method.use_topology:
            if topology_action is not None and (isinstance(topology_action, (bool, np.bool_)) or
                not isinstance(topology_action, (int, np.integer)) or int(topology_action) != 0 or
                self.step_count % self.cfg.slow_period):
                raise ValueError('USDE-only has no topology policy; only slow-clock KEEP is valid')
            topology_action = 0 if self.step_count % self.cfg.slow_period == 0 else None
        self._clear_disabled_received_information()
        result = super().step(actions, topology_action)
        if self._task_ready and len(set(self.targets)) < self.cfg.n_auv:
            self.task_metrics['same_target_steps'] += 1
        result[-1]['task_diagnostics'] = dict(self.task_metrics)
        return result

    def _info(self):
        info = super()._info()
        info['method_id'] = self.method.method_id
        info['method_fingerprint'] = self.method.fingerprint
        info['metrics']['usde_enabled'] = float(self.method.use_usde)
        info['metrics']['topology_reconfiguration_enabled'] = float(self.method.use_topology)
        if self._task_ready:
            info['task_diagnostics'] = dict(self.task_metrics)
        if not self.method.use_usde:
            info['metrics']['zero_disturbance_prior_rmse_mps'] = info['metrics']['disturbance_rmse_mps']
            info['metrics']['disturbance_rmse_mps'] = None
        return info
