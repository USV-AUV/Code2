"""Dated V4 task-aware pilot; historical V3 and 20260912 V4 stay frozen."""
