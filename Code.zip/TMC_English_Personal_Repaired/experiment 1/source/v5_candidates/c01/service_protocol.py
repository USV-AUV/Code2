"""Common, paid service protocol layered over the frozen R2 environment.

Compose ``class TaskV4Env(ServiceProtocolMixin, R2TaskV4Env)``. The candidate's
frozen MethodOptions supplies service_piggyback and service_release booleans.
The mixin never changes physical configuration, slots, PER, DATA size, motion,
global unique-goodput accounting, or AUV authority. All variants use it equally.

Piggyback uses the already charged 32-byte DATA header, not extra free bytes.
Sensor-local queue/lease information becomes AUV knowledge only upon a real
DATA arrival. Empty sensors retain their real standalone GRANT response.

Release is optional. A local target change sends a real 64-byte DATA_RELEASE.
Only its arrival at that SN can cancel that sender's grants/queued DATA through
the specified request generation. An SN-local cancellation watermark prevents
a reordered old request from reviving a cancelled visit. A newer visit or a
different owner's grant is untouched. Radio events already in flight remain.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import copy
import math
import struct

import numpy as np


SERVICE_HEADER = struct.Struct('<HIddHH6x')
SERVICE_HEADER_BYTES = 32
RELEASE_BITS = 512
MAX_GENERATION = 65535


def _uint(value, maximum, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or not 0 <= value <= maximum:
        raise ValueError(f'{name} must be an integer in [0,{maximum}]')
    return int(value)


def pack_service_header(sensor, data_seq, source_time, expires_at, buffer_count, generation):
    """sensor:uint16, seq:uint32, two doubles, count/flags:uint16, pad:6.

The flags field is the visit/request generation, bounded rather than silently
wrapping. This gives an executable 32-byte budget for the complete extension
including the existing sensor and logical DATA sequence fields.
"""
    values = (_uint(sensor, 65535, 'sensor'), _uint(data_seq, 2**32-1, 'data_seq'),
              float(source_time), float(expires_at), _uint(buffer_count, 65535, 'buffer_count'),
              _uint(generation, MAX_GENERATION, 'generation'))
    if not all(math.isfinite(x) for x in values[2:4]) or values[2] < 0:
        raise ValueError('Service header timestamps must be finite and source_time nonnegative')
    result = SERVICE_HEADER.pack(*values)
    if len(result) != SERVICE_HEADER_BYTES:
        raise AssertionError('DATA service header exceeds the existing 32-byte budget')
    return result


def unpack_service_header(wire):
    if len(wire) != SERVICE_HEADER_BYTES:
        raise ValueError('Service DATA header must be exactly 32 bytes')
    sensor, data_seq, source_time, expires_at, buffer_count, generation = SERVICE_HEADER.unpack(wire)
    pack_service_header(sensor, data_seq, source_time, expires_at, buffer_count, generation)
    return dict(sensor=sensor, data_seq=data_seq, source_time=source_time,
                expires_at=expires_at, buffer_count=buffer_count, generation=generation)


class ServiceProtocolMixin:
    """Cooperative reset/send/deliver/step hooks; no independent controller."""

    def _service_option(self, name):
        value = getattr(getattr(self, 'method_options', None), name, False)
        if type(value) is not bool:
            raise ValueError(f'{name} must be boolean')
        return value

    def _service_enabled(self):
        return self._service_option('service_piggyback') or self._service_option('service_release')

    def reset(self, seed=None):
        # reset is dynamically dispatched during CooperativeEnv construction.
        self.service_protocol_metrics = Counter()
        self.service_protocol_events = []
        self._service_request_generation = defaultdict(int)  # AUV-local sent requests
        self._service_received_generation = defaultdict(int)  # AUV-local arrived grants
        self._service_sensor_generation = {}  # SN-local current accepted owner/generation
        self._service_accepted_generation = defaultdict(int)  # SN-local per-owner latest request
        self._service_cancel_through = defaultdict(int)  # SN-local arrived release watermarks
        self._service_processing_request = None
        result = super().reset(seed)
        if self._service_enabled() and self.cfg.data_header_bits != 8 * SERVICE_HEADER_BYTES:
            raise ValueError('C01 service protocol requires the existing 256-bit DATA header')
        return result[0], self._info()

    def _send(self, src, dst, kind, payload, bits=None, expiry=None):
        if not self._service_enabled():
            return super()._send(src, dst, kind, payload, bits, expiry)
        data = copy.deepcopy(payload)
        if kind == 'DATA_REQUEST':
            j = int(data['sensor'])
            key = (int(src), j)
            generation = self._service_request_generation[key] + 1
            _uint(generation, MAX_GENERATION, 'generation')
            self._service_request_generation[key] = generation
            data['service_generation'] = generation
        elif kind == 'DATA_GRANT':
            j = int(data['sensor'])
            request = self._service_processing_request
            if request is None or request[:2] != (int(dst), j):
                raise RuntimeError('A service GRANT must originate from an actually received request')
            generation = request[2]
            self._service_sensor_generation[j] = (int(dst), generation)
            self._service_accepted_generation[(int(dst), j)] = generation
            data['service_generation'] = generation
            if self._service_option('service_piggyback') and self.buffers[j]:
                self.service_protocol_metrics['standalone_nonempty_grants_suppressed'] += 1
                return None
            self.service_protocol_metrics['standalone_grants_queued'] += 1
        elif kind == 'DATA':
            j, seq = int(data['sensor']), int(data['data_seq'])
            owner, expires = self.grants[j]
            known_owner, generation = self._service_sensor_generation.get(j, (int(owner), 0))
            if int(owner) != int(dst) or known_owner != int(dst):
                raise RuntimeError('DATA header cannot claim another receiver\'s service lease')
            # All of these values are owned/measured by the transmitting SN.
            stamp, count = float(self.network.time), len(self.buffers[j])
            pack_service_header(j, seq, stamp, expires, count, generation)
            data['service_header'] = dict(source_time=stamp, expires_at=float(expires),
                                          buffer_count=count, generation=generation)
            expected_bits = self.cfg.data_packet_bits + self.cfg.data_header_bits
            if bits != expected_bits:
                raise ValueError('Piggyback must retain the original complete DATA frame size')
            self.service_protocol_metrics['service_headers_queued'] += 1
        elif kind == 'DATA_RELEASE':
            _uint(data['sensor'], 65535, 'sensor')
            _uint(data['through_generation'], MAX_GENERATION, 'generation')
            if bits != RELEASE_BITS:
                raise ValueError('DATA_RELEASE must pay the declared 64-byte control frame')
        return super()._send(src, dst, kind, data, bits, expiry)

    def _accept_piggyback(self, delivery, previous_stamp):
        p, i = delivery.packet, delivery.receiver - 1
        payload = p.payload
        if not self._service_option('service_piggyback') or 'service_header' not in payload:
            return
        j, seq, header = int(payload['sensor']), int(payload['data_seq']), payload['service_header']
        pack_service_header(j, seq, header['source_time'], header['expires_at'],
                            header['buffer_count'], header['generation'])
        stamp, expiry = float(header['source_time']), float(header['expires_at'])
        generation, now = int(header['generation']), float(self.network.time)
        if stamp > now or p.src != self.cfg.n_auv + 1 + j:
            raise ValueError('DATA service evidence has invalid source or future timestamp')
        self.service_protocol_metrics['service_headers_arrived'] += 1
        # Expiry encodes the actual SN grant-generation timestamp. The newer
        # queue snapshot must not falsely acknowledge a later renewal request.
        grant_stamp = expiry - self.cfg.grant_ttl
        old = self.received_service_grants[i].get(j)
        if (0 <= grant_stamp <= now and expiry > now and generation > 0
                and generation >= self._service_received_generation[(i+1, j)]
                and (old is None or grant_stamp > old['source_time'])):
            self.received_service_grants[i][j] = dict(source_time=grant_stamp, expires_at=expiry)
            self._service_received_generation[(i+1, j)] = generation
            self.metrics['service_grants_received'] += 1
            self.service_protocol_metrics['piggyback_grants_received'] += 1
        if stamp < previous_stamp:
            self.service_protocol_metrics['stale_queue_headers_ignored'] += 1
            return
        # A sensor snapshot includes the packet in this DATA. Count that key
        # exactly once even on retransmission; subtract other known first-local
        # receipts after the snapshot. No remote ACK state/global truth is read.
        deducted = sum(sn == j and (receipt > stamp or data_seq == seq)
                       for (sn, data_seq), receipt in self.local_data_receipts[i].items())
        value = max(0., float(header['buffer_count']) - deducted)
        value = min(float(self.cfg.buffer_packets), value)
        self.queue_estimates[i, j] = value * self.cfg.data_packet_bits
        self.queue_stamps[i, j] = stamp
        self.local_task_reports[i][j] = (value, stamp)  # preserve originating snapshot time
        self.service_protocol_metrics['piggyback_queue_evidence_updates'] += 1

    def _arrived_release(self, delivery):
        p, c = delivery.packet, self.cfg
        j = int(p.payload['sensor'])
        generation = _uint(p.payload['through_generation'], MAX_GENERATION, 'generation')
        if not (1 <= p.src <= c.n_auv and delivery.receiver == c.n_auv + 1 + j and 0 <= j < c.n_sensors):
            self.service_protocol_metrics['invalid_releases_ignored'] += 1
            return
        key = (int(p.src), j)
        self._service_cancel_through[key] = max(self._service_cancel_through[key], generation)
        self.service_protocol_metrics['release_frames_arrived'] += 1
        active = self._service_sensor_generation.get(j)
        if active is None or active[0] != p.src or active[1] > generation:
            self.service_protocol_metrics['releases_without_matching_active_grant'] += 1
            return
        grant = self.grants.get(j)
        if grant is None or grant[0] != p.src:
            self.service_protocol_metrics['releases_without_matching_active_grant'] += 1
            return
        self.grants.pop(j)
        self._service_sensor_generation.pop(j, None)
        owner = c.n_auv + 1 + j
        queue, kept, removed = self.network._queues[owner], [], []
        for item in queue:
            packet = item.packet
            header = packet.payload.get('service_header', {})
            matches = (packet.kind == 'DATA' and packet.dst == p.src
                       and int(packet.payload.get('sensor', -1)) == j
                       and int(header.get('generation', MAX_GENERATION + 1)) <= generation)
            (removed if matches else kept).append(item)
        queue.clear(); queue.extend(kept)
        if hasattr(self.network, '_sync_flows'):
            self.network._sync_flows(owner)
        pending = self.inflight.get(j)
        if pending is not None and any(int(item.packet.payload['data_seq']) == pending[0] for item in removed):
            self.inflight.pop(j, None)  # queued application wait, not an on-air event
        self.service_protocol_metrics['grants_released'] += 1
        self.service_protocol_metrics['queued_data_copies_cancelled'] += len(removed)
        for item in removed:
            self.service_protocol_events.append(dict(time=float(self.network.time), event='paid_release_queued_data_cancel',
                sensor=j, receiver=int(p.src), generation=generation, data_seq=int(item.packet.payload['data_seq']),
                frame_seq=int(item.packet.seq)))
        # Deliberately do not edit _events, energy, transmissions, failed_hops,
        # buffers, collected, or acknowledged. Cancelled copies are not losses.

    def _deliver(self, deliveries):
        if not self._service_enabled():
            return super()._deliver(deliveries)
        c = self.cfg
        for delivery in deliveries:
            p = delivery.packet
            if p.kind == 'DATA_RELEASE':
                if self._service_option('service_release'):
                    self._arrived_release(delivery)
                continue
            if p.kind == 'DATA_REQUEST' and delivery.receiver > c.n_auv:
                j = delivery.receiver - c.n_auv - 1
                generation = _uint(p.payload.get('service_generation', 0), MAX_GENERATION, 'generation')
                key = (int(p.src), j)
                if (generation <= self._service_cancel_through[key]
                        or generation <= self._service_accepted_generation[key]):
                    self.service_protocol_metrics['stale_or_cancelled_requests_ignored'] += 1
                    continue
                previous = self._service_processing_request
                self._service_processing_request = (int(p.src), j, generation)
                try:
                    super()._deliver([delivery])
                finally:
                    self._service_processing_request = previous
                continue
            previous_stamp = None
            if p.kind == 'DATA' and 1 <= delivery.receiver <= c.n_auv:
                previous_stamp = float(self.queue_stamps[delivery.receiver-1, int(p.payload['sensor'])])
            super()._deliver([delivery])  # original DATA unique accounting and ACK exactly once
            if previous_stamp is not None:
                self._accept_piggyback(delivery, previous_stamp)
            elif p.kind == 'DATA_GRANT' and 1 <= delivery.receiver <= c.n_auv:
                i, j = delivery.receiver-1, int(p.payload['sensor'])
                grant = self.received_service_grants[i].get(j)
                if grant is not None and grant['source_time'] == p.payload['source_time']:
                    generation = _uint(p.payload.get('service_generation', 0), MAX_GENERATION, 'generation')
                    self._service_received_generation[(i+1,j)] = max(self._service_received_generation[(i+1,j)], generation)

    def _release_departed_targets(self, previous_targets):
        """Send only; this AUV cannot mutate any sensor's remote grant/queue."""
        if not self._service_option('service_release') or not getattr(self, '_task_ready', False):
            return
        for i, previous in enumerate(previous_targets):
            j = int(previous)
            if j == int(self.targets[i]):
                continue
            generation = max(self._service_request_generation[(i+1,j)],
                             self._service_received_generation[(i+1,j)])
            if generation == 0:
                continue
            self._send(i+1, self.cfg.n_auv+1+j, 'DATA_RELEASE',
                       dict(sensor=j, through_generation=generation), bits=RELEASE_BITS)
            self.service_protocol_metrics['release_frames_queued'] += 1

    def step(self, actions, topology_action=None):
        previous = self.targets.copy()
        result = super().step(actions, topology_action)
        if self._service_option('service_release'):
            self._release_departed_targets(previous)
            self.last_observations = self._observations()
            result = (self.last_observations.copy(), result[1], result[2], result[3], self._info())
        return result

    def _info(self):
        info = super()._info()
        info['service_protocol_diagnostics'] = dict(getattr(self, 'service_protocol_metrics', {}))
        return info
