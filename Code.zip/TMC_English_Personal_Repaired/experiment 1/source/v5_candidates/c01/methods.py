"""Frozen module identities for development Candidate01, not validated V5."""
from dataclasses import asdict, dataclass
import hashlib
import json


@dataclass(frozen=True)
class MethodSpec:
    method_id: str
    name: str
    use_usde: bool
    use_topology: bool
    base_method_id: str = 'full_v4'
    adapter_version: str = 'candidate01-20260917'

    def to_dict(self):
        return asdict(self)

    @property
    def fingerprint(self):
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True).encode()).hexdigest()[:16]


# Retain inherited IDs for adapter compatibility, but never reuse old fingerprints.
_METHODS = {
    'full_v4': MethodSpec('full_v4', 'Candidate01 complete topology and USDE', True, True),
    'topology_only_v4': MethodSpec('topology_only_v4', 'Candidate01 topology without USDE', False, True),
    'usde_only_v4': MethodSpec('usde_only_v4', 'Candidate01 USDE without topology', True, False),
}
METHOD_IDS = tuple(_METHODS)


def get_method(method_id):
    try:
        return _METHODS[method_id]
    except (KeyError, TypeError) as exc:
        raise ValueError(f'Unknown Candidate01 method: {method_id!r}; expected one of {METHOD_IDS}') from exc

