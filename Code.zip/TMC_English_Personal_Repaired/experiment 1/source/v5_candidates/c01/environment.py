"""Candidate 01: causal service evidence and slot-aware next-visit advice.

The physical environment is inherited unchanged. Each AUV can always request
and receive DATA without a root recommendation. The root knows only actually
delivered reports; 16 charged COORD bytes carry two compact recommendations.
This is an experimental method, NOT a claim of superiority over USDE-only.
"""
from collections import Counter
from dataclasses import asdict, dataclass, fields
import copy
import math
import struct
import numpy as np

from v4_task_20260917_r2.environment import (
    TaskV4Env as PreviousEnv, MethodOptions as PreviousOptions,
    local_fields, slow_fields, PEER_RECORD_BYTES,
)
from v4_task_20260917_r2.routing import routing_defaults
from improved.routing import RoutingOptions
from improved.environment import bounded_prediction
from .methods import get_method
from .service_protocol import ServiceProtocolMixin


ADVICE_BYTES = 16
NO_TARGET = 65535


@dataclass(frozen=True)
class MethodOptions(PreviousOptions):
    service_piggyback: bool = True
    service_release: bool = False
    slot_task_scheduler: bool = True
    task_advice: bool = True
    nominal_travel_speed: float = 1.2
    visit_packet_budget: float = 4.0
    advice_ttl_s: float = 45.0
    decision_interval_s: float = 12.0
    coordination_tolerance: float = 0.10

    def __post_init__(self):
        for field in fields(PreviousOptions):
            value = getattr(self, field.name)
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f'Invalid common method option {field.name}')
        if self.peer_reserved_priority > 1:
            raise ValueError('Reservation multiplier must be at most one')
        for name in ('service_piggyback', 'service_release', 'slot_task_scheduler', 'task_advice'):
            if type(getattr(self, name)) is not bool:
                raise ValueError(f'{name} must be boolean')
        for name in ('nominal_travel_speed', 'visit_packet_budget', 'advice_ttl_s', 'decision_interval_s'):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) <= 0:
                raise ValueError(f'{name} must be finite and positive')
        if not math.isfinite(self.coordination_tolerance) or not 0 <= self.coordination_tolerance < 1:
            raise ValueError('coordination_tolerance must be in [0,1)')
        if self.task_advice and not self.slot_task_scheduler:
            raise ValueError('Advice requires the common slot-aware scheduler')


def pack_advice(records):
    """Two fixed 8-byte records: uint16 SN, float32 queue, uint16 age ceiling."""
    if len(records) != 2:
        raise ValueError('Exactly two advice records are required')
    out = bytearray()
    for target, queue, age in records:
        if (type(target) is not int or not 0 <= target <= 65535 or
                type(age) is not int or not 0 <= age <= 65535 or
                not math.isfinite(queue) or queue < 0):
            raise ValueError('Invalid advice wire field')
        out.extend(struct.pack('<HfH', target, queue, age))
    if len(out) != ADVICE_BYTES:
        raise AssertionError('Wrong advice wire budget')
    return bytes(out)


class TaskV4Env(ServiceProtocolMixin, PreviousEnv):
    observation_schema_version = 'candidate-c01-20260917-causal-service-v1'

    def __init__(self, cfg=None, method_id='full_v4', method_options=None, routing_options=None):
        self._advice_ready = False
        super().__init__(cfg, method_id, method_options or MethodOptions(), routing_options or routing_defaults())
        # Same three module flags, independently authenticated candidate identity.
        self.method = get_method(method_id)
        if self.method_options.nominal_travel_speed > self.cfg.max_speed:
            raise ValueError('Nominal travel prediction must respect command authority')
        self.last_observations = self._observations()

    def reset(self, seed=None):
        self._advice_ready = False
        super().reset(seed)
        self.root_task_evidence = {}
        self.next_reconsider_at = np.zeros(self.cfg.n_auv)
        self.last_advice_decision = np.full(self.cfg.n_auv, -math.inf)
        self.advice_metrics = Counter()
        self._advice_ready = True
        if self.method_options.slot_task_scheduler:
            self._select_targets(force=True)
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _remember_root_report(self, payload):
        """Called only for an actual STATE delivery to USV. Never query AUVs."""
        source = payload.get('source_time', math.inf)
        if not math.isfinite(source) or not 0 <= source <= self.network.time:
            return
        for record in payload.get('task_reports', []):
            if not isinstance(record, (list, tuple)) or len(record) != 3:
                continue
            target, queue, stamp = record
            if (type(target) is not int or not 0 <= target < self.cfg.n_sensors or
                    not all(math.isfinite(v) for v in (queue, stamp)) or queue < 0 or
                    not 0 <= stamp <= source or
                    self.network.time - stamp > self.method_options.task_report_ttl_s):
                continue
            old = self.root_task_evidence.get(target)
            if old is None or stamp > old[1]:
                # It is already a received posterior. Do NOT subtract cumulative
                # collection again, nor sum reports from different AUVs.
                self.root_task_evidence[target] = (min(queue, self.cfg.buffer_packets), stamp)
                self.advice_metrics['root_queue_evidence_updates'] += 1

    def _deliver(self, deliveries):
        super()._deliver(deliveries)
        if not self._advice_ready:
            return
        for delivery in deliveries:
            if delivery.receiver == 0 and delivery.packet.kind == 'STATE':
                self._remember_root_report(delivery.packet.payload)

    def _nominal_utility(self, position, queue_packets, now):
        """Nominal bit/s per visit; a heuristic, not guaranteed task throughput.

        A first DATA service is at the next calendar slot AFTER estimated
        travel and handshake. K packets need K-1 further sensor frames, not K.
        Arrival prior and queued bits are local/received beliefs. No live SN
        buffers, channel outcomes or current truth appear in this calculation.
        """
        c, m = self.cfg, self.method_options
        distance = np.linalg.norm(self.sensor_positions - np.asarray(position), axis=1)
        travel = np.maximum(0., distance - .5 * c.collection_radius) / m.nominal_travel_speed
        frame = len(self.network.slot_owners) * c.slot_duration
        handshake = self.network.cooperative_slot_gap * 2.
        arrival = now + travel + handshake
        slots = np.array([self.network.slot_owners.index(c.n_auv + 1 + j) * c.slot_duration
                          for j in range(c.n_sensors)])
        wait = np.mod(slots - arrival, frame)
        queue = np.minimum(c.buffer_packets, np.maximum(0., queue_packets) + c.arrival_rate * (travel + handshake + wait))
        count = np.minimum(queue, m.visit_packet_budget)
        # Expected noninteger count is a fluid approximation, explicit here.
        service = wait + np.maximum(count - 1., 0.) * frame + (c.data_packet_bits + c.data_header_bits) / c.bit_rate
        total = np.maximum(c.dt, travel + handshake + service)
        return c.data_packet_bits * count / total

    def _root_recommendations(self, states):
        c, m = self.cfg, self.method_options
        records = [(NO_TARGET, 0., 0)] * c.n_auv
        original = np.full(c.n_sensors, c.initial_packets, dtype=float)
        stamps = np.zeros(c.n_sensors)
        for j, (queue, stamp) in self.root_task_evidence.items():
            if 0 <= self.time - stamp <= m.task_report_ttl_s:
                original[j], stamps[j] = queue, stamp
        forecast = np.minimum(c.buffer_packets, original + c.arrival_rate * (self.time - stamps))
        utilities, available = [], []
        current_targets = set()
        for value in states.values():
            target = value.get('target')
            if (type(target) is int and 0 <= target < c.n_sensors and
                    0 <= self.time - value['source_time'] <= c.state_ttl):
                current_targets.add(target)
        for node in range(1, c.n_auv + 1):
            payload = states.get(str(node))
            valid = payload is not None and 0 <= self.time - payload['source_time'] <= c.state_ttl
            available.append(valid)
            if not valid:
                utilities.append(np.zeros(c.n_sensors))
                continue
            position = bounded_prediction(payload, self.time, tau=m.prediction_tau_s)
            utility = self._nominal_utility(position, forecast, self.time)
            # Advice is for a NEXT visit, not permission to perform the current
            # one. Avoid predicting that either vehicle will leave a live visit
            # solely because the root recomputed a recommendation.
            for j in current_targets:
                utility[j] = 0.
            utilities.append(utility)
        chosen = [None] * c.n_auv
        if all(available):
            joint = utilities[0][:, None] + utilities[1][None, :]
            np.fill_diagonal(joint, -math.inf)
            chosen = list(np.unravel_index(np.argmax(joint), joint.shape))
        else:
            for i, valid in enumerate(available):
                if valid:
                    chosen[i] = int(np.argmax(utilities[i]))
        for i, target in enumerate(chosen):
            if target is not None and utilities[i][target] > 0:
                age = int(math.ceil(max(0., self.time - stamps[target])))
                if age <= 65535:
                    records[i] = (int(target), float(original[target]), age)
        # Round through the actual representation, not invisible float64 data.
        block = pack_advice(records)
        return [list(struct.unpack('<HfH', block[i * 8:(i + 1) * 8])) for i in range(c.n_auv)]

    def _publish_coord(self):
        if not self._advice_ready or not self.method_options.task_advice:
            return super()._publish_coord()
        self._clear_disabled_received_information()
        c = self.cfg
        if self.time - self.last_coord_sent < c.state_period - 1e-9:
            return
        states = {str(n): copy.deepcopy(d.packet.payload) for n, d in self.network.received_states.items()
                  if 1 <= n <= c.n_auv and 'position' in d.packet.payload}
        for payload in states.values():
            payload.pop('localization_time', None)
        advice = self._root_recommendations(states)
        bits = 8 * (40 + PEER_RECORD_BYTES * len(states) + ADVICE_BYTES)
        if bits > self.network.max_packet_bits:
            raise ValueError('Charged candidate COORD exceeds the physical slot')
        for i in range(c.n_auv):
            self._send(0, i + 1, 'COORD', dict(source_time=self.time,
                usv_position=self.usv_position.tolist(), states=states, next_visit_advice=advice), bits)
        self.last_coord_sent = self.time
        self.advice_metrics['recommendation_messages_created'] += c.n_auv

    def _received_advice(self, i):
        coord = self.coord_cache[i]
        m, c = self.method_options, self.cfg
        if not m.task_advice or not coord or not 0 <= self.time - coord['source_time'] <= m.advice_ttl_s:
            return None
        if coord['source_time'] <= self.last_advice_decision[i]:
            return None
        echoed_own_state = coord.get('states', {}).get(str(i + 1))
        if (not echoed_own_state or echoed_own_state.get('target') != int(self.targets[i]) or
                echoed_own_state.get('source_time', -math.inf) < self.target_since[i]):
            return None
        records = coord.get('next_visit_advice')
        if not isinstance(records, list) or len(records) != c.n_auv:
            return None
        try:
            pack_advice(records)
        except (ValueError, TypeError, struct.error):
            return None
        target, queue, age = records[i]
        if not 0 <= target < c.n_sensors:
            return None
        stamp = coord['source_time'] - age
        if not 0 <= stamp <= coord['source_time'] or self.time - stamp > m.task_report_ttl_s:
            return None
        self.last_advice_decision[i] = coord['source_time']
        # A more recent own observation wins. Imported evidence is NOT
        # re-advertised under a new local timestamp or treated as a new sensor.
        if stamp > self.queue_stamps[i, target]:
            self.queue_estimates[i, target] = min(queue, c.buffer_packets) * c.data_packet_bits
            self.queue_stamps[i, target] = stamp
            self.advice_metrics['advice_queue_evidence_updates'] += 1
        return int(target)

    def _select_targets(self, force=False):
        if not self._advice_ready or not self.method_options.slot_task_scheduler:
            return super()._select_targets(force)
        c, m = self.cfg, self.method_options
        for i in range(c.n_auv):
            self._ingest_task_reports(i)
            target = int(self.targets[i])
            elapsed = self.time - self.target_since[i]
            if not force and self.time < self.next_reconsider_at[i]:
                continue
            estimate = self._queue_forecast(i)
            distance = np.linalg.norm(self.sensor_positions - self.nav[i].position, axis=1)
            reservations = self._peer_reservations(i, distance)
            grant = self.received_service_grants[i].get(target)
            valid_grant = grant is not None and grant['expires_at'] > self.time
            empty = estimate[target] < m.queue_empty_packets * c.data_packet_bits
            conflict = target in reservations and not valid_grant
            if not (force or elapsed >= c.target_max_dwell or
                    (elapsed >= c.target_min_dwell and (empty or conflict))):
                continue
            hint = self._received_advice(i)
            estimate = self._queue_forecast(i)
            utilities = self._nominal_utility(self.nav[i].position, estimate / c.data_packet_bits, self.time)
            for j in reservations:
                utilities[j] *= m.peer_reserved_priority
            if conflict and not force:
                utilities[target] = -1.
            local_best = int(np.argmax(utilities))
            new = local_best
            if hint is not None:
                self.advice_metrics['departure_decisions_with_received_advice'] += 1
                if (hint not in reservations and (local_best != target or not valid_grant) and
                        utilities[hint] >= (1. - m.coordination_tolerance) * utilities[local_best]):
                    new = hint
                    self.advice_metrics['advice_adopted'] += 1
                    if hint != local_best:
                        self.advice_metrics['advice_changed_local_choice'] += 1
            self.advice_metrics['target_reconsiderations'] += 1
            self.next_reconsider_at[i] = self.time + m.decision_interval_s
            if new != target or force:
                if not force and conflict:
                    self.task_metrics['received_information_conflict_retargets'] += 1
                self.targets[i] = new
                self.target_since[i] = self.time
                if not force:
                    self.advice_metrics['actual_target_changes'] += 1

    def _info(self):
        info = super()._info()
        if self._advice_ready:
            info['advice_diagnostics'] = dict(self.advice_metrics)
        return info
