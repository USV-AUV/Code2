"""Exact R2 routing option type; no Candidate01 routing learner change."""
from v4_task_20260917_r2.routing import RoutingOptions

__all__ = ['RoutingOptions']

