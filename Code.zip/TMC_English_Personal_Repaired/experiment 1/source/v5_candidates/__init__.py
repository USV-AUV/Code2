"""Isolated development candidates; none is a validated V5 by its name alone."""
