"""Strict V3 module ablations; no changes to the frozen physical simulator.

Both variants retain V3 navigation fusion, service observations, bounded
prediction, direct actor commands, task/reward physics and TDMA resources.
Removing USDE removes its information from every downstream path, including
the missing-motion navigation prior and the training-only auxiliary actor loss.
It does not remove raw displacement/command observations: a policy may still
learn to infer disturbances from its permitted raw measurements.
"""
from __future__ import annotations

import numpy as np

from baselines.environment import NoDisturbanceEstimate
from improved.environment import ImprovedEnv

from .methods import get_method
from .routing import FixedStarMaintenanceNetwork


def _strip_disturbance(payload):
    """Discard disabled information, retaining source time, size and validity.

    These are already-received/published message values, never simulator truth.
    For normal fresh runs all STATE sources already contain zeros; the guard
    also prevents an imported old cache from accidentally restoring the module.
    Raw motion measurement validity/age metadata is deliberately not removed.
    """
    if not isinstance(payload, dict):
        return
    if "disturbance" in payload or "disturbance_valid" in payload:
        payload["disturbance"] = [0., 0.]
        payload["disturbance_valid"] = False
    states = payload.get("states")
    if isinstance(states, dict):
        for state in states.values():
            _strip_disturbance(state)


class AblationEnv(ImprovedEnv):
    # Exactly the same ordered local/root fields, disambiguated by MethodSpec.
    observation_schema_version = ImprovedEnv.observation_schema_version

    def __init__(self, cfg=None, method_id="topology_only_v3", method_options=None, routing_options=None):
        self.method = get_method(method_id)
        self._ablation_ready = False
        super().__init__(cfg, method_options, routing_options)

    def reset(self, seed=None):
        self._ablation_ready = False
        super().reset(seed)
        if not self.method.use_usde:
            self.usde = [NoDisturbanceEstimate(2) for _ in range(self.cfg.n_auv)]
        if not self.method.use_topology:
            self.network = FixedStarMaintenanceNetwork(self.cfg, self.seed, self.routing_options)
            self.network.application_link_filter = self._data_in_range
            self.network.on_transmit_payload = self._physical_localization
        self._ablation_ready = True
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _clear_disabled_received_information(self):
        if self.method.use_usde or not self._ablation_ready:
            return
        for cache in self.network.receive_cache.values():
            for delivery in cache.values():
                _strip_disturbance(delivery.packet.payload)
        for payload in self.coord_cache:
            _strip_disturbance(payload)

    def _observations(self):
        self._clear_disabled_received_information()
        result = super()._observations()
        if not self.method.use_usde:
            result[:, 8:10] = 0.
            result[:, 11] = 0.
        return result

    def _state_payload(self, i):
        payload = super()._state_payload(i)
        if not self.method.use_usde:
            _strip_disturbance(payload)
        return payload

    def _publish_coord(self):
        self._clear_disabled_received_information()
        return super()._publish_coord()

    def _root_states(self):
        self._clear_disabled_received_information()
        return super()._root_states()

    def _plan_usv(self):
        self._clear_disabled_received_information()
        return super()._plan_usv()

    def slow_state(self):
        self._clear_disabled_received_information()
        return super().slow_state()

    def _deliver(self, deliveries):
        result = super()._deliver(deliveries)
        self._clear_disabled_received_information()
        return result

    def step(self, actions, topology_action=None):
        if not self.method.use_topology:
            if topology_action is not None:
                if (isinstance(topology_action, (bool, np.bool_)) or
                    not isinstance(topology_action, (int, np.integer)) or int(topology_action) != 0):
                    raise ValueError("USDE-only V3 has no topology policy; only None/KEEP is allowed")
                if self.step_count % self.cfg.slow_period:
                    raise ValueError("Topology requests are only accepted on the slow clock")
            # Protocol maintenance is deterministic, not a DDQN decision and
            # never a free packet arrival. Finite leases use real CONFIG/ACK.
            topology_action = 0 if self.step_count % self.cfg.slow_period == 0 else None
        self._clear_disabled_received_information()
        # ImprovedEnv consumes the prior snapshot BEFORE the physical interval.
        # NoDisturbanceEstimate always supplies zero and initialized=False, so
        # missing navigation motion uses the known command alone. Raw motion is
        # still passed unchanged to both navigation and the disabled adapter.
        return super().step(actions, topology_action)

    def _info(self):
        info = super()._info()
        metrics = info["metrics"]
        metrics["usde_enabled"] = float(self.method.use_usde)
        metrics["topology_reconfiguration_enabled"] = float(self.method.use_topology)
        metrics["v3_strict_ablation"] = 1.
        if not self.method.use_usde:
            metrics["zero_disturbance_prior_rmse_mps"] = metrics["disturbance_rmse_mps"]
            metrics["disturbance_rmse_mps"] = None
        info["method_id"] = self.method.method_id
        info["method_fingerprint"] = self.method.fingerprint
        return info
