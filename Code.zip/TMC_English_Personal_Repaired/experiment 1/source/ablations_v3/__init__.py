"""Strict single-module ablations of the frozen full V3 method."""
