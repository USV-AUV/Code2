"""Explicit identities for strict ablations of the frozen full V3 method."""
from dataclasses import asdict, dataclass
import hashlib
import json


@dataclass(frozen=True)
class MethodSpec:
    method_id: str
    name: str
    use_usde: bool
    use_topology: bool
    base_method_id: str = "improved_full_v3"
    adapter_version: str = "strict-v3-ablation-v1"

    def to_dict(self):
        return asdict(self)

    @property
    def fingerprint(self):
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True).encode()).hexdigest()[:16]


_METHODS = {
    "topology_only_v3": MethodSpec("topology_only_v3", "V3 topology without USDE", False, True),
    "usde_only_v3": MethodSpec("usde_only_v3", "V3 USDE without topology reconfiguration", True, False),
}
METHOD_IDS = tuple(_METHODS)


def get_method(method_id):
    try:
        return _METHODS[method_id]
    except (KeyError, TypeError) as exc:
        raise ValueError(f"Unknown V3 ablation: {method_id!r}; expected one of {METHOD_IDS}") from exc
