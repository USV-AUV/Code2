"""Strict V3 ablation CUDA training and frozen evaluation; separate identities.

The current full V3 TD3/auxiliary loss and hyperparameters are reused verbatim.
The USDE-only ablation has no DDQN, optimizer, replay, or dummy topology weights.

No runtime controller: actors output final normalized speed and heading.
--steps is additional on resume; a resume always starts a NEW physical episode.
"""
from __future__ import annotations
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time
import uuid
import numpy as np
import torch

from usv_auv.config import Config
from usv_auv.deploy import environment_schema, load_checkpoint
from usv_auv.actions import action_encoding
from usv_auv.observations import observation_fields, root_observation_fields
from usv_auv.learning import LearningConfig, MaskedDoubleDQN, mlp, resolve_device, seed_all, rng_state, restore_rng
from usv_auv.train import atomic_json, atomic_save, require_finite, file_digest, store_completed_macro
from baselines.train import gpu_diagnostics, parameter_digests
from improved.environment import MethodOptions, SERVICE_FIELDS
from .environment import AblationEnv
from .methods import METHOD_IDS, get_method
from improved.routing import RoutingOptions, root_feature_names
from improved.learning import ImprovedTD3Agent, RevisionLearningOptions

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / 'runs/research_collection_v2_1m_20260909/frozen_config.json'
TRAIN_FORMAT = 'collection-v3-ablation-training-v1'
INFERENCE_FORMAT = 'collection-v3-ablation-inference-v1'


def sources():
    return {str(p.relative_to(ROOT)).replace('\\', '/'): file_digest(p)['sha256']
            for package in ('usv_auv', 'baselines', 'improved', 'ablations_v3')
            for p in sorted((ROOT / package).glob('*.py'))}


def new_output(path):
    output = Path(path).resolve()
    output.mkdir(parents=True, exist_ok=False)
    return output


def export(checkpoint):
    result = {key: value for key, value in checkpoint.items()
              if key not in ('agents', 'topology', 'rng', 'exploration_rng', 'pending_macro')}
    result['format'] = INFERENCE_FORMAT
    result['agents'] = [{'actor': a['actor']} for a in checkpoint['agents']]
    result['topology'] = ({'online': checkpoint['topology']['online']}
                          if checkpoint['topology'] is not None else None)
    return result


def save_bundle(checkpoint, output, milestone=False):
    if not milestone:
        atomic_save(checkpoint, output / 'checkpoint_latest.pt')
        atomic_save(export(checkpoint), output / 'policy_inference.pt')
        return
    import os
    import tempfile
    destination = output / 'milestones' / f"step_{checkpoint['global_step']:07d}"
    destination.parent.mkdir(exist_ok=True)
    if destination.exists():
        raise FileExistsError('Refusing to overwrite an ablation milestone')
    with tempfile.TemporaryDirectory(prefix='.stage_', dir=destination.parent) as directory:
        staging = Path(directory)
        atomic_save(checkpoint, staging / 'checkpoint.pt')
        atomic_save(export(checkpoint), staging / 'policy.pt')
        atomic_json({key: checkpoint[key] for key in ('run_id', 'global_step', 'config_fingerprint',
                    'method_id', 'method_spec', 'method_fingerprint', 'seed', 'learning_config', 'training_protocol',
                    'method_options', 'routing_options', 'revision_learning_options', 'source_hashes', 'observation_schema')}
                    | {'files': {name: file_digest(staging / name) for name in ('checkpoint.pt', 'policy.pt')}},
                    staging / 'metadata.json')
        os.rename(staging, destination)


def validate_method_identity(checkpoint, requested=None):
    method = get_method(checkpoint['method_id'])
    if requested is not None and requested != method.method_id:
        raise ValueError('Checkpoint belongs to a different ablation method')
    if checkpoint['method_spec'] != method.to_dict() or checkpoint['method_fingerprint'] != method.fingerprint:
        raise ValueError('Ablation method identity differs from its frozen specification')
    if method.use_topology != (checkpoint.get('topology') is not None):
        raise ValueError('DDQN presence differs from ablation method; no dummy topology is permitted')
    return method


def learning_config(cfg):
    """Exactly the latest full-V3 learner settings, including unused topology sizes."""
    return LearningConfig(hidden_dim=cfg.hidden_dim, gamma=cfg.gamma, tau=cfg.tau, batch_size=cfg.batch_size,
        replay_capacity=cfg.replay_size, topology_capacity=20000, topology_batch_size=32,
        actor_lr=cfg.learning_rate, critic_lr=cfg.learning_rate, topology_lr=cfg.learning_rate,
        policy_noise=cfg.policy_noise, noise_clip=cfg.noise_clip, policy_delay=cfg.policy_delay)


def training_protocol(cfg, smoke=False):
    """No phase/schedule weakening: each warmup-complete fast step updates TD3."""
    return {'td3_every_fast_step': True, 'replay_reset': False, 'smoke_overrides': smoke,
            'warmup_steps': 16 if smoke else cfg.warmup_steps, 'topology_warmup_steps': 40 if smoke else 20000,
            'topology_task_weight': .2, 'topology_age_weight': .1, 'topology_request_cost': .1}


def validate_settings(checkpoint, cfg):
    if checkpoint['environment_config'] != cfg.to_dict() or checkpoint['config_fingerprint'] != cfg.fingerprint:
        raise ValueError('Checkpoint environment/config fingerprint mismatch')
    expected = {
        'method_options': asdict(MethodOptions()), 'routing_options': asdict(RoutingOptions()),
        'learning_config': asdict(learning_config(cfg)),
        'revision_learning_options': asdict(RevisionLearningOptions(area_size=cfg.area_size,
            max_speed=cfg.max_speed, dt=cfg.dt, action_frame=cfg.action_frame)),
    }
    for key, value in expected.items():
        if checkpoint[key] != value:
            raise ValueError(f'Checkpoint {key} differs from the frozen full V3 settings')
    smoke = checkpoint['training_protocol']['smoke_overrides']
    if type(smoke) is not bool or checkpoint['training_protocol'] != training_protocol(cfg, smoke):
        raise ValueError('Checkpoint training protocol differs from full V3 schedule')


def make_environment_observer(env, info, method):
    from scripts.tmc_environment_observer import EnvironmentObserver

    class AblationEnvironmentObserver(EnvironmentObserver):
        def _snapshot(self, snapshot_info):
            if not method.use_usde and snapshot_info is not None:
                snapshot_info = {**snapshot_info, 'metrics': {key: value
                    for key, value in snapshot_info['metrics'].items() if key != 'disturbance_rmse_mps'}}
            return super()._snapshot(snapshot_info)

        def finalize(self):
            result = super().finalize()
            result['usde']['applicable'] = bool(method.use_usde)
            if not method.use_usde:
                result['usde']['reason'] = 'No USDE; zero/false ablation inputs are not estimator accuracy'
            # Both strict ablations retain the full-V3 physical now+5s planner horizon.
            result['planner_horizon_prediction']['applicable'] = True
            return result

    return AblationEnvironmentObserver(env, info)


class Policy:
    def __init__(self, checkpoint, device='cuda', method_id=None, verify=True):
        if checkpoint['format'] not in (TRAIN_FORMAT, INFERENCE_FORMAT):
            raise ValueError('Not a V3 ablation checkpoint')
        self.method = validate_method_identity(checkpoint, method_id)
        self.checkpoint = checkpoint
        if verify and checkpoint['source_hashes'] != sources():
            raise ValueError('Frozen ablation source hashes differ')
        self.cfg = Config.from_dict(checkpoint['environment_config'])
        if self.cfg.fingerprint != checkpoint['config_fingerprint']:
            raise ValueError('Config fingerprint mismatch')
        validate_settings(checkpoint, self.cfg)
        self.device = resolve_device(device)
        self.schema = checkpoint['observation_schema']
        if len(checkpoint['agents']) != self.cfg.n_auv or self.schema['n_auv'] != self.cfg.n_auv:
            raise ValueError('Checkpoint AUV count mismatch')
        expected_local = observation_fields(self.cfg.n_auv) + list(SERVICE_FIELDS)
        expected_root = root_observation_fields(self.cfg.n_auv) + list(root_feature_names(self.cfg.n_auv))
        if (self.schema['version'] != AblationEnv.observation_schema_version or
            self.schema['fields'] != expected_local or self.schema['slow_fields'] != expected_root or
            self.schema['observation_dim'] != len(expected_local) or self.schema['slow_observation_dim'] != len(expected_root) or
            self.schema['action_encoding'] != action_encoding(self.cfg.action_frame)):
            raise ValueError('Ablation checkpoint schema/action encoding mismatch')
        from itertools import product
        from usv_auv.network import AcousticNetwork
        expected_candidates = ([tuple(p) for p in product(range(self.cfg.n_auv + 1), repeat=self.cfg.n_auv)
                                if all(AcousticNetwork._valid_path(i, p) for i in range(1, self.cfg.n_auv + 1))]
                               if self.method.use_topology else [tuple(0 for _ in range(self.cfg.n_auv))])
        expected_actions = len(expected_candidates) + 1
        if (self.schema['topology_candidates'] != [list(p) for p in expected_candidates] or
                self.schema['topology_actions'] != expected_actions):
            raise ValueError('Ablation topology action schema mismatch')
        for saved in checkpoint['agents']:
            require_finite('actor weights', saved['actor'])
        if self.method.use_topology:
            require_finite('topology weights', checkpoint['topology']['online'])
        hidden = checkpoint['learning_config']['hidden_dim']
        self.actors = [mlp(self.schema['observation_dim'], 2, hidden, True).to(self.device)
                       for _ in range(self.cfg.n_auv)]
        for actor, state in zip(self.actors, checkpoint['agents']):
            actor.load_state_dict(state['actor']); actor.eval().requires_grad_(False)
        self.topology = None
        if self.method.use_topology:
            self.topology = mlp(self.schema['slow_observation_dim'], self.schema['topology_actions'], hidden).to(self.device)
            self.topology.load_state_dict(checkpoint['topology']['online'])
            self.topology.eval().requires_grad_(False)

    def make_environment(self):
        env = AblationEnv(self.cfg, self.method.method_id, MethodOptions(**self.checkpoint['method_options']),
                          RoutingOptions(**self.checkpoint['routing_options']))
        self.validate_environment(env)
        return env

    def validate_environment(self, env):
        other = getattr(env, 'method', None)
        if other is None or other.method_id != self.method.method_id or other.fingerprint != self.method.fingerprint:
            raise ValueError('Cannot bind a policy to a different ablation/full method')
        if env.cfg.to_dict() != self.cfg.to_dict() or environment_schema(env) != self.schema:
            raise ValueError('Ablation environment config/schema mismatch')

    def act(self, observations):
        values = np.asarray(observations, np.float32)
        if values.shape != (len(self.actors), self.schema['observation_dim']) or not np.isfinite(values).all():
            raise ValueError('Bad inference observations')
        with torch.inference_mode():
            return np.stack([a(torch.as_tensor(values[i], device=self.device)).cpu().numpy()
                             for i, a in enumerate(self.actors)])

    def topology_action(self, state, mask):
        state, mask = np.asarray(state, np.float32), np.asarray(mask, bool)
        if state.shape != (self.schema['slow_observation_dim'],) or not np.isfinite(state).all():
            raise ValueError('Bad slow state')
        if mask.shape != (self.schema['topology_actions'],) or not mask.any():
            raise ValueError('Bad routing mask')
        if self.topology is None:
            return None  # Fixed-star method submits no topology request.
        with torch.inference_mode():
            q = self.topology(torch.as_tensor(state, device=self.device))
            return int(q.masked_fill(~torch.as_tensor(mask, device=self.device), -torch.inf).argmax().item())


def train(args):
    method_spec = get_method(args.method)
    if Path(args.output).resolve().exists():
        raise FileExistsError('Use a NEW output directory, including for resume')
    if type(args.steps) is not int or args.steps < 1 or (args.steps > 200 and not args.allow_long_run):
        raise ValueError('Long training needs --allow-long-run')
    if args.checkpoint_every < 1 or args.log_every < 1:
        raise ValueError('Logging and checkpoints must be positive')
    device = resolve_device(args.device)
    if device.type != 'cuda':
        raise ValueError('Research training requires CUDA')
    saved = load_checkpoint(args.resume) if args.resume else None
    frozen = sources()
    if saved and (saved['format'] != TRAIN_FORMAT or saved['source_hashes'] != frozen):
        raise ValueError('Resume requires matching full ablation checkpoint/source')
    if saved:
        validate_method_identity(saved, args.method)
    cfg = Config.load(args.config)
    start_step = int(saved['global_step']) if saved else 0
    requested = list(args.milestones)
    if (len(requested) != len(set(requested)) or
        any(type(s) is not int or not start_step < s <= start_step + args.steps for s in requested)):
        raise ValueError('Milestones must be unique and within the additional training interval')
    if saved and len(saved['agents']) != cfg.n_auv:
        raise ValueError('Resume checkpoint AUV count mismatch')
    smoke = bool(getattr(args, 'smoke', False))
    if smoke and (args.steps > 200 or saved):
        raise ValueError('Smoke overrides only allowed for a fresh <=200-step run')
    if saved and cfg.to_dict() != saved['environment_config']:
        raise ValueError('Cannot change physical config on resume')
    if saved and args.seed is not None and args.seed != saved['seed']:
        raise ValueError('Cannot change the training seed on resume')
    method = MethodOptions(**saved['method_options']) if saved else MethodOptions()
    routing = RoutingOptions(**saved['routing_options']) if saved else RoutingOptions()
    options = RevisionLearningOptions(**saved['revision_learning_options']) if saved else RevisionLearningOptions(
        area_size=cfg.area_size, max_speed=cfg.max_speed, dt=cfg.dt, action_frame=cfg.action_frame)
    learning = learning_config(cfg)
    if saved and saved['learning_config'] != asdict(learning):
        raise ValueError('Resume learning configuration differs from frozen full V3 defaults')
    if saved:
        validate_settings(saved, cfg)
        if saved['training_protocol'] != training_protocol(cfg, smoke):
            raise ValueError('Cannot change training protocol on resume')
    seed = int(saved['seed']) if saved else (7 if args.seed is None else args.seed)
    seed_all(seed)
    env = AblationEnv(cfg, method_spec.method_id, method, routing)
    episode = int(saved['episode']) + 1 if saved else 0
    obs, info = env.reset(seed + episode)
    agents = [ImprovedTD3Agent(env.observation_dim, 2, learning, str(device), seed + 101 * (i + 1), options=options)
              for i in range(cfg.n_auv)]
    topology = (MaskedDoubleDQN(env.slow_observation_dim, env.network.n_actions, learning, str(device), seed + 10001)
                if method_spec.use_topology else None)
    exploration = np.random.default_rng(seed + 33333)
    if saved:
        for state in saved['agents']:
            for name in ('actor','critic','actor_target','critic_target'):
                require_finite('saved learning weights', state[name])
        if topology is not None:
            for name in ('online','target'): require_finite('saved topology weights', saved['topology'][name])
        if saved['observation_schema'] != environment_schema(env):
            raise ValueError('Resume observation schema differs from method environment')
        for agent, state in zip(agents, saved['agents']): agent.load_state_dict(state)
        if topology is not None: topology.load_state_dict(saved['topology'])
        restore_rng(saved['rng'])
        exploration.bit_generator.state = saved['exploration_rng']
    output = new_output(args.output)
    cfg.save(output / 'frozen_config.json')
    step = int(saved['global_step']) if saved else 0
    stop = step + args.steps
    run_id = saved['run_id'] if saved else str(uuid.uuid4())
    started = time.monotonic()
    previous_elapsed = saved.get('elapsed_seconds', 0.) if saved else 0.
    milestones = sorted(requested)
    manifest = dict(format=TRAIN_FORMAT, run_id=run_id, seed=seed,
                    method_id=method_spec.method_id, method_spec=method_spec.to_dict(), method_fingerprint=method_spec.fingerprint,
                    config_fingerprint=cfg.fingerprint, environment_config=cfg.to_dict(),
                    method_options=asdict(method), routing_options=asdict(routing),
                    revision_learning_options=asdict(options), learning_config=asdict(learning),
                    observation_schema=environment_schema(env), source_hashes=frozen,
                    parent_checkpoint=str(Path(args.resume).resolve()) if saved else None,
                    resume_mode='new_physical_episode_learning_resume' if saved else 'fresh',
                    training_protocol=training_protocol(cfg, smoke),
                    topology_learning_enabled=method_spec.use_topology,
                    resumed_pending_macro_discarded=bool(saved and saved.get('pending_macro') is not None),
                    device=str(device), gpu=torch.cuda.get_device_name(device), target_step=stop)
    initial_digest = parameter_digests(agents, topology)
    atomic_json(manifest, output / 'manifest.json')
    if saved and saved['training_protocol'] != manifest['training_protocol']:
        raise ValueError('Cannot change training protocol on resume')
    warmup = manifest['training_protocol']['warmup_steps']
    topology_warmup = manifest['training_protocol']['topology_warmup_steps']
    pending = None
    losses, episode_return = {}, 0.

    def payload():
        return manifest | dict(global_step=step, episode=episode,
            elapsed_seconds=previous_elapsed + time.monotonic() - started,
            agents=[a.state_dict() for a in agents], topology=topology.state_dict() if topology is not None else None,
            pending_macro=pending,
            rng=rng_state(), exploration_rng=exploration.bit_generator.state)

    def progress(status='running'):
        return dict(status=status, run_id=run_id, method_id=method_spec.method_id,
                    method_fingerprint=method_spec.fingerprint, global_step=step, target_step=stop,
                    elapsed_seconds=previous_elapsed + time.monotonic() - started,
                    td3_updates=[a.updates for a in agents], actor_updates=[a.updates // learning.policy_delay for a in agents],
                    ddqn_updates=topology.updates if topology is not None else 0,
                    topology_learning_enabled=topology is not None,
                    losses=losses, info=info)

    atomic_json(progress(), output / 'progress.json')
    try:
        with (output / 'training.jsonl').open('x', encoding='utf-8') as log:
            while step < stop:
                action_topo = None
                if topology is not None and pending is None:
                    slow, mask = env.slow_state()
                    epsilon = max(.03, .25 * math_exp(-max(0, step - 20000) / 100000))
                    action_topo = 0 if step < topology_warmup else topology.act(slow, mask, epsilon)
                    pending = dict(state=slow.copy(), mask=mask.copy(), action=action_topo, reward=0., duration=0)
                noise = max(.03, cfg.exploration_noise * (1. - min(step / 500000., 1.)))
                actions = (exploration.uniform(-1, 1, (cfg.n_auv, 2)).astype(np.float32) if step < warmup
                           else np.stack([a.act(obs[i], noise) for i, a in enumerate(agents)]))
                requests = env.network.metrics.get('config_requests', 0)
                next_obs, reward, term, trunc, info = env.step(actions.copy(), action_topo)
                require_finite('transition', [reward, *next_obs.ravel()])
                for i, agent in enumerate(agents):
                    agent.replay.add(obs[i], actions[i].copy(), reward, next_obs[i], term, trunc)
                    if step >= warmup:
                        result = agent.update(); require_finite('TD3 losses', result)
                        losses.update({f'auv_{i}_{k}': v for k, v in result.items()})
                step += 1; episode_return += reward; obs = next_obs
                if topology is not None:
                    # Central training reward uses received-state AoI and real
                    # CONFIG requests, NOT instantaneous true connectivity.
                    topo_reward = (.2 * reward - .1 * min(info['metrics']['mean_aoi_s'] / cfg.state_ttl, 3.)
                                   - .1 * (env.network.metrics.get('config_requests', 0) - requests))
                    pending['reward'] += cfg.gamma ** pending['duration'] * topo_reward
                    pending['duration'] += 1
                    if pending['duration'] == cfg.slow_period or term or trunc:
                        if store_completed_macro(pending['duration'], cfg.slow_period, term, trunc):
                            slow, mask = env.slow_state()
                            topology.replay.add(pending['state'], pending['mask'], pending['action'], pending['reward'],
                                slow, mask, pending['duration'], cfg.gamma, term, trunc)
                            if step >= topology_warmup:
                                result = topology.update(); require_finite('DDQN losses', result); losses.update(result)
                        pending = None
                if term or trunc:
                    log.write(json.dumps(dict(event='episode_end', global_step=step, episode=episode,
                        episode_return=episode_return, info=info), allow_nan=False) + '\n')
                    episode += 1; obs, _ = env.reset(seed + episode); episode_return = 0.
                if step % args.log_every == 0 or step == stop:
                    record = progress(); atomic_json(record, output / 'progress.json')
                    log.write(json.dumps(record, allow_nan=False) + '\n'); log.flush()
                    print(json.dumps({k:v for k,v in record.items() if k != 'info'}), flush=True)
                if step in milestones or step % args.checkpoint_every == 0:
                    checkpoint = payload()
                    if step in milestones: save_bundle(checkpoint, output, True)
                    if step % args.checkpoint_every == 0: save_bundle(checkpoint, output)
        if sources() != frozen: raise RuntimeError('Source changed during ablation training')
        save_bundle(payload(), output)
        summary = progress('completed') | dict(source_unchanged=True,
             gpu_diagnostics=gpu_diagnostics(agents, topology, device),
             initial_parameter_digests=initial_digest, final_parameter_digests=parameter_digests(agents, topology),
             saved_milestones=milestones, budget_semantics='same environment steps; optional DDQN changes compute, not TD3 schedule')
        atomic_json(summary, output / 'summary.json'); atomic_json(summary, output / 'progress.json')
        return summary
    except Exception as exc:
        record = progress('failed'); record['error'] = repr(exc)
        # A NaN loss must not stop failure-state publication.
        record['losses'] = {}; record['info'] = {}
        atomic_json(record, output / 'progress.json'); raise
    finally:
        env.close()


def math_exp(value):
    import math
    return math.exp(value)


def evaluate(args):
    from scripts.tmc_network_observer import NetworkObserver
    if not 1 <= args.episodes <= 30 or not 1 <= args.steps <= 1200:
        raise ValueError('Evaluation is bounded to 30 episodes of 1200 steps')
    if args.seed is None:
        raise ValueError('Evaluation requires an explicit, separately declared seed range')
    if Path(args.output).resolve().exists():
        raise FileExistsError('Evaluation requires a NEW output directory')
    checkpoint_sha = file_digest(args.checkpoint)['sha256']
    checkpoint = load_checkpoint(args.checkpoint)
    policy = Policy(checkpoint, args.device, args.method)
    env = policy.make_environment()
    output = new_output(args.output)
    seed_all(args.seed)
    records = []
    try:
        with (output / 'evaluation.jsonl').open('x', encoding='utf-8') as log:
            for episode in range(args.episodes):
                obs, info = env.reset(args.seed + episode)
                policy.validate_environment(env)
                eo, no = make_environment_observer(env, info, policy.method), NetworkObserver(env.network)
                total = 0.
                for index in range(args.steps):
                    topo = (policy.topology_action(*env.slow_state())
                            if policy.topology is not None and env.step_count % env.cfg.slow_period == 0 else None)
                    actions = policy.act(obs)
                    obs, reward, term, trunc, info = env.step(actions, topo)
                    total += reward
                    log.write(json.dumps(dict(episode=episode, seed=args.seed+episode, step=index+1, time=info['time'],
                        reward=reward, actions=actions.tolist(), topology_request=topo, terminated=term, truncated=trunc,
                        info=info, passive_environment=eo.after_step(info)), allow_nan=False) + '\n')
                    if term or trunc: break
                records.append(dict(episode=episode, seed=args.seed+episode, model_step=checkpoint['global_step'],
                    method_id=policy.method.method_id, steps=index+1, duration_s=info['time'], terminated=term, truncated=trunc,
                    evaluation_limit_reached=not(term or trunc), termination_reason=info['termination_reason'],
                    metrics_base=info['metrics'], environment=eo.finalize(), network=no.finalize(info['time']),
                    **{'return': total}))
                atomic_json(dict(status='evaluating', completed_episodes=len(records), total_episodes=args.episodes),
                            output/'progress.json')
        if sources() != checkpoint['source_hashes']:
            raise RuntimeError('Source changed during ablation evaluation')
        if file_digest(args.checkpoint)['sha256'] != checkpoint_sha:
            raise RuntimeError('Checkpoint changed during frozen evaluation')
        result = dict(status='completed', method_id=policy.method.method_id, method_spec=policy.method.to_dict(),
            method_fingerprint=policy.method.fingerprint, device=str(policy.device), tmc_metrics=True,
            training_steps=checkpoint['global_step'], checkpoint=str(Path(args.checkpoint).resolve()),
            checkpoint_sha256=checkpoint_sha, config_fingerprint=policy.cfg.fingerprint,
            environment_config=policy.cfg.to_dict(), source_hashes=sources(), episodes=records,
            scope='Frozen strict V3 ablation; all failures retained; short smoke is not performance evidence')
        atomic_json(result, output/'evaluation_summary.json')
        atomic_json(dict(status='completed', completed_episodes=len(records)), output/'progress.json')
        return {'status':'completed', 'episodes':len(records), 'output':str(output)}
    except Exception as exc:
        atomic_json(dict(status='failed', error=repr(exc), completed_episodes=len(records)), output/'progress.json')
        raise
    finally:
        env.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['train','evaluate'])
    parser.add_argument('--method', required=True, choices=METHOD_IDS)
    parser.add_argument('--verify-sources', action='store_true', help='Source verification is always enforced by this CLI')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    parser.add_argument('--steps', type=int, default=160)
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--seed', type=int, help='Training default 7; evaluation must explicitly specify its split')
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--episodes', type=int, default=1)
    parser.add_argument('--milestones', type=int, nargs='*', default=[])
    parser.add_argument('--allow-long-run', action='store_true')
    parser.add_argument('--smoke', action='store_true', help='Fresh <=200-step GPU integration check only')
    parser.add_argument('--log-every', type=int, default=1000)
    parser.add_argument('--checkpoint-every', type=int, default=10000)
    args = parser.parse_args()
    print(json.dumps(train(args) if args.mode=='train' else evaluate(args), ensure_ascii=True), flush=True)


if __name__ == '__main__': main()

