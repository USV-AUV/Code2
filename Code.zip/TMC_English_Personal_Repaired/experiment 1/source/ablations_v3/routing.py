"""Fixed-star route choice with the *same* V3 charged maintenance protocol.

The only candidate is the direct star. There is no learned topology policy.
Internally two action indices remain: KEEP and same-parent STAR maintenance;
this preserves HysteresisRoutingNetwork's renewal indexing without a dummy
DDQN. AblationEnv exposes only None/KEEP and performs KEEP on each slow tick.

Like full V3, version zero is the preinstalled star with an infinite route-TABLE
lease. This is not an always-available physical link: every packet still uses
the unchanged TDMA, propagation, packet-error, range and fault mechanisms.
Without a parent change this initial route need not generate CONFIG traffic.
We do not invent periodic configuration charges solely for the fixed baseline.
If a finite lease or uncertain transaction exists, the identical V3 report-
gated CONFIG/ACK procedure must renew/repair it, with real latency and energy.
No remote route map is updated for free and no AUV may forward another node's
packet as a relay. Direct discovery/HELLO and local replies remain enabled.
"""
import numpy as np

from improved.routing import HysteresisRoutingNetwork


class FixedStarMaintenanceNetwork(HysteresisRoutingNetwork):
    def _enumerate_topologies(self):
        return [tuple(0 for _ in range(self.n_auvs))]

    @property
    def star(self):
        return tuple(0 for _ in range(self.n_auvs))

    def request_topology(self, parents, time=None):
        if isinstance(parents, (bool, np.bool_)):
            raise ValueError("Fixed-star maintenance action must not be boolean")
        if isinstance(parents, (int, np.integer)):
            if int(parents) not in (0, 1):
                raise ValueError("Fixed-star network allows KEEP or same-parent maintenance only")
        else:
            try:
                values = tuple(parents)
            except TypeError as exc:
                raise ValueError("Invalid fixed-star maintenance request") from exc
            if values != self.star:
                raise ValueError("Fixed-star network cannot select an AUV relay")
        return super().request_topology(parents, time)

    def _install_config(self, packet, receiver):
        if tuple(packet.payload.get("parents", ())) != self.star:
            self.metrics["fixed_star_nonstar_config_dropped"] += 1
            return
        return super()._install_config(packet, receiver)

    def _enqueue(self, owner, packet, next_hop=None, routed=False):
        # Own packets and packets delivered to this AUV are not relay traffic.
        # This guard also rejects unexpected REPORT/application forwarding;
        # it does not disable a node's direct HELLO or its own acknowledgements.
        if 1 <= owner <= self.n_auvs and owner != packet.src and owner != packet.dst:
            self.metrics["fixed_star_relay_dropped"] += 1
            return
        return super()._enqueue(owner, packet, next_hop, routed)

    def _next_hop(self, owner, dst, version):
        record = self.installed_routes.get(owner, {}).get(version)
        if record is not None and tuple(record[0]) != self.star:
            self.metrics["fixed_star_nonstar_route_dropped"] += 1
            return None
        return super()._next_hop(owner, dst, version)
