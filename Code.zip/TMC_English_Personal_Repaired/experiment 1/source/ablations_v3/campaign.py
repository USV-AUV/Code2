"""Sequential V3 ablations, immutable 450k/1m bundles and fresh paired tests.

Only the two V3 ablations are trained. Reference policies and all old source
files remain frozen. A weak ablation is not screened out or automatically
retuned. Import/check/summarize do not launch training or evaluation.
"""
from __future__ import annotations

import argparse
import ctypes
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback
import uuid

from improved.campaign import (ROOT, CONFIG, BUDGETS, OLD_FULL, REVISION,
    now, read, sha, write_json, require, verify_files, pipeline_hashes,
    checkpoint_identity as legacy_identity, pid_alive)

DEFAULT_CAMPAIGN = ROOT / 'runs/ablations_v3_1m_20260910'
FULL_CAMPAIGN = ROOT / 'runs/improved_full_v3_20260910'
ABLATIONS = ('topology_only_v3', 'usde_only_v3')
EXTERNAL = ('synchronous_fim_rl', 'communication_aware_tmc')
MAIN_METHODS = (REVISION, *EXTERNAL, *ABLATIONS)
METHODS = (*MAIN_METHODS, OLD_FULL)
EVALUATION = {'seed': 9530000, 'episodes': 30, 'steps': 1200}
TRAINING = {'seed': 7, 'initial_steps': 100000, 'additional_steps': 900000,
            'final_global_step': 1000000, 'milestones': list(BUDGETS)}
PROTOCOL_FORMAT = 'collection-v3-strict-ablation-campaign-v1'


def method_identity(directory, budget, config_fp, method):
    """Validate both immutable model files, not only their path labels."""
    identity = legacy_identity(directory, budget, config_fp, method)
    if method in ABLATIONS:
        from .methods import get_method
        metadata, spec = identity['metadata'], get_method(method)
        require(metadata['method_id'] == method and metadata['method_spec'] == spec.to_dict()
                and metadata['method_fingerprint'] == spec.fingerprint, 'Ablation milestone method mismatch')
    return identity


def descriptors(campaign, protocol):
    campaign = Path(campaign).resolve()
    result = []
    for method in METHODS:
        for budget in BUDGETS:
            checkpoint = (campaign / method / 'continuation_train' / 'milestones' /
                          f'step_{budget:07d}' / 'policy.pt') if method in ABLATIONS else Path(
                              protocol['reference_models'][method][str(budget)]['checkpoint'])
            label = f'{method}_{budget:07d}'
            result.append(dict(label=label, method=method, budget=budget,
                               checkpoint=str(checkpoint), output=str(campaign / 'heldout' / label)))
    return result


def training_command(campaign, method, continuation=False):
    require(method in ABLATIONS, 'Only new ablations may train')
    directory = Path(campaign).resolve()
    command = ['-m', 'ablations_v3.workflow', 'train', '--method', method,
        '--config', str(directory / 'frozen_config.json'), '--device', 'cuda', '--seed', '7',
        '--allow-long-run', '--steps', '900000' if continuation else '100000',
        '--output', str(directory / method / ('continuation_train' if continuation else 'initial_train')),
        '--checkpoint-every', '10000', '--log-every', '1000', '--milestones']
    command += ['450000', '1000000'] if continuation else ['100000']
    if continuation:
        command += ['--resume', str(directory / method / 'initial_train/checkpoint_latest.pt')]
    return command


def evaluation_command(campaign, descriptor):
    method = descriptor['method']
    if method == OLD_FULL:
        return ['-m', 'ablations_v3.campaign', 'evaluate-old', '--campaign', str(Path(campaign).resolve()),
                '--budget', str(descriptor['budget'])]
    if method in ABLATIONS:
        prefix = ['-m', 'ablations_v3.workflow', 'evaluate', '--method', method]
    elif method == REVISION:
        prefix = ['-m', 'improved.workflow', 'evaluate']
    else:
        require(method in EXTERNAL, 'Unknown reference method')
        prefix = ['-m', 'baselines.evaluate', '--method', method, '--verify-sources', '--tmc-metrics']
    return prefix + ['--checkpoint', descriptor['checkpoint'], '--output', descriptor['output'],
        '--device', 'cuda', '--episodes', str(EVALUATION['episodes']), '--steps', str(EVALUATION['steps']),
        '--seed', str(EVALUATION['seed'])]


def prepare(campaign):
    import torch
    from improved import campaign as previous
    from improved.workflow import sources as full_sources
    from baselines.deploy import source_hashes as baseline_sources
    from usv_auv.config import Config
    from .workflow import sources
    from .methods import get_method

    campaign = Path(campaign).resolve()
    require(not campaign.exists() and campaign.parent.is_dir(), 'Require a new campaign directory')
    require(torch.cuda.is_available(), 'CUDA is required')
    probe = torch.ones(8, device='cuda', requires_grad=True)
    probe.square().sum().backward()
    require(bool(torch.isfinite(probe.grad).all()), 'CUDA gradient probe failed')
    require(shutil.disk_usage(campaign.parent).free >= 12 * 1024**3, 'Require at least 12 GiB free disk')
    previous_protocol = read(FULL_CAMPAIGN / 'protocol.json')
    previous_status = read(FULL_CAMPAIGN / 'campaign_status.json')
    require(previous_status['status'] == 'complete', 'Reference V3 campaign is incomplete')
    previous.validate_frozen(FULL_CAMPAIGN, previous_protocol, previous_status['protocol_sha256'])
    require(sha(FULL_CAMPAIGN / 'comparison/comparison.json') == previous_status['final_comparison_sha256'],
            'Reference V3 comparison changed')
    cfg = read(CONFIG)
    require(Config.from_dict(cfg).to_dict() == cfg and Config.from_dict(cfg).fingerprint == '48caa5c4f5bf9627',
            'Unexpected physical environment')
    full_train = FULL_CAMPAIGN / 'continuation_train'
    full_manifest = read(full_train / 'manifest.json')
    require(full_manifest['seed'] == 7 and full_manifest['environment_config'] == cfg,
            'V3 reference training config mismatch')
    frozen = dict(previous_protocol['protected_files'])
    references = {}
    for method in (REVISION, *EXTERNAL, OLD_FULL):
        references[method] = {}
        for budget in BUDGETS:
            directory = full_train / 'milestones' / f'step_{budget:07d}' if method == REVISION else Path(
                previous_protocol['old_models'][method][str(budget)]['checkpoint']).parent
            identity = method_identity(directory, budget, cfg_fp := Config.from_dict(cfg).fingerprint, method)
            references[method][str(budget)] = identity
            for name in ('checkpoint.pt', 'policy.pt', 'metadata.json'):
                path = directory / name
                frozen[str(path.resolve())] = sha(path)
    for path in (FULL_CAMPAIGN / 'protocol.json', FULL_CAMPAIGN / 'campaign_status.json',
                 FULL_CAMPAIGN / 'comparison/comparison.json', FULL_CAMPAIGN / 'comparison/REPORT_ZH.md',
                 full_train / 'manifest.json', full_train / 'frozen_config.json', full_train / 'summary.json',
                 ROOT / 'docs/V3_ABLATIONS_PROTOCOL_20260910.md'):
        frozen[str(path.resolve())] = sha(path)
    options = {key: full_manifest[key] for key in ('method_options', 'routing_options',
               'revision_learning_options', 'learning_config', 'training_protocol', 'observation_schema')}
    protocol = dict(format=PROTOCOL_FORMAT, campaign_id=str(uuid.uuid4()), created_at=now(),
        config_fingerprint=cfg_fp, environment_config=cfg, training=TRAINING, evaluation=EVALUATION,
        train_methods=list(ABLATIONS), main_methods=list(MAIN_METHODS), historical_methods=[OLD_FULL],
        method_specs={method: get_method(method).to_dict() for method in ABLATIONS},
        method_fingerprints={method: get_method(method).fingerprint for method in ABLATIONS},
        source_hashes=sources(), full_source_hashes=full_sources(), baseline_source_hashes=baseline_sources(),
        pipeline_source_hashes=pipeline_hashes(), protected_files=frozen, reference_models=references,
        v3_reference_options=options, reference_campaign=str(FULL_CAMPAIGN), python=sys.executable,
        gpu=torch.cuda.get_device_name(0), torch=torch.__version__, device='cuda', bootstrap_resamples=20000,
        control=dict(parallel_children=1, retry=False, autotune=False, performance_gate=False,
                     check_interval_minutes=20, all_training_before_evaluation=True,
                     resume_mode='new physical episode, preserved learning state'),
        limitations=[
            'Only one training seed; scene-paired intervals do not measure training-seed variability',
            'All failures retained; unavailable metrics are N/A, not zeros; no post-test model selection',
            'V3 ablations share TD3 settings/updates and auxiliary objective; disabling USDE removes its drift inputs everywhere',
            'Fixed star has the same preinstalled version-0 infinite route-table lease as V3; physical links can still fail',
            'Equal environment steps do not imply equal compute against external/legacy baselines; no dummy DDQN for fixed star',
            'FIM/Communication-Aware are existing common-environment adaptations, not exact original-paper replications',
            'Historical old full is not the V3 neither-module cell; this is not a complete 2x2 interaction experiment',
            '75 metric intervals are unadjusted for multiple comparisons; no presumption that the full method wins'])
    verify_files(frozen)
    campaign.mkdir()
    write_json(protocol, campaign / 'protocol.json')
    write_json(cfg, campaign / 'frozen_config.json')
    write_json(dict(status='prepared', campaign_id=protocol['campaign_id'], prepared_at=now(),
                    protocol_sha256=sha(campaign / 'protocol.json')), campaign / 'campaign_status.json')
    return dict(status='prepared', campaign=str(campaign), campaign_id=protocol['campaign_id'])


def validate_frozen(campaign, protocol, expected_protocol_sha=None):
    from .workflow import sources
    from .methods import get_method
    from improved.workflow import sources as full_sources
    from baselines.deploy import source_hashes as baseline_sources
    campaign = Path(campaign).resolve()
    if expected_protocol_sha is not None:
        require(sha(campaign / 'protocol.json') == expected_protocol_sha, 'Frozen protocol changed')
    require(protocol['format'] == PROTOCOL_FORMAT and protocol['training'] == TRAINING
            and protocol['evaluation'] == EVALUATION and protocol['train_methods'] == list(ABLATIONS)
            and protocol['main_methods'] == list(MAIN_METHODS) and protocol['historical_methods'] == [OLD_FULL],
            'Method set, budget or test scenes changed')
    require(protocol['method_specs'] == {m: get_method(m).to_dict() for m in ABLATIONS}
            and protocol['method_fingerprints'] == {m: get_method(m).fingerprint for m in ABLATIONS},
            'Ablation definition changed')
    require(sources() == protocol['source_hashes'] and full_sources() == protocol['full_source_hashes']
            and baseline_sources() == protocol['baseline_source_hashes'], 'Frozen method source changed')
    require(pipeline_hashes() == protocol['pipeline_source_hashes'], 'Passive metric pipeline changed')
    require(read(CONFIG) == read(campaign / 'frozen_config.json') == protocol['environment_config'],
            'Physical environment changed')
    verify_files(protocol['protected_files'])


def verify_training(campaign, protocol, method, continuation=False):
    require(method in ABLATIONS, 'Unknown learner')
    directory = Path(campaign) / method / ('continuation_train' if continuation else 'initial_train')
    manifest, summary = read(directory / 'manifest.json'), read(directory / 'summary.json')
    target = 1000000 if continuation else 100000
    require(summary['status'] == 'completed' and summary['global_step'] == target, 'Training incomplete')
    require(manifest['method_id'] == method and manifest['method_spec'] == protocol['method_specs'][method]
            and manifest['method_fingerprint'] == protocol['method_fingerprints'][method], 'Wrong ablation was trained')
    require(manifest['seed'] == 7 and manifest['environment_config'] == protocol['environment_config']
            and manifest['source_hashes'] == protocol['source_hashes'] and summary['source_unchanged'],
            'Training source/seed/config changed')
    reference = protocol['v3_reference_options']
    for key in ('method_options', 'routing_options', 'revision_learning_options', 'learning_config'):
        require(manifest[key] == reference[key], f'Unmatched V3 training options: {key}')
    for key, value in reference['training_protocol'].items():
        require(manifest['training_protocol'].get(key) == value, f'Unmatched V3 learning schedule: {key}')
    for key in ('version', 'fields', 'slow_fields', 'observation_dim', 'slow_observation_dim', 'action_encoding'):
        require(manifest['observation_schema'][key] == reference['observation_schema'][key],
                f'Unmatched V3 observation schema: {key}')
    expected_updates = target - reference['training_protocol']['warmup_steps']
    require(summary['td3_updates'] == [expected_updates] * protocol['environment_config']['n_auv'],
            'TD3 update budget differs from full V3')
    enabled = protocol['method_specs'][method]['use_topology']
    require(summary['ddqn_updates'] > 0 if enabled else summary['ddqn_updates'] == 0, 'Wrong DDQN update state')
    before, after = summary['initial_parameter_digests'], summary['final_parameter_digests']
    for key in ('actors', 'critics'):
        require(len(before[key]) == len(after[key]) == protocol['environment_config']['n_auv']
                and all(a != b for a, b in zip(before[key], after[key])), f'{key} did not learn')
    require(before['topology_online'] != after['topology_online'] if enabled else
            before['topology_online'] is None and after['topology_online'] is None, 'Wrong topology parameters')
    gpu = summary['gpu_diagnostics']
    expected_optimizers = 2 * protocol['environment_config']['n_auv'] + int(enabled)
    require(gpu['parameter_devices'] == ['cuda:0'] and gpu['optimizer_moment_devices'] == ['cuda:0']
            and gpu['populated_optimizers'] == gpu['optimizer_count'] == expected_optimizers,
            'CUDA parameter/optimizer verification failed')
    if continuation:
        initial = read(Path(campaign) / method / 'initial_train/manifest.json')
        require(manifest['run_id'] == initial['run_id']
                and manifest['resume_mode'] == 'new_physical_episode_learning_resume'
                and Path(manifest['parent_checkpoint']).resolve() ==
                    (Path(campaign) / method / 'initial_train/checkpoint_latest.pt').resolve(),
                'Wrong continuation lineage')
    for budget in BUDGETS if continuation else (100000,):
        identity = method_identity(directory / 'milestones' / f'step_{budget:07d}', budget,
                                   protocol['config_fingerprint'], method)
        require(identity['metadata']['source_hashes'] == protocol['source_hashes']
                and identity['metadata']['run_id'] == manifest['run_id'], 'Milestone lineage/source mismatch')
    return dict(manifest=manifest, summary=summary)


def validate_episodes(rows):
    require(len(rows) == EVALUATION['episodes'], 'Missing episodes; failures must not be removed')
    require([r['episode'] for r in rows] == list(range(EVALUATION['episodes'])), 'Episode order mismatch')
    require([r['seed'] for r in rows] == list(range(EVALUATION['seed'], EVALUATION['seed'] + EVALUATION['episodes'])),
            'Test scenarios not paired or from wrong split')


def evaluate_old(campaign, budget):
    """Evaluate frozen old full only as a historical reference."""
    from usv_auv.deploy import DeploymentPolicy, load_checkpoint
    from usv_auv.environment import CooperativeEnv
    from usv_auv.config import Config
    from usv_auv.learning import seed_all
    from scripts.tmc_environment_observer import EnvironmentObserver
    from scripts.tmc_network_observer import NetworkObserver
    campaign = Path(campaign).resolve()
    protocol, status = read(campaign / 'protocol.json'), read(campaign / 'campaign_status.json')
    validate_frozen(campaign, protocol, status['protocol_sha256'])
    descriptor = next(d for d in descriptors(campaign, protocol) if d['method'] == OLD_FULL and d['budget'] == budget)
    output, checkpoint = Path(descriptor['output']), Path(descriptor['checkpoint'])
    require(not output.exists(), 'Do not overwrite/retry an evaluation')
    saved = load_checkpoint(checkpoint)
    require(saved['global_step'] == budget and saved['environment_config'] == protocol['environment_config'],
            'Wrong historical model')
    policy = DeploymentPolicy(saved, 'cuda')
    env = CooperativeEnv(Config.from_dict(saved['environment_config']))
    policy.validate_environment(env)
    seed_all(EVALUATION['seed'])
    output.mkdir(parents=True)
    records = []
    try:
        with (output / 'evaluation.jsonl').open('x', encoding='utf-8') as log:
            for episode in range(EVALUATION['episodes']):
                seed = EVALUATION['seed'] + episode
                obs, info = env.reset(seed)
                eo, no = EnvironmentObserver(env, info), NetworkObserver(env.network)
                total = 0.
                for index in range(EVALUATION['steps']):
                    topo = policy.topology_action(*env.slow_state()) if env.step_count % env.cfg.slow_period == 0 else None
                    actions = policy.act(obs)
                    obs, reward, term, trunc, info = env.step(actions, topo)
                    total += float(reward)
                    log.write(json.dumps(dict(episode=episode, seed=seed, step=index+1, time=info['time'],
                        reward=float(reward), actions=actions.tolist(), topology_request=topo,
                        terminated=term, truncated=trunc, info=info, passive_environment=eo.after_step(info)),
                        allow_nan=False) + '\n')
                    if term or trunc:
                        break
                records.append(dict(episode=episode, seed=seed, method_id=OLD_FULL, model_step=budget,
                    steps=index+1, duration_s=info['time'], terminated=term, truncated=trunc,
                    evaluation_limit_reached=not(term or trunc), termination_reason=info['termination_reason'],
                    metrics_base=info['metrics'], environment=eo.finalize(), network=no.finalize(info['time']),
                    **{'return': total}))
                write_json(dict(status='evaluating', completed_episodes=len(records)), output / 'progress.json')
        validate_frozen(campaign, protocol, status['protocol_sha256'])
        write_json(dict(status='completed', method_id=OLD_FULL, training_steps=budget, checkpoint=str(checkpoint),
            checkpoint_sha256=sha(checkpoint), config_fingerprint=protocol['config_fingerprint'],
            source_hashes=protocol['source_hashes'], device=str(policy.device), tmc_metrics=True, episodes=records),
            output / 'evaluation_summary.json')
        write_json(dict(status='completed', completed_episodes=len(records)), output / 'progress.json')
        return dict(status='completed', output=str(output), episodes=len(records))
    except BaseException as error:
        write_json(dict(status='failed', error=repr(error), completed_episodes=len(records)), output / 'progress.json')
        raise
    finally:
        env.close()


def load_dataset(descriptor, protocol):
    from scripts.summarize_baseline_campaign import normalize_episode, summarize_rows
    output, checkpoint = Path(descriptor['output']), Path(descriptor['checkpoint'])
    result = read(output / 'evaluation_summary.json')
    method, budget = descriptor['method'], descriptor['budget']
    require(result['status'] == 'completed' and result['method_id'] == method
            and result['training_steps'] == budget and result['config_fingerprint'] == protocol['config_fingerprint'],
            'Evaluation method/budget/environment mismatch')
    require(Path(result['checkpoint']).resolve() == checkpoint.resolve(), 'Wrong evaluated checkpoint')
    identity = method_identity(checkpoint.parent, budget, protocol['config_fingerprint'], method)
    if method not in ABLATIONS:
        require(identity == protocol['reference_models'][method][str(budget)], 'Frozen reference changed')
    if method in EXTERNAL:
        require(result['source_hashes'] == protocol['baseline_source_hashes']
                and result['core_source_files_unchanged'] and result['baseline_sources_unchanged']
                and result['tmc_metrics'] and result['device'].startswith('cuda'), 'External baseline integrity failed')
        require(result['method_spec'] == identity['metadata']['method_spec']
                and result['method_fingerprint'] == identity['metadata']['method_fingerprint'], 'External method mismatch')
    else:
        require(result['checkpoint_sha256'] == identity['checkpoint_sha256'], 'Checkpoint checksum mismatch')
        expected_source = protocol['full_source_hashes'] if method == REVISION else protocol['source_hashes']
        require(result['source_hashes'] == expected_source, 'Evaluation sources mismatch')
        if method in ABLATIONS:
            require(result['method_spec'] == protocol['method_specs'][method]
                    and result['method_fingerprint'] == protocol['method_fingerprints'][method]
                    and identity['metadata']['source_hashes'] == protocol['source_hashes'], 'Ablation specification mismatch')
            require(result['device'].startswith('cuda') and result['tmc_metrics'],
                    'Ablation evaluation device/telemetry mismatch')
    validate_episodes(result['episodes'])
    rows = [normalize_episode(row, budget, method) for row in result['episodes']]
    for row in rows:
        if method in ABLATIONS:
            expected_usde = protocol['method_specs'][method]['use_usde']
            require(bool(row['metrics_base']['usde_enabled']) == expected_usde
                    and bool(row['environment']['usde']['applicable']) == expected_usde,
                    'Disabled USDE reported as an estimator')
            require(bool(row['metrics_base']['topology_reconfiguration_enabled']) ==
                    protocol['method_specs'][method]['use_topology'], 'Wrong topology metric identity')
    trace = output / 'evaluation.jsonl'
    dataset = summarize_rows(rows, trace, method)
    dataset.update(seed_order=[row['seed'] for row in rows], checkpoint_identity=identity,
        comparison_role='historical_reference' if method == OLD_FULL else 'main',
        raw_episode_metrics_base=[{k: row[k] for k in ('seed', 'duration_s', 'terminated', 'termination_reason', 'metrics_base')}
                                  for row in rows])
    files = {str(p.resolve()): sha(p) for p in (output / 'evaluation_summary.json', trace, checkpoint,
                                              checkpoint.parent / 'metadata.json')}
    return dataset, files


def paired_comparisons(datasets, resamples=20000):
    from scripts.summarize_baseline_campaign import paired_bootstrap
    from scripts.summarize_tmc_retest import selected_specs
    pairs = [(f'{method}_{budget:07d}', f'{REVISION}_{budget:07d}')
             for method in METHODS if method != REVISION for budget in BUDGETS]
    pairs += [(f'{method}_0450000', f'{method}_1000000') for method in METHODS]
    result = {}
    for left, right in pairs:
        require(datasets[left]['seed_order'] == datasets[right]['seed_order'], 'Unpaired scenarios')
        a, b = (datasets[key]['selected_values_by_paired_seed'] for key in (left, right))
        result[f'{right}_minus_{left}'] = dict(left=left, right=right,
            metrics={key: paired_bootstrap(a[key], b[key], resamples, 953091) for key, *_ in selected_specs()})
    return result


def render_report(summary):
    """Reuse registered metrics with a distinct strict-ablation context."""
    from improved.campaign import render_report as render_full
    report = render_full(summary)
    heading = "## Primary Mission and Communication Metrics"
    if heading not in report:
        raise ValueError("Primary metric table heading absent from full report")
    tables = report[report.index(heading):]
    tables = tables.replace(
        "No automatic retuning or outcome-based model selection follows failed gates.",
        "No after-the-fact performance filter or model reselection was used in this ablation comparison.")
    prefix = [
        "# Strict V3 Ablations: 450k and 1M Checkpoint Comparisons", "",
        "Status: completed. Each group uses 30 prespecified new scenario seeds (9530000–9530029); early failures remain included.",
        "Comparators: Synchronous FIM+RL, communication-aware TMC, newly trained topology-only and USDE-only variants, and the revised Full method.",
        "Historical old_full is not a strict double-module-disabled ablation; historical topology-only / USDE-only models are not merged into the primary matched comparison.",
        "Both new ablations were trained through 1M environment steps using 100k+900k continuation, without excluding models based on development-set performance.",
        "Navigation fusion, damped prediction, service observations, TD3 auxiliary loss and update cadence remain shared. The no-USDE condition has uninitialized zeroed estimation inputs, not privileged substitute measurements.",
        "USDE-only has no DDQN or relay rerouting; it retains the initialized star routes and the same physical communication faults.",
        "Full and the two external baselines use their previously frozen checkpoints in this comparison; they were not retrained.",
        "Physical conditions are shared. The actor outputs the final motion command with no fixed-time controller. N/A values are not imputed as zero.",
        *summary['limitations'], "", "## Recorded Training-Update Budgets", "",
        "| Variant | TD3 updates / AUV | DDQN updates | Training device |", "|---|---:|---:|---|",
    ]
    for method, item in summary['new_training'].items():
        prefix.append(f"| {method} | {item['td3_updates']} | {item['ddqn_updates']} | CUDA |")
    return "\n".join(prefix) + "\n\n" + tables

def summarize(campaign):
    from scripts.summarize_tmc_retest import selected_specs
    campaign = Path(campaign).resolve()
    protocol, status = read(campaign / 'protocol.json'), read(campaign / 'campaign_status.json')
    validate_frozen(campaign, protocol, status['protocol_sha256'])
    output = campaign / 'comparison'
    require(not output.exists(), 'Comparison already exists; do not overwrite or re-select')
    training = {m: verify_training(campaign, protocol, m, True)['summary'] for m in ABLATIONS}
    datasets, files = {}, {str(campaign / 'protocol.json'): sha(campaign / 'protocol.json')}
    for descriptor in descriptors(campaign, protocol):
        dataset, evidence = load_dataset(descriptor, protocol)
        datasets[descriptor['label']] = dataset
        files.update(evidence)
    result = dict(format='collection-v3-strict-ablation-comparison-v1', status='completed', split='heldout',
        campaign_id=protocol['campaign_id'], config_fingerprint=protocol['config_fingerprint'],
        training_seed=7, evaluation=EVALUATION, datasets=datasets,
        metric_definitions={key: dict(label_zh=label, unit=unit, section=section)
                            for key, label, unit, section, _ in selected_specs()},
        comparisons=paired_comparisons(datasets, protocol['bootstrap_resamples']), evidence_sha256=files,
        limitations=protocol['limitations'], new_training=training,
        main_methods=list(MAIN_METHODS), historical_methods=[OLD_FULL])
    verify_files(files)
    validate_frozen(campaign, protocol, status['protocol_sha256'])
    output.mkdir()
    write_json(result, output / 'comparison.json')
    (output / 'REPORT_ZH.md').write_text(render_report(result), encoding='utf-8')
    require(len(result['metric_definitions']) == 75 and len(result['datasets']) == 12, 'Incomplete comparison')
    return dict(status='completed', datasets=12, metrics=75, output=str(output))


def run(campaign):
    campaign = Path(campaign).resolve()
    protocol, initial = read(campaign / 'protocol.json'), read(campaign / 'campaign_status.json')
    require(initial['status'] == 'prepared', 'Campaign must be prepared and never started')
    protocol_sha = initial['protocol_sha256']
    validate_frozen(campaign, protocol, protocol_sha)
    with (campaign / 'runner_claim.json').open('x', encoding='utf-8') as stream:
        json.dump(dict(pid=os.getpid(), claimed_at=now(), protocol_sha256=protocol_sha), stream)
    status = dict(status='running', campaign_id=protocol['campaign_id'], runner_pid=os.getpid(),
                  started_at=now(), protocol_sha256=protocol_sha, completed_stages=[], child_pid=None)
    awake = os.name == 'nt' and bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))

    def publish(**values):
        status.update(values, updated_at=now())
        write_json(status, campaign / 'campaign_status.json')

    def child(label, arguments, progress):
        validate_frozen(campaign, protocol, protocol_sha)
        require(shutil.disk_usage(campaign).free >= 2 * 1024**3, 'Disk space below 2 GiB: stop safely')
        logs = campaign / 'process_logs'
        logs.mkdir(exist_ok=True)
        stdout, stderr = logs / f'{label}.stdout.log', logs / f'{label}.stderr.log'
        command = [protocol['python'], '-X', 'utf8', '-u', *arguments]
        publish(stage=label, command=command, active_progress_path=str(progress),
                active_stdout=str(stdout), active_stderr=str(stderr))
        environment = os.environ.copy()
        environment.update(PYTHONIOENCODING='utf-8', PYTHONUNBUFFERED='1')
        with stdout.open('xb') as out, stderr.open('xb') as err:
            process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err, stdin=subprocess.DEVNULL,
                env=environment, creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            publish(child_pid=process.pid)
            try:
                code = process.wait()
            except BaseException:
                process.terminate()
                process.wait(timeout=30)
                raise
        publish(child_pid=None, child_returncode=code)
        require(code == 0, f'Stage {label} failed ({code}); no implicit retry; inspect {stderr}')
        validate_frozen(campaign, protocol, protocol_sha)
        status['completed_stages'].append(label)
        publish()

    try:
        publish(prevent_idle_sleep_while_running=awake)
        for method in ABLATIONS:
            child(f'{method}_train_initial', training_command(campaign, method),
                  campaign / method / 'initial_train/progress.json')
            verify_training(campaign, protocol, method)
            from usv_auv.deploy import load_checkpoint
            latest = campaign / method / 'initial_train/checkpoint_latest.pt'
            saved = load_checkpoint(latest)
            require(saved['global_step'] == 100000 and saved['method_id'] == method
                    and saved['source_hashes'] == protocol['source_hashes']
                    and saved['environment_config'] == protocol['environment_config'], 'Bad 100k continuation checkpoint')
            del saved
            identity = {str(latest): sha(latest)}
            publish(continuation_checkpoint_identity=identity)
            verify_files(identity)
            child(f'{method}_train_continuation', training_command(campaign, method, True),
                  campaign / method / 'continuation_train/progress.json')
            verify_training(campaign, protocol, method, True)
        for descriptor in descriptors(campaign, protocol):
            child('heldout_' + descriptor['label'], evaluation_command(campaign, descriptor),
                  Path(descriptor['output']) / 'progress.json')
            result = read(Path(descriptor['output']) / 'evaluation_summary.json')
            require(result['status'] == 'completed', 'Incomplete evaluation')
            validate_episodes(result['episodes'])
        child('summarize_heldout', ['-m', 'ablations_v3.campaign', 'summarize', '--campaign', str(campaign)],
              campaign / 'comparison/progress.json')
        result = read(campaign / 'comparison/comparison.json')
        require(result['status'] == 'completed' and len(result['datasets']) == 12
                and len(result['metric_definitions']) == 75, 'Incomplete final comparison')
        verify_files(result['evidence_sha256'])
        validate_frozen(campaign, protocol, protocol_sha)
        report = campaign / 'comparison/REPORT_ZH.md'
        require(report.is_file() and report.stat().st_size > 0, 'Missing or empty final report')
        publish(status='complete', stage='complete', finished_at=now(),
                report=str(report), final_report_sha256=sha(report),
                final_comparison_sha256=sha(campaign / 'comparison/comparison.json'))
        return status
    except BaseException as error:
        publish(status='failed', error=repr(error), traceback=traceback.format_exc(), failed_at=now())
        raise
    finally:
        if awake:
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


def check(campaign):
    campaign = Path(campaign).resolve()
    status = read(campaign / 'campaign_status.json')
    path = status.get('active_progress_path')
    if path and Path(path).is_file():
        status['active_progress'] = read(path)
    status['runner_alive'] = pid_alive(status.get('runner_pid'))
    status['child_alive'] = pid_alive(status.get('child_pid'))
    status['free_disk_gib'] = shutil.disk_usage(campaign).free / 1024**3
    return status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('prepare', 'run', 'check', 'summarize', 'evaluate-old'))
    parser.add_argument('--campaign', type=Path, default=DEFAULT_CAMPAIGN)
    parser.add_argument('--budget', type=int, choices=BUDGETS, default=1000000)
    args = parser.parse_args()
    if args.mode == 'prepare': result = prepare(args.campaign)
    elif args.mode == 'run': result = run(args.campaign)
    elif args.mode == 'check': result = check(args.campaign)
    elif args.mode == 'summarize': result = summarize(args.campaign)
    else: result = evaluate_old(args.campaign, args.budget)
    print(json.dumps(result, ensure_ascii=True, allow_nan=False), flush=True)


if __name__ == '__main__':
    main()
