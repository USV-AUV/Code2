"""C04 local, bounded priority for a changed *transmitted* task intent.

No intent is remotely installed by this scheduler.  A STATE/COORD packet must
still win its ordinary application turn, have a usable local route, and use a
real metered slot.  Physical losses are not interpreted as successful receipt.
Only the transmitting owner's previously emitted payload is compared with its
current local packet.  The finite +2 bonus preserves the existing unbounded
flow-age ranks and management/rescue limits; it is not a delay guarantee.
"""
from numbers import Integral

from v6_candidates.c03.mac import (
    DynamicMacNetwork as ParentDynamicMacNetwork,
    FixedStarMacNetwork as ParentFixedStarMacNetwork,
    MacOptions, SlotLease, ChildLease, MAC_BITS,
)


INTENT_CHANGE_BONUS = 2.0


class _IntentMixin:
    def __init__(self, *args, intent_enabled=True, **kwargs):
        if type(intent_enabled) is not bool:
            raise ValueError('intent_enabled must be boolean')
        self.intent_enabled = intent_enabled
        # One map per transmitter/flow.  These are local TX facts, NOT remote
        # acknowledgements. Missing COORD peers do not erase previous facts.
        self.intent_last_transmitted = {}
        self._intent_tx_context = None
        super().__init__(*args, **kwargs)

    def _intent_signature(self, packet):
        """Task IDs only: ignore timestamps, own echo and MAC certificate pages."""
        payload = packet.payload
        if not isinstance(payload, dict):
            return ()

        def target(record):
            if not isinstance(record, dict):
                return None
            value = record.get('target')
            if (isinstance(value, bool) or not isinstance(value, Integral)
                    or not 0 <= value < self.n_nodes-self.n_auvs-1):
                return None
            return int(value)

        if packet.kind == 'STATE' and 1 <= packet.src <= self.n_auvs:
            value = target(payload)
            return () if value is None else ((int(packet.src), value),)
        if packet.kind != 'COORD' or packet.src != 0:
            return ()
        states = payload.get('states')
        if not isinstance(states, dict):
            return ()
        result = {}
        for key, record in states.items():
            if isinstance(key, bool):
                continue
            try:
                node = int(key)
            except (TypeError, ValueError, OverflowError):
                continue
            # JSON integer keys and their ordinary string spelling are valid.
            # Avoid treating fractional/alternate malformed IDs as known peers.
            if not (isinstance(key, Integral) or isinstance(key, str)
                    and str(node) == key):
                continue
            if not 1 <= node <= self.n_auvs or node == packet.dst:
                continue
            value = target(record)
            if value is not None:
                result[node] = value
        return tuple(sorted(result.items()))

    def _intent_changed(self, owner, packet):
        if not self.intent_enabled:
            return False
        current = self._intent_signature(packet)
        previous = self.intent_last_transmitted.get(self._flow(owner, packet), {})
        # A first/unknown intent gets normal service. A disappearing peer, own
        # echo removal, certificate paging and timestamp refresh are not change.
        return any(node in previous and previous[node] != value
                   for node, value in current)

    def _application_rank(self, owner, index):
        rank = super()._application_rank(owner, index)
        if (self.intent_enabled and
                self._intent_changed(owner, self._queues[owner][index].packet)):
            return (rank[0] + INTENT_CHANGE_BONUS, *rank[1:])
        return rank

    def _pop_queue(self, owner):
        item = super()._pop_queue(owner)
        context = self._intent_tx_context
        if self.intent_enabled and context is not None and context['owner'] == owner:
            context['item'] = item
        return item

    def _transmit_slot(self, owner, positions):
        if not self.intent_enabled:
            return super()._transmit_slot(owner, positions)
        previous = self._intent_tx_context
        context = {'owner': owner, 'item': None}
        self._intent_tx_context = context
        before = self.metrics['transmissions']
        try:
            result = super()._transmit_slot(owner, positions)
        finally:
            self._intent_tx_context = previous
        item = context['item']
        # A no-route pop is not a radio transmission. A failed physical hop IS
        # a paid emission, but neither this fact nor its signature implies ACK.
        if self.metrics['transmissions']-before == 1 and item is not None:
            packet = item.packet
            signature = self._intent_signature(packet)
            if signature:
                changed = self._intent_changed(owner, packet)
                facts = self.intent_last_transmitted.setdefault(self._flow(owner, packet), {})
                facts.update(signature)
                self.metrics['v6_intent_payload_transmissions'] += 1
                self.metrics['v6_intent_changed_payload_transmissions'] += int(changed)
        return result


class DynamicMacNetwork(_IntentMixin, ParentDynamicMacNetwork):
    """C03 delegated MAC plus the local changed-intent application bonus."""


class FixedStarMacNetwork(_IntentMixin, ParentFixedStarMacNetwork):
    """Exactly the same intent scheduler and paid MAC without AUV relaying."""
