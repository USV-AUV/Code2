"""C04 communication-bundle experiment: event-driven task evidence.

Original physics, autonomous DATA service, reward, and sole TD3 motion output
are inherited. There is no collision shield or simulator-truth reservation.
Only genuinely received peer intent can affect a local task choice. A missing
root reply never prevents autonomous service. This is not collision avoidance
with a safety guarantee: simultaneous unreported intents remain possible.
"""
from collections import Counter
from dataclasses import dataclass
import math
import numpy as np

from v6_candidates.c03.environment import TaskV4Env as PreviousEnv, MethodOptions as PreviousOptions
from v6_candidates.c01.environment import local_fields, slow_fields
from .methods import get_method
from .mac import DynamicMacNetwork, FixedStarMacNetwork, MacOptions


@dataclass(frozen=True)
class MethodOptions(PreviousOptions):
    mac_child_lease_frames: int = 1
    mac_child_lead_s: float = 14.4

    def __post_init__(self):
        super().__post_init__()
        if isinstance(self.mac_child_lead_s, bool) or not math.isfinite(self.mac_child_lead_s) or self.mac_child_lead_s <= 0:
            raise ValueError('mac_child_lead_s must be finite and positive')


class TaskV4Env(PreviousEnv):
    observation_schema_version = 'v6-c04-event-task-communication-local41-root90-v1'

    def __init__(self, cfg=None, method_id='full_v6', method_options=None, routing_options=None):
        self._c04_ready = False
        self._c04_method = get_method(method_id)
        options = method_options or MethodOptions(mac_enabled=self._c04_method.use_resource_mac)
        super().__init__(cfg, method_id, options, routing_options)
        self.method = self._c04_method
        self.last_observations = self._observations()

    def reset(self, seed=None):
        self._c04_ready = False
        result = super().reset(seed)
        c, m = self.cfg, self.method_options
        cls = DynamicMacNetwork if self._c04_method.use_topology else FixedStarMacNetwork
        self.network = cls(c, self.seed, routing_options=self.routing_options,
            mac_options=MacOptions(m.mac_prepare_lead_frames, m.mac_lease_frames,
                m.mac_frame_stride, m.mac_routed_auv_commits), donor_eligible=self._donor_eligible,
            intent_enabled=m.mac_enabled)
        self.network.application_link_filter = self._data_in_range
        self.network.on_transmit_payload = self._physical_localization
        self.method = self._c04_method
        self._intent_last_submitted = [None]*c.n_auv
        self._root_intent_seen = {}
        self._intent_coord_dirty = False
        self.c04_task_metrics = Counter()
        self.c04_task_events = []
        self._c04_ready = True
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _bundle_active(self):
        return self._c04_ready and self.method_options.mac_enabled

    def _send(self, src, dst, kind, payload, bits=None, expiry=None):
        result = super()._send(src, dst, kind, payload, bits, expiry)
        if self._bundle_active() and kind == 'STATE' and 1 <= src <= self.cfg.n_auv:
            # Local submission bookkeeping, deliberately NOT delivery/ACK.
            self._intent_last_submitted[src-1] = payload.get('target')
        return result

    def _publish_state(self):
        if self._bundle_active():
            c = self.cfg
            # A real target change does not wait for the next periodic sample.
            # At most one local STATE submission per dt; regular traffic still
            # supplies repeats. Both take the ordinary paid physical queue.
            for i in range(c.n_auv):
                if (self._intent_last_submitted[i] != int(self.targets[i]) and
                        self.time-self.last_state_sent[i] >= c.dt-1e-9):
                    self._send(i+1, 0, 'STATE', self._state_payload(i), c.state_packet_bits)
                    self.last_state_sent[i] = self.time
                    self.c04_task_metrics['event_state_submitted'] += 1
            if self._intent_coord_dirty:
                self._publish_coord()
        return super()._publish_state()

    def _deliver(self, deliveries):
        deliveries = list(deliveries)
        super()._deliver(deliveries)
        if not self._bundle_active():
            return
        for d in deliveries:
            if d.receiver != 0 or d.packet.kind != 'STATE':
                continue
            p, node = d.packet.payload, d.packet.src
            stamp, target = p.get('source_time', math.inf), p.get('target')
            if not 1 <= node <= self.cfg.n_auv or not 0 <= stamp <= self.network.time:
                continue
            old = self._root_intent_seen.get(node)
            if old is not None and stamp <= old[0]:
                continue
            if old is None or target != old[1]:
                self._intent_coord_dirty = True
            self._root_intent_seen[node] = (stamp, target)

    def _publish_coord(self):
        if (self._bundle_active() and self._intent_coord_dirty and
                self.time-self.last_coord_sent >= self.cfg.dt-1e-9):
            # Bypass periodic sampling, not queues, topology, slots or losses.
            # Parent preserves the complete charged payload/lease pagination.
            self.last_coord_sent = -math.inf
            super()._publish_coord()
            self._intent_coord_dirty = False
            self.c04_task_metrics['event_coord_batches_submitted'] += 1
            return
        return super()._publish_coord()

    def _peer_reservations(self, i, distances):
        if not self._bundle_active():
            return super()._peer_reservations(i, distances)
        coord = self.coord_cache[i]
        if not coord or coord['source_time'] > self.time:
            return set()
        reserved = set()
        for key, p in coord.get('states', {}).items():
            peer, target = int(key), p.get('target')
            age = self.time-p.get('source_time', math.inf)
            if (peer == i+1 or not 0 <= age <= self.cfg.state_ttl or
                    type(target) is not int or not 0 <= target < self.cfg.n_sensors):
                continue
            # Original source age and an unexpired reported service lease, not
            # the enclosing COORD timestamp, determine usable evidence.
            peer_grant = p.get('service', {}).get('grant_expires', -1.) > self.time
            own = self.received_service_grants[i].get(target)
            own_grant = own is not None and own['expires_at'] > self.time
            if not own_grant and (peer_grant or peer < i+1):
                reserved.add(target)
        return reserved

    def _select_targets(self, force=False):
        if self._bundle_active() and not force:
            c, m = self.cfg, self.method_options
            for i in range(c.n_auv):
                distance = np.linalg.norm(self.sensor_positions-self.nav[i].position, axis=1)
                reserved = self._peer_reservations(i, distance)
                old = int(self.targets[i])
                if old not in reserved:
                    continue
                # Received conflict with no own live service grant may change
                # the task immediately; it is not a post-TD3 motion override.
                self._ingest_task_reports(i)
                utility = self._nominal_utility(self.nav[i].position,
                    self._queue_forecast(i)/c.data_packet_bits, self.time)
                for target in reserved:
                    utility[target] = -math.inf
                new = int(np.argmax(utility))
                if new != old and math.isfinite(utility[new]):
                    self.targets[i] = new
                    self.target_since[i] = self.time
                    self.next_reconsider_at[i] = self.time+m.decision_interval_s
                    self.c04_task_metrics['received_conflict_retargets'] += 1
                    self.c04_task_events.append(dict(time=float(self.time), auv=i+1,
                        event='received_conflict_retarget', old_target=old, new_target=new))
        return super()._select_targets(force)

    def _mac_candidates(self):
        # Rebuild only the demand contribution, excluding a direct SN report
        # contradicted by a newer, actually received intent of that receiver.
        stale = set()
        for j, demand in self.mac_root_demands.items():
            delivery = self.network.received_states.get(demand['receiver'])
            p = delivery.packet.payload if delivery is not None else None
            if (p is not None and p.get('source_time', -1.) > demand['source_time'] and
                    p.get('target') != j and 0 <= self.network.time-p['source_time'] <= self.cfg.state_ttl):
                stale.add(j)
        candidates, protected = super()._mac_candidates()
        # A current AUV STATE for the same SN remains independent valid evidence.
        for j in stale:
            live = any(d.packet.payload.get('target') == j and
                0 <= self.network.time-d.packet.payload.get('source_time', math.inf) <= self.method_options.mac_demand_ttl_s
                for d in self.network.received_states.values())
            if not live:
                candidates = [(n, s) for n, s in candidates if n != self.cfg.n_auv+1+j]
                protected.discard(j)
        return candidates, protected

    def _child_tick(self, candidates):
        # Same C03 immutable certificate protocol. Restrict candidate pools to
        # enough *local predicted* command lead; this is not delivery certainty.
        net = self.network
        available = net.available_pool_leases
        def sufficiently_early_pools():
            result = []
            for pool in available():
                p = pool['parent']
                start = max(net.current_frame, p['start_frame'])
                start += (p['start_frame']-start) % p['frame_stride']
                first = start*net.frame_duration+p['slot_offset']*net.slot_duration
                if first <= net.time+2*net.cooperative_slot_gap:
                    first += p['frame_stride']*net.frame_duration
                if first > net.time+self.method_options.mac_child_lead_s:
                    result.append(pool)
            return result
        # Do not mutate the shared network API: the parent implementation has
        # no injection hook, so the explicit selection lives in a helper below.
        self._c04_child_tick(candidates, sufficiently_early_pools())

    def _c04_child_tick(self, candidates, eligible_pools):
        c, m, net = self.cfg, self.method_options, self.network
        all_pools = net.available_pool_leases()
        active = [x for pool in all_pools for x in pool['child_windows'] if x['end_frame'] > net.current_frame]
        if len(active) >= m.mac_child_max_active:
            return
        counts = Counter(x['borrower'] for x in active)
        sensors = [(n, score/(1+counts[n])) for n, score in candidates
                   if n > c.n_auv and counts[n] < m.mac_child_slots_per_sensor]
        if not sensors:
            return
        borrower = max(sensors, key=lambda item:(item[1], -item[0]))[0]
        own_offset = net.slot_owners.index(borrower)
        choices = []
        for pool in eligible_pools:
            p = pool['parent']
            start = max(net.current_frame, p['start_frame'])
            start += (p['start_frame']-start) % p['frame_stride']
            first = start*net.frame_duration+p['slot_offset']*net.slot_duration
            if first <= net.time+2*net.cooperative_slot_gap:
                start += p['frame_stride']
                first = start*net.frame_duration+p['slot_offset']*net.slot_duration
            if first-net.time > net.frame_duration:
                continue
            end = min(start+m.mac_child_lease_frames, p['end_frame'])
            if end <= start or any(max(start,x['start_frame']) < min(end,x['end_frame']) for x in pool['child_windows']):
                continue
            offsets = [own_offset]+[x['parent']['slot_offset'] for x in active if x['borrower'] == borrower]
            length = len(net.slot_owners)
            gap = min(min((p['slot_offset']-k)%length,(k-p['slot_offset'])%length) for k in offsets)
            score = float(p['donor'] == borrower)+gap/length-.25*(first-net.time)/net.frame_duration
            choices.append((score,p['lease_id'],start,end))
        if choices:
            _, parent, start, end = max(choices, key=lambda x:(x[0],-x[1]))
            child = net.propose_child(parent,borrower,start_frame=start,end_frame=end)
            if child is not None:
                self.mac_scheduler_metrics['child_leases_requested'] += 1
                self.mac_scheduler_events.append(dict(time=float(net.time),event='child_requested',
                    borrower=borrower,parent_id=parent,child_id=child,start_frame=start,end_frame=end,
                    demand_score=dict(candidates)[borrower]))

    def _info(self):
        info = super()._info()
        if self._c04_ready:
            info['task_intent_diagnostics'] = dict(self.c04_task_metrics)
        return info
