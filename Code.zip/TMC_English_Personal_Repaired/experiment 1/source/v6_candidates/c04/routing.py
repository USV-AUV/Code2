"""C04 keeps the C03 routing defaults; new communication behavior is explicit."""
from v6_candidates.c03.routing import RoutingOptions, routing_defaults

__all__ = ['RoutingOptions', 'routing_defaults']
