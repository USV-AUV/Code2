"""V6 candidate 02: bounded role leases and certificate paging."""
