"""V6-C02: role-bounded leases and paid round-robin certificate paging.

The original owner promises silence BEFORE acknowledging. Only an ACK actually
received at root permits COMMIT. Other nodes transmit only on locally received
COMMIT. Lost packets waste slots, never implicitly establish a lease. No global
owner table arbitrates a winner. The simulator audits independently held local
permissions and fails fast if the protocol ever admits two transmitters.

Existing synchronous TDMA clocks are assumed. Windows use integer frame indices
and half-open bounds. Alternate-frame leasing leaves every SN its original slot
at least once per two frames (72 s in the research configuration, versus 36 s
without lending). There is no early revocation or subleasing. SN borrowers
retain the five-frame maximum; USV/AUV borrowers can retain the same alternating
permissions for at most thirty frames, amortizing paid setup. Lengthening a
window does not remove the interleaved original-owner slots. This role rule is
identical across topology and fixed-star arms.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import heapq
import math
import struct

from usv_auv.network import Packet
from v4_task_20260917_r2.routing import TaskNetwork, FixedStarTaskNetwork


MAC_BITS = 512
MAC_KINDS = frozenset({'MAC_PREPARE', 'MAC_ACK', 'MAC_COMMIT'})
MAX_WINDOW_FRAMES = 30
SN_MAX_WINDOW_FRAMES = 5
COOPERATIVE_MAX_WINDOW_FRAMES = 30
MAX_FRAME_STRIDE = 5
_WIRE = struct.Struct('<Q I H H H I I B 37x')


def _integer(value, lower, upper, name):
    if type(value) is not int or not lower <= value <= upper:
        raise ValueError(f'{name} must be an integer in [{lower}, {upper}]')
    return value


@dataclass(frozen=True)
class MacOptions:
    prepare_lead_frames: int = 2
    lease_frames: int = 3
    frame_stride: int = 2
    routed_auv_commits: bool = True
    mac_control_service_s: float = 3.

    def __post_init__(self):
        _integer(self.prepare_lead_frames, 1, 5, 'prepare_lead_frames')
        _integer(self.lease_frames, 1, MAX_WINDOW_FRAMES, 'lease_frames')
        _integer(self.frame_stride, 2, MAX_FRAME_STRIDE, 'frame_stride')
        if type(self.routed_auv_commits) is not bool:
            raise ValueError('routed_auv_commits must be boolean')
        if (isinstance(self.mac_control_service_s, bool) or
                not math.isfinite(self.mac_control_service_s) or self.mac_control_service_s <= 0):
            raise ValueError('mac_control_service_s must be positive and finite')

    def to_dict(self):
        return asdict(self)


@dataclass(frozen=True)
class SlotLease:
    epoch: int
    lease_id: int
    donor: int
    borrower: int
    slot_offset: int
    start_frame: int
    end_frame: int
    frame_stride: int = 2

    def __post_init__(self):
        _integer(self.epoch, 0, 2**64-1, 'epoch')
        _integer(self.lease_id, 1, 2**32-1, 'lease_id')
        for name in ('donor', 'borrower', 'slot_offset'):
            _integer(getattr(self, name), 0, 65535, name)
        for name in ('start_frame', 'end_frame'):
            _integer(getattr(self, name), 0, 2**32-1, name)
        if not 0 < self.end_frame-self.start_frame <= MAX_WINDOW_FRAMES:
            raise ValueError('Lease window must span one to thirty frames')
        _integer(self.frame_stride, 2, MAX_FRAME_STRIDE, 'frame_stride')
        if self.donor == self.borrower:
            raise ValueError('Owner cannot lend its slot to itself')

    def active(self, frame):
        return (self.start_frame <= frame < self.end_frame and
                (frame-self.start_frame) % self.frame_stride == 0)

    def to_dict(self):
        return asdict(self)

    def wire(self):
        return _WIRE.pack(*(getattr(self, name) for name in self.__dataclass_fields__))


def _lease_conflict(left, right):
    """Also protect autonomous home slots across adjacent lease windows."""
    if left.slot_offset != right.slot_offset:
        return False
    if max(left.start_frame, right.start_frame) < min(left.end_frame, right.end_frame):
        return True
    # Alternating within EACH window is insufficient: a new odd-phase window
    # immediately after an even-phase window could silence two adjacent frames.
    return any(abs(a-b) < 2
        for a in range(left.start_frame, left.end_frame, left.frame_stride)
        for b in range(right.start_frame, right.end_frame, right.frame_stride))


class _MacMixin:
    def __init__(self, cfg, seed=0, routing_options=None, queue_options=None,
                 mac_options=None, donor_eligible=None, epoch=None):
        self.mac_options = (mac_options if isinstance(mac_options, MacOptions)
                            else MacOptions(**(mac_options or {})))
        # A simulation reset discards every in-flight frame. For a persistent
        # deployment caller MUST provide a fresh durable epoch on each reboot.
        self.mac_epoch = _integer(int(seed) & (2**64-1) if epoch is None else epoch,
                                  0, 2**64-1, 'epoch')
        self.donor_eligible = donor_eligible
        self.root_records = {}
        self._root_requests = {}
        self._mac_next_id = 0
        self._donor_promises = {}
        self._donor_watermark = {}
        self._borrower_commits = {}
        self._mac_tx_context = None
        self.mac_events = []
        super().__init__(cfg, seed, routing_options, queue_options)
        if self.max_packet_bits < MAC_BITS:
            raise ValueError('Physical slot cannot carry a 64-byte MAC control frame')
        self._donor_promises = {n: {} for n in range(self.n_auvs+1, self.n_nodes)}
        self._borrower_commits = {n: {} for n in range(self.n_nodes)}

    @property
    def frame_duration(self):
        return len(self.slot_owners) * self.slot_duration

    @property
    def current_frame(self):
        return int(math.floor((self.time + 1e-10) / self.frame_duration))

    def _mac_event(self, event, lease=None, **extra):
        self.mac_events.append(dict(time=float(self.time), event=event,
            **({'lease': lease.to_dict()} if lease is not None else {}), **extra))
        self.metrics['v6_mac_' + event] += 1

    def _validate_lease(self, value):
        if not isinstance(value, dict) or set(value) != set(SlotLease.__dataclass_fields__):
            raise ValueError('Unexpected lease wire fields')
        lease = SlotLease(**value)
        lease.wire()  # fixed 64-byte representability, no uncharged side fields
        if (lease.epoch != self.mac_epoch or not self.n_auvs < lease.donor < self.n_nodes
                or not 0 <= lease.borrower < self.n_nodes
                or not 0 <= lease.slot_offset < len(self.slot_owners)
                or self.slot_owners[lease.slot_offset] != lease.donor
                or lease.frame_stride != self.mac_options.frame_stride):
            raise ValueError('Lease epoch, ownership or node IDs are invalid')
        role_limit = (SN_MAX_WINDOW_FRAMES if lease.borrower > self.n_auvs
                      else COOPERATIVE_MAX_WINDOW_FRAMES)
        if lease.end_frame - lease.start_frame > role_limit:
            raise ValueError('Lease exceeds the public borrower-role window bound')
        return lease

    def _send_mac(self, kind, src, dst, lease):
        # A new donor promise cannot start retroactively. Its PREPARE queue
        # therefore expires at activation, not at the much later lease end.
        # This only expires protocol requests; no queued DATA is cancelled.
        deadline = lease.start_frame if kind == 'MAC_PREPARE' else lease.end_frame
        self.submit(Packet(src=src, dst=dst, kind=kind, payload=lease.to_dict(),
            created_at=float(self.time), size_bits=MAC_BITS,
            expires_at=deadline*self.frame_duration, ttl=1))
        self._mac_event(kind.lower()+'_queued', lease, src=src, dst=dst)

    def _service_interval(self, kind):
        # Shared weighted local flow-age service, NOT strict MAC priority. All
        # ordinary flow ages remain unbounded and the old bounded management
        # bursts still apply. This cannot guarantee setup before its deadline.
        if kind in {'MAC_PREPARE', 'MAC_COMMIT'}:
            return self.mac_options.mac_control_service_s
        return super()._service_interval(kind)

    def request_lease(self, donor, borrower, start_frame=None, end_frame=None,
                      slot_offset=None):
        """Root-only request based on root-known demand; no remote queue read.

        Return the root request ID, or None when root's own outstanding request
        conflicts. Donor acceptance, ACK reception and installation are later
        causal events. This method never grants a slot.
        """
        _integer(donor, self.n_auvs+1, self.n_nodes-1, 'donor')
        _integer(borrower, 0, self.n_nodes-1, 'borrower')
        if slot_offset is None:
            slot_offset = self.slot_owners.index(donor)
        start_frame = (self.current_frame + self.mac_options.prepare_lead_frames
                       if start_frame is None else start_frame)
        end_frame = (start_frame+self.mac_options.lease_frames
                     if end_frame is None else end_frame)
        lease = self._validate_lease(dict(epoch=self.mac_epoch,
            lease_id=self._mac_next_id+1, donor=donor, borrower=borrower,
            slot_offset=slot_offset, start_frame=start_frame, end_frame=end_frame,
            frame_stride=self.mac_options.frame_stride))
        if start_frame <= self.current_frame:
            raise ValueError('PREPARE must name a future frame')
        if start_frame > self.current_frame + 5:
            raise ValueError('PREPARE cannot reserve arbitrarily distant frames')
        for old in self._root_requests.values():
            if _lease_conflict(old, lease):
                self._mac_event('root_overlap_rejected', lease)
                return None
        self._mac_next_id = lease.lease_id
        self._root_requests[lease.lease_id] = lease
        self.root_records[lease.lease_id] = dict(lease=lease.to_dict(),
            requested_at=float(self.time), ack_received_at=None,
            commit_queued_at=None, status='requested')
        self._send_mac('MAC_PREPARE', 0, donor, lease)
        return lease.lease_id

    def retry_lease(self, lease_id):
        """Explicit paid retry with identical immutable content, no free ACK."""
        lease = self._root_requests.get(lease_id)
        if lease is None or self.current_frame >= lease.end_frame:
            return False
        record = self.root_records[lease_id]
        if record['ack_received_at'] is None:
            if self.current_frame >= lease.start_frame:
                return False
            self._send_mac('MAC_PREPARE', 0, lease.donor, lease)
        else:
            if lease.borrower == 0:
                return False  # ACK already installed root's local certificate.
            if self.mac_options.routed_auv_commits and lease.borrower <= self.n_auvs:
                return False  # Common periodic COORD carriers own paid retries.
            self._send_mac('MAC_COMMIT', 0, lease.borrower, lease)
        return True

    def root_coord_leases(self, receiver):
        """At most two ACK-backed root-local certificates for a paid COORD.

        Queuing a previous carrier is not proof of remote installation. Thus
        certificates remain eligible until expiry, without reading recipients'
        local commit tables. The caller must charge every repeated carrier.
        """
        if not self.mac_options.routed_auv_commits or not 1 <= receiver <= self.n_auvs:
            return []
        leases = [lease for key, lease in self._root_requests.items()
            if lease.borrower == receiver and self.current_frame < lease.end_frame
            and self.root_records[key]['ack_received_at'] is not None]
        # Only actual root-local radio transmission advances paging. Latest-
        # sample replacement can otherwise rotate away an unsent certificate.
        # Transmission is not remote receipt: all live certificates cycle.
        def priority(lease):
            last = self.root_records[lease.lease_id].get('last_coord_commit_transmitted_at')
            return (-math.inf if last is None else float(last),
                    lease.end_frame, lease.start_frame, lease.lease_id)
        leases.sort(key=priority)
        return [lease.to_dict() for lease in leases[:2]]

    def mark_coord_commits_queued(self, lease_ids):
        """Record actual local COORD enqueuing; cannot manufacture ACK facts."""
        for lease_id in dict.fromkeys(lease_ids):
            lease = self._root_requests.get(lease_id)
            record = self.root_records.get(lease_id)
            if lease is None or record is None or record['ack_received_at'] is None:
                raise ValueError('COORD certificate has no actually received donor ACK')
            present = any(q.packet.kind == 'COORD' and q.packet.src == 0
                and q.packet.dst == lease.borrower
                and q.packet.created_at == self.time
                and isinstance(q.packet.payload, dict)
                and lease.to_dict() in q.packet.payload.get('mac_leases', [])
                for q in self._queues[0])
            if not present:
                self._mac_event('coord_carrier_not_queued', lease)
                continue  # E.g. real queue overflow. No false queue-time claim.
            if record['commit_queued_at'] is None:
                record['commit_queued_at'] = float(self.time)
            record['last_commit_queued_at'] = float(self.time)
            record['status'] = 'ack_received_coord_commit_queued'
            self._mac_event('coord_commit_queued', lease)

    def _enqueue(self, owner, packet, next_hop=None, routed=False):
        if packet.kind in MAC_KINDS:
            if (routed or owner != packet.src or
                    (next_hop is not None and next_hop != packet.dst)):
                self._mac_event('illegal_relay_rejected')
                return None
        return super()._enqueue(owner, packet, next_hop, routed)

    def _pop_queue(self, owner):
        item = super()._pop_queue(owner)
        context = self._mac_tx_context
        if context is not None and context['owner'] == owner:
            context['item'] = item
        return item

    def _transmit_slot(self, owner, positions):
        previous = self._mac_tx_context
        context = {'owner': owner, 'item': None}
        self._mac_tx_context = context
        before = self.metrics['transmissions']
        try:
            result = super()._transmit_slot(owner, positions)
        finally:
            self._mac_tx_context = previous
        item = context['item']
        # Selection alone does not prove emission: e.g. no-route drops select
        # and remove a packet without sending it. Keep the physical base's
        # result and callbacks entirely unchanged; observe its actual delta.
        if owner == 0 and self.metrics['transmissions']-before == 1 and item is not None:
            packet = item.packet
            if packet.kind == 'COORD' and packet.src == 0 and isinstance(packet.payload, dict):
                for value in packet.payload.get('mac_leases', []):
                    if not isinstance(value, dict):
                        continue
                    lease_id = value.get('lease_id')
                    lease = self._root_requests.get(lease_id)
                    record = self.root_records.get(lease_id)
                    if (lease is not None and lease.to_dict() == value and record is not None
                            and record['ack_received_at'] is not None and packet.dst == lease.borrower):
                        record['last_coord_commit_transmitted_at'] = float(self.time)
                        self._mac_event('coord_commit_transmitted', lease)
        return result

    def _receive(self, packet, receiver, transmitter):
        before = len(self._outbox)
        result = super()._receive(packet, receiver, transmitter)
        if (packet.kind == 'COORD' and isinstance(packet.payload, dict)
                and 'mac_leases' in packet.payload and self._outbox[before:]):
            self._coord_commits_arrived(packet, receiver)
            # Ordinary COORD cache/outbox survive. Multi-hop source timestamps,
            # routing, reception and costs remain exclusively owned by base.
            return result
        if packet.kind not in MAC_KINDS:
            return result
        # super owns real physical reception, expiry, duplicate and hop counts.
        # An accepted ordinary application packet is the only processing gate.
        arrivals = self._outbox[before:]
        if not arrivals:
            return result
        del self._outbox[before:]
        if transmitter != packet.src or receiver != packet.dst or packet.size_bits != MAC_BITS:
            self._mac_event('invalid_frame_rejected')
            return result
        try:
            lease = self._validate_lease(packet.payload)
        except (ValueError, TypeError, struct.error):
            self._mac_event('invalid_frame_rejected')
            return result
        if self.current_frame >= lease.end_frame:
            self._mac_event('expired_frame_rejected', lease)
            return result
        if packet.kind == 'MAC_PREPARE':
            if packet.src != 0 or receiver != lease.donor:
                self._mac_event('invalid_endpoint_rejected', lease)
                return result
            self._donor_prepare(lease)
        elif packet.kind == 'MAC_ACK':
            if packet.src != lease.donor or receiver != 0:
                self._mac_event('invalid_endpoint_rejected', lease)
                return result
            self._root_ack(lease)
        else:
            if packet.src != 0 or receiver != lease.borrower:
                self._mac_event('invalid_endpoint_rejected', lease)
                return result
            self._install_local_commit(lease, receiver)
        return result

    def _install_local_commit(self, lease, receiver):
        previous = self._borrower_commits[receiver].get(lease.lease_id)
        if previous is not None and previous != lease:
            self._mac_event('inconsistent_duplicate_rejected', lease)
            return False
        # No lookup of donor promises/root ACK: an actually received root
        # certificate is this borrower's evidence, not simulator-global truth.
        self._borrower_commits[receiver][lease.lease_id] = lease
        self._mac_event('commit_received' if previous is None else 'duplicate_commit_received', lease)
        return True

    def _coord_commits_arrived(self, packet, receiver):
        payload = packet.payload
        certificates, states = payload.get('mac_leases'), payload.get('states')
        if (packet.src != 0 or packet.dst != receiver or not 1 <= receiver <= self.n_auvs
                or not isinstance(certificates, list) or not 1 <= len(certificates) <= 2
                or not isinstance(states, dict)):
            self._mac_event('invalid_coord_carrier_rejected')
            return
        charged_bits = 8*(40+112*len(states)+8+64*len(certificates))
        if packet.size_bits < charged_bits or packet.size_bits > self.max_packet_bits:
            self._mac_event('undersized_coord_carrier_rejected')
            return
        for value in certificates:
            try:
                lease = self._validate_lease(value)
            except (TypeError, ValueError, struct.error):
                self._mac_event('invalid_coord_certificate_rejected')
                continue
            if lease.borrower != receiver:
                self._mac_event('coord_borrower_mismatch_rejected', lease)
            elif self.current_frame >= lease.end_frame:
                self._mac_event('expired_coord_certificate_rejected', lease)
            elif self._install_local_commit(lease, receiver):
                self._mac_event('coord_commit_received', lease)

    def _donor_prepare(self, lease):
        promises = self._donor_promises[lease.donor]
        previous = promises.get(lease.lease_id)
        if previous is not None:
            if previous != lease:
                self._mac_event('inconsistent_duplicate_rejected', lease)
            elif self.current_frame < lease.end_frame:
                self._send_mac('MAC_ACK', lease.donor, 0, lease)
            return
        if (self.current_frame >= lease.start_frame or
                lease.lease_id <= self._donor_watermark.get(lease.donor, 0)):
            self._mac_event('stale_prepare_rejected', lease)
            return
        if any(_lease_conflict(old, lease) for old in promises.values()):
            self._mac_event('donor_overlap_rejected', lease)
            return
        # Only this original owner's local application queue is consulted.
        busy = any(q.packet.expires_at >= self.time and q.packet.kind not in MAC_KINDS
                   for q in self._queues[lease.donor])
        eligible = (not busy and (self.donor_eligible is None or
                    bool(self.donor_eligible(lease.donor, float(self.time)))))
        if not eligible:
            self._mac_event('donor_busy_rejected', lease)
            return
        promises[lease.lease_id] = lease
        self._donor_watermark[lease.donor] = lease.lease_id
        self._mac_event('silence_promised', lease)
        self._send_mac('MAC_ACK', lease.donor, 0, lease)

    def _root_ack(self, lease):
        if self._root_requests.get(lease.lease_id) != lease:
            self._mac_event('unsolicited_ack_rejected', lease)
            return
        record = self.root_records[lease.lease_id]
        if record['ack_received_at'] is not None:
            self._mac_event('duplicate_ack_received', lease)
            return
        record['ack_received_at'] = float(self.time)
        self._mac_event('ack_received', lease)
        if lease.borrower == 0:
            # No imaginary root-to-itself acoustic packet: the actual donor
            # ACK already gives this same local process the certificate.
            self._borrower_commits[0][lease.lease_id] = lease
            record['status'] = 'ack_received_local_commit'
            self._mac_event('root_local_commit', lease)
            return
        if self.mac_options.routed_auv_commits and lease.borrower <= self.n_auvs:
            record['status'] = 'awaiting_coord_carrier'
            self._mac_event('commit_waiting_coord', lease)
            return
        record['status'] = 'ack_received_commit_queued'
        record['commit_queued_at'] = float(self.time)
        # This is the only first-COMMIT creation path. No donor-table access.
        self._send_mac('MAC_COMMIT', 0, lease.borrower, lease)

    def local_authorized_owners(self, slot_index=None):
        """Audit independently held local permissions; NEVER pick a winner."""
        index = self._slot_index if slot_index is None else slot_index
        _integer(index, 0, 2**63-1, 'slot_index')
        offset, frame = index % len(self.slot_owners), index // len(self.slot_owners)
        original = self.slot_owners[offset]
        silent = any(p.slot_offset == offset and p.active(frame)
                     for p in self._donor_promises.get(original, {}).values())
        candidates = [] if silent else [original]
        for node, certificates in self._borrower_commits.items():
            if any(p.slot_offset == offset and p.active(frame) for p in certificates.values()):
                candidates.append(node)
        return tuple(candidates)

    def advance(self, t_end, positions):
        """Unchanged physical event loop, with locally authorized slot use."""
        if t_end < self.time-1e-10:
            raise ValueError('Network time cannot move backwards')
        self._outbox = []
        self._current_positions = positions
        while True:
            slot_time = self._slot_index*self.slot_duration
            event_time = self._events[0][0] if self._events else math.inf
            next_time = min(slot_time, event_time)
            if next_time > t_end+1e-10:
                break
            self._accrue_listen(next_time)
            self.time = next_time
            if event_time <= slot_time+1e-12:
                _, _, kind, data = heapq.heappop(self._events)
                if kind == 'arrival':
                    self._receive(*data)
                continue
            self._maintenance()
            owners = self.local_authorized_owners(self._slot_index)
            if len(owners) > 1:
                self._mac_event('authorization_collision', owners=list(owners), slot_index=self._slot_index)
                raise RuntimeError('V6 local MAC permissions conflict; refusing a global winner')
            original = self.slot_owners[self._slot_index % len(self.slot_owners)]
            index = self._slot_index
            self._slot_index += 1
            if not owners:
                self.metrics['slots'] += 1
                self.metrics['idle_slots'] += 1
                self.metrics['v6_mac_promised_uncommitted_slots'] += 1
                continue
            actual = owners[0]
            transmissions = self.metrics['transmissions']
            self._transmit_slot(actual, positions)
            if actual != original:
                self.metrics['v6_mac_borrowed_slot_opportunities'] += 1
                if self.metrics['transmissions'] > transmissions:
                    self.metrics['v6_mac_borrowed_slot_transmissions'] += 1
                else:
                    self.metrics['v6_mac_borrowed_idle_slots'] += 1
                self._mac_event('borrowed_slot', donor=original, borrower=actual,
                    slot_index=index, transmitted=self.metrics['transmissions'] > transmissions)
        self._accrue_listen(float(t_end))
        self.time = float(t_end)
        return list(self._outbox)

    def snapshot_metrics(self):
        result = super().snapshot_metrics()
        result['v6_mac'] = {k: int(v) for k, v in self.metrics.items() if k.startswith('v6_mac_')}
        return result


class DynamicMacNetwork(_MacMixin, TaskNetwork):
    """Topology-enabled network with the common dynamic MAC."""


class FixedStarMacNetwork(_MacMixin, FixedStarTaskNetwork):
    """Identical dynamic MAC and direct SN access; only AUV relays disabled."""
