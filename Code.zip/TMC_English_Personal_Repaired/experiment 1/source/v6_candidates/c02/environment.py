"""C02: amortized control leases and event-triggered sensor demand reporting.

The original service is never permission-gated. Only the declared resource-MAC
ablation flag differs across profiles; raw sensors, V5 common service fixes,
TD3 and physical resource budgets remain identical.
"""
from collections import Counter
from dataclasses import dataclass
import copy
import math
import numpy as np

from v6_candidates.c01.environment import (
    TaskV4Env as PreviousEnv, MethodOptions as PreviousOptions, local_fields, slow_fields,
)
from .mac import DynamicMacNetwork, FixedStarMacNetwork, MacOptions
from .methods import get_method


@dataclass(frozen=True)
class MethodOptions(PreviousOptions):
    mac_requests_per_tick: int = 1
    mac_max_leases: int = 16
    mac_max_leases_per_borrower: int = 2  # sensor borrowers
    mac_coop_leases_per_borrower: int = 4
    mac_coop_lease_frames: int = 30
    mac_demand_fallback_age_s: float = 30.
    mac_prepare_lead_frames: int = 3
    mac_sensor_prepare_lead_frames: int = 2
    mac_sensor_prediction_min_packets: float = 1.5

    def __post_init__(self):
        super().__post_init__()
        if type(self.mac_coop_leases_per_borrower) is not int or not 1 <= self.mac_coop_leases_per_borrower <= 8:
            raise ValueError('Cooperative leases per borrower must be integer [1,8]')
        if type(self.mac_coop_lease_frames) is not int or not 1 <= self.mac_coop_lease_frames <= 30:
            raise ValueError('Cooperative lease window must be integer [1,30]')
        if type(self.mac_sensor_prepare_lead_frames) is not int or not 1 <= self.mac_sensor_prepare_lead_frames <= 5:
            raise ValueError('Sensor prepare lead must be integer [1,5]')
        for key in ('mac_demand_fallback_age_s', 'mac_sensor_prediction_min_packets'):
            if isinstance(getattr(self, key), bool) or not math.isfinite(getattr(self, key)) or getattr(self, key) <= 0:
                raise ValueError(f'Invalid {key}')


class TaskV4Env(PreviousEnv):
    observation_schema_version = 'v6-c02-paid-network-bundle-local41-root90-v1'

    def __init__(self, cfg=None, method_id='full_v6', method_options=None, routing_options=None):
        spec = get_method(method_id)
        options = method_options or MethodOptions(mac_enabled=spec.use_resource_mac)
        if options.mac_enabled != spec.use_resource_mac:
            raise ValueError('Explicit MAC ablation option must match C02 method identity')
        self._c02_method = spec
        super().__init__(cfg, spec.base_method_id, options, routing_options)
        self.method = spec
        self.last_observations = self._observations()

    def reset(self, seed=None):
        super().reset(seed)
        c, m = self.cfg, self.method_options
        cls = DynamicMacNetwork if self._c02_method.use_topology else FixedStarMacNetwork
        self.network = cls(c, self.seed, routing_options=self.routing_options,
            mac_options=MacOptions(m.mac_prepare_lead_frames, m.mac_lease_frames,
                m.mac_frame_stride, m.mac_routed_auv_commits), donor_eligible=self._donor_eligible)
        self.network.application_link_filter = self._data_in_range
        self.network.on_transmit_payload = self._physical_localization
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _send(self, src, dst, kind, payload, bits=None, expiry=None):
        if (self._mac_ready and self.method_options.mac_enabled and kind == 'DATA_REQUEST'
                and 1 <= src <= self.cfg.n_auv):
            # One flag fits inside the existing 64B request, alongside SN ID,
            # visit generation and timing fields. It reports only a LOCAL need.
            # Successful coordination makes redundant direct reports unnecessary.
            payload = copy.deepcopy(payload)
            coord = self.coord_cache[src-1]
            now = self.network.time
            age = now-coord['source_time'] if coord is not None else now
            payload['request_root_mac_report'] = bool(age >= self.method_options.mac_demand_fallback_age_s)
        return super()._send(src, dst, kind, payload, bits, expiry)

    def _send_local_demand(self, delivery):
        # All MAC-enabled groups may use the original SN->root direct path.
        # It is event-triggered by the AUV's own stale coordination indication,
        # not disabled in star and not based on root's hidden knowledge.
        if delivery.packet.payload.get('request_root_mac_report') is not True:
            self.mac_scheduler_metrics['redundant_demand_reports_avoided'] += 1
            return
        return super()._send_local_demand(delivery)

    def _mac_candidates(self):
        candidates, protected = super()._mac_candidates()
        scores = dict(candidates)
        # Cooperative nodes are known hardware in the preinstalled schedule,
        # not invented remote demand. Fixed periodic STATE/COORD loads justify
        # an initial, paid control-capacity floor for every MAC-enabled arm.
        scores[0] = max(scores.get(0, 0.), 4.)
        for node in range(1, self.cfg.n_auv+1):
            scores[node] = max(scores.get(node, 0.), 3.)
        c, m, now = self.cfg, self.method_options, self.network.time
        for node, d in self.network.received_states.items():
            p = d.packet.payload
            j, stamp = p.get('target'), p.get('source_time', math.inf)
            if type(j) is not int or not 0 <= j < c.n_sensors or not 0 <= now-stamp <= m.mac_demand_ttl_s:
                continue
            queue = p.get('service', {}).get('queue_packets', 0.)
            if not math.isfinite(queue) or queue < m.mac_sensor_prediction_min_packets:
                scores.pop(c.n_auv+1+j, None)
                continue
            # Only received source-time position and public target coordinates.
            # Forecast is an approximation, never a promise of future motion.
            distance = np.linalg.norm(self.sensor_positions[j] - np.asarray(p['position'], dtype=float))
            travel = max(0., distance-c.collection_radius)/m.nominal_travel_speed
            age = now-stamp
            remaining = max(0., travel-age) + min(queue, m.visit_packet_budget)*self.network.frame_duration
            first_start = (self.network.current_frame+m.mac_sensor_prepare_lead_frames)*self.network.frame_duration
            if remaining < first_start-now:
                scores.pop(c.n_auv+1+j, None)
        return sorted(scores.items(), key=lambda kv: (-kv[1], kv[0])), protected

    def _mac_tick(self):
        if not self._mac_ready or not self.method_options.mac_enabled:
            return
        m, c, net = self.method_options, self.cfg, self.network
        if net.time+1e-9 < self.mac_next_decision:
            return
        self.mac_next_decision = net.time+m.mac_decision_interval_s
        candidates, protected = self._mac_candidates()
        active = [r['lease'] for r in net.root_records.values() if r['lease']['end_frame'] > net.current_frame]
        counts = Counter(p['borrower'] for p in active)
        used = {p['donor'] for p in active}
        for _ in range(min(m.mac_requests_per_tick, max(0, m.mac_max_leases-len(active)))):
            eligible = [(node, score/(1+counts[node])) for node, score in candidates
                        if counts[node] < (m.mac_coop_leases_per_borrower if node <= c.n_auv else m.mac_max_leases_per_borrower)]
            # Bootstrap at least two donor slots for the saturated root, then
            # one for each AUV before placing longer-horizon SN reservations.
            bootstrap = [kv for kv in eligible if kv[0] <= c.n_auv and counts[kv[0]] < (2 if kv[0] == 0 else 1)]
            if not eligible:
                break
            borrower = max(bootstrap or eligible, key=lambda kv: (kv[1], -kv[0]))[0]
            donors = [c.n_auv+1+j for j in range(c.n_sensors)
                      if j not in protected and c.n_auv+1+j not in used and c.n_auv+1+j != borrower]
            if not donors:
                break
            offsets = [net.slot_owners.index(p['donor']) for p in active if p['borrower'] == borrower]
            offsets += [k for k, node in enumerate(net.slot_owners) if node == borrower]
            length = len(net.slot_owners)
            reported_positions = [np.asarray(d.packet.payload['position'], dtype=float)
                for node, d in net.received_states.items()
                if 1 <= node <= c.n_auv and 'position' in d.packet.payload and
                0 <= net.time-d.packet.payload.get('source_time', math.inf) <= m.mac_demand_ttl_s]
            def separation(node):
                offset = net.slot_owners.index(node)
                gap = min(min((offset-v) % length, (v-offset) % length) for v in offsets)/length
                # Lending distant, currently unrequested sensors is less
                # likely to postpone the next local visit. This uses received
                # positions only; it cannot guarantee future non-use.
                distance = (min(np.linalg.norm(self.sensor_positions[node-c.n_auv-1]-p)
                                for p in reported_positions)/c.area_size if reported_positions else 0.)
                return gap + distance
            donor = max(donors, key=lambda node: (separation(node), -node))
            start = net.current_frame+(m.mac_prepare_lead_frames if borrower <= c.n_auv else m.mac_sensor_prepare_lead_frames)
            frames = m.mac_coop_lease_frames if borrower <= c.n_auv else m.mac_lease_frames
            lease_id = net.request_lease(donor, borrower, start_frame=start, end_frame=start+frames)
            used.add(donor)
            if lease_id is None:
                continue
            lease = net.root_records[lease_id]['lease']
            active.append(lease)
            counts[borrower] += 1
            self.mac_scheduler_metrics['leases_requested'] += 1
            self.mac_scheduler_events.append(dict(time=float(net.time), borrower=borrower,
                donor=donor, lease_id=lease_id, demand_score=dict(candidates)[borrower]))
