"""V6 C05: paid service-end communication without queue/in-flight cancellation."""
