"""C05 retains C04 routing; paid service-end belongs to the explicit bundle."""
from v6_candidates.c04.routing import RoutingOptions, routing_defaults

__all__ = ['RoutingOptions', 'routing_defaults']
