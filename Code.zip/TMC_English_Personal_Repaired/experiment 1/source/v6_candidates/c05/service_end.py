"""Paid service END without cancelling a single DATA copy.

Compose ``class TaskV4Env(ServiceEndMixin, C04Env)``. Only mac_enabled groups
use this module. Legacy service_release MUST remain False: that older module
removes queued DATA, whereas END here only closes a sensor-local service grant.
DATA_RELEASE uses the existing direct AUV->SN application transport, as does
DATA_REQUEST; it is not an uncharged broadcast or a newly invented relay path.

The 64-byte executable wire layout includes version/type, source/destination,
sensor/generation, sequence, source/expiry times, hop limit and route-version
space. JSON and Python dictionaries are logs, not an unlimited radio payload.
No END ACK/retry is synthesized. Loss/overflow leaves remote service unchanged.
"""
from collections import Counter, defaultdict
import copy
import math
import struct

from v5_candidates.c01.service_protocol import MAX_GENERATION, _uint


END_BITS = 512
END_VERSION = 1
END_WIRE = struct.Struct('<BBHHHHIddHI28x')


def pack_service_end(src, dst, sensor, generation, source_time, expires_at,
                     seq=0, ttl=2, route_version=None):
    """A complete fixed-width 64-byte END frame, including its envelope."""
    values = [_uint(src, 65535, 'source'), _uint(dst, 65535, 'destination'),
              _uint(sensor, 65535, 'sensor'),
              _uint(generation, MAX_GENERATION, 'generation')]
    if values[3] == 0:
        raise ValueError('END must name a positive locally known generation')
    seq = _uint(seq, 2**32-1, 'sequence')
    ttl = _uint(ttl, 65535, 'hop limit')
    route = 2**32-1 if route_version is None else _uint(route_version, 2**32-2, 'route version')
    if (isinstance(source_time, bool) or isinstance(expires_at, bool) or
            not math.isfinite(source_time) or not math.isfinite(expires_at) or
            not 0 <= source_time < expires_at):
        raise ValueError('Invalid END source/expiry timestamps')
    wire = END_WIRE.pack(END_VERSION, 1, *values, seq,
                         float(source_time), float(expires_at), ttl, route)
    if len(wire)*8 != END_BITS:
        raise AssertionError('END envelope exceeds declared frame budget')
    return wire


class ServiceEndMixin:
    """Local departure intent and causal sensor closure; never a controller."""

    def _service_end_enabled(self):
        return (getattr(self, '_service_end_ready', False) and
                getattr(self.method_options, 'mac_enabled', False))

    def reset(self, seed=None):
        self._service_end_ready = False
        self.service_end_metrics = Counter(data_cancellations=0)
        self.service_end_events = []
        self._service_end_received_through = defaultdict(int)  # each SN's arrived END
        self._service_end_local_through = defaultdict(int)  # each AUV's own departure
        result = super().reset(seed)
        if getattr(self.method_options, 'service_release', False):
            raise ValueError('C05 no-cancel END cannot enable legacy service_release')
        self._service_end_ready = True
        if self._service_end_enabled():
            self._install_service_end_tx_counter()
        return result[0], self._info()

    def _install_service_end_tx_counter(self):
        """Instance-only passive counter; selection, queues and RNG unchanged.

        A selected packet with no route is not an emission. A physical failure
        IS a paid emission. Works underneath the independent network observer.
        Static-USDE does not install either wrapper.
        """
        net = self.network
        original_pop, original_transmit = net._pop_queue, net._transmit_slot
        context = [None]

        def pop(owner):
            item = original_pop(owner)
            if context[0] is not None and context[0]['owner'] == owner:
                context[0]['item'] = item
            return item

        def transmit(owner, positions):
            previous = context[0]
            current = dict(owner=owner, item=None)
            context[0] = current
            before = net.metrics['transmissions']
            try:
                result = original_transmit(owner, positions)
            finally:
                context[0] = previous
            item = current['item']
            if (net.metrics['transmissions']-before == 1 and item is not None
                    and item.packet.kind == 'DATA_RELEASE'):
                self.service_end_metrics['end_frames_transmitted'] += 1
                self.service_end_metrics['end_tx_bits'] += item.packet.size_bits
                self.service_end_events.append(dict(time=float(net.time), event='end_transmitted',
                    source=int(item.packet.src), destination=int(item.packet.dst), seq=int(item.packet.seq)))
            return result

        net._pop_queue = pop
        net._transmit_slot = transmit

    def _departed_service_ends(self, previous_targets):
        if not self._service_end_enabled():
            return
        c = self.cfg
        for i, old in enumerate(previous_targets):
            j, owner = int(old), i+1
            if j == int(self.targets[i]):
                continue
            key = (owner, j)
            # Both maps are AUV-local history; NO SN grant/generation read.
            generation = max(self._service_request_generation[key],
                             self._service_received_generation[key])
            if generation <= self._service_end_local_through[key]:
                continue
            _uint(generation, MAX_GENERATION, 'generation')
            if generation == 0:
                continue
            now, expiry = float(self.network.time), float(self.network.time+self.cfg.state_ttl)
            dst = c.n_auv+1+j
            pack_service_end(owner, dst, j, generation, now, expiry)
            # Abandoning a local authorization is NOT knowledge of remote END
            # delivery. Even a lost/overflowed END must not resurrect it here.
            self._service_end_local_through[key] = generation
            if self._service_received_generation[key] <= generation:
                self.received_service_grants[i].pop(j, None)
            # The old pending request belongs to the locally abandoned visit.
            # Its retry clock must not suppress a genuinely new generation on
            # revisiting. This clears only the AUV's local waiting clock, never
            # the already queued request, SN state or a remote ACK timer.
            self.service_request_times[i].pop(j, None)
            payload = dict(sensor=j, through_generation=generation, end_version=END_VERSION)
            self.service_end_metrics['end_frames_submitted'] += 1
            before_seq = self.network._seq[owner]
            self._send(owner, dst, 'DATA_RELEASE', payload, END_BITS, expiry)
            # Inspect only the sender's own queue, not another node's state.
            queued = any(q.packet.kind == 'DATA_RELEASE' and q.packet.dst == dst
                and q.packet.seq > before_seq and q.packet.payload == payload
                for q in self.network._queues[owner])
            self.service_end_metrics['end_frames_queued' if queued else 'end_queue_rejected'] += 1
            self.service_end_events.append(dict(time=now, event='local_service_departure',
                auv=owner, sensor=j, through_generation=generation, queued=queued))

    def _arrived_service_end(self, delivery):
        p, c, now = delivery.packet, self.cfg, float(self.network.time)
        try:
            if (not isinstance(p.payload, dict) or
                    set(p.payload) != {'sensor', 'through_generation', 'end_version'} or
                    type(p.payload['end_version']) is not int or p.payload['end_version'] != END_VERSION):
                raise ValueError('Wrong END wire version or fields')
            j = _uint(p.payload['sensor'], c.n_sensors-1, 'sensor')
            generation = _uint(p.payload['through_generation'], MAX_GENERATION, 'generation')
            pack_service_end(p.src, p.dst, j, generation, p.created_at, p.expires_at,
                             p.seq, p.ttl, p.route_version)
            if (not 1 <= p.src <= c.n_auv or p.dst != c.n_auv+1+j
                    or delivery.receiver != p.dst or delivery.transmitter != p.src
                    or p.size_bits != END_BITS or not 0 <= p.created_at <= now < p.expires_at):
                raise ValueError('Invalid END endpoint, cost or timestamp')
        except (ValueError, TypeError, KeyError, OverflowError, struct.error):
            self.service_end_metrics['invalid_end_frames_ignored'] += 1
            return
        key = (int(p.src), j)
        self._service_end_received_through[key] = max(self._service_end_received_through[key], generation)
        self.service_end_metrics['end_frames_arrived'] += 1
        active, grant = self._service_sensor_generation.get(j), self.grants.get(j)
        matches = (active is not None and active[0] == p.src and active[1] <= generation
                   and grant is not None and grant[0] == p.src)
        if matches:
            # ONLY service admission metadata. Existing DATA copies, pending
            # ACK timers, actual bytes, radio events and all buffers survive.
            self.grants.pop(j)
            self._service_sensor_generation.pop(j, None)
            self.service_end_metrics['grants_closed'] += 1
        else:
            self.service_end_metrics['end_without_matching_grant'] += 1
        self.service_end_events.append(dict(time=now, event='service_end_arrived',
            auv=int(p.src), sensor=j, through_generation=generation, closed=bool(matches)))

    def _local_grant_snapshot(self, packet, receiver):
        if packet.kind not in {'DATA', 'DATA_GRANT'} or not 1 <= receiver <= self.cfg.n_auv:
            return None
        j = int(packet.payload['sensor'])
        key = (receiver, j)
        return (key, copy.deepcopy(self.received_service_grants[receiver-1].get(j)),
                self._service_received_generation[key])

    def _remove_abandoned_local_grant(self, packet, snapshot):
        if snapshot is None:
            return
        key, previous, previous_generation = snapshot
        ended = self._service_end_local_through[key]
        if not ended:
            return
        generation = (packet.payload.get('service_header', {}).get('generation', 0)
                      if packet.kind == 'DATA' else packet.payload.get('service_generation', 0))
        if generation > ended:
            return
        # The parent still processes late DATA, unique payloads, DATA_ACK and
        # sensor queue evidence exactly normally. Only abandoned authorization
        # is filtered; a later local visit's valid authorization is restored.
        owner, j = key
        if previous is not None and previous_generation > ended:
            self.received_service_grants[owner-1][j] = previous
        else:
            self.received_service_grants[owner-1].pop(j, None)
        self.service_end_metrics['late_abandoned_grant_evidence_ignored'] += 1

    def _deliver(self, deliveries):
        if not self._service_end_enabled():
            return super()._deliver(deliveries)
        for delivery in deliveries:
            p = delivery.packet
            if p.kind == 'DATA_RELEASE':
                self._arrived_service_end(delivery)
                continue  # NEVER reaches the legacy cancelling release path.
            if p.kind == 'DATA_REQUEST' and delivery.receiver > self.cfg.n_auv:
                j = delivery.receiver-self.cfg.n_auv-1
                try:
                    generation = _uint(p.payload.get('service_generation', 0), MAX_GENERATION, 'generation')
                    if not 1 <= p.src <= self.cfg.n_auv or p.dst != delivery.receiver or p.payload.get('sensor') != j:
                        raise ValueError('Invalid request endpoint')
                except (ValueError, TypeError, AttributeError):
                    self.service_end_metrics['invalid_end_aware_requests_ignored'] += 1
                    continue
                if generation <= self._service_end_received_through[(int(p.src), j)]:
                    self.service_end_metrics['requests_blocked_by_arrived_end'] += 1
                    continue
            snapshot = self._local_grant_snapshot(p, delivery.receiver)
            super()._deliver([delivery])
            self._remove_abandoned_local_grant(p, snapshot)

    def step(self, actions, topology_action=None):
        if not self._service_end_enabled():
            return super().step(actions, topology_action)
        previous = self.targets.copy()
        result = super().step(actions, topology_action)
        self._departed_service_ends(previous)
        self.last_observations = self._observations()
        return self.last_observations.copy(), result[1], result[2], result[3], self._info()

    def _info(self):
        info = super()._info()
        info['service_end_diagnostics'] = dict(getattr(self, 'service_end_metrics', {}))
        return info
