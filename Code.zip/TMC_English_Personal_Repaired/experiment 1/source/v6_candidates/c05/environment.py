"""C05: C04 plus a paid, generation-safe end of future service generation.

No queued DATA is deleted. No physics, actor action, reward, measurement,
bandwidth, or service endpoint is changed. The whole communication bundle is
absent from the primary static-USDE ablation.
"""
from dataclasses import dataclass

from v6_candidates.c04.environment import TaskV4Env as PreviousEnv, MethodOptions as PreviousOptions
from v6_candidates.c01.environment import local_fields, slow_fields
from .service_end import ServiceEndMixin
from .methods import get_method


@dataclass(frozen=True)
class MethodOptions(PreviousOptions):
    pass


class TaskV4Env(ServiceEndMixin, PreviousEnv):
    observation_schema_version = 'v6-c05-paid-service-end-local41-root90-v1'

    def __init__(self, cfg=None, method_id='full_v6', method_options=None, routing_options=None):
        self._c05_method = get_method(method_id)
        options = method_options or MethodOptions(mac_enabled=self._c05_method.use_resource_mac)
        super().__init__(cfg, method_id, options, routing_options)
        self.method = self._c05_method
        self.last_observations = self._observations()

    def reset(self, seed=None):
        super().reset(seed)
        self.method = self._c05_method
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()
