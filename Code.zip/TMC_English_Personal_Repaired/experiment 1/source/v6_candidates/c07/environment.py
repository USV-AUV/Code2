"""C07: received next-visit admission and local outward task selection.

These are task-choice heuristics, not a motion controller or safety guarantee.
Current-task conflict resolution remains C06 ID/grant based. New visits avoid
actually received peer service regions, irrespective of peer ID. A losing
vehicle already inside a winning peer's service region prefers nominally
outward alternative tasks; its TD3 action is never replaced or constrained.
"""
from collections import Counter
import math
import numpy as np

from v6_candidates.c04.environment import TaskV4Env as IntentEnv
from v6_candidates.c06.environment import (
    TaskV4Env as PreviousEnv, MethodOptions, local_fields, slow_fields,
)
from .methods import get_method


class TaskV4Env(PreviousEnv):
    observation_schema_version = 'v6-c07-admission-escape-local41-root90-v1'

    def __init__(self, cfg=None, method_id='full_v6', method_options=None, routing_options=None):
        self._c07_ready = False
        self._c07_method = get_method(method_id)
        super().__init__(cfg, method_id, method_options, routing_options)
        self.method = self._c07_method
        self.last_observations = self._observations()

    def reset(self, seed=None):
        self._c07_ready = False
        super().reset(seed)
        # C06 created the actual network and installed the C05 passive END
        # counter. Reuse that instance; do not invent new MAC capabilities.
        self.method = self._c07_method
        self.c07_task_metrics = Counter()
        self.c07_task_events = []
        self._c07_ready = True
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _admission_active(self):
        return self._c07_ready and self.method_options.mac_enabled

    def _received_peer_targets(self, i):
        """Target identities from this AUV's delivered COORD, not root truth."""
        coord = self.coord_cache[i]
        if not coord or not 0 <= coord.get('source_time', math.inf) <= self.time:
            return set()
        targets = set()
        for key, payload in coord.get('states', {}).items():
            peer, target = int(key), payload.get('target')
            age = self.time-payload.get('source_time', math.inf)
            if (peer != i+1 and 1 <= peer <= self.cfg.n_auv
                    and 0 <= age <= self.cfg.state_ttl
                    and type(target) is int and 0 <= target < self.cfg.n_sensors):
                targets.add(target)
        return targets

    def _admission_reservations(self, i, current_target):
        radius = 2*self.cfg.collection_radius+self.cfg.min_separation
        blocked = set()
        for target in self._received_peer_targets(i):
            distances = np.linalg.norm(self.sensor_positions-self.sensor_positions[target], axis=1)
            blocked.update(map(int, np.flatnonzero(distances <= radius)))
        # A new-visit rule must not evict the currently legitimate low-ID
        # winner. Only the original conflict-resolution mask may remove it.
        blocked.discard(current_target)
        # Keep C06's existing local live-grant protection, not a remote grant
        # query or an assumption that someone else accepted a service END.
        for target, grant in self.received_service_grants[i].items():
            if grant['expires_at'] > self.time:
                blocked.discard(target)
        return blocked

    def _outward_task_utilities(self, i, utilities, distances):
        """Filter only a losing current visit already within a winning region.

        For a nominal segment p+t(q-p), its squared distance to c has
        derivative 2(p-c).(q-p)+2t||q-p||^2. A nonnegative initial dot product
        makes that *nominal segment* non-inward. It does not constrain TD3.
        """
        winning = IntentEnv._peer_reservations(self, i, distances)
        local = self.nav[i].position
        radius = self.cfg.collection_radius+self.cfg.min_separation
        keep = np.ones(self.cfg.n_sensors, dtype=bool)
        centers = []
        for target in sorted(winning):
            radial = local-self.sensor_positions[target]
            norm2 = float(radial @ radial)
            if norm2 > radius*radius:
                continue
            if norm2 == 0.:
                self.c07_task_metrics['escape_origin_unconstrained'] += 1
                continue  # Every nonzero segment moves outward at the center.
            centers.append(target)
            keep &= (self.sensor_positions-local) @ radial >= 0.
        if not centers:
            return utilities, centers, False
        self.c07_task_metrics['escape_filter_considered'] += 1
        valid = np.isfinite(utilities)
        if not np.any(valid & keep):
            # Only the new directional filter falls back. Existing resolution
            # and admission masks stay intact; do not stop or choose -infinity.
            self.c07_task_metrics['escape_no_outward_candidate_fallback'] += 1
            return utilities, centers, True
        filtered = utilities.copy()
        filtered[~keep] = -math.inf
        self.c07_task_metrics['escape_filter_applied'] += 1
        self.c07_task_metrics['escape_direction_candidates_removed'] += int(np.sum(valid & ~keep))
        return filtered, centers, False

    def _select_targets(self, force=False):
        if not self._admission_active():
            return super()._select_targets(force)
        c, m = self.cfg, self.method_options
        for i in range(c.n_auv):
            target = int(self.targets[i])
            distance = np.linalg.norm(self.sensor_positions-self.nav[i].position, axis=1)
            priority = self._peer_reservations(i, distance)  # Unmodified C06.
            grant = self.received_service_grants[i].get(target)
            valid_grant = grant is not None and grant['expires_at'] > self.time
            conflict = target in priority and not valid_grant
            self._ingest_task_reports(i)
            if conflict and not force:
                admission = self._admission_reservations(i, target)
                blocked = priority | admission
                utilities = self._masked_task_utilities(i, blocked)
                if not np.any(np.isfinite(utilities)):
                    self.c06_task_metrics['region_no_candidate'] += 1
                    self.c07_task_metrics['admission_no_candidate'] += 1
                    continue
                utilities, centers, fallback = self._outward_task_utilities(i, utilities, distance)
                new = int(np.argmax(utilities))
                if new != target:
                    self.targets[i] = new
                    self.target_since[i] = self.time
                    self.next_reconsider_at[i] = self.time+m.decision_interval_s
                    self.c04_task_metrics['received_conflict_retargets'] += 1
                    self.c04_task_events.append(dict(time=float(self.time), auv=i+1,
                        event='received_conflict_retarget', old_target=target, new_target=new))
                    self.c06_task_metrics['region_conflict_retargets'] += 1
                    self.c06_task_events.append(dict(time=float(self.time), auv=i+1,
                        event='received_region_retarget', old_target=target, new_target=new,
                        masked_targets=sorted(blocked)))
                    self.c07_task_metrics['received_conflict_task_changes'] += 1
                    self.c07_task_events.append(dict(time=float(self.time), auv=i+1,
                        event='received_conflict_outward_task', old_target=target, new_target=new,
                        priority_mask=sorted(priority), admission_mask=sorted(admission),
                        inside_winning_centers=centers, direction_fallback=fallback))
                continue
            elapsed = self.time-self.target_since[i]
            if not force and self.time < self.next_reconsider_at[i]:
                continue
            estimate = self._queue_forecast(i)
            empty = estimate[target] < m.queue_empty_packets*c.data_packet_bits
            if not (force or elapsed >= c.target_max_dwell or
                    (elapsed >= c.target_min_dwell and (empty or conflict))):
                continue
            admission = self._admission_reservations(i, target)
            blocked = priority | admission
            utilities = self._masked_task_utilities(i, blocked)
            if not np.any(np.isfinite(utilities)):
                self.c06_task_metrics['region_no_candidate'] += 1
                self.c07_task_metrics['admission_no_candidate'] += 1
                continue
            new = int(np.argmax(utilities))
            self.advice_metrics['target_reconsiderations'] += 1
            self.next_reconsider_at[i] = self.time+m.decision_interval_s
            if new != target or force:
                self.targets[i] = new
                self.target_since[i] = self.time
                if not force:
                    self.advice_metrics['actual_target_changes'] += 1
            if blocked:
                self.c06_task_metrics['ordinary_region_masked_decisions'] += 1
            if admission:
                self.c07_task_metrics['next_visit_admission_decisions'] += 1
                self.c07_task_events.append(dict(time=float(self.time), auv=i+1,
                    event='next_visit_admission', old_target=target, new_target=new,
                    priority_mask=sorted(priority), admission_mask=sorted(admission)))

    def _info(self):
        info = super()._info()
        if self._admission_active():
            info['task_admission_diagnostics'] = dict(self.c07_task_metrics)
        return info
