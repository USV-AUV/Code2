"""Explicit V6-C07 network-bundle and constituent-module ablations."""
from dataclasses import asdict, dataclass
import hashlib
import json


@dataclass(frozen=True)
class MethodSpec:
    method_id: str
    name: str
    use_usde: bool
    use_topology: bool
    use_resource_mac: bool
    base_method_id: str
    adapter_version: str = 'v6-c07-20260918'

    def to_dict(self):
        return asdict(self)

    @property
    def fingerprint(self):
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True).encode()).hexdigest()[:16]


_METHODS = {
    'full_v6': MethodSpec('full_v6', 'V6-C07 full communication bundle + USDE', True, True, True, 'full_v6'),
    'topology_only_v6': MethodSpec('topology_only_v6', 'V6-C07 communication bundle without USDE', False, True, True, 'topology_only_v6'),
    'usde_only_v6': MethodSpec('usde_only_v6', 'V6-C07 USDE without communication bundle', True, False, False, 'usde_only_v6'),
    'usde_mac_v6': MethodSpec('usde_mac_v6', 'V6-C07 USDE + dynamic MAC without topology', True, False, True, 'usde_only_v6'),
}
METHOD_IDS = tuple(_METHODS)


def get_method(method_id):
    try:
        return _METHODS[method_id]
    except (KeyError, TypeError) as exc:
        raise ValueError(f'Unknown V6-C07 method: {method_id!r}; expected {METHOD_IDS}') from exc


