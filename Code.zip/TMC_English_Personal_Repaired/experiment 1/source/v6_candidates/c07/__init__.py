"""V6 C07: fresh peer-region admission and outward immediate-yield targets."""

