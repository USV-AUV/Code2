"""C07 retains frozen C06 routing; only causal task selection changes."""
from v6_candidates.c06.routing import RoutingOptions, routing_defaults

__all__ = ['RoutingOptions', 'routing_defaults']

