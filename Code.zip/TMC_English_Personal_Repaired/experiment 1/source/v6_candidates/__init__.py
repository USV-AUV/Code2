"""Independent V6 candidates; historical implementations remain frozen."""
