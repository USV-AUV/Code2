"""C03 retains C01 routing options; the explicit spec declares resource MAC."""
from v6_candidates.c01.routing import RoutingOptions, routing_defaults

__all__ = ['RoutingOptions', 'routing_defaults']
