"""Root pool subleases: one real command, no free remote state or release.

Root can subdelegate only an ACK-backed parent lease already installed at root.
It first promises local silence for the entire child window, then queues a paid
direct MAC_SUBCOMMIT. Only its real arrival authorizes the SN. Lost commands
waste the window; root cannot reclaim early. Child rights are a subset of the
parent's alternating frames, so every original SN retains its protected home
slots even if the child is that same original SN. There is no recursive lending.
"""
from dataclasses import dataclass
import struct

from usv_auv.network import Packet
from v6_candidates.c02.mac import (
    DynamicMacNetwork as ParentDynamicMacNetwork,
    FixedStarMacNetwork as ParentFixedStarMacNetwork,
    MacOptions, SlotLease, MAC_BITS, MAC_KINDS as PARENT_MAC_KINDS, _integer,
)


MAC_KINDS = PARENT_MAC_KINDS | {'MAC_SUBCOMMIT'}
MAX_CHILD_WINDOW_FRAMES = 3
_CHILD_WIRE = struct.Struct('<Q I H H H I I B I H I I 23x')


@dataclass(frozen=True)
class ChildLease:
    parent: SlotLease
    child_id: int
    borrower: int
    start_frame: int
    end_frame: int

    def __post_init__(self):
        if not isinstance(self.parent, SlotLease) or self.parent.borrower != 0:
            raise ValueError('Only a root-held parent lease is delegable')
        _integer(self.child_id, 1, 2**32-1, 'child_id')
        _integer(self.borrower, 0, 65535, 'borrower')
        _integer(self.start_frame, 0, 2**32-1, 'start_frame')
        _integer(self.end_frame, 0, 2**32-1, 'end_frame')
        if not 0 < self.end_frame-self.start_frame <= MAX_CHILD_WINDOW_FRAMES:
            raise ValueError('Child window must span one to three frames')
        if self.start_frame < self.parent.start_frame or self.end_frame > self.parent.end_frame:
            raise ValueError('Child window must be contained in its parent window')
        if not any(self.parent.active(f) for f in range(self.start_frame,self.end_frame)):
            raise ValueError('Child window has no parent-authorized frame')

    def active(self, frame):
        return self.start_frame <= frame < self.end_frame and self.parent.active(frame)

    def to_dict(self):
        return dict(parent=self.parent.to_dict(),child_id=self.child_id,
            borrower=self.borrower,start_frame=self.start_frame,end_frame=self.end_frame)

    def wire(self):
        values=[getattr(self.parent,name) for name in self.parent.__dataclass_fields__]
        return _CHILD_WIRE.pack(*values,self.child_id,self.borrower,self.start_frame,self.end_frame)


class _PoolMixin:
    def __init__(self,*args,**kwargs):
        self._child_next_id=0
        self._child_promises={}
        self._child_commits={}
        self.root_child_records={}
        super().__init__(*args,**kwargs)
        self._child_commits={n:{} for n in range(self.n_auvs+1,self.n_nodes)}

    def _validate_child(self,value):
        fields={'parent','child_id','borrower','start_frame','end_frame'}
        if not isinstance(value,dict) or set(value)!=fields:
            raise ValueError('Unexpected child certificate fields')
        parent=self._validate_lease(value['parent'])
        child=ChildLease(parent=parent,**{k:v for k,v in value.items() if k!='parent'})
        _integer(child.borrower,self.n_auvs+1,self.n_nodes-1,'borrower')
        child.wire()
        return child

    def _root_has_parent(self,parent):
        record=self.root_records.get(parent.lease_id)
        return (parent.borrower==0 and self._borrower_commits[0].get(parent.lease_id)==parent
                and self._root_requests.get(parent.lease_id)==parent
                and record is not None and record['ack_received_at'] is not None
                and self.current_frame<parent.end_frame)

    def available_pool_leases(self):
        """Only root's ACK/local-install facts and its own silence promises."""
        result=[]
        for parent in self._borrower_commits[0].values():
            if not self._root_has_parent(parent):
                continue
            children=[c.to_dict() for c in self._child_promises.values()
                if c.parent==parent and c.end_frame>self.current_frame]
            result.append(dict(parent=parent.to_dict(),child_windows=children))
        return sorted(result,key=lambda item:(item['parent']['end_frame'],item['parent']['lease_id']))

    def propose_child(self,parent_id,borrower,start_frame,end_frame):
        """Promise root silence first; enqueue one real 512-bit SN command.

        Returns None for an unavailable parent, overlapping already promised
        window, or no remaining slot. Never reads any child's queue/installation.
        Invalid caller parameters raise ValueError. Current-frame activation is
        allowed, but authorizes only calendar slots not already processed.
        """
        _integer(parent_id,1,2**32-1,'parent_id')
        _integer(borrower,self.n_auvs+1,self.n_nodes-1,'borrower')
        parent=self._borrower_commits[0].get(parent_id)
        if parent is None or not self._root_has_parent(parent):
            self._mac_event('child_parent_unavailable',parent_id=parent_id)
            return None
        child=self._validate_child(dict(parent=parent.to_dict(),child_id=self._child_next_id+1,
            borrower=borrower,start_frame=start_frame,end_frame=end_frame))
        if child.start_frame<self.current_frame:
            raise ValueError('Child activation cannot be backdated to a past frame')
        if not any(child.active(f) and f*len(self.slot_owners)+parent.slot_offset>=self._slot_index
                   for f in range(child.start_frame,child.end_frame)):
            self._mac_event('child_no_remaining_slot',child=child.to_dict())
            return None
        for old in self._child_promises.values():
            if old.parent==parent and max(old.start_frame,child.start_frame)<min(old.end_frame,child.end_frame):
                self._mac_event('child_overlap_rejected',child=child.to_dict())
                return None
        # Irrevocable even if the queue is full or the command is later lost.
        self._child_next_id=child.child_id
        self._child_promises[child.child_id]=child
        self.root_child_records[child.child_id]=dict(certificate=child.to_dict(),
            promised_at=float(self.time),submitted_at=float(self.time))
        self._mac_event('child_silence_promised',child=child.to_dict())
        self.submit(Packet(0,borrower,'MAC_SUBCOMMIT',child.to_dict(),float(self.time),
            MAC_BITS,expires_at=child.end_frame*self.frame_duration,ttl=1))
        self._mac_event('child_subcommit_submitted',child=child.to_dict())
        return child.child_id

    def retry_child(self,child_id):
        """Optional paid repeat of immutable content; never extends silence."""
        child=self._child_promises.get(child_id)
        if child is None or self.current_frame>=child.end_frame:
            return False
        self.submit(Packet(0,child.borrower,'MAC_SUBCOMMIT',child.to_dict(),float(self.time),
            MAC_BITS,expires_at=child.end_frame*self.frame_duration,ttl=1))
        self._mac_event('child_subcommit_retry_submitted',child=child.to_dict())
        return True

    def _service_interval(self,kind):
        if kind=='MAC_SUBCOMMIT':
            return self.mac_options.mac_control_service_s
        return super()._service_interval(kind)

    def _enqueue(self,owner,packet,next_hop=None,routed=False):
        if packet.kind=='MAC_SUBCOMMIT' and (packet.src!=0 or owner!=0 or routed or
                (next_hop is not None and next_hop!=packet.dst)):
            self._mac_event('child_illegal_relay_rejected')
            return None
        return super()._enqueue(owner,packet,next_hop,routed)

    def _receive(self,packet,receiver,transmitter):
        before=len(self._outbox)
        result=super()._receive(packet,receiver,transmitter)
        if packet.kind!='MAC_SUBCOMMIT' or not self._outbox[before:]:
            return result
        del self._outbox[before:]  # Other ordinary application deliveries survive.
        if packet.src!=0 or transmitter!=0 or packet.dst!=receiver or packet.size_bits!=MAC_BITS:
            self._mac_event('child_invalid_endpoint_rejected')
            return result
        try:
            child=self._validate_child(packet.payload)
        except (ValueError,TypeError,struct.error):
            self._mac_event('child_invalid_certificate_rejected')
            return result
        if child.borrower!=receiver:
            self._mac_event('child_borrower_mismatch_rejected',child=child.to_dict())
            return result
        if self.current_frame>=child.end_frame:
            self._mac_event('child_expired_certificate_rejected',child=child.to_dict())
            return result
        previous=self._child_commits[receiver].get(child.child_id)
        if previous is not None and previous!=child:
            self._mac_event('child_inconsistent_duplicate_rejected',child=child.to_dict())
            return result
        # Receiver trusts only an arrived root certificate, not root's internal
        # promise or original donor state. The network audit is not its oracle.
        self._child_commits[receiver][child.child_id]=child
        self._mac_event('child_commit_received' if previous is None else 'child_duplicate_received',
                        child=child.to_dict())
        return result

    def local_authorized_owners(self,slot_index=None):
        index=self._slot_index if slot_index is None else slot_index
        owners=list(super().local_authorized_owners(index))
        offset,frame=index%len(self.slot_owners),index//len(self.slot_owners)
        if 0 in owners and any(c.parent.slot_offset==offset and c.active(frame)
                and self._borrower_commits[0].get(c.parent.lease_id)==c.parent
                for c in self._child_promises.values()):
            owners.remove(0)
        for node,certificates in self._child_commits.items():
            if node not in owners and any(c.parent.slot_offset==offset and c.active(frame)
                                         for c in certificates.values()):
                owners.append(node)
        return tuple(owners)

    def _transmit_slot(self,owner,positions):
        index=self._slot_index-1
        offset,frame=index%len(self.slot_owners),index//len(self.slot_owners)
        child=next((c for c in self._child_commits.get(owner,{}).values()
                    if c.parent.slot_offset==offset and c.active(frame)),None)
        before=self.metrics['transmissions']
        result=super()._transmit_slot(owner,positions)
        if child is not None:
            sent=self.metrics['transmissions']>before
            self.metrics['v6_mac_child_slot_opportunities']+=1
            self.metrics['v6_mac_child_slot_transmissions']+=int(sent)
            self.metrics['v6_mac_child_idle_slots']+=int(not sent)
            if owner==self.slot_owners[offset]:
                self.metrics['v6_mac_child_returned_home_slots']+=1
                self.metrics['v6_mac_child_returned_home_transmissions']+=int(sent)
            self._mac_event('child_slot',child=child.to_dict(),slot_index=index,transmitted=sent)
        return result


class DynamicMacNetwork(_PoolMixin,ParentDynamicMacNetwork):
    """Topology-enabled C03, with the common causally delegated pool."""


class FixedStarMacNetwork(_PoolMixin,ParentFixedStarMacNetwork):
    """Identical C03 pool/physical protocol, but no AUV relaying."""
