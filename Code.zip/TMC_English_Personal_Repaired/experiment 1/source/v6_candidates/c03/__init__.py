"""V6 C03: paid, bounded subdelegation of root's existing slot pool."""
