"""C03: a paid root slot pool with short, irrevocable delegated SN grants.

The root's existing long-term certificates are the ONLY allocatable pool.
Reassigning their use requires a real SUBCOMMIT and a root-local silence
promise first. No global slot table or free remote installation is permitted.
"""
from collections import Counter
from dataclasses import dataclass
import math
import numpy as np

from v6_candidates.c02.environment import TaskV4Env as PreviousEnv, MethodOptions as PreviousOptions
from v6_candidates.c01.environment import TaskV4Env as C01Env, local_fields, slow_fields
from .methods import get_method
from .mac import DynamicMacNetwork, FixedStarMacNetwork, MacOptions


@dataclass(frozen=True)
class MethodOptions(PreviousOptions):
    mac_pool_slots: int = 10
    mac_auv_slots: int = 3
    mac_child_lease_frames: int = 3
    mac_child_slots_per_sensor: int = 2
    mac_child_max_active: int = 4
    mac_sensor_prediction_min_packets: float = .5

    def __post_init__(self):
        super().__post_init__()
        for name, lower, upper in (('mac_pool_slots', 2, 16), ('mac_auv_slots', 1, 8),
                ('mac_child_lease_frames', 1, 3), ('mac_child_slots_per_sensor', 1, 4),
                ('mac_child_max_active', 1, 8)):
            if type(getattr(self, name)) is not int or not lower <= getattr(self, name) <= upper:
                raise ValueError(f'{name} must be an integer in [{lower},{upper}]')
        if self.mac_child_max_active >= self.mac_pool_slots:
            raise ValueError('Retain some pool slots for root control traffic')
        if self.mac_pool_slots + 2*self.mac_auv_slots > self.mac_max_leases:
            raise ValueError('Parent pool and AUV allocations exceed shared parent budget')


class TaskV4Env(PreviousEnv):
    observation_schema_version = 'v6-c03-paid-delegated-pool-local41-root90-v1'

    def __init__(self, cfg=None, method_id='full_v6', method_options=None, routing_options=None):
        spec = get_method(method_id)
        options = method_options or MethodOptions(mac_enabled=spec.use_resource_mac)
        if options.mac_enabled != spec.use_resource_mac:
            raise ValueError('Explicit MAC ablation option must match C03 identity')
        self._c03_method = spec
        super().__init__(cfg, method_id, options, routing_options)
        self.method = spec
        self.last_observations = self._observations()

    def reset(self, seed=None):
        super().reset(seed)
        c, m = self.cfg, self.method_options
        cls = DynamicMacNetwork if self._c03_method.use_topology else FixedStarMacNetwork
        self.network = cls(c, self.seed, routing_options=self.routing_options,
            mac_options=MacOptions(m.mac_prepare_lead_frames, m.mac_lease_frames,
                m.mac_frame_stride, m.mac_routed_auv_commits), donor_eligible=self._donor_eligible)
        self.network.application_link_filter = self._data_in_range
        self.network.on_transmit_payload = self._physical_localization
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _mac_candidates(self):
        # C01 reads received reports, not C02's slow three-message SN horizon.
        # C03 SN allocation no longer has that old setup delay.
        candidates, protected = C01Env._mac_candidates(self)
        return candidates, protected

    def _parent_tick(self, protected):
        c, m, net = self.cfg, self.method_options, self.network
        active = [r['lease'] for r in net.root_records.values() if r['lease']['end_frame'] > net.current_frame]
        counts = Counter(p['borrower'] for p in active)
        limits = {0: m.mac_pool_slots, **{n: m.mac_auv_slots for n in range(1, c.n_auv+1)}}
        allowed = [n for n in limits if counts[n] < limits[n]]
        if not allowed or len(active) >= m.mac_max_leases:
            return
        # A small initial root pool first; then equal fractional progress for
        # the known periodic cooperative loads. No remote queue is consulted.
        borrower = 0 if 0 in allowed and counts[0] < min(4, limits[0]) else min(allowed, key=lambda n: (counts[n]/limits[n], n))
        used = {p['donor'] for p in active}
        donors = [c.n_auv+1+j for j in range(c.n_sensors)
                  if j not in protected and c.n_auv+1+j not in used]
        if not donors:
            return
        offsets = [net.slot_owners.index(p['donor']) for p in active if p['borrower'] == borrower]
        offsets += [k for k, node in enumerate(net.slot_owners) if node == borrower]
        positions = [np.asarray(d.packet.payload['position'], dtype=float)
            for node, d in net.received_states.items() if 1 <= node <= c.n_auv and
            'position' in d.packet.payload and 0 <= net.time-d.packet.payload.get('source_time', math.inf) <= m.mac_demand_ttl_s]
        length = len(net.slot_owners)
        def utility(node):
            offset = net.slot_owners.index(node)
            separation = min(min((offset-k) % length, (k-offset) % length) for k in offsets)/length
            distance = (min(np.linalg.norm(self.sensor_positions[node-c.n_auv-1]-p) for p in positions)/c.area_size
                        if positions else 0.)
            return separation+distance
        donor = max(donors, key=lambda n: (utility(n), -n))
        start = net.current_frame + m.mac_prepare_lead_frames
        lease_id = net.request_lease(donor, borrower, start_frame=start, end_frame=start+m.mac_coop_lease_frames)
        if lease_id is not None:
            self.mac_scheduler_metrics['leases_requested'] += 1
            self.mac_scheduler_events.append(dict(time=float(net.time), event='parent_requested',
                donor=donor, borrower=borrower, lease_id=lease_id))

    def _child_tick(self, candidates):
        c, m, net = self.cfg, self.method_options, self.network
        pools = net.available_pool_leases()  # ONLY root's own received certificates/promises
        active = [child for pool in pools for child in pool['child_windows'] if child['end_frame'] > net.current_frame]
        if len(active) >= m.mac_child_max_active:
            return
        counts = Counter(child['borrower'] for child in active)
        sensors = [(node, score/(1+counts[node])) for node, score in candidates
                   if node > c.n_auv and counts[node] < m.mac_child_slots_per_sensor]
        if not sensors:
            return
        # One paid child command per shared scheduler tick. Increased demand
        # cannot summon unlimited free commands or activate an unreceived grant.
        borrower = max(sensors, key=lambda kv: (kv[1], -kv[0]))[0]
        choices = []
        own_offset = net.slot_owners.index(borrower)
        for pool in pools:
            parent = pool['parent']
            start = max(net.current_frame, parent['start_frame'])
            if (start-parent['start_frame']) % parent['frame_stride']:
                start += parent['frame_stride']-(start-parent['start_frame']) % parent['frame_stride']
            first_time = start*net.frame_duration + parent['slot_offset']*net.slot_duration
            if first_time <= net.time + 2*net.cooperative_slot_gap:
                start += parent['frame_stride']
                first_time = start*net.frame_duration + parent['slot_offset']*net.slot_duration
            # The current received visit evidence does not justify very distant
            # speculative child windows. Wait for fresh reports instead.
            if first_time-net.time > net.frame_duration:
                continue
            end = min(start+m.mac_child_lease_frames, parent['end_frame'])
            if end <= start or any(max(start, x['start_frame']) < min(end, x['end_frame'])
                                   for x in pool['child_windows']):
                continue
            offsets = [own_offset] + [x['parent']['slot_offset'] for x in active if x['borrower'] == borrower]
            length = len(net.slot_owners)
            gap = min(min((parent['slot_offset']-k) % length, (k-parent['slot_offset']) % length) for k in offsets)
            # Restoring a currently requested original donor is legitimate but
            # still requires a received child certificate; no promise is erased.
            restore = 1. if parent['donor'] == borrower else 0.
            score = restore + gap/length - .25*(first_time-net.time)/net.frame_duration
            choices.append((score, parent['lease_id'], start, end))
        if not choices:
            return
        _, parent_id, start, end = max(choices, key=lambda x: (x[0], -x[1]))
        child_id = net.propose_child(parent_id, borrower, start_frame=start, end_frame=end)
        if child_id is not None:
            self.mac_scheduler_metrics['child_leases_requested'] += 1
            self.mac_scheduler_events.append(dict(time=float(net.time), event='child_requested',
                borrower=borrower, parent_id=parent_id, child_id=child_id,
                start_frame=start, end_frame=end, demand_score=dict(candidates)[borrower]))

    def _mac_tick(self):
        if not self._mac_ready or not self.method_options.mac_enabled:
            return
        net = self.network
        if net.time+1e-9 < self.mac_next_decision:
            return
        self.mac_next_decision = net.time+self.method_options.mac_decision_interval_s
        candidates, protected = self._mac_candidates()
        self._parent_tick(protected)
        self._child_tick(candidates)
