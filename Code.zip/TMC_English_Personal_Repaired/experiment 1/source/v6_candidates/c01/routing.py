"""V6 shares the frozen V5 C01 routing options; MAC is environment-side."""
from v5_candidates.c01.routing import RoutingOptions


def routing_defaults():
    """Same method-only timing used in the preceding frozen candidate."""
    return RoutingOptions(decision_dwell_s=45., renewal_margin_s=60.,
                          direct_recovery_s=30., state_stale_s=25.)

__all__ = ['RoutingOptions', 'routing_defaults']
