"""V6-C01 identities: identical shared MAC, exact two-module ablations."""
from dataclasses import asdict, dataclass
import hashlib
import json


@dataclass(frozen=True)
class MethodSpec:
    method_id: str
    name: str
    use_usde: bool
    use_topology: bool
    base_method_id: str
    adapter_version: str = 'v6-c01-20260918'

    def to_dict(self):
        return asdict(self)

    @property
    def fingerprint(self):
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True).encode()).hexdigest()[:16]


_METHODS = {
    'full_v6': MethodSpec('full_v6', 'V6-C01 topology + USDE + common dynamic MAC', True, True, 'full_v4'),
    'topology_only_v6': MethodSpec('topology_only_v6', 'V6-C01 topology + common dynamic MAC', False, True, 'topology_only_v4'),
    'usde_only_v6': MethodSpec('usde_only_v6', 'V6-C01 USDE + common dynamic MAC', True, False, 'usde_only_v4'),
}
METHOD_IDS = tuple(_METHODS)


def get_method(method_id):
    try:
        return _METHODS[method_id]
    except (KeyError, TypeError) as exc:
        raise ValueError(f'Unknown V6 method: {method_id!r}; expected {METHOD_IDS}') from exc
