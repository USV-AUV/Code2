"""V6-C01: causally requested, paid, expiring extra transmission slots.

The root reads received STATE or direct SN demand, never remote queues/true
positions/grants. SNs can report service directly even in the fixed-star arm.
The shared scheduler does not gate original service or change physical rates.
TD3 remains the sole final movement policy; no post-policy compensation.
"""
from collections import Counter
from dataclasses import dataclass
import copy
import math
import struct

from v5_candidates.c01.environment import (
    TaskV4Env as PreviousEnv, MethodOptions as PreviousOptions, local_fields, slow_fields,
)
from .mac import DynamicMacNetwork, FixedStarMacNetwork, MacOptions, MAC_KINDS
from .methods import get_method


DEMAND_BITS = 512
_DEMAND_WIRE = struct.Struct('<HHHdddI30x')  # 64 bytes including padding


@dataclass(frozen=True)
class MethodOptions(PreviousOptions):
    task_advice: bool = False
    service_release: bool = False
    mac_enabled: bool = True
    mac_decision_interval_s: float = 12.
    mac_demand_report_interval_s: float = 72.
    mac_demand_ttl_s: float = 90.
    mac_max_leases: int = 10
    mac_max_leases_per_borrower: int = 2
    mac_requests_per_tick: int = 2
    mac_prepare_lead_frames: int = 2
    mac_lease_frames: int = 5
    mac_frame_stride: int = 2
    mac_routed_auv_commits: bool = True

    def __post_init__(self):
        super().__post_init__()
        if type(self.mac_enabled) is not bool or type(self.mac_routed_auv_commits) is not bool:
            raise ValueError('MAC feature flags must be boolean')
        if self.task_advice or self.service_release:
            raise ValueError('V6-C01 excludes unselected advice/release branches')
        for name in ('mac_decision_interval_s', 'mac_demand_report_interval_s', 'mac_demand_ttl_s'):
            v = getattr(self, name)
            if isinstance(v, bool) or not math.isfinite(v) or v <= 0:
                raise ValueError(f'{name} must be positive and finite')
        for name in ('mac_max_leases', 'mac_max_leases_per_borrower', 'mac_requests_per_tick'):
            v = getattr(self, name)
            if type(v) is not int or not 1 <= v <= 30:
                raise ValueError(f'{name} must be an integer in [1,30]')
        MacOptions(self.mac_prepare_lead_frames, self.mac_lease_frames, self.mac_frame_stride,
                   self.mac_routed_auv_commits)


def pack_demand(payload):
    expected = {'sensor', 'receiver', 'generation', 'source_time', 'expires_at', 'queue_packets', 'report_seq'}
    if not isinstance(payload, dict) or set(payload) != expected:
        raise ValueError('Invalid MAC_DEMAND fields')
    for key, maximum in (('sensor', 65535), ('receiver', 65535), ('generation', 65535), ('report_seq', 2**32-1)):
        if type(payload[key]) is not int or not 0 <= payload[key] <= maximum:
            raise ValueError('Invalid MAC_DEMAND integer')
    for key in ('source_time', 'expires_at', 'queue_packets'):
        if isinstance(payload[key], bool) or not math.isfinite(payload[key]) or payload[key] < 0:
            raise ValueError('Invalid MAC_DEMAND scalar')
    if payload['expires_at'] <= payload['source_time']:
        raise ValueError('MAC_DEMAND service expiry must follow its source timestamp')
    wire = _DEMAND_WIRE.pack(*(payload[k] for k in
        ('sensor', 'receiver', 'generation', 'source_time', 'expires_at', 'queue_packets', 'report_seq')))
    if len(wire) * 8 != DEMAND_BITS:
        raise AssertionError('MAC_DEMAND exceeded charged size')
    return wire


class TaskV4Env(PreviousEnv):
    observation_schema_version = 'v6-c01-paid-dynamic-mac-local41-root90-v1'

    def __init__(self, cfg=None, method_id='full_v6', method_options=None, routing_options=None):
        spec = get_method(method_id)
        self._mac_ready = False
        super().__init__(cfg, spec.base_method_id, method_options or MethodOptions(), routing_options)
        self.method = spec
        self.last_observations = self._observations()

    def reset(self, seed=None):
        self._mac_ready = False
        super().reset(seed)
        c, m = self.cfg, self.method_options
        cls = DynamicMacNetwork if self.method.use_topology else FixedStarMacNetwork
        self.network = cls(c, self.seed, routing_options=self.routing_options,
            mac_options=MacOptions(m.mac_prepare_lead_frames, m.mac_lease_frames, m.mac_frame_stride,
                                   m.mac_routed_auv_commits),
            donor_eligible=self._donor_eligible)
        self.network.application_link_filter = self._data_in_range
        self.network.on_transmit_payload = self._physical_localization
        self.mac_root_demands = {}  # only genuinely delivered MAC_DEMAND snapshots
        self.mac_sensor_report_times = {}  # SN-local rate limiter
        self.mac_sensor_report_seq = Counter()
        self.mac_scheduler_metrics = Counter()
        self.mac_scheduler_events = []
        self.mac_next_decision = 0.
        self._mac_ready = True
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _donor_eligible(self, node, now):
        # Executed by this SN on an actually received PREPARE, never at root.
        j = node - self.cfg.n_auv - 1
        grant = self.grants.get(j)
        pending = any(q.packet.expires_at >= now and q.packet.kind not in MAC_KINDS
                      for q in self.network._queues[node])
        return (grant is None or grant[1] <= now) and not pending

    def _send(self, src, dst, kind, payload, bits=None, expiry=None):
        leases = []
        if (self._mac_ready and self.method_options.mac_enabled and
                self.method_options.mac_routed_auv_commits and kind == 'COORD' and
                src == 0 and 1 <= dst <= self.cfg.n_auv):
            leases = self.network.root_coord_leases(dst)
        if leases:
            payload = copy.deepcopy(payload)
            # Sending an AUV its own obsolete state has no observation use.
            # Keep the peer's full 112B record. This frees enough actual wire
            # space for up to two 64B certificates within the original 288B.
            payload['states'].pop(str(dst), None)
            payload['states'].pop(dst, None)
            payload['mac_leases'] = leases
            bits = 8 * (40 + 112*len(payload['states']) + 8 + 64*len(leases))
            if bits > self.network.max_packet_bits:
                raise ValueError('Paid COORD certificates exceed unchanged slot payload')
        result = super()._send(src, dst, kind, payload, bits, expiry)
        if leases:
            # This records a local submission only, never remote installation.
            self.network.mark_coord_commits_queued([lease['lease_id'] for lease in leases])
            self.mac_scheduler_metrics['coord_certificate_submissions'] += 1
            self.mac_scheduler_metrics['coord_certificate_bytes_submitted'] += 8 + 64*len(leases)
        return result

    def _send_local_demand(self, delivery):
        """SN-local accepted request -> paid direct root report, rate limited."""
        p, c, now = delivery.packet, self.cfg, self.network.time
        j = delivery.receiver - c.n_auv - 1
        generation = p.payload.get('service_generation')
        if self._service_sensor_generation.get(j) != (p.src, generation):
            return
        key = (j, p.src)
        if now - self.mac_sensor_report_times.get(key, -math.inf) < self.method_options.mac_demand_report_interval_s:
            return
        grant = self.grants.get(j)
        if grant is None or grant[0] != p.src or grant[1] <= now:
            return
        self.mac_sensor_report_times[key] = now
        self.mac_sensor_report_seq[j] += 1
        payload = dict(sensor=int(j), receiver=int(p.src), generation=int(generation),
            source_time=float(now), expires_at=float(grant[1]), queue_packets=float(len(self.buffers[j])),
            report_seq=int(self.mac_sensor_report_seq[j]))
        pack_demand(payload)
        self._send(delivery.receiver, 0, 'MAC_DEMAND', payload, DEMAND_BITS,
                   min(grant[1], now + self.method_options.mac_demand_ttl_s))
        self.mac_scheduler_metrics['demand_reports_queued'] += 1

    def _accept_root_demand(self, delivery):
        p, c, now = delivery.packet, self.cfg, self.network.time
        try:
            pack_demand(p.payload)
        except (ValueError, TypeError, OverflowError, struct.error):
            self.mac_scheduler_metrics['invalid_demand_rejected'] += 1
            return
        value = p.payload
        j, receiver, stamp = value['sensor'], value['receiver'], value['source_time']
        if (delivery.receiver != 0 or p.src != c.n_auv+1+j or not 0 <= j < c.n_sensors or
                not 1 <= receiver <= c.n_auv or p.size_bits != DEMAND_BITS or
                not 0 <= now-stamp <= self.method_options.mac_demand_ttl_s or
                value['expires_at'] <= now or value['queue_packets'] > c.buffer_packets):
            self.mac_scheduler_metrics['invalid_demand_rejected'] += 1
            return
        old = self.mac_root_demands.get(j)
        if old is None or (stamp, value['report_seq']) > (old['source_time'], old['report_seq']):
            self.mac_root_demands[j] = copy.deepcopy(value)
            self.mac_scheduler_metrics['demand_reports_arrived'] += 1

    def _deliver(self, deliveries):
        if not self._mac_ready or not self.method_options.mac_enabled:
            return super()._deliver(deliveries)
        for d in deliveries:
            if d.packet.kind == 'MAC_DEMAND':
                self._accept_root_demand(d)
                continue
            super()._deliver([d])
            if d.packet.kind == 'DATA_REQUEST' and d.receiver > self.cfg.n_auv:
                self._send_local_demand(d)

    def _mac_candidates(self):
        """Root information only. Values are demand scores, not permissions.

        Earlier AUV target intent can prepare a future SN slot before contact;
        actual direct SN reports remain a common fallback, including fixed star.
        Root need not (and cannot) know whether a remote COMMIT was installed.
        """
        c, m, now = self.cfg, self.method_options, self.network.time
        scores, protected = {}, set()
        root_load = sum(q.packet.expires_at >= now and q.packet.kind not in
            {'MAC_PREPARE', 'MAC_COMMIT', 'MAC_ACK', 'MAC_DEMAND'} for q in self.network._queues[0])
        if root_load >= 2:
            scores[0] = 2. + min(root_load, 12) / 12.
        for node, delivery in self.network.received_states.items():
            p = delivery.packet.payload
            stamp = p.get('source_time', math.inf)
            if not 1 <= node <= c.n_auv or not 0 <= now-stamp <= m.mac_demand_ttl_s:
                continue
            j, service = p.get('target'), p.get('service', {})
            if type(j) is not int or not 0 <= j < c.n_sensors:
                continue
            protected.add(j)
            phase = service.get('phase', 0)
            queue = service.get('queue_packets', 0.)
            if not math.isfinite(queue) or queue < 0:
                continue
            # A freshly transmitted imminent visit is useful before the SN
            # sends its own service report; stale intent decays, not free truth.
            freshness = max(.1, 1. - (now-stamp) / m.mac_demand_ttl_s)
            if queue >= .5:
                scores[c.n_auv+1+j] = max(scores.get(c.n_auv+1+j, 0.),
                    freshness * (2. + min(queue, 4.)/4. + (1. if phase else 0.)))
                scores[node] = max(scores.get(node, 0.), freshness * (2. + (1. if phase else 0.)))
        for j, p in self.mac_root_demands.items():
            if (0 <= now-p['source_time'] <= m.mac_demand_ttl_s and p['expires_at'] > now):
                protected.add(j)
                freshness = max(.1, 1.-(now-p['source_time'])/m.mac_demand_ttl_s)
                if p['queue_packets'] >= .5:
                    owner = c.n_auv+1+j
                    scores[owner] = max(scores.get(owner, 0.), 4.*freshness)
                    scores[p['receiver']] = max(scores.get(p['receiver'], 0.), 3.*freshness)
        return sorted(scores.items(), key=lambda kv: (-kv[1], kv[0])), protected

    def _mac_tick(self):
        if not self._mac_ready or not self.method_options.mac_enabled:
            return
        m, c, net = self.method_options, self.cfg, self.network
        if net.time + 1e-9 < self.mac_next_decision:
            return
        self.mac_next_decision = net.time + m.mac_decision_interval_s
        candidates, protected = self._mac_candidates()
        active = [r['lease'] for r in net.root_records.values() if r['lease']['end_frame'] > net.current_frame]
        counts = Counter(p['borrower'] for p in active)
        used = {p['donor'] for p in active}
        for _ in range(min(m.mac_requests_per_tick, max(0, m.mac_max_leases-len(active)))):
            eligible = [(n, s/(1+counts[n])) for n, s in candidates if counts[n] < m.mac_max_leases_per_borrower]
            if not eligible:
                break
            borrower = max(eligible, key=lambda kv: (kv[1], -kv[0]))[0]
            donors = [c.n_auv+1+j for j in range(c.n_sensors)
                      if j not in protected and c.n_auv+1+j not in used and c.n_auv+1+j != borrower]
            if not donors:
                break
            # Spread extra opportunities within the frame, using calendar IDs
            # alone. No physical position/channel success or donor buffer peek.
            offsets = [net.slot_owners.index(p['donor']) for p in active if p['borrower'] == borrower]
            offsets += [i for i, n in enumerate(net.slot_owners) if n == borrower]
            length = len(net.slot_owners)
            def separation(n):
                offset = net.slot_owners.index(n)
                return min(min((offset-other) % length, (other-offset) % length) for other in offsets)
            donor = max(donors, key=lambda n: (separation(n), -n))
            lease_id = net.request_lease(donor, borrower)
            if lease_id is None:
                used.add(donor)
                continue
            lease = net.root_records[lease_id]['lease']
            active.append(lease)
            counts[borrower] += 1
            used.add(donor)
            self.mac_scheduler_metrics['leases_requested'] += 1
            self.mac_scheduler_events.append(dict(time=float(net.time), borrower=borrower,
                donor=donor, lease_id=lease_id, demand_score=dict(candidates)[borrower]))

    def step(self, actions, topology_action=None):
        self._mac_tick()
        return super().step(actions, topology_action)

    def _info(self):
        info = super()._info()
        if self._mac_ready:
            info['mac_scheduler'] = dict(self.mac_scheduler_metrics)
        return info
