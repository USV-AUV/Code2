"""C06 retains C05 routing; only received communication task handling changes."""
from v6_candidates.c05.routing import RoutingOptions, routing_defaults

__all__ = ['RoutingOptions', 'routing_defaults']

