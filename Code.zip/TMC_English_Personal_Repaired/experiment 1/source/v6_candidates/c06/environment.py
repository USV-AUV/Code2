"""C06: received task-region conflicts and causal urgent COORD service.

The public sensor map expands an already valid C04 peer reservation to nearby
service regions. No true peer state, controller, physical relaxation, new claim
field, or central service permission is introduced. An own live local grant is
preserved. This is a task-selection heuristic, NOT a collision safety proof.
"""
from collections import Counter
from dataclasses import dataclass
import math
import numpy as np

from v6_candidates.c05.environment import TaskV4Env as PreviousEnv, MethodOptions as PreviousOptions
from v6_candidates.c01.environment import local_fields, slow_fields
from .methods import get_method
from .mac import DynamicMacNetwork, FixedStarMacNetwork, MacOptions


@dataclass(frozen=True)
class MethodOptions(PreviousOptions):
    def __post_init__(self):
        super().__post_init__()
        # C06 is a bounded extension of the existing common slot-aware task
        # scheduler, not a silent replacement when that scheduler is disabled.
        if not self.slot_task_scheduler:
            raise ValueError('C06 requires slot_task_scheduler=True')


class TaskV4Env(PreviousEnv):
    observation_schema_version = 'v6-c06-conflict-recipient-region-local41-root90-v1'

    def __init__(self, cfg=None, method_id='full_v6', method_options=None, routing_options=None):
        self._c06_ready = False
        self._c06_method = get_method(method_id)
        options = method_options or MethodOptions(mac_enabled=self._c06_method.use_resource_mac)
        super().__init__(cfg, method_id, options, routing_options)
        self.method = self._c06_method
        self.last_observations = self._observations()

    def reset(self, seed=None):
        self._c06_ready = False
        super().reset(seed)
        c, m = self.cfg, self.method_options
        cls = DynamicMacNetwork if self._c06_method.use_topology else FixedStarMacNetwork
        self.network = cls(c, self.seed, routing_options=self.routing_options,
            mac_options=MacOptions(m.mac_prepare_lead_frames, m.mac_lease_frames,
                m.mac_frame_stride, m.mac_routed_auv_commits), donor_eligible=self._donor_eligible,
            intent_enabled=m.mac_enabled, sensor_positions=self.sensor_positions)
        self.network.application_link_filter = self._data_in_range
        self.network.on_transmit_payload = self._physical_localization
        # C05 reset installed the passive END counter on its prior network.
        # This new instance needs its own hook; static USDE installs neither.
        if self._service_end_enabled():
            self._install_service_end_tx_counter()
        self.method = self._c06_method
        self.c06_task_metrics = Counter()
        self.c06_task_events = []
        self._c06_ready = True
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def _region_active(self):
        return self._c06_ready and self.method_options.mac_enabled

    def _peer_reservations(self, i, distances):
        original = super()._peer_reservations(i, distances)
        if not self._region_active() or not original:
            return original
        radius = 2*self.cfg.collection_radius+self.cfg.min_separation
        reserved = set()
        for target in original:
            separation = np.linalg.norm(self.sensor_positions-self.sensor_positions[target], axis=1)
            reserved.update(map(int, np.flatnonzero(separation <= radius)))
        # Applying the region extension must not revoke a locally known valid
        # service authorization at a different neighboring sensor either.
        for target, grant in self.received_service_grants[i].items():
            if grant['expires_at'] > self.time:
                reserved.discard(target)
        return reserved

    def _masked_task_utilities(self, i, reserved):
        utilities = self._nominal_utility(self.nav[i].position,
            self._queue_forecast(i)/self.cfg.data_packet_bits, self.time).copy()
        for target in reserved:
            utilities[target] = -math.inf
        return utilities

    def _select_targets(self, force=False):
        if not self._region_active():
            return super()._select_targets(force)
        c, m = self.cfg, self.method_options
        for i in range(c.n_auv):
            target = int(self.targets[i])
            distance = np.linalg.norm(self.sensor_positions-self.nav[i].position, axis=1)
            reservations = self._peer_reservations(i, distance)
            grant = self.received_service_grants[i].get(target)
            valid_grant = grant is not None and grant['expires_at'] > self.time
            conflict = target in reservations and not valid_grant
            self._ingest_task_reports(i)
            # Preserve C04's immediate reaction to received conflict, without
            # waiting for the ordinary minimum dwell/reconsideration gates.
            if conflict and not force:
                utilities = self._masked_task_utilities(i, reservations)
                if not np.any(np.isfinite(utilities)):
                    self.c06_task_metrics['region_no_candidate'] += 1
                    continue
                new = int(np.argmax(utilities))
                if new != target:
                    self.targets[i] = new
                    self.target_since[i] = self.time
                    self.next_reconsider_at[i] = self.time+m.decision_interval_s
                    self.c04_task_metrics['received_conflict_retargets'] += 1
                    self.c04_task_events.append(dict(time=float(self.time), auv=i+1,
                        event='received_conflict_retarget', old_target=target, new_target=new))
                    self.c06_task_metrics['region_conflict_retargets'] += 1
                    self.c06_task_events.append(dict(time=float(self.time), auv=i+1,
                        event='received_region_retarget', old_target=target, new_target=new,
                        masked_targets=sorted(reservations)))
                continue
            elapsed = self.time-self.target_since[i]
            if not force and self.time < self.next_reconsider_at[i]:
                continue
            estimate = self._queue_forecast(i)
            empty = estimate[target] < m.queue_empty_packets*c.data_packet_bits
            if not (force or elapsed >= c.target_max_dwell or
                    (elapsed >= c.target_min_dwell and (empty or conflict))):
                continue
            # Unlike C04's normal-choice soft penalty, every actual received
            # reservation is a hard task mask on this branch too.
            utilities = self._masked_task_utilities(i, reservations)
            if not np.any(np.isfinite(utilities)):
                self.c06_task_metrics['region_no_candidate'] += 1
                continue
            new = int(np.argmax(utilities))
            self.advice_metrics['target_reconsiderations'] += 1
            self.next_reconsider_at[i] = self.time+m.decision_interval_s
            if new != target or force:
                self.targets[i] = new
                self.target_since[i] = self.time
                if not force:
                    self.advice_metrics['actual_target_changes'] += 1
            if reservations:
                self.c06_task_metrics['ordinary_region_masked_decisions'] += 1

    def _info(self):
        info = super()._info()
        if self._region_active():
            info['task_region_diagnostics'] = dict(self.c06_task_metrics)
        return info
