"""V6 C06: received-intent service overlap exclusion and conflict COORD priority."""

