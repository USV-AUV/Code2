"""C06: bounded, root-local priority for a causally known task conflict.

This changes only the ordering of already queued COORD frames.  It neither
allocates slots nor creates packets, grants, remote observations or ACKs.  The
existing STATE.service.coord_source_time is usable only when it names a COORD
that this root actually transmitted with the relevant conflict evidence.
"""
import math
from numbers import Integral, Real

import numpy as np

from v6_candidates.c04.mac import (
    DynamicMacNetwork as ParentDynamicMacNetwork,
    FixedStarMacNetwork as ParentFixedStarMacNetwork,
    MacOptions, SlotLease, ChildLease, MAC_BITS,
)


CONFLICT_NOTIFICATION_BONUS = 2.0


def _finite(value):
    return (isinstance(value, Real) and not isinstance(value, bool)
            and math.isfinite(float(value)))


class _ConflictMixin:
    def __init__(self, cfg, *args, intent_enabled=True, sensor_positions=None, **kwargs):
        get = cfg.get if isinstance(cfg, dict) else lambda name, default: getattr(cfg, name, default)
        radius, separation = get('collection_radius', 6.), get('min_separation', 3.)
        if not _finite(radius) or radius <= 0 or not _finite(separation) or separation < 0:
            raise ValueError('Conflict geometry requires positive radius and nonnegative separation')
        self.conflict_radius = 2. * float(radius) + float(separation)
        self._conflict_root_epochs = {}
        self._conflict_epoch_counter = 0
        self.conflict_coord_history = {}
        self._conflict_tx_context = None
        super().__init__(cfg, *args, intent_enabled=intent_enabled, **kwargs)
        self.sensor_positions = None
        if sensor_positions is not None:
            positions = np.array(sensor_positions, dtype=float, copy=True)
            if positions.shape != (self.n_nodes-self.n_auvs-1, 2) or not np.isfinite(positions).all():
                raise ValueError('sensor_positions must be the finite public (n_sensors, 2) map')
            positions.setflags(write=False)
            self.sensor_positions = positions

    def _conflict_target(self, payload):
        if not isinstance(payload, dict):
            return None
        target = payload.get('target')
        if (not isinstance(target, Integral) or isinstance(target, bool)
                or not 0 <= target < self.n_nodes-self.n_auvs-1):
            return None
        return int(target)

    def _conflict_fresh(self, payload):
        if self._conflict_target(payload) is None:
            return False
        stamp = payload.get('source_time')
        return (_finite(stamp) and float(stamp) >= 0.
                and 0. <= self.time-float(stamp) <= self.state_ttl)

    def _conflict_root_payload(self, node):
        # receive_cache[0] contains only packets actually accepted at the USV.
        delivery = self.received_states.get(node)
        if (delivery is None or delivery.receiver != 0 or delivery.packet.src != node
                or delivery.packet.dst != 0 or delivery.packet.kind != 'STATE'):
            return None
        payload = delivery.packet.payload
        return payload if self._conflict_fresh(payload) else None

    def _conflict_note_root_state(self, node, payload):
        target = self._conflict_target(payload)
        stamp = payload.get('source_time') if isinstance(payload, dict) else None
        old = self._conflict_root_epochs.get(node)
        if old is None or old['target'] != target:
            self._conflict_epoch_counter += 1
            self._conflict_root_epochs[node] = dict(target=target,
                epoch=self._conflict_epoch_counter,
                since=float(stamp) if _finite(stamp) else math.inf)

    def _receive(self, packet, receiver, transmitter):
        if not self.intent_enabled or receiver != 0 or packet.kind != 'STATE':
            return super()._receive(packet, receiver, transmitter)
        before = self.received_states.get(packet.src)
        result = super()._receive(packet, receiver, transmitter)
        after = self.received_states.get(packet.src)
        if after is not None and after is not before:
            self._conflict_note_root_state(packet.src, after.packet.payload)
        return result

    def _conflict_overlaps(self, left, right):
        if left == right:
            return True
        return (self.sensor_positions is not None and
                np.linalg.norm(self.sensor_positions[left]-self.sensor_positions[right])
                <= self.conflict_radius)

    def _conflict_live_grant(self, payload):
        service = payload.get('service', {})
        expiry = service.get('grant_expires') if isinstance(service, dict) else None
        return _finite(expiry) and float(expiry) > self.time

    def _conflict_keys(self, packet):
        """Local-root conflicts supported by this actual queued COORD content.

        Epochs count only target changes observed at this root.  They are local
        bookkeeping, not transmitted fields or globally agreed reservations.
        Refreshing a STATE timestamp does not create a new task epoch.
        """
        if (not self.intent_enabled or packet.kind != 'COORD' or packet.src != 0
                or not 1 <= packet.dst <= self.n_auvs or not isinstance(packet.payload, dict)):
            return ()
        receiver = packet.dst
        own = self._conflict_root_payload(receiver)
        if own is None or self._conflict_live_grant(own):
            return ()
        states = packet.payload.get('states')
        stamp = packet.payload.get('source_time')
        if not isinstance(states, dict) or not _finite(stamp) or not 0 <= self.time-float(stamp) <= self.state_ttl:
            return ()
        self._conflict_note_root_state(receiver, own)
        own_epoch = self._conflict_root_epochs[receiver]
        keys = []
        for peer in range(1, self.n_auvs+1):
            if peer == receiver:
                continue
            current = self._conflict_root_payload(peer)
            carried = states.get(str(peer), states.get(peer))
            if current is None or not self._conflict_fresh(carried):
                continue
            self._conflict_note_root_state(peer, current)
            peer_epoch = self._conflict_root_epochs[peer]
            target = self._conflict_target(carried)
            if (target != peer_epoch['target'] or carried['source_time'] < peer_epoch['since']
                    or carried['source_time'] > stamp):
                continue
            if (self._conflict_overlaps(own_epoch['target'], target)
                    and (peer < receiver or self._conflict_live_grant(carried))):
                keys.append((receiver, own_epoch['epoch'], own_epoch['target'],
                             peer, peer_epoch['epoch'], target))
        return tuple(keys)

    def _conflict_prune_history(self):
        for receiver in list(self.conflict_coord_history):
            history = self.conflict_coord_history[receiver]
            for stamp in list(history):
                if self.time-history[stamp]['sent_at'] > self.state_ttl:
                    del history[stamp]
            if not history:
                del self.conflict_coord_history[receiver]

    def _conflict_acknowledged(self, receiver, key):
        own = self._conflict_root_payload(receiver)
        if own is None:
            return False
        service = own.get('service', {})
        ack = service.get('coord_source_time') if isinstance(service, dict) else None
        if not _finite(ack) or not 0 <= float(ack) <= own['source_time']:
            return False
        record = self.conflict_coord_history.get(receiver, {}).get(float(ack))
        # Exact stamp -> emitted evidence lookup, not an arbitrary newer ACK.
        # A source sample generated before actual TX cannot acknowledge it.
        return bool(record and not record['ambiguous'] and key in record['keys']
                    and own['source_time'] >= record['sent_at']
                    and self.time-record['sent_at'] <= self.state_ttl)

    def _conflict_needs_notification(self, packet):
        self._conflict_prune_history()
        return any(not self._conflict_acknowledged(packet.dst, key)
                   for key in self._conflict_keys(packet))

    def _application_rank(self, owner, index):
        rank = super()._application_rank(owner, index)
        if (self.intent_enabled and owner == 0
                and self._conflict_needs_notification(self._queues[owner][index].packet)):
            return (rank[0]+CONFLICT_NOTIFICATION_BONUS, *rank[1:])
        return rank

    def _pop_queue(self, owner):
        item = super()._pop_queue(owner)
        context = self._conflict_tx_context
        if self.intent_enabled and context is not None and context['owner'] == owner:
            context['item'] = item
        return item

    def _transmit_slot(self, owner, positions):
        if not self.intent_enabled or owner != 0:
            return super()._transmit_slot(owner, positions)
        previous = self._conflict_tx_context
        context = {'owner': owner, 'item': None}
        self._conflict_tx_context = context
        before = self.metrics['transmissions']
        try:
            result = super()._transmit_slot(owner, positions)
        finally:
            self._conflict_tx_context = previous
        item = context['item']
        if self.metrics['transmissions']-before == 1 and item is not None:
            packet = item.packet
            if packet.kind == 'COORD' and packet.src == 0 and isinstance(packet.payload, dict):
                stamp = packet.payload.get('source_time')
                if _finite(stamp) and 0 <= self.time-float(stamp) <= self.state_ttl:
                    self._conflict_prune_history()
                    keys = self._conflict_keys(packet)
                    needed = any(not self._conflict_acknowledged(packet.dst, key) for key in keys)
                    history = self.conflict_coord_history.setdefault(packet.dst, {})
                    old = history.get(float(stamp))
                    # Reusing an envelope timestamp for inconsistent evidence
                    # makes its cumulative ACK ambiguous; fail conservatively.
                    if old is None:
                        history[float(stamp)] = dict(sent_at=float(self.time), keys=keys, ambiguous=False)
                    elif old['keys'] != keys:
                        old['ambiguous'] = True
                    self.metrics['v6_conflict_coord_transmissions'] += int(bool(keys))
                    self.metrics['v6_conflict_unacknowledged_transmissions'] += int(needed)
        return result


class DynamicMacNetwork(_ConflictMixin, ParentDynamicMacNetwork):
    """C04 dynamic MAC with bounded root-local conflict notification priority."""


class FixedStarMacNetwork(_ConflictMixin, ParentFixedStarMacNetwork):
    """The identical C06 scheduler on the fixed-star topology."""
