"""Baseline-only frozen inference; no full-method checkpoint impersonation."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from usv_auv.actions import normalized_action_schema, physical_commands
from usv_auv.config import Config
from usv_auv.deploy import config_fingerprint, environment_schema
from usv_auv.learning import _mask, mlp, resolve_device
from .methods import get_method


TRAINING_FORMAT = "usv-auv-baseline-training-v1"
INFERENCE_FORMAT = "usv-auv-baseline-inference-v1"


def source_hashes():
    root = Path(__file__).resolve().parents[1]
    actual = {name: {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                     for path in sorted((root / name).glob("*.py"))}
              for name in ("usv_auv", "baselines")}
    from english_source_compat import project_baseline_source_hashes
    return project_baseline_source_hashes(actual)


def load_checkpoint(path):
    """Only load trusted local project artifacts; torch pickle is executable."""
    return torch.load(Path(path), map_location="cpu", weights_only=False)


def validate_checkpoint(checkpoint, method_id=None, verify_sources=False):
    if checkpoint.get("format") not in (TRAINING_FORMAT, INFERENCE_FORMAT):
        raise ValueError("Not a baseline checkpoint; full-method checkpoints are not accepted")
    saved_method = checkpoint["method_id"]
    if method_id is not None and saved_method != method_id:
        raise ValueError("Checkpoint baseline method does not match requested method")
    method = get_method(saved_method)
    if checkpoint["method_spec"] != method.to_dict() or checkpoint["method_fingerprint"] != method.fingerprint:
        raise ValueError("Baseline method definition or fingerprint changed")
    config = checkpoint["environment_config"]
    if config_fingerprint(config) != checkpoint["config_fingerprint"]:
        raise ValueError("Baseline environment fingerprint is inconsistent")
    cfg = Config.from_dict(config)
    if cfg.to_dict() != config:
        raise ValueError("Baseline checkpoint must preserve a complete unmodified environment configuration")
    schema = normalized_action_schema(checkpoint["observation_schema"], cfg.action_frame)
    if schema != checkpoint["observation_schema"]:
        raise ValueError("Baseline checkpoints require explicit action encoding")
    from usv_auv.observations import SCHEMA_VERSION, observation_fields, root_observation_fields
    if (schema.get("version") != SCHEMA_VERSION or schema.get("fields") != observation_fields(cfg.n_auv)
            or schema.get("slow_fields") != root_observation_fields(cfg.n_auv)):
        raise ValueError("Baseline observation field order/version does not match the implementation")
    if bool(checkpoint.get("topology") is not None) != bool(method.use_topology):
        raise ValueError("Checkpoint topology network presence disagrees with its method")
    if len(checkpoint["agents"]) != cfg.n_auv or schema["n_auv"] != cfg.n_auv:
        raise ValueError("Baseline checkpoint AUV count mismatch")
    for state in checkpoint["agents"]:
        if state["observation_dim"] != schema["observation_dim"] or state["action_dim"] != 2:
            raise ValueError("Actor dimensions do not match baseline observation/action schema")
    if verify_sources and checkpoint["source_hashes"] != source_hashes():
        raise ValueError("Frozen baseline/core source hashes no longer match")
    return method, cfg, schema


def inference_payload(checkpoint):
    validate_checkpoint(checkpoint)
    keys = ("method_id", "method_spec", "method_fingerprint", "environment_config", "config_fingerprint",
            "observation_schema", "learning_config", "training_options", "global_step", "seed", "run_id",
            "source_hashes", "budget_semantics")
    result = {key: checkpoint[key] for key in keys}
    result.update(format=INFERENCE_FORMAT,
                  agents=[{key: state[key] for key in ("actor", "observation_dim", "action_dim")}
                          for state in checkpoint["agents"]],
                  topology=({key: checkpoint["topology"][key] for key in ("online", "observation_dim", "n_actions")}
                            if checkpoint["topology"] is not None else None),
                  scope="Simulation-only baseline inference; not a TMC paper reproduction or sea-trial controller")
    return result


class BaselinePolicy:
    def __init__(self, checkpoint, device="cuda", method_id=None, verify_sources=False):
        self.method, self.cfg, self.schema = validate_checkpoint(checkpoint, method_id, verify_sources)
        self.device = resolve_device(device)
        self.checkpoint = checkpoint
        self.environment_config = checkpoint["environment_config"]
        self.config_fingerprint = checkpoint["config_fingerprint"]
        self.action_frame = self.cfg.action_frame
        hidden = checkpoint["learning_config"]["hidden_dim"]
        self.actors = []
        for saved in checkpoint["agents"]:
            actor = mlp(saved["observation_dim"], 2, hidden, True).to(self.device)
            actor.load_state_dict(saved["actor"])
            actor.eval().requires_grad_(False)
            self.actors.append(actor)
        self.topology = None
        if self.method.use_topology:
            saved = checkpoint["topology"]
            if saved["observation_dim"] != self.schema["slow_observation_dim"] or saved["n_actions"] != self.schema["topology_actions"]:
                raise ValueError("Topology network dimensions do not match schema")
            self.topology = mlp(saved["observation_dim"], saved["n_actions"], hidden).to(self.device)
            self.topology.load_state_dict(saved["online"])
            self.topology.eval().requires_grad_(False)

    @classmethod
    def from_checkpoint(cls, path, device="cuda", method_id=None, verify_sources=False):
        return cls(load_checkpoint(path), device, method_id, verify_sources)

    def validate_environment(self, env):
        actual_method = getattr(env, "method", None)
        if (actual_method is None or getattr(actual_method, "method_id", None) != self.method.method_id
                or getattr(actual_method, "fingerprint", None) != self.method.fingerprint):
            raise ValueError("Environment method identity does not match this baseline policy")
        if env.cfg.to_dict() != self.environment_config:
            raise ValueError("Evaluation environment differs from baseline checkpoint")
        if environment_schema(env) != self.schema:
            raise ValueError("Baseline observation fields, dimensions, candidate order or action encoding changed")

    def bind_environment(self, env):
        self.validate_environment(env)
        env.set_response_policy(self.act)

    def act(self, observations):
        observations = np.asarray(observations, dtype=np.float32)
        if observations.shape != (len(self.actors), self.schema["observation_dim"]) or not np.all(np.isfinite(observations)):
            raise ValueError("Invalid baseline decision observations")
        with torch.inference_mode():
            return np.stack([actor(torch.as_tensor(observations[i], device=self.device)).cpu().numpy()
                             for i, actor in enumerate(self.actors)]).astype(np.float32)

    def topology_action(self, state, mask):
        if self.topology is None:
            return None  # Fixed-star BaselineEnv owns its unchanged installation.
        valid = _mask(mask, self.schema["topology_actions"])
        values = np.asarray(state, dtype=np.float32)
        if values.shape != (self.schema["slow_observation_dim"],) or not np.all(np.isfinite(values)):
            raise ValueError("Invalid baseline slow observations")
        with torch.inference_mode():
            q = self.topology(torch.as_tensor(values, device=self.device))
            return int(q.masked_fill(~torch.as_tensor(valid, device=self.device), -torch.inf).argmax().item())

    def physical_commands(self, normalized_actions, observations):
        return physical_commands(normalized_actions, self.cfg.max_speed, self.cfg.action_frame, observations)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--method")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--verify-sources", action="store_true")
    parser.add_argument("--input", type=Path, help="Optional JSONL telemetry; without it performs a bounded load check")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-records", type=int, default=60)
    args = parser.parse_args()
    if not 1 <= args.max_records <= 1200:
        parser.error("--max-records must be between 1 and 1200")
    policy = BaselinePolicy.from_checkpoint(args.checkpoint, args.device, args.method, args.verify_sources)
    if args.input is None:
        print(json.dumps({"status": "loaded", "method_id": policy.method.method_id, "device": str(policy.device),
                          "global_step": policy.checkpoint["global_step"], "actors": len(policy.actors),
                          "topology_network": policy.topology is not None}, ensure_ascii=True))
        return
    if args.output is None or args.output.exists() or args.output.resolve() == args.input.resolve():
        parser.error("Telemetry inference requires a new distinct --output file")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.input.open(encoding="utf-8") as source, args.output.open("x", encoding="utf-8") as target:
        for index, line in enumerate(source):
            if index >= args.max_records:
                break
            item = json.loads(line)
            if item.get("method_id") != policy.method.method_id or item.get("method_fingerprint") != policy.method.fingerprint:
                raise ValueError("Telemetry does not declare the matching baseline method")
            if item.get("observation_schema") != policy.schema or item.get("config_fingerprint") != policy.config_fingerprint:
                raise ValueError("Telemetry schema/configuration mismatch")
            observations = item["observations"]
            actions = policy.act(observations)
            result = {"actions": actions.tolist(), "method_id": policy.method.method_id,
                      "topology_action": policy.topology_action(item["slow_state"], item["mask"])
                          if "slow_state" in item else None,
                      **{key: value.tolist() for key, value in policy.physical_commands(actions, observations).items()}}
            target.write(json.dumps(result, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
