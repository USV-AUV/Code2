"""Immutable method identities; physical/learning configuration is separate."""
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = PROJECT_ROOT / "runs/research_collection_v2_1m_20260909/frozen_config.json"
ADAPTER_VERSION = "matched-collection-v2-baselines-v1"


@dataclass(frozen=True)
class MethodSpec:
    method_id: str
    name: str
    use_usde: bool
    use_topology: bool
    planner_kind: str
    use_phase: bool
    category: str
    adapter_version: str = ADAPTER_VERSION

    def to_dict(self):
        return asdict(self)

    @property
    def fingerprint(self):
        raw = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


_METHODS = (
    MethodSpec("synchronous_fim_rl", "Synchronous FIM+RL (matched)", False, False,
               "synchronous_fim", False, "external_matched_adaptation"),
    MethodSpec("communication_aware_tmc", "Communication-Aware TMC (matched)", False, False,
               "actor_response_fim", True, "external_matched_adaptation"),
    MethodSpec("topology_only", "+Topology Reconfiguration (without USDE)", False, True,
               "current", True, "proposed_method_ablation"),
    MethodSpec("usde_only", "+Disturbance Rejection (USDE without reconfiguration)", True, False,
               "current", True, "proposed_method_ablation"),
)
METHOD_IDS = tuple(item.method_id for item in _METHODS)


def get_method(method_id):
    if isinstance(method_id, MethodSpec):
        canonical = get_method(method_id.method_id)
        if canonical != method_id:
            raise ValueError("A method specification cannot override its registered identity")
        return canonical
    for spec in _METHODS:
        if spec.method_id == method_id:
            return spec
    raise ValueError(f"Unknown baseline {method_id!r}; choose one of {METHOD_IDS}")
