"""Matched external-method adaptations and clean CollectionV2 ablations.

This package deliberately does not edit or replace the frozen usv_auv package.
"""
