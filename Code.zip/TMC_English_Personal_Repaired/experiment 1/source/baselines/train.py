"""Bounded baseline training with reused TD3/DDQN mathematics and fresh outputs."""
from __future__ import annotations

import argparse
import copy
from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import tempfile
import time
import uuid

import numpy as np
import torch

from usv_auv.config import Config
from usv_auv.deploy import environment_schema
from usv_auv.learning import LearningConfig, MaskedDoubleDQN, TD3Agent, resolve_device, restore_rng, rng_state, seed_all
from usv_auv.train import PhaseSchedule, atomic_json, atomic_save, json_safe, require_finite, store_completed_macro
from .deploy import TRAINING_FORMAT, inference_payload, load_checkpoint, source_hashes, validate_checkpoint
from .methods import DEFAULT_CONFIG, METHOD_IDS, get_method


@dataclass(frozen=True)
class TrainingOptions:
    batch_size: int
    topology_batch_size: int
    replay_capacity: int
    topology_capacity: int
    warmup_steps: int
    td3_pretrain_steps: int
    topology_pretrain_steps: int
    alternating_block_steps: int
    action_noise: float

    def validate(self, period):
        for name in ("batch_size", "topology_batch_size", "replay_capacity", "topology_capacity"):
            if type(getattr(self, name)) is not int or getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.replay_capacity < self.batch_size or self.topology_capacity < self.topology_batch_size:
            raise ValueError("Replay capacity must cover the batch size")
        if self.warmup_steps < 0 or not np.isfinite(self.action_noise) or self.action_noise < 0:
            raise ValueError("Invalid warmup or exploration setting")
        for name in ("td3_pretrain_steps", "topology_pretrain_steps", "alternating_block_steps"):
            if getattr(self, name) < 1 or getattr(self, name) % period:
                raise ValueError("Schedule blocks must be positive multiples of slow_period")


def module_digest(module):
    result = hashlib.sha256()
    for key, tensor in sorted(module.state_dict().items()):
        result.update(key.encode())
        result.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return result.hexdigest()


def parameter_digests(agents, topology):
    return {"actors": [module_digest(agent.actor) for agent in agents],
            "critics": [module_digest(agent.critic) for agent in agents],
            "topology_online": module_digest(topology.online) if topology is not None else None,
            "topology_target": module_digest(topology.target) if topology is not None else None}


def save_checkpoint_bundle(checkpoint, output, milestone=False):
    """Atomic individual latest files, or an immutable atomically published milestone directory."""
    output = Path(output)
    if not milestone:
        atomic_save(checkpoint, output / "checkpoint_latest.pt")
        atomic_save(inference_payload(checkpoint), output / "policy_inference.pt")
        return None
    step = checkpoint["global_step"]
    if type(step) is not int or step < 1:
        raise ValueError("Milestone global step must be a positive integer")
    destination = output / "milestones" / f"step_{step:07d}"
    if destination.exists():
        raise FileExistsError("Refusing to overwrite a baseline milestone")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f".step_{step:07d}_", dir=destination.parent) as temporary:
        staging = Path(temporary)
        atomic_save(checkpoint, staging / "checkpoint.pt")
        atomic_save(inference_payload(checkpoint), staging / "policy.pt")
        files = {name: {"bytes": (staging / name).stat().st_size,
                        "sha256": hashlib.sha256((staging / name).read_bytes()).hexdigest()}
                 for name in ("checkpoint.pt", "policy.pt")}
        metadata = {"format": "usv-auv-baseline-milestone-v1", "global_step": step,
                    "run_id": checkpoint["run_id"], "method_id": checkpoint["method_id"],
                    "method_spec": checkpoint["method_spec"], "method_fingerprint": checkpoint["method_fingerprint"],
                    "config_fingerprint": checkpoint["config_fingerprint"],
                    "observation_schema": checkpoint["observation_schema"],
                    "training_options": checkpoint["training_options"], "training_stage": checkpoint.get("training_stage"),
                    "files": files}
        atomic_json(metadata, staging / "metadata.json")
        if destination.exists():
            raise FileExistsError("Milestone destination appeared while publishing")
        os.rename(staging, destination)
    return {"global_step": step, "directory": str(destination.resolve()),
            "method_id": checkpoint["method_id"], "method_fingerprint": checkpoint["method_fingerprint"],
            "config_fingerprint": checkpoint["config_fingerprint"], "files": files}


def deterministic_response(agents):
    """Root response uses only received supplied observations, never live env."""
    def act(batch):
        batch = np.asarray(batch, dtype=np.float32)
        if batch.shape != (len(agents), agents[0].observation_dim) or not np.isfinite(batch).all():
            raise ValueError("Actor-response observation batch is invalid")
        # noise_std=0 avoids both global and per-agent random-number draws.
        return np.stack([agent.act(batch[i], 0.) for i, agent in enumerate(agents)])
    return act


def gpu_diagnostics(agents, topology, device):
    modules = [module for agent in agents for module in (agent.actor, agent.critic, agent.actor_target, agent.critic_target)]
    if topology is not None:
        modules.extend((topology.online, topology.target))
    parameter_devices = sorted({str(parameter.device) for module in modules for parameter in module.parameters()})
    optimizers = [optimizer for agent in agents for optimizer in (agent.actor_optimizer, agent.critic_optimizer)]
    if topology is not None:
        optimizers.append(topology.optimizer)
    moment_devices, scalar_devices = set(), set()
    populated = 0
    for optimizer in optimizers:
        populated += bool(optimizer.state)
        for state in optimizer.state.values():
            for key, value in state.items():
                if isinstance(value, torch.Tensor):
                    (scalar_devices if key == "step" and value.numel() == 1 else moment_devices).add(str(value.device))
    if device.type == "cuda":
        if any(not name.startswith("cuda") for name in parameter_devices + list(moment_devices)):
            raise RuntimeError("Baseline networks or Adam moments unexpectedly left CUDA")
    return {"requested_device": str(device), "parameter_devices": parameter_devices,
            "optimizer_moment_devices": sorted(moment_devices), "optimizer_scalar_step_devices": sorted(scalar_devices),
            "populated_optimizers": populated, "optimizer_count": len(optimizers),
            "note": "Adam scalar step counters may be CPU in non-capturable mode; parameters and optimizer moments must be CUDA"}


def options_from_args(cfg, args, saved=None):
    defaults = {"batch_size": cfg.batch_size, "topology_batch_size": 8, "replay_capacity": cfg.replay_size,
                "topology_capacity": 5000, "warmup_steps": cfg.warmup_steps,
                "td3_pretrain_steps": cfg.td3_pretrain_steps, "topology_pretrain_steps": cfg.topology_pretrain_steps,
                "alternating_block_steps": cfg.alternating_block_steps, "action_noise": cfg.exploration_noise}
    values = dict(saved["training_options"]) if saved else defaults
    for key in values:
        override = getattr(args, key, None)
        if override is not None:
            if saved and override != values[key]:
                raise ValueError(f"Cannot change {key} when resuming a baseline checkpoint")
            values[key] = override
    result = TrainingOptions(**values)
    result.validate(cfg.slow_period)
    return result


def train(args):
    from .environment import BaselineEnv
    if not 1 <= args.steps or (args.steps > 200 and not args.allow_long_run):
        raise ValueError("Default bounded run is at most 200 steps; longer explicit runs require --allow-long-run")
    if args.log_every < 1:
        raise ValueError("log_every must be positive")
    if args.checkpoint_every < 1:
        raise ValueError("checkpoint_every must be positive")
    if any(type(step) is not int or step < 1 for step in args.milestones) or len(set(args.milestones)) != len(args.milestones):
        raise ValueError("Milestones must be distinct positive integer steps")
    output = Path(args.output).resolve()
    if output.exists():
        raise FileExistsError("Use a new baseline run directory, including on resume")
    device = resolve_device(args.device)
    if device.type != "cuda":
        raise ValueError("Baseline training requires CUDA; CPU is only for non-training unit checks/evaluation")
    saved = load_checkpoint(args.resume) if args.resume else None
    method = get_method(args.method)
    if saved:
        if saved.get("format") != TRAINING_FORMAT:
            raise ValueError("Resume requires a full baseline training checkpoint")
        validate_checkpoint(saved, args.method, args.verify_sources)
    milestones = sorted(set(args.milestones) | set(saved.get("milestones", []) if saved else []))
    saved_milestones = copy.deepcopy(saved.get("saved_milestones", [])) if saved else []
    raw_config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    cfg = Config.from_dict(raw_config)
    if cfg.to_dict() != raw_config:
        raise ValueError("Use the complete original frozen config; learning overrides are separate TrainingOptions")
    if saved and saved["environment_config"] != raw_config:
        raise ValueError("Resume cannot change the physical environment configuration")
    options = options_from_args(cfg, args, saved)
    learning = LearningConfig(hidden_dim=cfg.hidden_dim, gamma=cfg.gamma, tau=cfg.tau,
        actor_lr=cfg.learning_rate, critic_lr=cfg.learning_rate, topology_lr=cfg.learning_rate,
        policy_noise=cfg.policy_noise, noise_clip=cfg.noise_clip, policy_delay=cfg.policy_delay,
        batch_size=options.batch_size, topology_batch_size=options.topology_batch_size,
        replay_capacity=options.replay_capacity, topology_capacity=options.topology_capacity)
    if saved and saved["learning_config"] != asdict(learning):
        raise ValueError("Resume learning configuration disagrees with its immutable options/environment")
    seed = saved["seed"] if saved else (cfg.seed if args.seed is None else args.seed)
    if saved and args.seed is not None and args.seed != seed:
        raise ValueError("Resume cannot change the training seed")
    hashes = source_hashes()
    seed_all(seed)
    env = BaselineEnv(cfg, args.method)
    episode = int(saved["episode"]) + 1 if saved else 0
    observations, info = env.reset(seed=seed + episode)
    observations = np.asarray(observations, np.float32)
    schema = environment_schema(env)
    if saved and saved["observation_schema"] != schema:
        raise ValueError("Resume baseline observation schema or topology candidate order differs")
    agents = [TD3Agent(schema["observation_dim"], 2, learning, str(device), seed + 101 * (i + 1))
              for i in range(cfg.n_auv)]
    topology = (MaskedDoubleDQN(schema["slow_observation_dim"], schema["topology_actions"], learning,
                               str(device), seed + 10001) if method.use_topology else None)
    schedule = PhaseSchedule(options.td3_pretrain_steps, options.topology_pretrain_steps, options.alternating_block_steps)
    global_step = int(saved["global_step"]) if saved else 0
    slow_decisions = int(saved.get("slow_decisions", 0)) if saved else 0
    phase = saved["training_stage"] if saved else (schedule.phase(global_step) if topology is not None else "td3_every_fast_step")
    discarded = int(saved.get("discarded_partial_macros", 0)) if saved else 0
    exploration_rng = np.random.default_rng(seed + 33333)
    if saved:
        for agent, state in zip(agents, saved["agents"]):
            agent.load_state_dict(state)
        if topology is not None:
            topology.load_state_dict(saved["topology"])
        restore_rng(saved["rng"])
        exploration_rng.bit_generator.state = saved["exploration_rng"]
        if saved.get("pending_slow") is not None:
            discarded += 1
    env.set_response_policy(deterministic_response(agents))
    initial_digests = saved["initial_parameter_digests"] if saved else parameter_digests(agents, topology)
    invocation_initial = parameter_digests(agents, topology)
    initial_updates = [agent.updates for agent in agents]
    initial_topology_updates = topology.updates if topology is not None else 0
    run_id = saved["run_id"] if saved else str(uuid.uuid4())
    budget_semantics = ("same phase schedule as full method; TD3 and topology alternate; report actual gradient updates"
                        if topology is not None else "TD3 updates on every post-warmup fast step; same environment steps do NOT equal full-method gradient/compute budget")
    output.mkdir(parents=True)
    atomic_json(raw_config, output / "frozen_config.json")
    atomic_json(hashes, output / "source_hashes.json")
    pending = None
    latest_losses = {}
    episode_return = 0.
    started = time.monotonic()
    previous_elapsed = float(saved.get("elapsed_seconds", 0.)) if saved else 0.
    stop_at = global_step + args.steps
    manifest = {"method_id": method.method_id, "method_spec": method.to_dict(), "method_fingerprint": method.fingerprint,
        "config_fingerprint": cfg.fingerprint, "environment_config": raw_config, "observation_schema": schema,
        "training_options": asdict(options), "learning_config": asdict(learning), "source_hashes": hashes,
        "seed": seed, "run_id": run_id, "device": str(device), "gpu": torch.cuda.get_device_name(device),
        "torch": torch.__version__, "start_step": global_step, "additional_steps": args.steps,
        "target_step": stop_at, "budget_semantics": budget_semantics,
        "checkpoint_every": args.checkpoint_every, "milestones": milestones,
        "resume": str(Path(args.resume).resolve()) if args.resume else None,
        "resume_mode": "new_episode_learning_resume" if saved else "fresh",
        "scope": "bounded baseline implementation smoke unless a long run was explicitly authorized"}
    atomic_json(manifest, output / "manifest.json")

    def progress(status="running"):
        return {"status": status, "method_id": method.method_id, "global_step": global_step,
                "target_step": stop_at, "stage": phase, "td3_updates": [a.updates for a in agents],
                "actor_updates": [a.updates // learning.policy_delay for a in agents],
                "ddqn_updates": topology.updates if topology is not None else 0,
                "discarded_partial_macros": discarded, "losses": latest_losses,
                "saved_milestones": copy.deepcopy(saved_milestones),
                "elapsed_seconds": previous_elapsed + time.monotonic() - started,
                "info": json_safe(info), "budget_semantics": budget_semantics}

    def payload():
        return {"format": TRAINING_FORMAT, "method_id": method.method_id, "method_spec": method.to_dict(),
                "method_fingerprint": method.fingerprint, "environment_config": raw_config,
                "config_fingerprint": cfg.fingerprint, "observation_schema": schema,
                "training_options": asdict(options), "learning_config": asdict(learning),
                "agents": [agent.state_dict() for agent in agents],
                "topology": topology.state_dict() if topology is not None else None,
                "global_step": global_step, "episode": episode, "slow_decisions": slow_decisions,
                "training_stage": phase, "pending_slow": copy.deepcopy(pending),
                "discarded_partial_macros": discarded, "seed": seed, "run_id": run_id,
                "rng": rng_state(), "exploration_rng": copy.deepcopy(exploration_rng.bit_generator.state),
                "source_hashes": hashes, "initial_parameter_digests": initial_digests,
                "milestones": milestones, "saved_milestones": copy.deepcopy(saved_milestones),
                "checkpoint_every": args.checkpoint_every,
                "budget_semantics": budget_semantics, "elapsed_seconds": previous_elapsed + time.monotonic() - started,
                "resume_semantics": "new episode; learner/optimizers/replay/RNG retained; partial old macro discarded"}

    try:
        atomic_json(progress(), output / "progress.json")
        with (output / "training.jsonl").open("x", encoding="utf-8") as log:
            while global_step < stop_at:
                requested_topology = None
                if topology is not None and pending is None:
                    next_phase = schedule.phase(global_step)
                    if next_phase != phase:
                        for agent in agents:
                            agent.replay.clear()
                        topology.replay.clear()
                        phase = next_phase
                    slow_state, mask = env.slow_state()
                    require_finite("slow state", slow_state)
                    if phase == "td3_curriculum":
                        choices = np.flatnonzero(mask)
                        if not len(choices):
                            raise ValueError("Empty topology mask")
                        requested_topology = int(choices[slow_decisions % len(choices)])
                    else:
                        epsilon = max(.05, .5 * np.exp(-topology.updates / 2000)) if phase in ("topology_only", "alternate_topology") else 0.
                        requested_topology = topology.act(slow_state, mask, epsilon)
                    pending = {"state": np.asarray(slow_state).copy(), "mask": np.asarray(mask).copy(),
                               "action": requested_topology, "reward": 0., "duration": 0}
                    slow_decisions += 1
                update_td3 = topology is None or phase in ("td3_curriculum", "alternate_td3")
                update_topology = topology is not None and phase in ("topology_only", "alternate_topology")
                if global_step < options.warmup_steps and update_td3:
                    actions = exploration_rng.uniform(-1., 1., (cfg.n_auv, 2)).astype(np.float32)
                else:
                    actions = np.stack([agent.act(observations[i], options.action_noise if update_td3 else 0.)
                                        for i, agent in enumerate(agents)])
                original_actions = actions.copy()
                require_finite("actions", original_actions)
                next_observations, reward, terminated, truncated, info = env.step(actions.copy(), topology_action=requested_topology)
                next_observations = np.asarray(next_observations, np.float32)
                require_finite("next observations", next_observations)
                require_finite("reward", reward)
                for i, agent in enumerate(agents):
                    agent.replay.add(observations[i], original_actions[i], float(reward), next_observations[i],
                                     bool(terminated), bool(truncated))
                    if update_td3 and global_step >= options.warmup_steps:
                        losses = agent.update()
                        require_finite("TD3 losses", losses)
                        latest_losses.update({f"auv_{i}_{key}": value for key, value in losses.items()})
                if pending is not None:
                    pending["reward"] += learning.gamma ** pending["duration"] * float(reward)
                    pending["duration"] += 1
                global_step += 1
                episode_return += float(reward)
                observations = next_observations
                if pending is not None and (pending["duration"] == cfg.slow_period or terminated or truncated):
                    if store_completed_macro(pending["duration"], cfg.slow_period, bool(terminated), bool(truncated)):
                        next_slow, next_mask = env.slow_state()
                        topology.replay.add(pending["state"], pending["mask"], pending["action"], pending["reward"],
                                            next_slow, next_mask, pending["duration"], learning.gamma,
                                            bool(terminated), bool(truncated))
                        if update_topology:
                            losses = topology.update()
                            require_finite("DDQN losses", losses)
                            latest_losses.update(losses)
                    else:
                        discarded += 1
                    pending = None
                if terminated or truncated:
                    log.write(json.dumps({"event": "episode_end", "global_step": global_step, "episode": episode,
                        "return": episode_return, "terminated": bool(terminated), "truncated": bool(truncated),
                        "info": json_safe(info)}, ensure_ascii=False, allow_nan=False) + "\n")
                    episode += 1
                    observations, _ = env.reset(seed=seed + episode)
                    observations = np.asarray(observations, np.float32)
                    # Rebind defensively: reset must not allow a stale planner callback.
                    env.set_response_policy(deterministic_response(agents))
                    episode_return = 0.
                if global_step in milestones or global_step % args.checkpoint_every == 0:
                    snapshot = payload()
                    if global_step in milestones:
                        published = save_checkpoint_bundle(snapshot, output, milestone=True)
                        saved_milestones.append(published)
                    if global_step % args.checkpoint_every == 0:
                        # Refresh saved milestone provenance after publication.
                        save_checkpoint_bundle(payload(), output)
                if global_step % args.log_every == 0 or global_step == stop_at:
                    record = progress()
                    log.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
                    log.flush()
                    atomic_json(record, output / "progress.json")
                    print(json.dumps({key: value for key, value in record.items() if key != "info"}, ensure_ascii=True), flush=True)
        final_hashes = source_hashes()
        if final_hashes["usv_auv"] != hashes["usv_auv"]:
            raise RuntimeError("Core source files changed during baseline training")
        if args.verify_sources and final_hashes != hashes:
            raise RuntimeError("Frozen baseline source files changed during training")
        gpu = gpu_diagnostics(agents, topology, device)
        final_digests = parameter_digests(agents, topology)
        final = payload()
        save_checkpoint_bundle(final, output)
        summary = {**progress("completed"), "gpu_diagnostics": gpu, "initial_parameter_digests": initial_digests,
            "invocation_initial_parameter_digests": invocation_initial, "final_parameter_digests": final_digests,
            "actors_changed_from_initial": [a != b for a, b in zip(initial_digests["actors"], final_digests["actors"])],
            "critics_changed_from_initial": [a != b for a, b in zip(initial_digests["critics"], final_digests["critics"])],
            "actors_changed_this_invocation": [a != b for a, b in zip(invocation_initial["actors"], final_digests["actors"])],
            "critics_changed_this_invocation": [a != b for a, b in zip(invocation_initial["critics"], final_digests["critics"])],
            "topology_changed_this_invocation": (invocation_initial["topology_online"] != final_digests["topology_online"] if topology else None),
            "td3_updates_this_invocation": [agent.updates - initial for agent, initial in zip(agents, initial_updates)],
            "ddqn_updates_this_invocation": (topology.updates if topology else 0) - initial_topology_updates,
            "core_source_files_unchanged": True, "baseline_sources_unchanged": final_hashes["baselines"] == hashes["baselines"],
            "checkpoint": str(output / "checkpoint_latest.pt"), "inference": str(output / "policy_inference.pt"),
            "resume_mode": manifest["resume_mode"]}
        atomic_json(summary, output / "summary.json")
        atomic_json(progress("completed"), output / "progress.json")
        return summary
    except Exception as error:
        failed = progress("failed")
        failed["error"] = repr(error)
        try:
            atomic_json(failed, output / "progress.json")
        except (TypeError, ValueError):
            atomic_json({"status": "failed", "error": repr(error), "global_step": global_step}, output / "progress.json")
        raise
    finally:
        env.close()


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--method", required=True, choices=METHOD_IDS)
    result.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    result.add_argument("--output", required=True, type=Path)
    result.add_argument("--device", default="cuda")
    result.add_argument("--steps", type=int, default=200, help="Additional environment steps, including when resuming")
    result.add_argument("--allow-long-run", action="store_true", help="Explicitly remove the default 200-step smoke cap")
    result.add_argument("--resume", type=Path)
    result.add_argument("--verify-sources", action="store_true")
    result.add_argument("--seed", type=int)
    result.add_argument("--log-every", type=int, default=40)
    result.add_argument("--checkpoint-every", type=int, default=10000)
    result.add_argument("--milestones", nargs="*", type=int, default=[450000, 1000000],
                        help="Immutable exact global-step model directories; existing directories are never overwritten")
    for name in ("batch_size", "topology_batch_size", "replay_capacity", "topology_capacity", "warmup_steps",
                 "td3_pretrain_steps", "topology_pretrain_steps", "alternating_block_steps"):
        result.add_argument("--" + name.replace("_", "-"), type=int)
    result.add_argument("--action-noise", type=float)
    return result


def main():
    args = parser().parse_args()
    print(json.dumps(train(args), ensure_ascii=True, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
