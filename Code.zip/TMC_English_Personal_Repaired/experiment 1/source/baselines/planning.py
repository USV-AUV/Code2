"""Source-grounded FIM planners adapted to the unchanged physical simulator.

Sources: arXiv:2504.14894 Eq.(8); local TMC.pdf Eq.(24),(40)-(42);
360ZMEM/USV-AUV-colab and Hugh41/USV-AUV-delay. Independently implemented.
The historical implementation's actor-response map is candidate-independent.
No predictor below queries current AUV state, true flow, a sensor or an RNG.

sum(J_k) is a team geometry score, NOT the joint information matrix for the
distinct unknown positions of every AUV. logdet is a monotone D-optimal score.
Current measurement geometry and bounded finite candidates replace the old
phase-difference surrogate and unconstrained/teleporting differential search.
"""
from collections.abc import Mapping
import math

import numpy as np

from usv_auv.actions import decode_actions
from usv_auv.observations import observation_fields
from usv_auv.planner import PlanResult, PlannerConfig, reachable_candidates, usbl_position_fim


MOVEMENT_WEIGHT = 0.1
MOVEMENT_SCALE_M = 100.0


def _received(states, now, cfg):
    values = states.values() if isinstance(states, Mapping) else states
    valid = {}
    for state in values:
        if not 1 <= state.node_id <= cfg.n_auv:
            continue
        if not 0 <= now - state.source_time <= cfg.state_ttl:
            continue
        previous = valid.get(state.node_id)
        if previous is None or previous.source_time < state.source_time:
            valid[state.node_id] = state
    return valid


def source_response_positions(received, payloads, cfg, policy_callback):
    """One-step response p_tau + dt*u(pi(s_tau)), not a t+5s prediction.

Every s_tau is a source-time snapshot physically received in STATE. Missing
snapshots are omitted, never reconstructed from the live environment. Callback
uses current learned weights, without exploration or optimizer updates. The
padding row for a missing AUV is not used in any geometric prediction.
"""
    fields = observation_fields(cfg.n_auv)
    batch = np.zeros((cfg.n_auv, len(fields)), dtype=np.float32)
    included = {}
    for node, state in received.items():
        payload = payloads.get(node, payloads.get(str(node)))
        if not isinstance(payload, Mapping) or "policy_observation" not in payload:
            continue
        if float(payload.get("source_time", math.inf)) != state.source_time:
            raise ValueError("Policy snapshot and received state timestamps disagree")
        obs = np.asarray(payload["policy_observation"], dtype=np.float32)
        if obs.shape != (len(fields),) or not np.all(np.isfinite(obs)):
            raise ValueError("Malformed physically received policy snapshot")
        # A source with no USDE cannot secretly transmit an initialized estimate.
        for name in ("estimated_dx", "estimated_dy", "estimator_initialized"):
            if obs[fields.index(name)] != 0:
                raise ValueError("USDE is forbidden in the Communication-Aware baseline")
        batch[node - 1] = obs
        included[node] = state
    if not included:
        return {}
    if policy_callback is None:
        raise RuntimeError("Install the follower actor callback before running Communication-Aware planning")
    # Inputs are private copies; an accidental mutating callback cannot change
    # received buffers or silently alter the action's target-relative frame.
    actions = np.asarray(policy_callback(batch.copy()), dtype=float)
    if actions.shape != (cfg.n_auv, 2) or not np.isfinite(actions).all() or np.any(np.abs(actions) > 1.000001):
        raise ValueError("Follower callback must return finite normalized AUV actions")
    velocities = decode_actions(actions, cfg.max_speed, cfg.action_frame, batch)
    return {node: np.asarray(state.position).copy() + cfg.dt * velocities[node - 1]
            for node, state in included.items()}


def plan_baseline(current_position, now, horizon, states, cfg, kind,
                  policy_callback=None, policy_payloads=None):
    """Return a reachable USV target from delivered information only.

Synchronous: hold received positions as instantaneous geometry, replan each
fast tick, no phase input and no motion penalty. It is not an oracle link.
CA: source-snapshot actor response, replan each slow tick, movement penalty.
Both use the same physical FIM geometry, 33 nominal local candidates and speed
authority as the current simulator. No link truth or free measurements enter.
"""
    if kind not in ("synchronous_fim", "actor_response_fim"):
        raise ValueError("This planner implements only the two external matched methods")
    if not math.isfinite(now) or not math.isfinite(horizon) or horizon <= 0:
        raise ValueError("Planner clock must be finite and horizon positive")
    pcfg = PlannerConfig(bounds=((0., cfg.area_size), (0., cfg.area_size)),
                         usv_max_speed=cfg.usv_speed, auv_depth=cfg.auv_depth,
                         range_sigma=max(cfg.usbl_sigma, 1e-6),
                         bearing_sigma=max(cfg.usbl_bearing_sigma, 1e-6))
    current = np.asarray(current_position, dtype=float)
    candidates = reachable_candidates(current, horizon, pcfg)
    received = _received(states, now, cfg)
    if kind == "synchronous_fim":
        geometry = {node: np.asarray(state.position).copy() for node, state in received.items()}
    else:
        geometry = source_response_positions(received, policy_payloads or {}, cfg, policy_callback)
    if not geometry:
        return PlanResult(current.copy(), 0., {"geometry": 0., "movement": 0., "available_nodes": 0.},
                          {}, candidates.copy(), np.zeros(len(candidates)))
    scores, components = [], []
    for candidate in candidates:
        fim = sum((usbl_position_fim(pos, candidate, cfg.auv_depth, pcfg.range_sigma,
                                    pcfg.bearing_sigma) for pos in geometry.values()), np.zeros((2, 2)))
        sign, logdet = np.linalg.slogdet(fim)
        if sign <= 0 or not math.isfinite(float(logdet)):
            raise ValueError("Expected positive-definite finite geometry information")
        movement = float(np.sum((candidate - current)**2)) / MOVEMENT_SCALE_M**2
        cost = -float(logdet) + (MOVEMENT_WEIGHT * movement if kind == "actor_response_fim" else 0.)
        scores.append(cost)
        components.append({"geometry": -float(logdet), "movement": movement,
                           "available_nodes": float(len(geometry)),
                           "source_snapshot_one_step": float(kind == "actor_response_fim")})
    best = int(np.argmin(scores))
    return PlanResult(candidates[best].copy(), float(scores[best]), components[best],
                      geometry, candidates.copy(), np.asarray(scores))
