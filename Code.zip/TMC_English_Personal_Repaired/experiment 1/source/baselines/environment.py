"""Baseline adapters around the frozen physical simulator.

No controller, ocean, fault, measurement, data-service, reward or action-decoding
logic is reimplemented here. Method identity belongs to the baseline manifest;
the unchanged physical Config fingerprint alone is not a method identifier.
"""
from __future__ import annotations

import copy
import math
from typing import Callable

import numpy as np

from usv_auv.environment import CooperativeEnv
from usv_auv.estimation import EstimateSnapshot
from usv_auv.network import AcousticNetwork

from .methods import get_method


class NoDisturbanceEstimate:
    """No estimator: zeros plus the SAME raw measurement validity/age metadata.

    Raw displacement and executed action remain available to every actor. This
    adapter neither computes nor smooths their residual. ``initialized`` always
    stays false; ``valid`` describes the raw measurement, not a drift estimate.
    """

    def __init__(self, dimensions: int = 2):
        self.dimensions = int(dimensions)
        if self.dimensions < 1:
            raise ValueError("dimensions must be positive")
        self.reset()

    def reset(self):
        self._valid = False
        self._age = 0.
        self._gaps = 0
        return self.snapshot()

    @property
    def estimate(self):
        return np.zeros(self.dimensions)

    @property
    def initialized(self):
        return False

    @property
    def valid(self):
        return self._valid

    @property
    def age(self):
        return self._age

    def snapshot(self):
        return EstimateSnapshot(self.estimate, self._valid, self._age, False,
                                np.zeros(self.dimensions), self._gaps)

    def update(self, displacement, command_integral, elapsed, valid=True):
        if not math.isfinite(elapsed) or elapsed <= 0:
            raise ValueError("elapsed must be finite and positive")
        self._valid = bool(valid)
        self._age = 0. if valid else self._age + float(elapsed)
        self._gaps = 0 if valid else self._gaps + 1
        return self.snapshot()


class FixedStarNetwork(AcousticNetwork):
    """Same acoustic medium and packets; only route reconfiguration is absent.

    Discovery/report traffic is retained for a controlled route-selection
    ablation. Installed route validity is NOT physical link availability.
    """

    def _enumerate_topologies(self):
        return [tuple(0 for _ in range(self.n_auvs))]

    @property
    def n_actions(self):
        return 1  # KEEP only; no dummy learned topology agent is necessary.

    def action_mask(self, time=None):
        return np.ones(1, dtype=bool)

    def request_topology(self, parents, time=None):
        if time is not None and abs(float(time) - self.time) > 1e-8:
            raise ValueError("topology request must use current network time")
        if isinstance(parents, (int, np.integer)):
            if int(parents) != 0:
                raise ValueError("fixed-star baseline permits KEEP only")
        elif tuple(parents) != tuple(0 for _ in range(self.n_auvs)):
            raise ValueError("fixed-star baseline cannot install another route")
        return True

    def _send_config_roots(self):
        raise RuntimeError("CONFIG generation is disabled for the fixed-star baseline")

    def _install_config(self, packet, receiver):
        raise RuntimeError("CONFIG installation is disabled for the fixed-star baseline")


class BaselineEnv(CooperativeEnv):
    """Independent extension with the frozen local feature and action schema.

    The communication-aware actor-response planner is allowed to consume only
    complete historical policy observations delivered in real STATE frames.
    Additional policy observations are never piggybacked on compact COORD.
    """

    POLICY_STATE_FIXED_BYTES = 64
    POLICY_OBSERVATION_DTYPE = "float32"

    def __init__(self, cfg=None, method_id="synchronous_fim_rl"):
        self.method = get_method(method_id)
        self._response_policy: Callable | None = None
        super().__init__(cfg)

    @property
    def policy_state_wire_layout(self):
        return dict(version="baseline-policy-state-v1", fixed_header_and_state_bytes=self.POLICY_STATE_FIXED_BYTES,
                    fixed_layout_bytes={"src_dst_kind_flags": 4, "sequence": 4, "source_time": 8,
                                        "position_xy": 8, "velocity_xy": 8, "disturbance_xy": 8,
                                        "disturbance_age": 4, "target": 2, "task_weight": 4,
                                        "uncertainty": 4, "localization_time": 8, "padding": 2},
                    policy_observation_dtype=self.POLICY_OBSERVATION_DTYPE,
                    policy_observation_count=self.observation_dim,
                    policy_observation_bytes=4 * self.observation_dim,
                    required_packet_bits=8 * (self.POLICY_STATE_FIXED_BYTES + 4 * self.observation_dim),
                    allocated_packet_bits=self.cfg.state_packet_bits,
                    observation_schema_version=self.observation_schema_version,
                    observation_fields=list(self.observation_schema))

    @property
    def planner_semantics(self):
        kind = self.method.planner_kind
        return dict(kind=kind,
                    update_period_s=self.cfg.dt if kind == "synchronous_fim" else self.cfg.dt * self.cfg.slow_period,
                    state_access="received STATE payloads only; never current remote truth",
                    actor_response_time="received source_time + cfg.dt" if kind == "actor_response_fim" else None,
                    actor_response_candidate_dependence="candidate-independent, as in the original policy input" if kind == "actor_response_fim" else None,
                    communication_period_s=self.cfg.state_period)

    def _validate_policy_wire_capacity(self):
        if self.method.planner_kind != "actor_response_fim":
            return
        needed = self.policy_state_wire_layout["required_packet_bits"]
        if self.cfg.state_packet_bits < needed:
            raise ValueError(f"actor-response STATE needs {needed} bits for the complete historical observation; "
                             f"configured state_packet_bits={self.cfg.state_packet_bits}")
        if self.network.max_packet_bits < self.cfg.state_packet_bits:
            raise ValueError("actor-response STATE exceeds declared network packet capacity")

    def reset(self, seed=None):
        super().reset(seed)
        if not self.method.use_usde:
            self.usde = [NoDisturbanceEstimate() for _ in range(self.cfg.n_auv)]
        if not self.method.use_topology:
            # The base reset has not submitted/advanced packets. Construct the
            # same seeded physical medium and reconnect both physical callbacks.
            self.network = FixedStarNetwork(self.cfg, self.seed)
            self.network.application_link_filter = self._data_in_range
            self.network.on_transmit_payload = self._physical_localization
        self._validate_policy_wire_capacity()
        self.last_observations = self._observations()
        return self.last_observations.copy(), self._info()

    def set_response_policy(self, callback):
        """Set a side-effect-free inference callback; no current observation feed."""
        if callback is not None and not callable(callback):
            raise TypeError("response policy must be callable or None")
        self._response_policy = callback

    def _observations(self):
        observations = super()._observations()
        if not self.method.use_phase:
            for field in ("phase_sin", "phase_cos"):
                observations[:, self.observation_schema.index(field)] = 0.
        return observations

    def _state_payload(self, i):
        payload = super()._state_payload(i)
        if self.method.planner_kind == "actor_response_fim":
            self._validate_policy_wire_capacity()
            historical = np.asarray(self.last_observations[i], dtype=np.float32)
            if historical.shape != (self.observation_dim,) or not np.all(np.isfinite(historical)):
                raise ValueError("historical policy observation must match the complete finite local schema")
            payload["policy_observation"] = historical.copy().tolist()
            # Layout is a static codec declaration, not an extra JSON payload
            # transmitted on wire. Its version/flags fit the fixed header budget.
            payload["policy_observation_layout"] = self.policy_state_wire_layout
        return payload

    def _publish_coord(self):
        if self.method.planner_kind != "actor_response_fim":
            return super()._publish_coord()
        c = self.cfg
        if self.time - self.last_coord_sent < c.state_period - 1e-9:
            return
        states = {str(node): copy.deepcopy(d.packet.payload)
                  for node, d in self.network.received_states.items()
                  if node != 0 and isinstance(d.packet.payload, dict) and "position" in d.packet.payload}
        for state in states.values():
            state.pop("localization_time", None)
            state.pop("policy_observation", None)
            state.pop("policy_observation_layout", None)
        bits = 8 * (40 + 48 * len(states))
        for i in range(c.n_auv):
            self._send(0, i + 1, "COORD", dict(source_time=self.time,
                       usv_position=self.usv_position.tolist(), states=states), bits)
        self.last_coord_sent = self.time

    def _plan_usv(self):
        if self.method.planner_kind == "current":
            return super()._plan_usv()
        from .planning import plan_baseline
        horizon = self.cfg.dt if self.method.planner_kind == "synchronous_fim" else self.cfg.dt * self.cfg.slow_period
        payloads = {int(node): copy.deepcopy(delivery.packet.payload)
                    for node, delivery in self.network.received_states.items()
                    if node != 0 and isinstance(delivery.packet.payload, dict)
                    and float(delivery.packet.payload.get("source_time", math.inf)) <= self.time}
        self.last_plan = plan_baseline(self.usv_position.copy(), self.time, horizon,
                                       self._root_states(), self.cfg, self.method.planner_kind,
                                       policy_callback=self._response_policy, policy_payloads=payloads)
        self.usv_target = self.last_plan.target.copy()

    def step(self, actions, topology_action=None):
        if not self.method.use_topology:
            if topology_action is not None and (not isinstance(topology_action, (int, np.integer)) or int(topology_action) != 0):
                raise ValueError("this baseline has no topology decision; use None or KEEP")
        if self.method.planner_kind == "synchronous_fim" and self.step_count % self.cfg.slow_period:
            # Preserve error-before-advance behavior before this extra local plan.
            if self.done:
                raise RuntimeError("Call reset after terminal/truncated transition")
            if np.asarray(actions, dtype=float).shape != (self.cfg.n_auv, 2):
                raise ValueError("Wrong number of AUV actions")
            if topology_action is not None:
                raise ValueError("Topology decisions are only accepted on the slow clock")
            self._plan_usv()
        return super().step(actions, topology_action=topology_action if self.method.use_topology else None)

    def _info(self):
        info = super()._info()
        # With no estimator, inherited RMSE is explicitly a zero-drift prior
        # diagnostic for passive-tool compatibility, NOT estimator accuracy.
        info["metrics"]["usde_enabled"] = float(self.method.use_usde)
        info["metrics"]["topology_reconfiguration_enabled"] = float(self.method.use_topology)
        return info
