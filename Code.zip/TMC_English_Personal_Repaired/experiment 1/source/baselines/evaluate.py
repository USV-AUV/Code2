"""Bounded frozen baseline evaluation; optional shared passive TMC telemetry."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from usv_auv.learning import seed_all
from usv_auv.train import atomic_json, json_safe
from .deploy import BaselinePolicy, source_hashes


def make_environment_observer(env, info, method):
    from scripts.tmc_environment_observer import EnvironmentObserver

    class BaselineEnvironmentObserver(EnvironmentObserver):
        def _observe_new_plan(self, old_step, old_time):
            if method.planner_kind == "current":
                return super()._observe_new_plan(old_step, old_time)
            # External methods' cached/current or one-step response coordinates
            # are not forecasts made for the core planner's now+5 second time.

        def _snapshot(self, snapshot_info):
            if not method.use_usde and snapshot_info is not None:
                snapshot_info = {**snapshot_info, "metrics": {
                    key: value for key, value in snapshot_info["metrics"].items()
                    if key != "disturbance_rmse_mps"}}
            return super()._snapshot(snapshot_info)

        def finalize(self):
            result = super().finalize()
            result["usde"]["applicable"] = bool(method.use_usde)
            if not method.use_usde:
                result["usde"]["reason"] = "No USDE in this baseline; zero-prior physical diagnostic is not estimator accuracy"
            result["planner_horizon_prediction"]["applicable"] = method.planner_kind == "current"
            if method.planner_kind != "current":
                result["planner_horizon_prediction"]["reason"] = (
                    "External cached/one-step actor-response geometry is not the core planner's 5-second prediction; not scored as one")
            return result

    return BaselineEnvironmentObserver(env, info)


def evaluate(args):
    from .environment import BaselineEnv
    if not 1 <= args.steps <= 1200 or not 1 <= args.episodes <= 30:
        raise ValueError("Frozen evaluation is bounded to 1..30 episodes of 1..1200 steps")
    output = Path(args.output).resolve()
    if output.exists():
        raise FileExistsError("Evaluation output must be a new directory")
    hashes = source_hashes()
    policy = BaselinePolicy.from_checkpoint(args.checkpoint, args.device, args.method, args.verify_sources)
    env = BaselineEnv(policy.cfg, policy.method.method_id)
    policy.bind_environment(env)
    seed_all(args.seed)
    output.mkdir(parents=True)
    records = []
    try:
        with (output / "evaluation.jsonl").open("x", encoding="utf-8") as log:
            for episode in range(args.episodes):
                observations, info = env.reset(seed=args.seed + episode)
                policy.bind_environment(env)
                environment_observer = network_observer = None
                if args.tmc_metrics:
                    from scripts.tmc_network_observer import NetworkObserver
                    environment_observer = make_environment_observer(env, info, policy.method)
                    network_observer = NetworkObserver(env.network)
                total_reward = 0.
                terminated = truncated = False
                for index in range(args.steps):
                    topology_action = None
                    if policy.topology is not None and env.step_count % policy.cfg.slow_period == 0:
                        state, mask = env.slow_state()
                        topology_action = policy.topology_action(state, mask)
                    actions = policy.act(observations)
                    observations, reward, terminated, truncated, info = env.step(actions, topology_action=topology_action)
                    total_reward += float(reward)
                    row = {"episode": episode, "seed": args.seed + episode, "step": index + 1,
                           "time": info["time"], "reward": float(reward), "topology_request": topology_action,
                           "actions": actions.tolist(), "terminated": bool(terminated), "truncated": bool(truncated),
                           "info": json_safe(info)}
                    if environment_observer is not None:
                        row["passive_environment"] = environment_observer.after_step(info)
                    log.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                    if terminated or truncated:
                        break
                record = {"episode": episode, "seed": args.seed + episode, "method_id": policy.method.method_id,
                          "model_step": policy.checkpoint["global_step"], "steps": index + 1,
                          "duration_s": info["time"], "terminated": bool(terminated), "truncated": bool(truncated),
                          "evaluation_limit_reached": not (terminated or truncated), "return": total_reward,
                          "termination_reason": info["termination_reason"], "metrics_base": json_safe(info["metrics"])}
                if environment_observer is not None:
                    record["environment"] = environment_observer.finalize()
                    record["network"] = network_observer.finalize(float(info["time"]))
                records.append(record)
                atomic_json({"status": "evaluating", "completed_episodes": len(records), "total_episodes": args.episodes}, output / "progress.json")
        final_hashes = source_hashes()
        if hashes["usv_auv"] != final_hashes["usv_auv"]:
            raise RuntimeError("Core sources changed during baseline evaluation")
        if args.verify_sources and hashes != final_hashes:
            raise RuntimeError("Frozen baseline sources changed during evaluation")
        result = {"status": "completed", "scope": "Frozen baseline simulation; a short smoke is not task-performance evidence",
                  "checkpoint": str(Path(args.checkpoint).resolve()), "method_id": policy.method.method_id,
                  "method_spec": policy.method.to_dict(), "method_fingerprint": policy.method.fingerprint,
                  "training_steps": policy.checkpoint["global_step"], "config_fingerprint": policy.config_fingerprint,
                  "device": str(policy.device), "source_hashes": hashes, "core_source_files_unchanged": True,
                  "baseline_sources_unchanged": hashes["baselines"] == final_hashes["baselines"],
                  "tmc_metrics": args.tmc_metrics, "episodes": records}
        atomic_json(result, output / "evaluation_summary.json")
        atomic_json({"status": "completed", "completed_episodes": len(records)}, output / "progress.json")
        return result
    except Exception as error:
        atomic_json({"status": "failed", "error": repr(error), "completed_episodes": len(records)}, output / "progress.json")
        raise
    finally:
        env.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--method")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--steps", type=int, default=128)
    parser.add_argument("--episodes", type=int, default=1)
    parser.add_argument("--seed", type=int, default=9400000)
    parser.add_argument("--verify-sources", action="store_true")
    parser.add_argument("--tmc-metrics", action="store_true")
    args = parser.parse_args()
    print(json.dumps(evaluate(args), ensure_ascii=True, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
