"""One shared, pure observation schema for simulation and telemetry deployment.

Inputs are local navigation/measurement and received cache only. No function in
this module accepts a simulator, true position, current field or physical graph.
"""
import numpy as np


LOCAL_FIELDS = (
    'position_x','position_y','target_dx','target_dy','executed_ux','executed_uy',
    'measured_vx','measured_vy','estimated_dx','estimated_dy','measurement_valid',
    'estimator_initialized','measurement_age','measurement_overage','phase_sin',
    'phase_cos','target_queue_ratio','target_distance','localization_age',
    'localization_overage','parent_id','relay_role','route_valid','coord_valid',
    'coord_age','coord_overage','usv_dx','usv_dy',
)
PEER_FIELDS = ('dx','dy','age','valid')
SCHEMA_VERSION = 'local-v1-root-v2-direct-velocity'


def observation_fields(n_auv):
    return list(LOCAL_FIELDS)+[f'peer_slot_{i}_{key}' for i in range(n_auv-1) for key in PEER_FIELDS]


def age_features(age, scale):
    return [min(max(float(age),0.)/scale,1.),float(age>scale)]


def build_observation(cfg, node_id, now, step, local_position, target_position,
                      target_queue_ratio, executed_velocity, measured_delta,
                      estimate, localization_time, topology, coord=None):
    local_position=np.asarray(local_position,float)
    goal=np.asarray(target_position,float)-local_position
    coord={} if coord is None else coord
    age_scale=cfg.state_ttl
    phase=2*np.pi*(step%cfg.slow_period)/cfg.slow_period
    lastfix=0. if localization_time is None else localization_time
    coord_valid=bool(coord and coord.get('source_time',float('inf'))<=now)
    coord_age=max(0.,now-coord['source_time']) if coord_valid else now+age_scale
    usv_rel=(np.asarray(coord['usv_position'])-local_position)/cfg.area_size if coord_valid else np.zeros(2)
    parents=tuple(topology.get('parents',()))
    estimate_age=estimate.age
    values=[*(local_position/cfg.area_size),*(goal/cfg.area_size),
            *(np.asarray(executed_velocity)/cfg.max_speed),
            *(np.asarray(measured_delta)/cfg.dt/cfg.max_speed),
            *(np.asarray(estimate.estimate)/cfg.max_speed),float(estimate.valid),
            float(estimate.initialized),*age_features(estimate_age,age_scale),
            np.sin(phase),np.cos(phase),np.clip(target_queue_ratio,0,1),
            np.linalg.norm(goal)/cfg.area_size,*age_features(now-lastfix,age_scale),
            float(topology.get('parent',0))/cfg.n_auv,
            float(node_id in parents),float(topology.get('route_valid',False)),
            float(coord_valid),*age_features(coord_age,age_scale),*usv_rel]
    peers=coord.get('states',{}) if coord_valid else {}
    for peer in range(1,cfg.n_auv+1):
        if peer==node_id:continue
        p=peers.get(str(peer),peers.get(peer))
        if p is not None and float(p['source_time'])<=now:
            age=max(0.,now-float(p['source_time']))
            # Bounded prediction from actually received source-time state.
            disturbance=np.asarray(p['disturbance']) if p.get('disturbance_valid',False) else np.zeros(2)
            displacement=min(age,cfg.state_ttl)*(np.asarray(p['velocity'])+disturbance)
            xy=np.asarray(p['position'])+displacement
            values.extend([*((xy-local_position)/cfg.area_size),min(age/age_scale,1.),1.])
        else:values.extend([0.,0.,1.,0.])
    result=np.asarray(values,dtype=np.float32)
    if result.shape!=(len(observation_fields(cfg.n_auv)),) or not np.all(np.isfinite(result)):
        raise ValueError('Nonfinite or mismatched policy observation')
    return result


def root_observation_fields(n_auv):
    state_fields=('px','py','ux','uy','dx','dy','disturbance_valid','disturbance_age',
                  'uncertainty','target','age','overage','received')
    names=[f'auv_{i}_{key}' for i in range(1,n_auv+1) for key in state_fields]
    names += [f'{key}_{i}_{j}' for key in ('link_quality','report_age')
              for i in range(n_auv+1) for j in range(n_auv+1)]
    names += ['usv_x','usv_y','pending','phase','pending_age','pending_retry_ratio','pending_lease_left','pending_deadline_left']
    names += [f'{key}_{i}' for key in ('active_parent','active_ack','pending_parent','pending_ack') for i in range(1,n_auv+1)]
    return names


def build_root_observation(cfg,now,step,usv_position,received_payloads,report):
    """Pure root builder: accepts ONLY locally received state/report snapshots."""
    c=cfg;values=[]
    for i in range(1,c.n_auv+1):
        p=received_payloads.get(i,received_payloads.get(str(i)))
        if p is None or float(p['source_time'])>now:
            values.extend([0.]*10+[1.,0.,0.]);continue
        age=max(0.,now-p['source_time'])
        values.extend([*(np.asarray(p['position'])/c.area_size),*(np.asarray(p['velocity'])/c.max_speed),
                       *(np.asarray(p['disturbance'])/c.max_speed),float(p.get('disturbance_valid',False)),
                       min(p.get('disturbance_age',0.)/c.state_ttl,1.),p.get('uncertainty',0.)/c.area_size,
                       float(p.get('target',0))/c.n_sensors,min(age/c.state_ttl,1.),float(age>c.state_ttl),1.])
    values.extend(np.nan_to_num(report['link_quality'],nan=0.).ravel())
    age=np.asarray(report['report_age'])
    values.extend(np.clip(np.nan_to_num(age,posinf=c.report_ttl)/c.report_ttl,0.,1.).ravel())
    p=report['pending']
    values.extend([*(np.asarray(usv_position)/c.area_size),float(p is not None),
                   (step%c.slow_period)/c.slow_period,
                   0. if p is None else min((now-p['requested_at'])/((c.max_retries+1)*c.config_timeout),1.),
                   0. if p is None else p['retries']/max(1,c.max_retries),
                   0. if p is None else max(0.,p['expires']-now)/c.route_lease,
                   0. if p is None else max(0.,p['deadline']-now)/c.config_timeout])
    values.extend([parent/c.n_auv for parent in report['active_parents']])
    values.extend([float(report['confirmed_versions'].get(i,-1)==report['root_active_version']) for i in range(1,c.n_auv+1)])
    values.extend([0. if p is None else parent/c.n_auv for parent in ([0]*c.n_auv if p is None else p['parents'])])
    values.extend([float(p is not None and i in p['acks']) for i in range(1,c.n_auv+1)])
    result=np.asarray(values,np.float32)
    if result.shape!=(len(root_observation_fields(c.n_auv)),) or not np.all(np.isfinite(result)):
        raise ValueError('Nonfinite or mismatched root observation')
    return result
