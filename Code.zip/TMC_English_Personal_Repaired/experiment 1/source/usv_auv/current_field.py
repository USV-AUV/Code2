"""Seeded, smooth space-time current field (m/s), independent of the policy."""
import numpy as np


class CurrentField:
    def __init__(self, cfg, seed=0):
        self.cfg = cfg
        rng = np.random.default_rng(np.random.SeedSequence([seed, 187]))
        self.phase = rng.uniform(0, 2*np.pi)
        self.center = np.array([.55, .45])*cfg.area_size

    def velocity(self, positions, time):
        p = np.asarray(positions, dtype=float)
        c = self.cfg
        phase = 2*np.pi*time/c.current_period+self.phase
        background = np.array([c.current_x+c.current_amplitude*np.cos(phase),
                               c.current_y+c.current_amplitude*np.sin(phase)])
        r = p-self.center
        radius = c.vortex_radius
        # psi=A exp(-r^2/l^2), so peak speed equals |vortex_speed|.
        amplitude = c.vortex_speed*radius*np.exp(.5)/np.sqrt(2)
        multiplier = 2*amplitude/radius**2*np.exp(-np.sum(r*r, axis=-1)/radius**2)
        vortex = np.stack([-r[..., 1], r[..., 0]], axis=-1)*multiplier[..., None]
        return background+vortex

    @property
    def speed_upper_bound(self):
        c = self.cfg
        return float(np.hypot(c.current_x,c.current_y)+abs(c.current_amplitude)+abs(c.vortex_speed))
