"""Causal, continuous-service environment for the complete proposed method.

This is a research kinematic simulator, not a six-DOF vessel controller. Only
the physical process reads true positions and currents. Observation builders
and the USV planner read local measurements and actually delivered messages.
"""
from collections import Counter, deque
import copy
import math
import numpy as np

from .config import Config
from .actions import decode_actions as decode_velocity_actions
from .current_field import CurrentField
from .estimation import DiscreteUSDE, NavigationState
from .network import AcousticNetwork, Packet
from .observations import (SCHEMA_VERSION, build_observation, observation_fields,
                           build_root_observation, root_observation_fields)
from .planner import ObservedLink, PlannerConfig, ReceivedState, plan_usv, sample_usbl_fix


def _advance_usv(position, target, max_distance, area_size):
    """Move along an in-bounds segment without rounding past its endpoint.

    This only repairs floating-point representation at the USV box boundary;
    illegal inputs and material overshoots remain errors.  The returned travel
    distance retains the existing speed limit and propulsion-energy definition.
    """
    position=np.asarray(position,dtype=float)
    target=np.asarray(target,dtype=float)
    if not math.isfinite(area_size) or area_size<=0:
        raise ValueError('USV area_size must be finite and positive')
    if not math.isfinite(max_distance) or max_distance<0:
        raise ValueError('USV max_distance must be finite and nonnegative')
    for name,point in (('position',position),('target',target)):
        if point.shape!=(2,) or not np.all(np.isfinite(point)):
            raise ValueError(f'USV {name} must be a finite XY coordinate')
        if np.any(point<0.) or np.any(point>area_size):
            raise ValueError(f'USV {name} lies outside movement bounds')
    displacement=target-position
    distance=float(np.linalg.norm(displacement))
    if distance==0.:
        distance=math.hypot(float(displacement[0]),float(displacement[1]))
    if not math.isfinite(distance):
        raise ValueError('USV movement distance must be finite')
    moved=min(distance,max_distance)
    if distance<=max_distance:
        # Normalizing and multiplying back can make a zero boundary negative.
        # Exact arrival also handles zero and sub-1e-12 distances without drift.
        return target.copy(),moved
    updated=position+displacement/distance*moved
    tolerance=8.*np.finfo(float).eps*max(1.,area_size)
    if not np.all(np.isfinite(updated)) or np.any(-updated>tolerance) or np.any(updated-area_size>tolerance):
        raise ValueError('USV numerical movement lies outside movement bounds')
    # At most a few machine-precision units at the arena scale; never a safety
    # projection for AUV motion or for an invalid USV target/current position.
    return np.clip(updated,0.,area_size),moved


class CooperativeEnv:
    observation_schema_version=SCHEMA_VERSION

    def __init__(self,cfg=None):
        self.cfg=Config() if cfg is None else copy.deepcopy(cfg)
        self.cfg.validate()
        self.observation_schema=observation_fields(self.cfg.n_auv)
        self.observation_dim=len(self.observation_schema)
        self.slow_observation_schema=root_observation_fields(self.cfg.n_auv)
        self.slow_observation_dim=len(self.slow_observation_schema)
        self.reset(self.cfg.seed)

    def reset(self,seed=None):
        c=self.cfg
        self.seed=c.seed if seed is None else int(seed)
        self.rng=np.random.default_rng(np.random.SeedSequence([self.seed,1]))
        self.motion_rng=np.random.default_rng(np.random.SeedSequence([self.seed,2]))
        self.arrival_rng=np.random.default_rng(np.random.SeedSequence([self.seed,3]))
        self.localization_rng=np.random.default_rng(np.random.SeedSequence([self.seed,4]))
        self.current=CurrentField(c,self.seed)
        self.network=AcousticNetwork(c,self.seed)
        self.network.application_link_filter=self._data_in_range
        self.network.on_transmit_payload=self._physical_localization
        self.time=0.;self.step_count=0;self.done=False;self.termination_reason=''
        self.sensor_positions=self.rng.uniform(.08*c.area_size,.92*c.area_size,(c.n_sensors,2))
        # Known deployment geometry is not a continual navigation ground-truth feed.
        self.auv_positions=np.column_stack((np.linspace(.30,.70,c.n_auv)*c.area_size,
                                           np.full(c.n_auv,.45*c.area_size)))
        self.usv_position=np.array([.5,.5])*c.area_size
        self.usv_target=self.usv_position.copy()
        self.nav=[NavigationState(p+self.motion_rng.normal(0,c.initial_position_sigma,2),
                                 history_seconds=c.navigation_history_seconds) for p in self.auv_positions]
        self.usde=[DiscreteUSDE(c.usde_kappa) for _ in range(c.n_auv)]
        self.executed_velocities=np.zeros((c.n_auv,2))
        self.measured_delta=np.zeros((c.n_auv,2))
        self.last_actions=np.zeros((c.n_auv,2))
        self.last_actions[:,0]=-1.
        self.last_state_sent=np.full(c.n_auv,-math.inf)
        self.last_request=np.full(c.n_auv,-math.inf)
        # AUV-side knowledge, populated only by DATA_GRANT packets that arrive.
        # Never use the sensor-side self.grants table to suppress a request.
        self.received_service_grants=[{} for _ in range(c.n_auv)]
        self.service_request_times=[{} for _ in range(c.n_auv)]
        sensor_frame=len(self.network.slot_owners)*c.slot_duration
        cooperative_turn=(c.n_auv+2)*self.network.cooperative_slot_gap*(
            1.+1./max(1,self.network.max_management_run))
        self.service_renew_lead=sensor_frame+cooperative_turn+c.slot_duration
        # DATA may take a sensor's first opportunity and GRANT its next one.
        # This is a retry budget, not a claim of bounded queueing latency.
        self.service_retry_interval=2.*sensor_frame+cooperative_turn+c.slot_duration
        self.last_coord_sent=-math.inf
        self.last_localization_sent=np.full(c.n_auv,-math.inf)
        self.coord_cache=[None for _ in range(c.n_auv)]
        self.pending_fixes=[]
        self.targets=np.arange(c.n_auv)%c.n_sensors
        self.target_since=np.full(c.n_auv,-math.inf)
        # Each AUV knows the declared initial buffer prior and arrival rates only.
        self.queue_estimates=np.full((c.n_auv,c.n_sensors),c.initial_packets*c.data_packet_bits,dtype=float)
        self.queue_stamps=np.zeros((c.n_auv,c.n_sensors))
        self.buffers=[deque(range(c.initial_packets)) for _ in range(c.n_sensors)]
        self.next_data_seq=np.full(c.n_sensors,c.initial_packets,dtype=np.int64)
        self.grants={};self.inflight={}
        self.collected=set();self.acknowledged=set()
        self.metrics=Counter(initial_bits=c.initial_packets*c.data_packet_bits*c.n_sensors)
        self.metrics.update(arrival_bits=0,overflow_bits=0,collected_bits=0,ack_released_bits=0,
                            propulsion_energy_j=0.,usv_energy_j=0.,localization_fixes=0,
                            collection_attempts=0,safety_events=0)
        self._select_targets(force=True)
        self.last_plan=None
        self.last_observations=self._observations()
        return self.last_observations.copy(),self._info()

    def _positions_3d(self):
        c=self.cfg
        xy=np.vstack((self.usv_position,self.auv_positions,self.sensor_positions))
        z=np.r_[0.,np.full(c.n_auv,-c.auv_depth),np.full(c.n_sensors,-c.sensor_depth)]
        return np.column_stack((xy,z))

    def _data_in_range(self,packet,transmitter,receiver,time,positions):
        return float(np.linalg.norm(positions[transmitter,:2]-positions[receiver,:2]))<=self.cfg.collection_radius

    def _physical_localization(self,packet,transmitter,receiver,time,positions):
        """Physical sensor only: the result stays in the in-flight reply packet."""
        if packet.kind!='LOCALIZATION' or receiver!=0 or not 1<=transmitter<=self.cfg.n_auv:return None
        c=self.cfg
        measured=sample_usbl_fix(positions[transmitter,:2],positions[0,:2],c.auv_depth,
                                c.usbl_sigma,c.usbl_bearing_sigma,self.localization_rng)
        return dict(position=measured.tolist(),source_time=time)

    def _send(self,src,dst,kind,payload,bits=None,expiry=None):
        c=self.cfg
        self.network.submit(Packet(src=int(src),dst=int(dst),kind=kind,
                            payload=copy.deepcopy(payload),created_at=self.network.time,
                            size_bits=c.control_packet_bits if bits is None else int(bits),
                            expires_at=self.network.time+c.state_ttl if expiry is None else expiry))

    def _queue_forecast(self,i):
        c=self.cfg
        estimate=self.queue_estimates[i]+np.maximum(0.,self.time-self.queue_stamps[i])*c.arrival_rate*c.data_packet_bits
        return np.minimum(c.buffer_packets*c.data_packet_bits,estimate)

    def _select_targets(self,force=False):
        c=self.cfg
        for i in range(c.n_auv):
            estimate=self._queue_forecast(i)
            target=int(self.targets[i])
            old_empty=estimate[target]<.5*c.data_packet_bits
            if force or (old_empty and self.time-self.target_since[i]>=c.target_min_dwell) or self.time-self.target_since[i]>=c.target_max_dwell:
                distance=np.linalg.norm(self.sensor_positions-self.nav[i].position,axis=1)
                # Fixed local scheduler, not a new learned action or true queue access.
                priority=estimate/(distance+10.)
                coord=self.coord_cache[i]
                if coord is not None:
                    for key,peer in coord.get('states',{}).items():
                        if int(key)!=i+1 and self.time-peer['source_time']<c.state_ttl:
                            j=peer.get('target')
                            if j is not None and 0<=int(j)<c.n_sensors:priority[int(j)]*=.35
                new=int(np.argmax(priority))
                if new!=target or force:
                    self.targets[i]=new;self.target_since[i]=self.time

    def _state_payload(self,i):
        s=self.usde[i].snapshot();nav=self.nav[i]
        loc_time=nav.last_correction_time
        return dict(position=nav.position.tolist(),velocity=self.executed_velocities[i].tolist(),
                    disturbance=s.estimate.tolist(),source_time=self.time,
                    disturbance_valid=s.initialized,disturbance_age=s.age,
                    target=int(self.targets[i]),task_weight=1.,
                    uncertainty=self.cfg.initial_position_sigma+.05*(self.time-(loc_time or 0.)),
                    localization_time=loc_time)

    def _publish_state(self):
        c=self.cfg
        for i in range(c.n_auv):
            if self.time-self.last_state_sent[i]>=c.state_period-1e-9:
                self._send(i+1,0,'STATE',self._state_payload(i),c.state_packet_bits)
                self.last_state_sent[i]=self.time

    def _root_states(self):
        result={}
        for node,delivery in self.network.received_states.items():
            p=delivery.packet.payload
            if node==0 or not isinstance(p,dict) or 'position' not in p:continue
            result[node]=ReceivedState(node,p['position'],p['velocity'],p['disturbance'],
                                      p['source_time'],p.get('disturbance_valid',False),
                                      p.get('disturbance_age',0.),p.get('uncertainty',0.),
                                      p.get('task_weight',1.),True)
        return result

    def _plan_usv(self):
        c=self.cfg
        links={edge:ObservedLink(edge[0],edge[1],float(p),c.slot_duration*(c.n_auv+c.n_sensors+1),float(stamp))
               for edge,(stamp,p) in self.network.link_reports.items()}
        states=self._root_states()
        self.last_plan=plan_usv(self.usv_position,self.time,c.dt*c.slow_period,states,links,
                               {i+1:p for i,p in enumerate(self.network.root_parents)},
                               PlannerConfig(bounds=((0,c.area_size),(0,c.area_size)),
                                   usv_max_speed=c.usv_speed,auv_depth=c.auv_depth,
                                   sound_speed=c.sound_speed,link_report_ttl=c.report_ttl,
                                   max_state_age=c.state_ttl,range_sigma=max(c.usbl_sigma,1e-6),
                                   bearing_sigma=max(c.usbl_bearing_sigma,1e-6)))
        self.usv_target=self.last_plan.target.copy()

    def _publish_coord(self):
        c=self.cfg
        if self.time-self.last_coord_sent<c.state_period-1e-9:return
        states={str(node):copy.deepcopy(d.packet.payload) for node,d in self.network.received_states.items()
                if node!=0 and isinstance(d.packet.payload,dict) and 'position' in d.packet.payload}
        for state in states.values():state.pop('localization_time',None)
        # Fixed compact wire schema: header/time/USV XY 40 bytes; 48 bytes per peer.
        bits=8*(40+48*len(states))
        for i in range(c.n_auv):
            self._send(0,i+1,'COORD',dict(source_time=self.time,usv_position=self.usv_position.tolist(),states=states),bits)
        self.last_coord_sent=self.time

    def _request_data(self):
        c=self.cfg
        interval=max(c.dt,(1+c.n_auv+c.n_sensors)*c.slot_duration)
        for i in range(c.n_auv):
            j=int(self.targets[i])
            if c.service_grant_aware:
                grant=self.received_service_grants[i].get(j)
                last=self.service_request_times[i].get(j,-math.inf)
                if grant is not None and grant['expires_at']-self.time>self.service_renew_lead:
                    continue
                pending=math.isfinite(last) and (grant is None or grant['source_time']<last)
                holdoff=max(interval,self.service_retry_interval) if pending else interval
                if self.time-last<holdoff:continue
            elif self.time-self.last_request[i]<interval:continue
            if np.linalg.norm(self.nav[i].position-self.sensor_positions[j])<=c.collection_radius*1.5:
                self._send(i+1,1+c.n_auv+j,'DATA_REQUEST',{'auv':i+1,'sensor':j})
                self.last_request[i]=self.time
                if c.service_grant_aware:
                    self.service_request_times[i][j]=self.time
                    self.metrics['service_requests']+=1
                    if pending:self.metrics['service_request_retries']+=1
                    elif grant is not None:self.metrics['service_renewal_requests']+=1

    def _queue_data(self):
        c=self.cfg
        for j,(receiver,expiry) in list(self.grants.items()):
            if self.network.time>expiry:continue
            if not self.buffers[j]:continue
            pending=self.inflight.get(j)
            if pending is not None and self.network.time<pending[1]:continue
            seq=int(self.buffers[j][0])
            deadline=self.network.time+c.service_ack_timeout
            self._send(c.n_auv+1+j,receiver,'DATA',{'sensor':j,'data_seq':seq},
                       c.data_packet_bits+c.data_header_bits,deadline)
            self.inflight[j]=(seq,deadline)
            self.metrics['collection_attempts']+=1

    def _deliver(self,deliveries):
        c=self.cfg
        for delivery in deliveries:
            p=delivery.packet;payload=p.payload;receiver=delivery.receiver
            if p.kind=='COORD' and 1<=receiver<=c.n_auv:
                old=self.coord_cache[receiver-1]
                if old is None or payload['source_time']>old['source_time']:
                    self.coord_cache[receiver-1]=copy.deepcopy(payload)
            elif p.kind=='DATA_REQUEST' and receiver>c.n_auv:
                j=receiver-c.n_auv-1
                # Source only knows the request it received. No omniscient allocation.
                old=self.grants.get(j)
                if old is not None and old[0]!=p.src and old[1]>self.network.time:continue
                self.grants[j]=(p.src,self.network.time+c.grant_ttl)
                grant_payload=dict(sensor=j,buffer_bits=len(self.buffers[j])*c.data_packet_bits,
                                   source_time=self.network.time)
                if c.service_grant_aware:
                    # Fixed-width sensor ID, buffer count and two timestamps
                    # still fit the declared 512-bit control packet budget.
                    grant_payload['expires_at']=self.grants[j][1]
                    self._send(receiver,p.src,'DATA_GRANT',grant_payload,
                               expiry=min(self.grants[j][1],self.network.time+c.state_ttl))
                else:self._send(receiver,p.src,'DATA_GRANT',grant_payload)
            elif p.kind=='DATA_GRANT' and 1<=receiver<=c.n_auv:
                i=receiver-1;j=int(payload['sensor'])
                if payload['source_time']>=self.queue_stamps[i,j]:
                    self.queue_estimates[i,j]=payload['buffer_bits'];self.queue_stamps[i,j]=payload['source_time']
                if c.service_grant_aware:
                    stamp=float(payload['source_time']);expiry=float(payload.get('expires_at',-math.inf))
                    old=self.received_service_grants[i].get(j)
                    if (math.isfinite(stamp) and math.isfinite(expiry) and stamp<=self.network.time
                            and expiry>self.network.time and expiry>stamp
                            and (old is None or stamp>old['source_time'])):
                        self.received_service_grants[i][j]={'source_time':stamp,'expires_at':expiry}
                        self.metrics['service_grants_received']+=1
                    elif expiry<=self.network.time:self.metrics['service_expired_grants_received']+=1
            elif p.kind=='DATA' and 1<=receiver<=c.n_auv:
                j=int(payload['sensor']);seq=int(payload['data_seq']);key=(j,seq)
                if key not in self.collected:
                    self.collected.add(key);self.metrics['collected_bits']+=c.data_packet_bits
                    i=receiver-1
                    self.queue_estimates[i,j]=max(0.,self._queue_forecast(i)[j]-c.data_packet_bits)
                    self.queue_stamps[i,j]=self.network.time
                self._send(receiver,p.src,'DATA_ACK',{'sensor':j,'data_seq':seq})
            elif p.kind=='DATA_ACK' and receiver>c.n_auv:
                j=receiver-c.n_auv-1;seq=int(payload['data_seq']);key=(j,seq)
                if seq in self.buffers[j] and key not in self.acknowledged:
                    self.buffers[j].remove(seq);self.acknowledged.add(key)
                    self.metrics['ack_released_bits']+=c.data_packet_bits
                if j in self.inflight and self.inflight[j][0]==seq:self.inflight.pop(j)
            elif p.kind=='LOCALIZATION' and receiver==0:
                # The reply carries a measurement sampled at its actual TX time,
                # not the current truth at the later receive time.
                if not 1<=p.src<=c.n_auv or 'position' not in payload:continue
                self._send(0,p.src,'LOCALIZATION_FIX',payload,
                           expiry=payload['source_time']+c.state_ttl)
            elif p.kind=='LOCALIZATION_PING' and 1<=receiver<=c.n_auv:
                self._send(receiver,0,'LOCALIZATION',{})
            elif p.kind=='LOCALIZATION_FIX' and 1<=receiver<=c.n_auv:
                self.pending_fixes.append((receiver-1,payload['position'],payload['source_time']))

    def _localization_requests(self):
        c=self.cfg
        # Each attempted interrogation and its reply occupy physical TDMA slots.
        period=max(c.state_period,2*(1+c.n_auv+c.n_sensors)*c.slot_duration)
        for i in range(c.n_auv):
            if self.time-self.last_localization_sent[i]>=period:
                self._send(0,i+1,'LOCALIZATION_PING',{})
                self.last_localization_sent[i]=self.time

    def _arrivals(self):
        c=self.cfg
        new=self.arrival_rng.poisson(c.arrival_rate*c.dt,c.n_sensors)
        for j,count in enumerate(new):
            self.metrics['arrival_bits']+=int(count)*c.data_packet_bits
            admitted=min(int(count),c.buffer_packets-len(self.buffers[j]))
            self.metrics['overflow_bits']+=(int(count)-admitted)*c.data_packet_bits
            start=int(self.next_data_seq[j]);self.next_data_seq[j]+=int(count)
            self.buffers[j].extend(range(start,start+admitted))

    @staticmethod
    def decode_actions(actions,max_speed,action_frame='global',observations=None):
        # Keep the legacy two-argument static API as global-heading decoding.
        return decode_velocity_actions(actions,max_speed,action_frame,observations)

    def step(self,actions,topology_action=None):
        if self.done:raise RuntimeError('Call reset after terminal/truncated transition')
        c=self.cfg
        actions=np.asarray(actions,dtype=float)
        if actions.shape!=(c.n_auv,2):raise ValueError('Wrong number of AUV actions')
        # Decode in exactly the observation frame supplied to the actor, before
        # planning, packet deliveries, target changes or navigation corrections.
        executed=self.decode_actions(actions,c.max_speed,getattr(c,'action_frame','global'),
                                     self.last_observations)
        before=dict(self.metrics);energy_before=float(np.sum(self.network.energy_j))
        old_dist=np.array([np.linalg.norm(self.nav[i].position-self.sensor_positions[self.targets[i]]) for i in range(c.n_auv)])
        if topology_action is not None and self.step_count%c.slow_period:
            raise ValueError('Topology decisions are only accepted on the slow clock')
        if self.step_count%c.slow_period==0:
            if topology_action is not None:self.network.request_topology(int(topology_action),self.time)
            self._plan_usv();self._publish_coord()
        self.last_actions=actions.copy();self.executed_velocities=executed.copy()
        self._arrivals();self._publish_state();self._request_data();self._localization_requests();self._queue_data()
        previous_true=self.auv_positions.copy()
        h=c.dt/c.substeps
        outside=False;collision=False
        for substep in range(c.substeps):
            start_time=self.time+substep*h
            before_positions=self._positions_3d()
            # Explicit midpoint integration; policy action is held for the full fast step.
            d0=self.current.velocity(self.auv_positions,start_time)
            midpoint=self.auv_positions+.5*h*(executed+d0)
            current=self.current.velocity(midpoint,start_time+.5*h)
            self.auv_positions+=h*(executed+current)
            # Detect throughout the integration, not only at the fast-step endpoint.
            # Commands are held to the next decision tick; failure stays latched.
            outside |= bool(np.any((self.auv_positions<0)|(self.auv_positions>c.area_size)))
            collision |= any(np.linalg.norm(self.auv_positions[i]-self.auv_positions[j])<c.min_separation
                             for i in range(c.n_auv) for j in range(i))
            self.usv_position,moved=_advance_usv(self.usv_position,self.usv_target,
                                                 c.usv_speed*h,c.area_size)
            self.metrics['usv_energy_j']+=h*(c.usv_idle_w+2*(moved/h)**2)
            after_positions=self._positions_3d()
            def interpolate(t,b=before_positions,a=after_positions,t0=start_time):
                alpha=np.clip((t-t0)/h,0.,1.)
                return b+alpha*(a-b)
            deliveries=self.network.advance(start_time+h,interpolate)
            self._deliver(deliveries);self._queue_data()
        self.time+=c.dt;self.step_count+=1
        for i in range(c.n_auv):
            valid=bool(self.motion_rng.random()>=c.displacement_dropout)
            delta=self.auv_positions[i]-previous_true[i]+self.motion_rng.normal(0,c.displacement_sigma,2)
            self.measured_delta[i]=delta if valid else 0.
            self.nav[i].advance(delta,c.dt,valid)
            self.usde[i].update(delta,executed[i]*c.dt,c.dt,valid)
        for i,position,source_time in self.pending_fixes:
            if self.nav[i].correct_absolute(position,source_time):self.metrics['localization_fixes']+=1
        self.pending_fixes=[]
        speeds=np.linalg.norm(executed,axis=1)
        self.metrics['propulsion_energy_j']+=float(np.sum(c.propulsion_idle_w+c.propulsion_c2*speeds**2+c.propulsion_c3*speeds**3)*c.dt)
        terminated=outside or collision
        truncated=self.step_count>=c.episode_steps and not terminated
        self.done=terminated or truncated
        self.termination_reason='boundary' if outside else 'collision' if collision else 'time_limit' if truncated else ''
        if terminated:self.metrics['safety_events']+=1
        bits=self.metrics['collected_bits']-before['collected_bits']
        lost=self.metrics['overflow_bits']-before['overflow_bits']
        energy=(self.metrics['propulsion_energy_j']-before['propulsion_energy_j']+
                self.metrics['usv_energy_j']-before['usv_energy_j']+
                float(np.sum(self.network.energy_j))-energy_before)
        aois=[self.time-d.packet.created_at if (d:=self.network.received_states.get(i+1)) is not None else self.time
              for i in range(c.n_auv)]
        self._select_targets()
        new_dist=np.array([np.linalg.norm(self.nav[i].position-self.sensor_positions[self.targets[i]]) for i in range(c.n_auv)])
        # F=gamma*Phi(next)-Phi(now), Phi=-sum(LOCAL target distance)/area.
        # Include target changes in next Phi; absorbing physical failure has Phi=0.
        progress=float((np.sum(old_dist)-c.gamma*(0. if terminated else np.sum(new_dist)))/c.area_size)
        reward=(c.reward_data_weight*bits/c.reward_data_scale-c.reward_overflow_weight*lost/c.reward_overflow_scale
                -c.reward_energy_weight*energy/c.reward_energy_scale
                -c.reward_age_weight*sum(aois)/c.reward_age_scale
                -c.reward_safety_weight*terminated+c.reward_progress_weight*progress)
        self.last_observations=self._observations()
        self.assert_conservation()
        return self.last_observations.copy(),float(reward),bool(terminated),bool(truncated),self._info()

    def _observations(self):
        c=self.cfg
        return np.stack([build_observation(c,i+1,self.time,self.step_count,self.nav[i].position,
                              self.sensor_positions[self.targets[i]],
                              self._queue_forecast(i)[self.targets[i]]/(c.buffer_packets*c.data_packet_bits),
                              self.executed_velocities[i],self.measured_delta[i],self.usde[i].snapshot(),
                              self.nav[i].last_correction_time,self.network.local_observation(i+1),self.coord_cache[i])
                         for i in range(c.n_auv)])

    def slow_state(self):
        payloads={i:d.packet.payload for i,d in self.network.received_states.items()}
        result=build_root_observation(self.cfg,self.time,self.step_count,self.usv_position,
                                      payloads,self.network.root_observation(self.time))
        return result,self.network.action_mask(self.time).copy()

    def assert_conservation(self):
        m=self.metrics;c=self.cfg
        physical=sum(map(len,self.buffers))*c.data_packet_bits
        assert m['initial_bits']+m['arrival_bits']==m['overflow_bits']+m['ack_released_bits']+physical
        assert m['collected_bits']==len(self.collected)*c.data_packet_bits
        assert self.acknowledged<=self.collected
        assert all(len(b)<=c.buffer_packets for b in self.buffers)

    def _info(self):
        c=self.cfg;m=dict(self.metrics)
        network=self.network.snapshot_metrics()
        for key,value in network.items():
            if isinstance(value,(int,float,np.number)):m['network_'+key]=float(value)
        m['communication_energy_j']=float(np.sum(self.network.energy_j))
        m['total_energy_j']=float(m['propulsion_energy_j']+m['usv_energy_j']+m['communication_energy_j'])
        m['buffer_bits']=sum(map(len,self.buffers))*c.data_packet_bits
        m['mean_aoi_s']=float(np.mean([self.time-d.packet.created_at if (d:=self.network.received_states.get(i+1)) is not None else self.time for i in range(c.n_auv)]))
        m['position_rmse_m']=float(np.sqrt(np.mean([np.sum((self.nav[i].position-self.auv_positions[i])**2) for i in range(c.n_auv)])))
        # Truth appears only in diagnostic info, never in actor or planner inputs.
        flow=self.current.velocity(self.auv_positions,self.time)
        m['disturbance_rmse_mps']=float(np.sqrt(np.mean([(np.linalg.norm(e.estimate-flow[i]))**2 for i,e in enumerate(self.usde)])))
        return {'metrics':m,'time':self.time,'step':self.step_count,'termination_reason':self.termination_reason}

    def close(self):
        pass
