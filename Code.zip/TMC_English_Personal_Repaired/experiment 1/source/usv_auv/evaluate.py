"""Bounded simulation-only evaluation with frozen policies and JSONL metrics."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np

from .deploy import DeploymentPolicy, load_checkpoint
from .learning import seed_all
from .train import json_safe, load_environment_config


def evaluate_checkpoint(checkpoint_path: Path, output: Path, steps: int = 200,
                        episodes: int = 1, seed: int = 10_000, device: str = "cpu",
                        config_path: Path | None = None) -> dict[str, Any]:
    from .environment import CooperativeEnv
    if steps < 1 or episodes < 1:
        raise ValueError("steps and episodes must be positive")
    checkpoint = load_checkpoint(checkpoint_path)
    policy = DeploymentPolicy(checkpoint, device)
    cfg = load_environment_config(config_path, checkpoint["environment_config"])
    seed_all(seed)
    env = CooperativeEnv(cfg)
    output.mkdir(parents=True, exist_ok=True)
    episode_results = []
    with (output / "evaluation.jsonl").open("w", encoding="utf-8") as log:
        for episode in range(episodes):
            observations, info = env.reset(seed=seed + episode)
            if episode == 0:
                policy.validate_environment(env, check_config=config_path is None)
            total_reward = 0.0
            terminated = truncated = False
            for step in range(steps):
                topology_action = None
                if env.step_count % cfg.slow_period == 0:
                    slow_state, mask = env.slow_state()
                    topology_action = policy.topology_action(slow_state, mask)
                actions = policy.act(observations)
                observations, reward, terminated, truncated, info = env.step(actions, topology_action=topology_action)
                total_reward += float(reward)
                log.write(json.dumps({"episode": episode, "step": step + 1,
                                      "reward": float(reward), "topology_request": topology_action,
                                      "actions": actions.tolist(), "terminated": bool(terminated),
                                      "truncated": bool(truncated), "info": json_safe(info)},
                                     ensure_ascii=False) + "\n")
                if terminated or truncated:
                    break
            result = {"episode": episode, "seed": seed + episode, "steps": step + 1,
                      "return": total_reward, "terminated": bool(terminated), "truncated": bool(truncated),
                      "evaluation_limit_reached": not (terminated or truncated) and step + 1 == steps,
                      "final_info": json_safe(info)}
            episode_results.append(result)
    returns = np.array([result["return"] for result in episode_results])
    summary = {"scope": "Frozen policy simulation, not sea-trial validation or a comparative improvement result.",
               "checkpoint": str(checkpoint_path), "training_steps": checkpoint.get("global_step"),
               "training_config_fingerprint": policy.config_fingerprint,
               "evaluation_config_fingerprint": cfg.fingerprint,
               "explicit_test_scenario_override": config_path is not None,
               "episodes": episode_results, "mean_return": float(returns.mean()),
               "std_return": float(returns.std()), "device": device}
    (output / "evaluation_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("--output", type=Path, default=Path("runs/evaluation"))
    parser.add_argument("--config", type=Path, help="Optional explicit test scenario, with matching observation/action dimensions")
    parser.add_argument("--steps", type=int, default=200, help="Maximum steps per episode")
    parser.add_argument("--episodes", type=int, default=1)
    parser.add_argument("--seed", type=int, default=10_000)
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    print(json.dumps(evaluate_checkpoint(args.checkpoint, args.output, args.steps, args.episodes,
                                         args.seed, args.device, args.config), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
