"""Read-only runtime and one-step environment validation; does not train."""
import json
import platform
import sys
import numpy as np
import torch
from .config import Config
from .environment import CooperativeEnv


def main():
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA is required for the intended training workflow. No CPU fallback is taken.')
    x=torch.randn((16,16),device='cuda',requires_grad=True)
    loss=(x@x.T).square().mean();loss.backward();torch.cuda.synchronize()
    env=CooperativeEnv(Config())
    obs,info=env.reset()
    env.step(np.tile([-1.,0.],(env.cfg.n_auv,1)),topology_action=0)
    result=dict(python=sys.executable,python_version=platform.python_version(),torch=torch.__version__,
                numpy=np.__version__,cuda=torch.version.cuda,gpu=torch.cuda.get_device_name(0),
                gpu_forward_backward='passed',observations=list(obs.shape),
                slow_observation_dim=env.slow_observation_dim,topology_actions=env.network.n_actions,
                one_environment_step='passed',training_started=False)
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
