"""Topology-aware, disturbance-informed USV/AUV research simulation.

TD3 commands water-relative velocity directly. No low-level controller is used.
"""
__version__ = "0.1.0"
