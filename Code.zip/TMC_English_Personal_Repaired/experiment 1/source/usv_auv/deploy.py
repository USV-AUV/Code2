"""Pure policy inference for simulation; no vehicle or sea-trial interface.

Load only trusted local checkpoints. JSONL input contains observations already
constructed from local measurements and received messages, never raw simulator
truth. The module neither estimates currents nor corrects the returned actions.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch

from .learning import _mask, mlp, resolve_device
from .actions import action_encoding, normalized_action_schema, physical_commands as decode_physical_commands


def load_checkpoint(path: str | Path) -> dict[str, Any]:
    return torch.load(Path(path), map_location="cpu", weights_only=False)


def config_fingerprint(values: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(values, sort_keys=True).encode()).hexdigest()[:16]


def environment_schema(env) -> dict[str, Any]:
    cfg = env.cfg if hasattr(env, "cfg") else env.config
    fields = getattr(env, "observation_schema", None)
    if callable(fields):
        fields = fields()
    slow_fields = getattr(env, "slow_observation_schema", None)
    if callable(slow_fields):
        slow_fields = slow_fields()
    return {"version": getattr(env, "observation_schema_version", "usv-auv-full-v1"),
            "n_auv": cfg.n_auv,
            "observation_dim": int(env.observation_dim),
            "slow_observation_dim": int(env.slow_observation_dim),
            "topology_actions": int(env.network.n_actions),
            "topology_candidates": [list(parents) for parents in env.network.candidates],
            "fields": fields, "slow_fields": slow_fields,
            "action_encoding": action_encoding(getattr(cfg, "action_frame", "global"))}


def inference_payload(checkpoint: dict[str, Any]) -> dict[str, Any]:
    """Strip replay, optimizers, critic weights, and training-only state."""
    return {"format": "usv-auv-topology-usde-inference-v1",
            "environment_config": checkpoint["environment_config"],
            "config_fingerprint": checkpoint["config_fingerprint"],
            "observation_schema": normalized_action_schema(checkpoint["observation_schema"],
                                                            checkpoint["environment_config"].get("action_frame", "global")),
            "learning_config": checkpoint["learning_config"],
            "global_step": checkpoint.get("global_step", 0),
            "training_stage": checkpoint.get("training_stage"),
            "agents": [{"actor": item["actor"], "observation_dim": item["observation_dim"],
                        "action_dim": item["action_dim"]} for item in checkpoint["agents"]],
            "topology": {key: checkpoint["topology"][key]
                         for key in ("online", "observation_dim", "n_actions")},
            "scope": "Simulation inference only; not sea-trial validated; no hardware interface."}


class DeploymentPolicy:
    def __init__(self, checkpoint: dict[str, Any], device: str = "cpu") -> None:
        self.device = resolve_device(device)
        self.environment_config = checkpoint["environment_config"]
        self.config_fingerprint = checkpoint["config_fingerprint"]
        if config_fingerprint(self.environment_config) != self.config_fingerprint:
            raise ValueError("Checkpoint configuration fingerprint is inconsistent")
        self.action_frame = self.environment_config.get("action_frame", "global")
        self.schema = normalized_action_schema(checkpoint["observation_schema"], self.action_frame)
        from .observations import SCHEMA_VERSION, observation_fields, root_observation_fields
        n_auv = self.environment_config["n_auv"]
        if (self.schema.get("version") != SCHEMA_VERSION
                or self.schema.get("fields") != observation_fields(n_auv)
                or self.schema.get("slow_fields") != root_observation_fields(n_auv)):
            raise ValueError("Checkpoint observation field order/version does not match this inference implementation")
        hidden = checkpoint["learning_config"]["hidden_dim"]
        self.actors = []
        self.observation_dims = []
        for saved in checkpoint["agents"]:
            if saved["action_dim"] != 2:
                raise ValueError("This simulator requires two normalized final velocity commands")
            actor = mlp(saved["observation_dim"], saved["action_dim"], hidden, True).to(self.device)
            actor.load_state_dict(saved["actor"])
            actor.eval().requires_grad_(False)
            self.actors.append(actor)
            self.observation_dims.append(saved["observation_dim"])
        topology = checkpoint["topology"]
        self.slow_observation_dim = topology["observation_dim"]
        self.n_actions = topology["n_actions"]
        self.topology = mlp(self.slow_observation_dim, self.n_actions, hidden).to(self.device)
        self.topology.load_state_dict(topology["online"])
        self.topology.eval().requires_grad_(False)
        if (self.schema["n_auv"] != len(self.actors)
                or self.schema["n_auv"] != n_auv
                or any(dimension != self.schema["observation_dim"] for dimension in self.observation_dims)
                or self.schema["slow_observation_dim"] != self.slow_observation_dim
                or self.schema["topology_actions"] != self.n_actions):
            raise ValueError("Checkpoint network dimensions disagree with its observation schema")

    def validate_schema(self, schema: dict[str, Any], configuration_fingerprint: str) -> None:
        """Allow a telemetry adapter to validate without constructing a simulator."""
        if normalized_action_schema(schema) != self.schema or configuration_fingerprint != self.config_fingerprint:
            raise ValueError("Telemetry schema or configuration does not match checkpoint")

    @classmethod
    def from_checkpoint(cls, path: str | Path, device: str = "cpu") -> "DeploymentPolicy":
        return cls(load_checkpoint(path), device)

    def validate_environment(self, env, check_config: bool = True) -> None:
        if environment_schema(env) != self.schema:
            raise ValueError("Environment observation fields or topology action ordering differ from checkpoint")
        cfg = env.cfg if hasattr(env, "cfg") else env.config
        if check_config and cfg.fingerprint != self.config_fingerprint:
            # A legacy complete configuration can omit newly introduced fields
            # whose defaults preserve the legacy behavior (e.g. global frame).
            # The stored raw fingerprint was already authenticated on load;
            # require exact full equality after explicit default expansion.
            from .config import Config
            if Config.from_dict(self.environment_config).to_dict() != cfg.to_dict():
                raise ValueError("Environment configuration differs from checkpoint")

    def act(self, observations: Any) -> np.ndarray:
        observations = np.asarray(observations, np.float32)
        if len(observations) != len(self.actors) or not np.isfinite(observations).all():
            raise ValueError("inference observation count or finiteness mismatch")
        actions = []
        with torch.inference_mode():
            for i, actor in enumerate(self.actors):
                if observations[i].shape != (self.observation_dims[i],):
                    raise ValueError(f"AUV {i} observation dimension mismatch")
                action = actor(torch.as_tensor(observations[i], device=self.device))
                actions.append(action.cpu().numpy())
        return np.asarray(actions, np.float32)

    def physical_commands(self, normalized_actions: Any, observations: Any = None) -> dict[str, np.ndarray]:
        """Decode the actor's final commands, with no disturbance compensation.

        Directions are world-frame planar velocity directions, not a tested
        vessel heading controller. No physical device is commanded here.
        """
        actions = np.asarray(normalized_actions, dtype=float)
        if actions.shape != (len(self.actors), 2) or not np.isfinite(actions).all():
            raise ValueError("normalized actions have invalid shape or values")
        if observations is not None:
            observations = np.asarray(observations, dtype=float)
            if (observations.shape != (len(self.actors), self.schema["observation_dim"])
                    or not np.all(np.isfinite(observations))):
                raise ValueError("Physical command observations must match the complete actor observation schema")
        return decode_physical_commands(actions, self.environment_config["max_speed"],
                                        self.action_frame, observations)

    def topology_action(self, slow_observation: Any, mask: Any) -> int:
        mask = _mask(mask, self.n_actions)
        state = np.asarray(slow_observation, np.float32)
        if state.shape != (self.slow_observation_dim,) or not np.isfinite(state).all():
            raise ValueError("slow observation dimension or finiteness mismatch")
        with torch.inference_mode():
            values = self.topology(torch.as_tensor(state, device=self.device))
            values = values.masked_fill(~torch.as_tensor(mask, device=self.device), -torch.inf)
            return int(values.argmax().item())


def main() -> None:
    parser = argparse.ArgumentParser(description="Simulation-only policy JSONL inference; no hardware control.")
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("--input", default="-", help="JSONL path or - for stdin")
    parser.add_argument("--output", default="-", help="JSONL path or - for stdout")
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    policy = DeploymentPolicy.from_checkpoint(args.checkpoint, args.device)
    source = sys.stdin if args.input == "-" else Path(args.input).open(encoding="utf-8")
    destination = sys.stdout if args.output == "-" else Path(args.output).open("w", encoding="utf-8")
    try:
        for line in source:
            if not line.strip():
                continue
            item = json.loads(line)
            if 'observation_schema' not in item or 'config_fingerprint' not in item:
                raise ValueError('Telemetry must declare observation_schema and config_fingerprint')
            policy.validate_schema(item['observation_schema'],item['config_fingerprint'])
            actions = policy.act(item["observations"])
            result = {"actions": actions.tolist(), "topology_action": None,
                      "action_encoding": policy.schema["action_encoding"],
                      **{key: value.tolist() for key, value in policy.physical_commands(actions, item["observations"]).items()}}
            if "slow_state" in item or "mask" in item:
                if "slow_state" not in item or "mask" not in item:
                    raise ValueError("slow_state and mask must be supplied together")
                result["topology_action"] = policy.topology_action(item["slow_state"], item["mask"])
            destination.write(json.dumps(result, ensure_ascii=False) + "\n")
            destination.flush()
    finally:
        if source is not sys.stdin:
            source.close()
        if destination is not sys.stdout:
            destination.close()


if __name__ == "__main__":
    main()
