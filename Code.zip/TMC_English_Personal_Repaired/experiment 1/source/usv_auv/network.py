"""Causal acoustic packets, fixed-owner TDMA and locally installed two-hop routes.

Physical link state is private to the simulator. Policy masks use only reports
which have actually arrived at node zero. All packets, including discovery and
configuration acknowledgements, share the same serialized acoustic resource.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from collections import Counter, defaultdict, deque
from itertools import product
from typing import Any, Callable, Mapping
import copy
import heapq
import math

import numpy as np


def _get(cfg: Any, names: str | tuple[str, ...], default: Any) -> Any:
    if isinstance(names, str):
        names = (names,)
    for name in names:
        if isinstance(cfg, Mapping) and name in cfg:
            return cfg[name]
        if hasattr(cfg, name):
            return getattr(cfg, name)
    return default


@dataclass
class Packet:
    src: int
    dst: int
    kind: str = "STATE"
    payload: Any = field(default_factory=dict)
    created_at: float = 0.0
    size_bits: int = 512
    seq: int = -1
    ttl: int = 2
    route_version: int | None = None
    expires_at: float = math.inf


@dataclass
class Delivery:
    packet: Packet
    receiver: int
    arrived_at: float
    transmitter: int
    duplicate: bool = False

    @property
    def time(self) -> float:
        return self.arrived_at


@dataclass
class _Queued:
    packet: Packet
    next_hop: int | None = None
    routed: bool = False


MANAGEMENT = {"HELLO", "HELLO_ACK", "REPORT", "CONFIG", "CONFIG_ACK"}
ROUTED = {"STATE", "COORD"}


class AcousticNetwork:
    """Standalone CPU network. ``advance`` returns real application arrivals.

    Node zero is the USV, 1..n_auvs are AUVs and remaining IDs are sensors.
    ``positions`` is a node-indexed (N,2/3) array or a callable of event time.
    No graph based on these true positions is returned by observation methods.
    """

    def __init__(self, cfg: Any = None, seed: int = 0):
        cfg = {} if cfg is None else cfg
        self.cfg = cfg
        self.n_auvs = int(_get(cfg, ("n_auvs", "n_auv", "N_AUV"), 2))
        self.n_sensors = int(_get(cfg, ("n_sensors", "n_s", "n_sn"), 0))
        self.n_nodes = 1 + self.n_auvs + self.n_sensors
        self.cooperative_nodes = tuple(range(self.n_auvs + 1))
        self.rate_bps = float(_get(cfg, ("bit_rate", "acoustic_rate_bps", "rate_bps"), 8000.0))
        self.bandwidth_hz = float(_get(cfg, "bandwidth_hz", self.rate_bps))
        self.sound_speed = float(_get(cfg, ("sound_speed", "c_sound"), 1500.0))
        self.max_range = float(_get(cfg, ("link_range", "acoustic_max_range", "max_range"), 350.0))
        declared_data = int(_get(cfg, "data_packet_bits", 512)) + int(_get(cfg, "data_header_bits", 0))
        declared = max(declared_data, int(_get(cfg, "state_packet_bits", 512)),
                       int(_get(cfg, "control_packet_bits", 512)))
        self.max_packet_bits = int(_get(cfg, "max_packet_bits", declared))
        self.control_packet_bits = int(_get(cfg, "control_packet_bits", 512))
        self.guard = float(_get(cfg, ("guard_time", "guard_s", "guard"), 0.02))
        self.processing_delay = float(_get(cfg, "processing_delay", 0.0))
        geometric_max = math.sqrt(2 * float(_get(cfg, "area_size", self.max_range))**2 + float(_get(cfg, "sensor_depth", 0))**2)
        self.propagation_bound = min(self.max_range, geometric_max)
        minimum = self.max_packet_bits / self.rate_bps + self.propagation_bound / self.sound_speed + self.guard + self.processing_delay
        self.slot_duration = float(_get(cfg, ("slot_duration", "slot_s"), minimum))
        if self.slot_duration + 1e-12 < minimum:
            raise ValueError("slot_duration is shorter than serialization + propagation + guard")
        explicit_owners = _get(cfg, "slot_owners", None)
        group_size = _get(cfg, "tdma_sensors_per_group", None)
        if explicit_owners is not None:
            owners = explicit_owners
        elif group_size is not None:
            group_size = int(group_size)
            if group_size <= 0:
                raise ValueError("tdma_sensors_per_group must be positive")
            sensors = list(range(self.n_auvs + 1, self.n_nodes))
            owners = []
            for offset in range(0, max(1, len(sensors)), group_size):
                owners.extend(self.cooperative_nodes)
                owners.extend(sensors[offset:offset + group_size])
        else:
            owners = range(self.n_nodes)
        self.slot_owners = tuple(int(x) for x in owners)
        if not self.slot_owners or any(i < 0 or i >= self.n_nodes for i in self.slot_owners):
            raise ValueError("slot_owners must be valid preinstalled node IDs")
        self.base_per = float(_get(cfg, ("base_per", "packet_error_rate"), 0.02))
        self.distance_per = float(_get(cfg, "distance_per", 0.10))
        self.hello_period = float(_get(cfg, "hello_period", 10.0))
        self.report_max_age = float(_get(cfg, ("report_ttl", "report_max_age"), 60.0))
        self.config_timeout = float(_get(cfg, "config_timeout", 60.0))
        self.route_lease = float(_get(cfg, "route_lease", 600.0))
        self.max_config_retries = int(_get(cfg, ("max_retries", "max_config_retries"), 2))
        self.max_queue = int(_get(cfg, ("queue_limit", "max_queue"), 128))
        self.switch_dwell = float(_get(cfg, "switch_dwell", 0.0))
        self.state_ttl = float(_get(cfg, "state_ttl", 90.0))
        self.max_management_run = int(_get(cfg, "max_management_run", 2))
        self.discovery_enabled = bool(_get(cfg, "discovery_enabled", True))
        self.tx_w = float(_get(cfg, ("tx_power_w", "tx_w"), 8.0))
        self.rx_w = float(_get(cfg, ("rx_power_w", "rx_w"), 0.6))
        self.listen_w = float(_get(cfg, ("listen_power_w", "listen_w"), 0.05))
        self.snr_db_at_100m = _get(cfg, "snr_db_at_100m", None)
        self.spreading_db = float(_get(cfg, "spreading_db", 15.0))
        self.absorption_db_per_km = float(_get(cfg, "absorption_db_per_km", 4.0))
        self.burst_good_to_bad = float(_get(cfg, "burst_good_to_bad", 0.0))
        self.burst_bad_to_good = float(_get(cfg, "burst_bad_to_good", 1.0))
        self.burst_bad_per = float(_get(cfg, "burst_bad_per", 0.7))
        if not (0 <= self.base_per <= 1) or self.rate_bps <= 0 or self.sound_speed <= 0:
            raise ValueError("invalid physical network parameters")
        self.rng = np.random.default_rng(seed)
        self._burst_rng = np.random.default_rng(np.random.SeedSequence([int(seed), 529]))
        self._burst_bad = np.zeros((self.n_nodes, self.n_nodes), dtype=bool)
        self._burst_tick = -1
        self.seed = int(seed)
        self.time = 0.0
        self._slot_index = 0
        self._event_id = 0
        self._events: list[tuple[float, int, str, Any]] = []
        self._queues = {i: deque() for i in range(self.n_nodes)}
        self._seq = Counter()
        self._management_run = Counter()
        self._management_cursor = Counter()
        self._last_application_flow: dict[int, tuple[str, int, int]] = {}
        self._seen = defaultdict(set)
        self._delivered_ids = defaultdict(set)
        self._next_hello = {i: 0.0 for i in self.cooperative_nodes}
        self._local_edges = {i: {} for i in self.cooperative_nodes}
        self._root_edges: dict[tuple[int, int], tuple[float, float]] = {}
        self._pending_probes: dict[tuple[int, int, int], tuple[float, float]] = {}
        coop_gaps = []
        for node in self.cooperative_nodes:
            offsets = [i for i, owner in enumerate(self.slot_owners) if owner == node]
            if not offsets:
                raise ValueError("every cooperative node needs a preinstalled slot")
            coop_gaps.extend(b - a for a, b in zip(offsets, offsets[1:] + [offsets[0] + len(self.slot_owners)]))
        self.cooperative_slot_gap = max(coop_gaps) * self.slot_duration
        fair_round = (self.n_auvs + 2) * self.cooperative_slot_gap * (1.0 + 1.0 / max(1, self.max_management_run))
        self.probe_timeout = float(_get(cfg, "probe_timeout", max(self.hello_period, fair_round) + self.slot_duration))
        self._radio_intervals: list[tuple[float, float, int, float]] = []
        self.receive_cache = {i: {} for i in self.cooperative_nodes}
        self.metrics = Counter()
        self.energy_j = np.zeros(self.n_nodes, dtype=float)
        self.faults: list[dict[str, Any]] = []
        for fault in _get(cfg, "faults", []):
            if isinstance(fault, Mapping):
                self.add_fault(**fault)
            else:
                self.add_fault(*fault)
        self.topologies = self._enumerate_topologies()
        self.candidates = self.topologies
        self.active_parents = tuple(0 for _ in range(self.n_auvs))
        self.active_version = {i: 0 for i in self.cooperative_nodes}
        self.installed_routes = {i: {0: (self.active_parents, math.inf)} for i in self.cooperative_nodes}
        self.confirmed_versions = {i: 0 for i in self.cooperative_nodes}
        self.pending: dict[str, Any] | None = None
        self._version_counter = 0
        self._last_switch = -math.inf
        self._outbox: list[Delivery] = []
        self.application_link_filter: Callable[[Packet, int, int, float, np.ndarray], bool] | None = None
        self.on_transmit_payload: Callable[[Packet, int, int, float, np.ndarray], dict | None] | None = None
        self._current_positions: Any = None

    def _enumerate_topologies(self) -> list[tuple[int, ...]]:
        trees = []
        for parents in product(range(self.n_auvs + 1), repeat=self.n_auvs):
            if all(self._valid_path(i, parents) for i in range(1, self.n_auvs + 1)):
                trees.append(tuple(parents))
        return trees

    @staticmethod
    def _valid_path(node: int, parents: tuple[int, ...]) -> bool:
        seen = set()
        for _ in range(2):
            if node == 0:
                return True
            if node in seen or node < 1 or node > len(parents):
                return False
            seen.add(node)
            node = parents[node - 1]
        return node == 0

    def candidate_topologies(self) -> list[tuple[int, ...]]:
        return list(self.topologies)

    @property
    def n_actions(self) -> int:
        return len(self.topologies) + 1  # index zero is KEEP/RECOVER

    def add_fault(self, src: int, dst: int, start: float, end: float,
                  bidirectional: bool = False, **_: Any) -> None:
        if end <= start:
            raise ValueError("fault end must follow start")
        self.faults.append(dict(src=int(src), dst=int(dst), start=float(start), end=float(end)))
        if bidirectional:
            self.faults.append(dict(src=int(dst), dst=int(src), start=float(start), end=float(end)))

    def submit(self, packet: Packet | Mapping[str, Any]) -> int:
        if not isinstance(packet, Packet):
            packet = Packet(**packet)
        packet = copy.deepcopy(packet)
        self._check_node(packet.src)
        if packet.dst != -1:
            self._check_node(packet.dst)
        if packet.created_at > self.time + 1e-9:
            raise ValueError("cannot queue a packet generated in the future")
        if packet.size_bits <= 0 or packet.size_bits > self.max_packet_bits:
            raise ValueError("packet size exceeds the declared fixed-slot payload limit")
        if packet.seq < 0:
            packet.seq = self._new_seq(packet.src)
        if packet.kind in ROUTED and packet.route_version is None:
            packet.route_version = self.active_version.get(packet.src, 0)
        if packet.kind in ROUTED and math.isinf(packet.expires_at):
            packet.expires_at = packet.created_at + self.state_ttl
        self._enqueue(packet.src, packet, routed=packet.kind in ROUTED)
        return packet.seq

    send = submit

    def _check_node(self, node: int) -> None:
        if not 0 <= node < self.n_nodes:
            raise ValueError(f"unknown node {node}")

    def _new_seq(self, src: int) -> int:
        self._seq[src] += 1
        return self._seq[src]

    def _enqueue(self, owner: int, packet: Packet, next_hop: int | None = None,
                 routed: bool = False) -> None:
        queue = self._queues[owner]
        if packet.kind in ROUTED or packet.kind in {"HELLO", "REPORT"}:
            retained = [q for q in queue if not (
                q.packet.kind == packet.kind and q.packet.src == packet.src
                and q.packet.dst == packet.dst and q.packet.created_at <= packet.created_at)]
            self.metrics["queue_replaced"] += len(queue) - len(retained)
            queue.clear()
            queue.extend(retained)
        if len(queue) >= self.max_queue:
            self.metrics["queue_dropped"] += 1
            return
        queue.append(_Queued(packet, next_hop, routed))

    def _management(self, src: int, dst: int, kind: str, payload: Any,
                    *, ttl: int = 2, version: int | None = None,
                    next_hop: int | None = None, routed: bool = False) -> None:
        # Compact on-wire metadata budget: header + directed edge IDs, source
        # measurement time and one success flag. No application state is here.
        edges = payload.get("edges", []) if isinstance(payload, dict) else []
        bits = max(self.control_packet_bits, 128 + 64 * len(edges))
        if bits > self.max_packet_bits:
            raise ValueError("link report exceeds declared physical packet size")
        p = Packet(src, dst, kind, payload, self.time, bits,
                   self._new_seq(src), ttl, version,
                   self.time + max(self.report_max_age, self.config_timeout))
        self._enqueue(src, p, next_hop, routed)

    def _push_event(self, at: float, kind: str, value: Any) -> None:
        self._event_id += 1
        heapq.heappush(self._events, (at, self._event_id, kind, value))

    def advance(self, t_end: float, positions: np.ndarray | Callable[[float], np.ndarray]) -> list[Delivery]:
        if t_end < self.time - 1e-10:
            raise ValueError("network time cannot move backwards")
        self._outbox = []
        self._current_positions = positions
        while True:
            slot_time = self._slot_index * self.slot_duration
            event_time = self._events[0][0] if self._events else math.inf
            next_time = min(slot_time, event_time)
            if next_time > t_end + 1e-10:
                break
            self._accrue_listen(next_time)
            self.time = next_time
            # Arrivals at a boundary precede that boundary's slot transmission.
            if event_time <= slot_time + 1e-12:
                _, _, kind, data = heapq.heappop(self._events)
                if kind == "arrival":
                    self._receive(*data)
                continue
            self._maintenance()
            owner = self.slot_owners[self._slot_index % len(self.slot_owners)]
            self._slot_index += 1
            self._transmit_slot(owner, positions)
        self._accrue_listen(float(t_end))
        self.time = float(t_end)
        return list(self._outbox)

    def _accrue_listen(self, until: float) -> None:
        self.energy_j += self.listen_w * max(0.0, until - self.time)
        for start, end, node, power in self._radio_intervals:
            self.energy_j[node] += max(0.0, min(until, end) - max(self.time, start)) * power
        self._radio_intervals = [span for span in self._radio_intervals if span[1] > until]

    def _maintenance(self) -> None:
        while self._burst_tick < int(math.floor(self.time)):
            self._burst_tick += 1
            randoms = self._burst_rng.random(self._burst_bad.shape)
            self._burst_bad = np.where(self._burst_bad,
                randoms >= self.burst_bad_to_good, randoms < self.burst_good_to_bad)
        for (observer, peer, seq), (deadline, probe_time) in list(self._pending_probes.items()):
            if deadline <= self.time:
                # A missed ACK identifies failed two-way exchange, not which
                # physical direction failed. Conservative pair evidence only.
                self._note_edge(observer, observer, peer, probe_time, 0.0)
                self._note_edge(observer, peer, observer, probe_time, 0.0)
                del self._pending_probes[(observer, peer, seq)]
                self.metrics["probe_timeouts"] += 1
        if self.discovery_enabled:
            for node in self.cooperative_nodes:
                if self.time + 1e-10 >= self._next_hello[node]:
                    own_table = self._root_edges if node == 0 else self._local_edges[node]
                    # Only self-observed incident links may be piggybacked. Do
                    # not recursively gossip reports into an unlimited flood.
                    edges = [(a, b, t, p) for (a, b), (t, p) in own_table.items()
                             if node in (a, b)]
                    self._management(node, -1, "HELLO", {"edges": edges}, ttl=1)
                    self._next_hello[node] = self.time + self.hello_period
        if self.pending and self.time >= self.pending["deadline"]:
            if self.pending["retries"] < self.max_config_retries:
                self.pending["retries"] += 1
                self.pending["deadline"] = self.time + self.config_timeout
                self._send_config_roots()
            else:
                self.metrics["config_timeouts"] += 1
                self.pending = None

    def _pop_queue(self, owner: int) -> _Queued | None:
        queue = self._queues[owner]
        kept = [q for q in queue if q.packet.expires_at >= self.time]
        self.metrics["expired_packets"] += len(queue) - len(kept)
        queue.clear()
        queue.extend(kept)
        if not queue:
            return None
        app_indices = [i for i, q in enumerate(queue) if q.packet.kind not in MANAGEMENT]
        mgmt_indices = [i for i, q in enumerate(queue) if q.packet.kind in MANAGEMENT]
        if app_indices and (not mgmt_indices or self._management_run[owner] >= self.max_management_run):
            # Latest-sample replacement must not keep moving STATE/COORD behind
            # a permanent stream of request/ACK packets. Round-robin flow IDs
            # are independent of enqueue time and protect every destination.
            def flow(i: int) -> tuple[str, int, int]:
                p = queue[i].packet
                return (p.kind, p.src, p.dst)
            flows = sorted({flow(i) for i in app_indices})
            previous = self._last_application_flow.get(owner)
            selected = next((f for f in flows if previous is None or f > previous), flows[0])
            index = next(i for i in app_indices if flow(i) == selected)
            self._last_application_flow[owner] = selected
            self._management_run[owner] = 0
        else:
            # Bounded class service prevents ACKs from starving HELLO/reports.
            # There can be n_auvs ACKs for each broadcast HELLO opportunity.
            urgent = [i for i in mgmt_indices if queue[i].packet.kind in {"CONFIG", "CONFIG_ACK"}]
            cycle = ["HELLO_ACK"] * self.n_auvs + ["HELLO", "REPORT"]
            index = None
            if urgent:
                index = urgent[0]
            elif mgmt_indices:
                for _ in range(len(cycle)):
                    kind = cycle[self._management_cursor[owner] % len(cycle)]
                    self._management_cursor[owner] += 1
                    choices = [i for i in mgmt_indices if queue[i].packet.kind == kind]
                    if choices:
                        index = choices[0]
                        break
            if index is None:
                index = (mgmt_indices or app_indices)[0]
            self._management_run[owner] += 1
        item = queue[index]
        del queue[index]
        return item

    def _positions_at(self, positions: Any, at: float) -> np.ndarray:
        value = positions(at) if callable(positions) else positions
        value = np.asarray(value, dtype=float)
        if value.ndim != 2 or value.shape[0] != self.n_nodes or value.shape[1] not in (2, 3):
            raise ValueError("positions must contain one 2D/3D position per network node")
        return value

    def _is_failed(self, src: int, dst: int, start: float, finish: float) -> bool:
        return any(f["src"] == src and f["dst"] == dst
                   and start < f["end"] and finish > f["start"] for f in self.faults)

    def _transmit_slot(self, owner: int, positions: Any) -> None:
        item = self._pop_queue(owner)
        self.metrics["slots"] += 1
        if item is None:
            self.metrics["idle_slots"] += 1
            return
        p = item.packet
        if item.routed:
            hop = self._next_hop(owner, p.dst, p.route_version)
            if hop is None:
                self.metrics["no_route_dropped"] += 1
                return
            recipients = [hop]
        elif item.next_hop == -1:
            recipients = [i for i in self.cooperative_nodes if i != owner]
        elif item.next_hop is not None:
            recipients = [item.next_hop]
        elif p.dst == -1:
            recipients = [i for i in self.cooperative_nodes if i != owner]
        else:
            recipients = [p.dst]
        xy = self._positions_at(positions, self.time)
        duration = p.size_bits / self.rate_bps
        self._radio_intervals.append((self.time, self.time + duration, owner,
                                      max(0.0, self.tx_w - self.listen_w)))
        self.metrics["transmissions"] += 1
        self.metrics["tx_bits"] += p.size_bits
        self.metrics["busy_time"] += self.slot_duration
        if p.kind in MANAGEMENT:
            self.metrics["management_transmissions"] += 1
        else:
            self.metrics["application_transmissions"] += 1
        for receiver in recipients:
            emitted = copy.deepcopy(p)
            if p.kind == "LOCALIZATION" and self.on_transmit_payload is not None:
                payload = self.on_transmit_payload(copy.deepcopy(p), owner, receiver, self.time, xy.copy())
                if payload is not None:
                    if not isinstance(payload, dict):
                        raise TypeError("on_transmit_payload must return dict or None")
                    emitted.payload = copy.deepcopy(payload)
                    emitted.created_at = self.time
            distance = float(np.linalg.norm(xy[owner] - xy[receiver]))
            arrival = self.time + duration + distance / self.sound_speed + self.processing_delay
            if distance <= self.max_range:
                rx_start = self.time + distance / self.sound_speed
                self._radio_intervals.append((rx_start, rx_start + duration, receiver,
                                              max(0.0, self.rx_w - self.listen_w)))
            if p.kind == "HELLO":
                self._pending_probes[(owner, receiver, p.seq)] = (self.time + self.probe_timeout, self.time)
            if self.snr_db_at_100m is None:
                per = min(1.0, max(0.0, self.base_per + self.distance_per * (distance / self.max_range) ** 2))
            else:
                snr_db = float(self.snr_db_at_100m) - self.spreading_db * math.log10(max(distance, 1.0) / 100.0) - self.absorption_db_per_km * (distance - 100.0) / 1000.0
                # Received power SNR is not Eb/N0. For the declared uncoded
                # BPSK approximation, Eb/N0 = SNR * bandwidth / bit rate.
                eb_n0 = 10.0 ** (snr_db / 10.0) * self.bandwidth_hz / self.rate_bps
                ber = 0.5 * math.erfc(math.sqrt(eb_n0))
                per = 1.0 - (1.0 - self.base_per) * (1.0 - ber) ** p.size_bits
            if self._burst_bad[owner, receiver]:
                per = max(per, self.burst_bad_per)
            success = distance <= self.max_range and not self._is_failed(owner, receiver, self.time, arrival)
            if p.kind == "DATA" and self.application_link_filter is not None:
                success = success and bool(self.application_link_filter(p, owner, receiver, self.time, xy))
            success = success and self.rng.random() >= per
            if success:
                self._push_event(arrival, "arrival", (emitted, receiver, owner))
            else:
                self.metrics["failed_hops"] += 1

    def _next_hop(self, owner: int, dst: int, version: int | None) -> int | None:
        if owner == dst:
            return None
        record = self.installed_routes.get(owner, {}).get(version)
        if record is None or record[1] < self.time:
            return None
        parents, _ = record
        # Tree paths are computed from the version locally installed at owner.
        def ancestors(node: int) -> list[int]:
            path = [node]
            while node:
                node = parents[node - 1]
                if node in path or len(path) > 3:
                    return []
                path.append(node)
            return path
        left, right = ancestors(owner), ancestors(dst)
        if not left or not right:
            return None
        common = next((x for x in left if x in right), None)
        if common is None:
            return None
        path = left[:left.index(common) + 1] + list(reversed(right[:right.index(common)]))
        return path[1] if len(path) > 1 else None

    def _note_edge(self, observer: int, src: int, dst: int, measured_at: float, quality: float = 1.0) -> None:
        table = self._root_edges if observer == 0 else self._local_edges[observer]
        old = table.get((src, dst))
        if old is None or measured_at >= old[0]:
            table[(src, dst)] = (measured_at, quality)

    def _receive(self, p: Packet, receiver: int, transmitter: int) -> None:
        if p.expires_at < self.time:
            self.metrics["expired_arrivals"] += 1
            return
        if p.kind == "DATA" and self.application_link_filter is not None:
            xy = self._positions_at(self._current_positions, self.time)
            if not self.application_link_filter(p, transmitter, receiver, self.time, xy):
                self.metrics["application_range_dropped"] += 1
                return
        self.metrics["received_hops"] += 1
        if p.kind == "HELLO":
            self._note_edge(receiver, transmitter, receiver, self.time)
            if receiver == 0:
                for a, b, stamp, quality in p.payload.get("edges", []):
                    if transmitter in (int(a), int(b)):
                        self._note_edge(0, int(a), int(b), float(stamp), float(quality))
            self._management(receiver, transmitter, "HELLO_ACK",
                             {"probe_src": transmitter, "probe_seq": p.seq, "observed_at": self.time}, ttl=1)
            return
        if p.kind == "HELLO_ACK":
            self._pending_probes.pop((receiver, transmitter, int(p.payload["probe_seq"])), None)
            self._note_edge(receiver, transmitter, receiver, self.time)
            self._note_edge(receiver, receiver, transmitter, float(p.payload["observed_at"]))
            return
        if p.kind == "REPORT":
            key = (p.src, p.seq, p.kind)
            if key in self._seen[receiver]:
                return
            self._seen[receiver].add(key)
            if receiver == 0:
                for a, b, t, quality in p.payload["edges"]:
                    self._note_edge(0, int(a), int(b), float(t), float(quality))
            elif p.ttl > 1 and receiver != p.src:
                self._enqueue(receiver, replace(p, ttl=p.ttl - 1), next_hop=-1)
            return
        if p.kind == "CONFIG":
            self._install_config(p, receiver)
            return
        if p.kind == "CONFIG_ACK" and receiver == 0:
            version = int(p.payload["version"])
            self.confirmed_versions[p.src] = max(self.confirmed_versions[p.src], version)
            if self.pending and self.pending["version"] == version:
                self.pending["acks"].add(p.src)
                if len(self.pending["acks"]) == self.n_auvs:
                    self.active_parents = self.pending["parents"]
                    self.active_version[0] = version
                    self.metrics["config_successes"] += 1
                    self.metrics["config_total_latency"] += self.time - self.pending["requested_at"]
                    self.pending = None
            return
        if p.kind in ROUTED or p.kind == "CONFIG_ACK":
            if receiver != p.dst:
                if p.ttl <= 1:
                    self.metrics["ttl_dropped"] += 1
                elif p.route_version in self.installed_routes.get(receiver, {}):
                    self._enqueue(receiver, replace(p, ttl=p.ttl - 1), routed=True)
                else:
                    self.metrics["unknown_version_dropped"] += 1
                return
        duplicate_key = (p.src, p.seq, p.kind)
        duplicate = duplicate_key in self._delivered_ids[receiver]
        self._delivered_ids[receiver].add(duplicate_key)
        if p.kind in ROUTED:
            cache = self.receive_cache[receiver]
            old = cache.get(p.src)
            if old is None or (p.created_at, p.seq) > (old.packet.created_at, old.packet.seq):
                cache[p.src] = Delivery(copy.deepcopy(p), receiver, self.time, transmitter, duplicate)
        self._outbox.append(Delivery(p, receiver, self.time, transmitter, duplicate))

    def request_topology(self, parents: int | tuple[int, ...] | list[int], time: float | None = None) -> bool:
        if time is not None and abs(time - self.time) > 1e-8:
            raise ValueError("topology request must use current network time")
        if isinstance(parents, (int, np.integer)):
            if parents == 0:
                return True
            if not 1 <= parents < self.n_actions:
                raise ValueError("invalid topology action")
            parents = self.topologies[int(parents) - 1]
        parents = tuple(int(x) for x in parents)
        if parents not in self.topologies:
            raise ValueError("topology must be a rooted loop-free depth-two tree")
        if self.pending is not None or self.time - self._last_switch < self.switch_dwell:
            return False
        if parents == self.active_parents and all(v == self.active_version[0] and self.installed_routes[i][v][1] >= self.time for i, v in self.active_version.items()):
            return True
        self._version_counter += 1
        version = self._version_counter
        expires = self.time + self.route_lease
        self.installed_routes[0][version] = (parents, expires)
        self.pending = dict(version=version, parents=parents, expires=expires,
                            deadline=self.time + self.config_timeout, requested_at=self.time,
                            retries=0, acks=set())
        self.metrics["config_requests"] += 1
        self._last_switch = self.time
        self._send_config_roots()
        return True

    def _send_config_roots(self) -> None:
        p = self.pending
        for node, parent in enumerate(p["parents"], start=1):
            if parent == 0:
                self._management(0, node, "CONFIG", {"parents": p["parents"], "version": p["version"], "expires": p["expires"]},
                                 version=p["version"], next_hop=node)

    def _install_config(self, p: Packet, receiver: int) -> None:
        version = int(p.payload["version"])
        expires = float(p.payload["expires"])
        parents = tuple(p.payload["parents"])
        if expires < self.time or version < self.active_version[receiver] or parents not in self.topologies:
            self.metrics["stale_configs"] += 1
            return
        self.installed_routes[receiver][version] = (parents, expires)
        self.active_version[receiver] = version
        self._management(receiver, 0, "CONFIG_ACK", {"version": version}, version=version, routed=True)
        for child, parent in enumerate(parents, start=1):
            if parent == receiver:
                self._enqueue(receiver, replace(p, dst=child), next_hop=child)

    def action_mask(self, time: float | None = None) -> np.ndarray:
        at = self.time if time is None else float(time)
        mask = np.zeros(self.n_actions, dtype=bool)
        mask[0] = True
        if self.pending is not None or at - self._last_switch < self.switch_dwell:
            return mask
        for index, parents in enumerate(self.topologies, start=1):
            available = True
            for node, parent in enumerate(parents, start=1):
                for edge in ((node, parent), (parent, node)):
                    report = self._root_edges.get(edge)
                    available &= report is not None and at - report[0] <= self.report_max_age and report[1] > 0
            mask[index] = available
        return mask

    def root_observation(self, time: float | None = None) -> dict[str, Any]:
        at = self.time if time is None else float(time)
        quality = np.zeros((self.n_auvs + 1, self.n_auvs + 1))
        ages = np.full_like(quality, np.inf)
        for (src, dst), (stamp, value) in self._root_edges.items():
            quality[src, dst] = value
            ages[src, dst] = max(0.0, at - stamp)
        return dict(time=at, link_quality=quality, report_age=ages,
                    mask=self.action_mask(at), active_parents=self.active_parents,
                    root_active_version=self.active_version[0],
                    confirmed_versions=dict(self.confirmed_versions),
                    pending=copy.deepcopy(self.pending), cache=copy.deepcopy(self.receive_cache[0]))

    def local_observation(self, node: int) -> dict[str, Any]:
        if node not in self.cooperative_nodes:
            raise ValueError("local coordination observations are only for USV/AUV")
        version = self.active_version[node]
        parents, expires = self.installed_routes[node][version]
        return dict(version=version, parent=(parents[node - 1] if node else -1),
                    parents=tuple(parents), route_valid=expires >= self.time,
                    cache=copy.deepcopy(self.receive_cache[node]))

    def snapshot_metrics(self) -> dict[str, Any]:
        result = dict(self.metrics)
        result["energy_j"] = self.energy_j.copy()
        result["time"] = self.time
        result["queue_lengths"] = {i: len(q) for i, q in self._queues.items()}
        return result

    @property
    def received_states(self) -> dict[int, Delivery]:
        return self.receive_cache[0]

    @property
    def root_parents(self) -> tuple[int, ...]:
        return self.active_parents

    @property
    def local_versions(self) -> dict[int, int]:
        return dict(self.active_version)

    @property
    def local_parents(self) -> dict[int, int]:
        return {i: self.installed_routes[i][self.active_version[i]][0][i-1] for i in range(1, self.n_auvs+1)}

    @property
    def root_confirmed(self) -> dict[int, int]:
        return dict(self.confirmed_versions)

    @property
    def link_reports(self) -> dict[tuple[int, int], tuple[float, float]]:
        """Root-received (measurement_time, success estimate), never true links."""
        return dict(self._root_edges)
