"""Causal local motion estimation, independent of simulator truth and controllers.

All positions and command integrals use metres in one world frame.  Absolute
navigation fixes never enter :class:`DiscreteUSDE`; only an independent motion
increment and the command integral over exactly the same interval do.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Sequence

import numpy as np


def _vector(value: Sequence[float] | np.ndarray, dimensions: int, name: str) -> np.ndarray:
    result = np.array(value, dtype=float, copy=True)
    if result.shape != (dimensions,) or not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be a finite vector of length {dimensions}")
    return result


@dataclass(frozen=True)
class EstimateSnapshot:
    """A copied estimate; ``valid`` refers to the latest measurement interval.

    ``initialized`` remains true during a measurement gap, whereas ``age`` and
    ``gaps`` record how stale that held estimate has become.  ``age`` is time
    since the latest valid interval ended, not a claim about zero filter lag.
    """

    estimate: np.ndarray
    valid: bool
    age: float
    initialized: bool
    residual: np.ndarray
    gaps: int = 0

    def to_dict(self) -> dict:
        return {
            "estimate": self.estimate.tolist(), "valid": self.valid,
            "age": self.age, "initialized": self.initialized,
            "residual": self.residual.tolist(), "gaps": self.gaps,
        }


class DiscreteUSDE:
    """Exponentially filter a measured interval-average velocity residual.

    This is a sampled USDE-inspired estimator, not an action compensator.
    ``command_integral`` is the sum/integral of *executed water-relative*
    velocities over ``elapsed``.  For a multi-step measurement it must include
    every command, rather than the final command multiplied by the whole gap.
    """

    def __init__(self, kappa: float, dimensions: int = 2) -> None:
        if not math.isfinite(kappa) or kappa <= 0:
            raise ValueError("kappa must be finite and positive")
        if not isinstance(dimensions, int) or dimensions < 1:
            raise ValueError("dimensions must be a positive integer")
        self.kappa = float(kappa)
        self.dimensions = dimensions
        self.reset()

    def reset(self) -> EstimateSnapshot:
        self._estimate = np.zeros(self.dimensions)
        self._residual = np.zeros(self.dimensions)
        self._valid = False
        self._initialized = False
        self._age = 0.0
        self._gaps = 0
        return self.snapshot()

    @property
    def estimate(self) -> np.ndarray:
        return self._estimate.copy()

    @property
    def age(self) -> float:
        return self._age

    @property
    def valid(self) -> bool:
        return self._valid

    @property
    def initialized(self) -> bool:
        return self._initialized

    def snapshot(self) -> EstimateSnapshot:
        return EstimateSnapshot(
            self._estimate.copy(), self._valid, self._age,
            self._initialized, self._residual.copy(), self._gaps,
        )

    def update(
        self,
        displacement: Sequence[float] | np.ndarray | None,
        command_integral: Sequence[float] | np.ndarray | None,
        elapsed: float,
        valid: bool = True,
    ) -> EstimateSnapshot:
        if not math.isfinite(elapsed) or elapsed <= 0:
            raise ValueError("elapsed must be finite and positive")
        if not valid:
            # A missing or navigation-reset increment is not a flow sample.
            self._valid = False
            self._age += float(elapsed)
            self._gaps += 1
            return self.snapshot()
        measured = _vector(displacement, self.dimensions, "displacement")
        commanded = _vector(command_integral, self.dimensions, "command_integral")
        self._residual = (measured - commanded) / elapsed
        gain = -math.expm1(-elapsed / self.kappa)
        self._estimate += gain * (self._residual - self._estimate)
        self._valid = True
        self._initialized = True
        self._age = 0.0
        self._gaps = 0
        return self.snapshot()


@dataclass(frozen=True)
class _OdomSample:
    time: float
    integral: np.ndarray
    segment_valid: bool


class NavigationState:
    """Local pose with timestamped, delayed absolute-position corrections.

    The history is an independent odometry integral.  Applying an absolute fix
    changes the pose offset, not the motion history or a USDE input.  A fix at
    time tau updates the present pose to fix(tau) + odom(now) - odom(tau).
    Between sample times odometry uses a piecewise-constant average velocity.
    A correction is rejected when its propagation crosses missing odometry.
    """

    def __init__(
        self,
        initial_position: Sequence[float] | np.ndarray,
        timestamp: float = 0.0,
        history_seconds: float = 600.0,
    ) -> None:
        if not math.isfinite(history_seconds) or history_seconds <= 0:
            raise ValueError("history_seconds must be finite and positive")
        self.history_seconds = float(history_seconds)
        self.reset(initial_position, timestamp)

    def reset(
        self, initial_position: Sequence[float] | np.ndarray, timestamp: float = 0.0
    ) -> None:
        self._position = _vector(initial_position, 2, "initial_position")
        if not math.isfinite(timestamp):
            raise ValueError("timestamp must be finite")
        self._time = float(timestamp)
        self._integral = np.zeros(2)
        self._history = [_OdomSample(self._time, self._integral.copy(), True)]
        self._last_correction_time: float | None = None
        self.measurement_valid = True

    @property
    def position(self) -> np.ndarray:
        return self._position.copy()

    @property
    def time(self) -> float:
        return self._time

    @property
    def last_correction_time(self) -> float | None:
        return self._last_correction_time

    def advance(
        self,
        displacement: Sequence[float] | np.ndarray | None,
        elapsed: float,
        valid: bool = True,
    ) -> np.ndarray:
        if not math.isfinite(elapsed) or elapsed <= 0:
            raise ValueError("elapsed must be finite and positive")
        increment = _vector(displacement, 2, "displacement") if valid else np.zeros(2)
        self._position += increment
        self._integral += increment
        self._time += float(elapsed)
        self.measurement_valid = bool(valid)
        self._history.append(_OdomSample(self._time, self._integral.copy(), bool(valid)))
        cutoff = self._time - self.history_seconds
        # Retain one point before the cutoff to interpolate across it.
        while len(self._history) > 2 and self._history[1].time <= cutoff:
            self._history.pop(0)
        return self.position

    def _integral_at(self, source_time: float) -> np.ndarray | None:
        tolerance = 1e-9
        if source_time < self._history[0].time - tolerance or source_time > self._time + tolerance:
            return None
        source_time = min(max(source_time, self._history[0].time), self._time)
        for index, sample in enumerate(self._history):
            if source_time == sample.time:
                if any(not s.segment_valid for s in self._history[index + 1:]):
                    return None
                return sample.integral.copy()
            if sample.time > source_time:
                previous = self._history[index - 1]
                if any(not s.segment_valid for s in self._history[index:]):
                    return None
                fraction = (source_time - previous.time) / (sample.time - previous.time)
                return previous.integral + fraction * (sample.integral - previous.integral)
        return None

    def correct_absolute(
        self, position: Sequence[float] | np.ndarray, source_time: float
    ) -> bool:
        """Apply an arrived fix; return false for stale, future or unpropagatable fixes.

        The caller invokes this only once the message has actually arrived.
        Fixes do not overwrite the present pose with an old source-time pose.
        """
        measurement = _vector(position, 2, "position")
        if not math.isfinite(source_time):
            raise ValueError("source_time must be finite")
        if self._last_correction_time is not None and source_time <= self._last_correction_time:
            return False
        source_integral = self._integral_at(float(source_time))
        if source_integral is None:
            return False
        self._position = measurement + self._integral - source_integral
        self._last_correction_time = float(source_time)
        return True
