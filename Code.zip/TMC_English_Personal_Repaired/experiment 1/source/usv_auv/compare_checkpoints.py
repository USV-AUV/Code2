"""Frozen checkpoint comparison on paired held-out simulation seeds.

No training, scenario override, current removal or fault removal is performed.
Inference is on CUDA by default; the paired-episode bootstrap is CPU NumPy.
Confidence intervals describe test-scenario variation for these checkpoints,
not robustness across independently trained policy seeds.
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import time
from typing import Any, Mapping, Sequence
import uuid

import numpy as np


BOOTSTRAP_SAMPLES = 20_000
BOOTSTRAP_SEED = 20_260_908
PRIMARY_RELATIVE_THRESHOLD_PERCENT = 5.0
EXPECTED_STEPS = (450_000, 1_000_000)

METRICS = {
    "collected_bits": ("successful collection / bit", "higher"),
    "ack_released_bits": ("ACK acknowledged / bit", "higher"),
    "overflow_bits": ("  / bit", "lower"),
    "total_energy_j": ("energy / J", "conditional"),
    "time_mean_aoi_s": ("time mean AoI / s", "conditional"),
    "final_mean_aoi_s": ("mean AoI / s", "conditional"),
    "return": (" ", "higher"),
    "config_successes": ("topology successful", "descriptive"),
    "bits_per_joule": ("collection / J", "conditional"),
    "steps": ("episode", "descriptive"),
    "duration_s": ("episode / s", "descriptive"),
    "terminated": ("safety failure", "lower"),
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return [_json_safe(item) for item in value.tolist()]
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_safe(item) for item in value]
    return value


def _atomic_json(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(_json_safe(value), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _code_hashes() -> dict[str, str]:
    return {path.name: _sha256(path) for path in sorted(Path(__file__).parent.glob("*.py"))}


def _fingerprint(config: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(dict(config), sort_keys=True).encode()).hexdigest()[:16]


def load_milestone_metadata(path: Path, checkpoint: Mapping[str, Any], digest: str) -> dict[str, Any] | None:
    """Authenticate the sibling metadata for an inference-only milestone file."""
    metadata_path = path.parent / "metadata.json"
    if not metadata_path.exists():
        return None
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata["files"][path.name] != {"bytes": path.stat().st_size, "sha256": digest}:
            raise ValueError("Checkpoint size/SHA256 differs from milestone metadata")
        for key in ("global_step", "config_fingerprint", "observation_schema"):
            if metadata[key] != checkpoint[key]:
                raise ValueError(f"Milestone metadata disagrees on {key}")
        for key in ("seed", "run_id"):
            if key not in metadata or (key in checkpoint and checkpoint[key] != metadata[key]):
                raise ValueError(f"Milestone metadata is missing or disagrees on {key}")
        return metadata
    except (KeyError, TypeError, OSError, json.JSONDecodeError) as error:
        raise ValueError(f"Invalid milestone metadata: {metadata_path}") from error


def _validate_expected_steps(expected_steps: Sequence[int]) -> tuple[int, int]:
    if (len(expected_steps) != 2
            or any(isinstance(step, bool) or not isinstance(step, (int, np.integer)) or step < 0
                   for step in expected_steps)
            or expected_steps[0] >= expected_steps[1]):
        raise ValueError("expected_steps must contain two increasing nonnegative integer milestones")
    return int(expected_steps[0]), int(expected_steps[1])


def validate_checkpoint_pair(
    early: Mapping[str, Any], late: Mapping[str, Any],
    expected_steps: Sequence[int] = EXPECTED_STEPS,
) -> dict[str, Any]:
    """Validate comparison metadata before any environment evaluation begins."""
    expected_steps = _validate_expected_steps(expected_steps)
    for label, checkpoint in (("early", early), ("late", late)):
        for key in ("environment_config", "config_fingerprint", "observation_schema", "global_step"):
            if key not in checkpoint:
                raise ValueError(f"{label} checkpoint missing {key}")
        if _fingerprint(checkpoint["environment_config"]) != checkpoint["config_fingerprint"]:
            raise ValueError(f"{label} checkpoint has an inconsistent configuration fingerprint")
        step = checkpoint["global_step"]
        if isinstance(step, bool) or not isinstance(step, (int, np.integer)) or step < 0:
            raise ValueError("Checkpoint global_step must be a nonnegative integer")
    if early["config_fingerprint"] != late["config_fingerprint"] or early["environment_config"] != late["environment_config"]:
        raise ValueError("Both checkpoints must have identical full environment configurations")
    if early["observation_schema"] != late["observation_schema"]:
        raise ValueError("Checkpoint observation/action schemas must be identical")
    if early["global_step"] > late["global_step"]:
        raise ValueError("Early checkpoint has more training steps than late checkpoint")
    early_seed = early.get("seed", early.get("manifest", {}).get("seed"))
    late_seed = late.get("seed", late.get("manifest", {}).get("seed"))
    if early_seed is not None and late_seed is not None and early_seed != late_seed:
        raise ValueError("Milestone comparison requires the same training seed")
    early_run, late_run = early.get("run_id"), late.get("run_id")
    if early_run is not None and late_run is not None and early_run != late_run:
        raise ValueError("Milestone checkpoints belong to different training runs")
    return {
        "config_fingerprint": early["config_fingerprint"],
        "observation_schema": early["observation_schema"],
        "early_training_steps": int(early["global_step"]),
        "late_training_steps": int(late["global_step"]),
        "expected_training_steps": list(expected_steps),
        "requested_milestones_match": (early["global_step"], late["global_step"]) == expected_steps,
        "training_seed": early_seed if early_seed is not None else late_seed,
        "training_seed_provenance_available": early_seed is not None and late_seed is not None,
        "training_run_id": early_run if early_run is not None else late_run,
        "same_training_run_verified": early_run is not None and early_run == late_run,
    }


def paired_metric_statistics(
    early: Sequence[float], late: Sequence[float], *,
    bootstrap_samples: int = BOOTSTRAP_SAMPLES, seed: int = BOOTSTRAP_SEED,
) -> dict[str, Any]:
    """Percentile CI for mean(late-early), resampling complete episode pairs."""
    left, right = np.asarray(early, dtype=float), np.asarray(late, dtype=float)
    if left.ndim != 1 or right.shape != left.shape or left.size == 0:
        raise ValueError("Metrics must be nonempty, equal-length one-dimensional arrays")
    if not np.isfinite(left).all() or not np.isfinite(right).all():
        raise ValueError("Metrics must be finite")
    if isinstance(bootstrap_samples, bool) or not isinstance(bootstrap_samples, int) or bootstrap_samples < 1:
        raise ValueError("bootstrap_samples must be a positive integer")
    difference = right - left
    rng = np.random.default_rng(seed)
    samples = np.empty(bootstrap_samples)
    for start in range(0, bootstrap_samples, 500):
        stop = min(start + 500, bootstrap_samples)
        indices = rng.integers(0, left.size, size=(stop - start, left.size))
        samples[start:stop] = difference[indices].mean(axis=1)
    lower, upper = np.quantile(samples, [0.025, 0.975])
    early_mean, late_mean = float(left.mean()), float(right.mean())
    return {
        "n_pairs": int(left.size), "early_mean": early_mean, "late_mean": late_mean,
        "absolute_difference": float(difference.mean()),
        "ci95": [float(lower), float(upper)],
        "relative_percent": 100.0 * (late_mean - early_mean) / early_mean if early_mean > 0 else None,
        "relative_defined": early_mean > 0,
        "single_pair_no_population_inference": left.size < 2,
    }


def _validate_record(record: Mapping[str, Any]) -> dict[str, Any]:
    result = dict(record)
    if isinstance(result.get("seed"), bool) or not isinstance(result.get("seed"), (int, np.integer)):
        raise ValueError("Each episode needs an integer seed")
    if isinstance(result.get("steps"), bool) or not isinstance(result.get("steps"), (int, np.integer)) or result["steps"] < 1:
        raise ValueError("Each episode needs positive actual steps")
    for key in (
        "collected_bits", "ack_released_bits", "overflow_bits", "total_energy_j",
        "time_mean_aoi_s", "final_mean_aoi_s", "config_successes", "duration_s", "return",
    ):
        if key not in result or isinstance(result[key], bool):
            raise ValueError(f"Missing or invalid episode metric: {key}")
        value = float(result[key])
        if not math.isfinite(value) or (key != "return" and value < 0):
            raise ValueError(f"Invalid episode metric: {key}")
        result[key] = value
    if result["duration_s"] <= 0:
        raise ValueError("Episode duration must be positive")
    if result["ack_released_bits"] > result["collected_bits"]:
        raise ValueError("ACK-released bits cannot exceed unique collected bits")
    for key in ("terminated", "truncated", "survived_full_horizon"):
        if not isinstance(result.get(key), (bool, np.bool_)):
            raise ValueError(f"Episode needs a Boolean {key}")
        result[key] = bool(result[key])
    if result["terminated"] and result["truncated"]:
        raise ValueError("Physical termination and time truncation cannot both be true")
    if result["terminated"] and result["survived_full_horizon"]:
        raise ValueError("A physically failed episode is not a full-horizon survivor")
    result["bits_per_joule"] = (
        result["collected_bits"] / result["total_energy_j"] if result["total_energy_j"] > 0 else None
    )
    return result


def summarize_paired_episodes(
    early_records: Sequence[Mapping[str, Any]], late_records: Sequence[Mapping[str, Any]], *,
    bootstrap_samples: int = BOOTSTRAP_SAMPLES, bootstrap_seed: int = BOOTSTRAP_SEED,
) -> dict[str, Any]:
    early = [_validate_record(row) for row in early_records]
    late = [_validate_record(row) for row in late_records]
    if not early or not late:
        raise ValueError("At least one paired test episode is required")
    left = {row["seed"]: row for row in early}
    right = {row["seed"]: row for row in late}
    if len(left) != len(early) or len(right) != len(late) or set(left) != set(right):
        raise ValueError("Episode seeds must be unique and identical across policies")
    seeds = sorted(left)
    statistics = {}
    for index, (metric, (label, direction)) in enumerate(METRICS.items()):
        valid_seeds = [s for s in seeds if left[s].get(metric) is not None and right[s].get(metric) is not None]
        result = None if not valid_seeds else paired_metric_statistics(
            [left[s][metric] for s in valid_seeds], [right[s][metric] for s in valid_seeds],
            bootstrap_samples=bootstrap_samples, seed=bootstrap_seed + index,
        )
        statistics[metric] = {"label": label, "direction": direction, "statistics": result,
                              "excluded_undefined_pairs": len(seeds) - len(valid_seeds)}
    primary = statistics["collected_bits"]["statistics"]
    meets_primary = bool(
        len(seeds) >= 2 and primary["relative_percent"] is not None
        and primary["relative_percent"] >= PRIMARY_RELATIVE_THRESHOLD_PERCENT
        and primary["ci95"][0] > 0
    )
    failure_early = sum(left[s]["terminated"] for s in seeds)
    failure_late = sum(right[s]["terminated"] for s in seeds)
    safety_tradeoff = failure_late > failure_early
    survivors = [s for s in seeds if left[s]["survived_full_horizon"] and right[s]["survived_full_horizon"]
                 and math.isclose(left[s]["duration_s"], right[s]["duration_s"], rel_tol=0, abs_tol=1e-8)]
    survivor_statistics = {}
    for index, key in enumerate(("total_energy_j", "time_mean_aoi_s", "bits_per_joule")):
        selected = [s for s in survivors if left[s].get(key) is not None and right[s].get(key) is not None]
        survivor_statistics[key] = None if not selected else paired_metric_statistics(
            [left[s][key] for s in selected], [right[s][key] for s in selected],
            bootstrap_samples=bootstrap_samples, seed=bootstrap_seed + 100 + index,
        )
    overflow_uninformative = all(left[s]["overflow_bits"] == 0 and right[s]["overflow_bits"] == 0 for s in seeds)
    warnings = [
        "Intervals describe paired evaluation-scenario variability between frozen checkpoints; they do not establish training-seed robustness.",
        "Shared scenario seeds do not imply identical per-packet random draws once paths and transmission counts diverge.",
        "Energy, AoI and bits-per-joule depend on executed episode durations and cannot be interpreted without termination counts.",
        "The subset of runs where both policies survive is descriptive and cannot replace the all-episode primary comparison.",
        "Primary criteria were prespecified; secondary metric intervals are unadjusted and descriptive.",
    ]
    if safety_tradeoff:
        warnings.append("The later checkpoint has more safety failures; any payload gain must be reported alongside that tradeoff.")
    if overflow_uninformative:
        warnings.append("No overflow was observed in either group; this comparison cannot establish overflow reductions.")
    if primary["relative_percent"] is None:
        warnings.append("The earlier payload mean is zero, so relative improvement is undefined; use the absolute difference.")
    if len(seeds) < 2:
        warnings.append("Only one paired evaluation scenario is available; a degenerate bootstrap interval cannot support population inference.")
    return {
        "n_pairs": len(seeds), "paired_seeds": seeds,
        "bootstrap": {"unit": "paired_test_episode_seed", "samples": bootstrap_samples,
                      "seed": bootstrap_seed, "interval": "95% paired percentile CI for mean(late-early)"},
        "primary_endpoint": {"metric": "collected_bits", "minimum_relative_percent": PRIMARY_RELATIVE_THRESHOLD_PERCENT,
                             "requires_absolute_ci_lower_above_zero": True, "criterion_met": meets_primary,
                             "statistics": primary},
        "safety": {"early_failure_count": failure_early, "late_failure_count": failure_late,
                   "late_has_more_failures": safety_tradeoff},
        "overflow_zero_in_both_uninformative": overflow_uninformative,
        "metrics": statistics,
        "matched_full_horizon": {"n_pairs": len(survivors), "seeds": survivors, "metrics": survivor_statistics},
        "warnings": warnings,
        "interpretation": (
            "Payload criterion passed, but safety failures increased; interpret the result as a tradeoff." if meets_primary and safety_tradeoff else
            "The payload criterion passed on these fixed checkpoints and evaluated scenarios." if meets_primary else
            "The prespecified payload criterion was not met in these evaluation scenarios."
        ),
    }


def _number(value: Any) -> str:
    return "N/A" if value is None else f"{float(value):.6g}"


def render_comparison_markdown(report: Mapping[str, Any]) -> str:
    """Report a paired earlier-versus-later checkpoint test in English."""
    summary, protocol, metadata = report["comparison"], report["protocol"], report["checkpoints"]
    expected = metadata.get("expected_training_steps", EXPECTED_STEPS)

    def milestone_label(step: int) -> str:
        if step > 0 and step % 1_000_000 == 0: return f"{step // 1_000_000}m"
        if step > 0 and step % 1_000 == 0: return f"{step // 1_000}k"
        return str(step)

    lines = [
        f"# Paired Checkpoint Comparison: {milestone_label(expected[0])} vs. {milestone_label(expected[1])}",
        "", summary["interpretation"], "",
        f"Training steps: {metadata['early_training_steps']} to {metadata['late_training_steps']}. "
        f"Evaluation: {summary['n_pairs']} paired scenario seeds, up to {protocol['steps']} steps each; "
        f"checkpoint physical conditions retained; device: {protocol['device']}.", "",
        "Primary criterion: at least 5% greater mean accepted unique payload and a strictly positive lower bound "
        "of the paired bootstrap interval. Differences are later minus earlier; preferred signs depend on the metric.", "",
        "| Metric | Earlier mean | Later mean | Difference and 95% interval | Relative change |",
        "|---|---:|---:|---|---:|",
    ]
    for key in METRICS:
        item = summary["metrics"][key]
        stats = item["statistics"]
        if stats is None:
            lines.append(f"| {item['label']} | N/A | N/A | No valid pairs | N/A |")
            continue
        low, high = stats["ci95"]
        relative = "N/A" if stats["relative_percent"] is None else f"{stats['relative_percent']:+.3f}%"
        lines.append(f"| {item['label']} | {_number(stats['early_mean'])} | {_number(stats['late_mean'])} | "
                     f"{_number(stats['absolute_difference'])} [{_number(low)}, {_number(high)}] | {relative} |")
    lines.extend(["", f"Paired scenarios surviving the complete horizon under both policies: {summary['matched_full_horizon']['n_pairs']}.",
                  "Conditional energy, time-mean AoI and bits-per-joule comparisons appear in comparison.json and cannot replace the all-episode primary comparison.", "",
                  "Time-mean AoI is weighted over actually executed fast steps; instantaneous terminal AoI is separately recorded. "
                  "Early failures are not imputed as surviving episodes or removed from primary outcomes.", ""])
    lines.extend(f"- {warning}" for warning in summary["warnings"])
    lines.extend(["", "The early/ and late/ directories contain episode-level records and trajectories. "
                  "paired_episodes.csv retains duration, termination causes and raw metrics; provenance.json and milestones.jsonl record model and code identities.", ""])
    return "\n".join(lines)

def _metric(info: Mapping[str, Any], name: str, default: float | None = None) -> float:
    metrics = info.get("metrics", {})
    if name not in metrics and default is None:
        raise ValueError(f"Environment omitted required evaluation metric {name}")
    value = float(metrics.get(name, default))
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"Environment produced invalid metric {name}")
    return value


def _evaluate_policy(
    checkpoint: Mapping[str, Any], label: str, output: Path, protocol: Mapping[str, Any],
    progress_path: Path, milestone,
) -> list[dict[str, Any]]:
    from .config import Config
    from .deploy import DeploymentPolicy
    from .environment import CooperativeEnv
    from .learning import seed_all

    policy = DeploymentPolicy(dict(checkpoint), protocol["device"])
    cfg = Config.from_dict(checkpoint["environment_config"])
    seed_all(protocol["seed"])
    env = CooperativeEnv(cfg)
    policy.validate_environment(env, check_config=True)
    output.mkdir(parents=True, exist_ok=True)
    records = []
    offset = 0 if label == "early" else protocol["episodes"]

    def progress(done: int, episode_step: int = 0) -> None:
        _atomic_json(progress_path, {
            "status": "evaluating", "policy": label, "model_step": int(checkpoint["global_step"]),
            "episode_done": done, "episodes_total": protocol["episodes"], "step_in_episode": episode_step,
            "overall_episode_done": offset + done, "overall_episodes_total": 2 * protocol["episodes"],
            "updated_at": _utc_now(),
        })

    progress(0)
    print(json.dumps({"status": "evaluation_started", "policy": label, "model_step": checkpoint["global_step"]}), flush=True)
    try:
        with (output / "evaluation.jsonl").open("w", encoding="utf-8") as trace, (output / "episodes.jsonl").open("w", encoding="utf-8") as episodes_log:
            for episode in range(protocol["episodes"]):
                test_seed = protocol["seed"] + episode
                observations, info = env.reset(seed=test_seed)
                initial_time = previous_time = float(info["time"])
                accumulated_aoi = 0.0
                total_reward = 0.0
                terminated = truncated = False
                for index in range(protocol["steps"]):
                    topology_action = None
                    if env.step_count % cfg.slow_period == 0:
                        slow_state, mask = env.slow_state()
                        topology_action = policy.topology_action(slow_state, mask)
                    actions = policy.act(observations)
                    observations, reward, terminated, truncated, info = env.step(actions, topology_action=topology_action)
                    now = float(info["time"])
                    interval = now - previous_time
                    if not math.isfinite(interval) or interval <= 0 or not math.isfinite(float(reward)):
                        raise ValueError("Invalid episode time advance or reward")
                    total_reward += float(reward)
                    accumulated_aoi += interval * _metric(info, "mean_aoi_s")
                    previous_time = now
                    trace.write(json.dumps(_json_safe({
                        "episode": episode, "seed": test_seed, "step": index + 1, "time": now,
                        "reward": float(reward), "topology_request": topology_action, "actions": actions,
                        "terminated": bool(terminated), "truncated": bool(truncated), "info": info,
                    }), ensure_ascii=False, allow_nan=False) + "\n")
                    if (index + 1) % 100 == 0:
                        trace.flush()
                        progress(episode, index + 1)
                    if terminated or truncated:
                        break
                actual_steps = index + 1
                duration = previous_time - initial_time
                nominal_horizon = min(protocol["steps"], cfg.episode_steps)
                record = _validate_record({
                    "episode": episode, "seed": test_seed, "steps": actual_steps,
                    "duration_s": duration, "terminated": bool(terminated), "truncated": bool(truncated),
                    "termination_reason": str(info.get("termination_reason", "")),
                    "evaluation_limit_reached": not (terminated or truncated) and actual_steps == protocol["steps"],
                    "survived_full_horizon": not terminated and actual_steps >= nominal_horizon,
                    "collected_bits": _metric(info, "collected_bits"),
                    "ack_released_bits": _metric(info, "ack_released_bits"),
                    "overflow_bits": _metric(info, "overflow_bits"),
                    "total_energy_j": _metric(info, "total_energy_j"),
                    "time_mean_aoi_s": accumulated_aoi / duration,
                    "final_mean_aoi_s": _metric(info, "mean_aoi_s"),
                    "return": total_reward,
                    "config_successes": _metric(info, "network_config_successes", 0.0),
                })
                records.append(record)
                episodes_log.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
                episodes_log.flush()
                trace.flush()
                progress(episode + 1)
                print(json.dumps({"status": "episode_complete", "policy": label,
                                  "episode_done": episode + 1, "episodes_total": protocol["episodes"],
                                  "seed": test_seed, "steps": actual_steps, "collected_bits": record["collected_bits"],
                                  "terminated": bool(terminated)}, ensure_ascii=False), flush=True)
        _atomic_json(output / "evaluation_summary.json", {
            "policy": label, "training_steps": checkpoint["global_step"],
            "configuration_fingerprint": cfg.fingerprint, "protocol": protocol,
            "aoi_time_average_method": "right-endpoint fast-step samples weighted by actual elapsed seconds",
            "episodes": records,
        })
        milestone("policy_evaluation_complete", policy=label, model_step=checkpoint["global_step"], episodes=len(records))
        return records
    finally:
        env.close()
        del env, policy
        gc.collect()


def compare_checkpoints(
    early_path: Path, late_path: Path, output: Path, *, episodes: int = 30,
    steps: int = 1200, seed: int = 9_000_000, device: str = "cuda",
    expected_steps: Sequence[int] = EXPECTED_STEPS,
) -> dict[str, Any]:
    """Run only after training has produced both immutable milestone files."""
    from .deploy import load_checkpoint

    if episodes < 1 or steps < 1:
        raise ValueError("episodes and steps must be positive")
    expected_steps = _validate_expected_steps(expected_steps)
    if isinstance(seed, bool) or not isinstance(seed, (int, np.integer)) or seed < 0 or seed + episodes - 1 >= 2 ** 32:
        raise ValueError("Test seeds must be nonnegative integers and fit uint32")
    early_path, late_path, output = Path(early_path).resolve(), Path(late_path).resolve(), Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError("Use a fresh comparison output directory to preserve previous evidence")
    early, late = load_checkpoint(early_path), load_checkpoint(late_path)
    early_digest, late_digest = _sha256(early_path), _sha256(late_path)
    early_metadata = load_milestone_metadata(early_path, early, early_digest)
    late_metadata = load_milestone_metadata(late_path, late, late_digest)
    if early_metadata is not None:
        early = {**early, "seed": early_metadata["seed"], "run_id": early_metadata["run_id"]}
    if late_metadata is not None:
        late = {**late, "seed": late_metadata["seed"], "run_id": late_metadata["run_id"]}
    metadata = validate_checkpoint_pair(early, late, expected_steps=expected_steps)
    training_seed = metadata["training_seed"]
    seed_source = "checkpoint_or_verified_milestone"
    if training_seed is None:
        training_seed = late["environment_config"].get("seed")
        seed_source = "environment_config_fallback_unverified"
    if isinstance(training_seed, bool) or not isinstance(training_seed, (int, np.integer)) or training_seed < 0:
        raise ValueError("A nonnegative training seed is required to exclude training reset seeds")
    # train.py resets with training_seed + episode. At most one new episode
    # follows each training step; use actual progress, not requested milestones.
    training_reset_seed_upper_bound = int(training_seed) + metadata["late_training_steps"]
    if seed <= training_reset_seed_upper_bound:
        raise ValueError(f"Test seeds must be above the conservative training reset range "
                         f"<= {training_reset_seed_upper_bound} (training seed + actual late global_step)")
    output.mkdir(parents=True, exist_ok=True)
    protocol = {"episodes": episodes, "steps": steps, "seed": seed, "device": device,
                "expected_training_steps": list(expected_steps),
                "training_reset_seed_upper_bound": training_reset_seed_upper_bound,
                "training_reset_seed_bound_source": seed_source,
                "test_seeds": list(range(seed, seed + episodes)), "configuration_override": False,
                "bootstrap_samples": BOOTSTRAP_SAMPLES, "bootstrap_seed": BOOTSTRAP_SEED,
                "primary_relative_threshold_percent": PRIMARY_RELATIVE_THRESHOLD_PERCENT}
    provenance = {
        "run_id": str(uuid.uuid4()), "started_at": _utc_now(), "protocol": protocol,
        "checkpoints": metadata, "environment_config": early["environment_config"],
        "early": {"path": str(early_path), "sha256": early_digest, "training_stage": early.get("training_stage"),
                  "manifest": early.get("manifest"), "resume_semantics": early.get("resume_semantics"),
                  "verified_milestone_metadata": early_metadata},
        "late": {"path": str(late_path), "sha256": late_digest, "training_stage": late.get("training_stage"),
                 "manifest": late.get("manifest"), "resume_semantics": late.get("resume_semantics"),
                 "verified_milestone_metadata": late_metadata},
        "code_sha256": _code_hashes(),
        "scope": "Two frozen checkpoints; paired held-out simulation scenarios; no independent-training-seed inference.",
    }
    _atomic_json(output / "provenance.json", provenance)
    progress_path = output / "comparison_progress.json"

    def milestone(event: str, **fields: Any) -> None:
        item = {"time": _utc_now(), "run_id": provenance["run_id"], "event": event, **fields}
        with (output / "milestones.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(_json_safe(item), ensure_ascii=False, allow_nan=False) + "\n")

    started = time.monotonic()
    milestone("comparison_started", early_step=metadata["early_training_steps"], late_step=metadata["late_training_steps"])
    try:
        left = _evaluate_policy(early, "early", output / "early", protocol, progress_path, milestone)
        right = _evaluate_policy(late, "late", output / "late", protocol, progress_path, milestone)
        summary = summarize_paired_episodes(left, right)
        if not metadata["requested_milestones_match"]:
            summary["warnings"].append(f"  {expected_steps[0]}   {expected_steps[1]} training; "
                                       " . ")
        if seed_source == "environment_config_fallback_unverified":
            summary["warnings"].append("training seed data, environment seed  ; "
                                       "training coverage seed, scenario training reset  . ")
        if not metadata["same_training_run_verified"]:
            summary["warnings"].append("training run_id  ;   checkpoint  ,  . ")
        code_unchanged = _code_hashes() == provenance["code_sha256"]
        if not code_unchanged:
            summary["warnings"].append(" ,  . ")
        report = {
            "format": "usv-auv-paired-checkpoint-comparison-v1", "completed_at": _utc_now(),
            "elapsed_seconds": time.monotonic() - started, "protocol": protocol, "checkpoints": metadata,
            "source_files_unchanged": code_unchanged, "comparison": summary,
            "early_episodes": left, "late_episodes": right,
            "workflow_milestone_evidence_valid": metadata["requested_milestones_match"] and code_unchanged and metadata["same_training_run_verified"],
        }
        _atomic_json(output / "comparison.json", report)
        (output / "comparison.md").write_text(render_comparison_markdown(report), encoding="utf-8")
        paired_rows = []
        right_by_seed = {row["seed"]: row for row in right}
        for row in left:
            other = right_by_seed[row["seed"]]
            joined = {"seed": row["seed"]}
            for prefix, source in (("early", row), ("late", other)):
                joined.update({f"{prefix}_{key}": value for key, value in source.items() if key != "seed"})
            for metric in METRICS:
                joined[f"difference_{metric}"] = None if row.get(metric) is None or other.get(metric) is None else float(other[metric]) - float(row[metric])
            paired_rows.append(joined)
        with (output / "paired_episodes.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(paired_rows[0]))
            writer.writeheader()
            writer.writerows(paired_rows)
        milestone("comparison_complete", primary_criterion_met=summary["primary_endpoint"]["criterion_met"],
                  safety_tradeoff=summary["safety"]["late_has_more_failures"], source_files_unchanged=code_unchanged)
        _atomic_json(progress_path, {"status": "completed", "model_step": metadata["late_training_steps"],
                                    "episode_done": episodes, "episodes_total": episodes,
                                    "overall_episode_done": 2 * episodes, "overall_episodes_total": 2 * episodes,
                                    "updated_at": _utc_now(), "comparison_json": str(output / "comparison.json")})
        return report
    except Exception as error:
        milestone("comparison_failed", error=repr(error))
        _atomic_json(progress_path, {"status": "failed", "updated_at": _utc_now(), "error": repr(error)})
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--early", type=Path, required=True)
    parser.add_argument("--late", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--episodes", type=int, default=30)
    parser.add_argument("--steps", type=int, default=1200)
    parser.add_argument("--seed", type=int, default=9_000_000)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--expected-steps", type=int, nargs=2, metavar=("EARLY", "LATE"),
                        default=EXPECTED_STEPS, help="Expected training milestones (default: 450000 1000000)")
    args = parser.parse_args()
    report = compare_checkpoints(args.early, args.late, args.output, episodes=args.episodes,
                                 steps=args.steps, seed=args.seed, device=args.device,
                                 expected_steps=args.expected_steps)
    print(json.dumps({"status": "completed", "output": str(args.output.resolve()),
                      "interpretation": report["comparison"]["interpretation"],
                      "primary_criterion_met": report["comparison"]["primary_endpoint"]["criterion_met"]},
                     ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
