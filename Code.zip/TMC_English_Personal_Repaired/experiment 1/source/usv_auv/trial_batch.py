"""Sequential fresh trials: never place two training workers on the GPU."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--status', type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text(encoding='utf-8'))
    if args.status.exists():
        raise FileExistsError('Batch status already exists; preserve prior run')
    state = {'batch_pid': os.getpid(), 'plan': str(args.plan.resolve()), 'stage': 'starting', 'trials': []}

    def publish():
        state['updated_at'] = datetime.now(timezone.utc).isoformat()
        temporary = args.status.with_suffix('.tmp')
        temporary.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding='utf-8')
        os.replace(temporary, args.status)

    for trial in plan['trials']:
        output = Path(trial['output'])
        if output.exists():
            raise FileExistsError(f'Trial directory already exists: {output}')
    for trial in plan['trials']:
        command = [sys.executable, '-u', '-m', 'usv_auv.trial_workflow', '--config', trial['config'],
                   '--output', trial['output'], '--steps', str(trial['steps']), '--label', trial['label']]
        state.update(stage='training', current=trial['output'])
        child = subprocess.Popen(command)
        state['child_pid'] = child.pid
        publish()
        code = child.wait()
        state['trials'].append({'output': trial['output'], 'exit_code': code})
        if code:
            state.update(stage='failed', child_pid=None)
            publish()
            raise RuntimeError(f'Trial failed with code {code}; no automatic retry')
    state.update(stage='complete', child_pid=None)
    publish()


if __name__ == '__main__':
    main()
