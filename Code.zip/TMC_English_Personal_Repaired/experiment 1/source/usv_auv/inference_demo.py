"""Exercise exported policies and the JSONL deployment interface, with no updates."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import numpy as np
from .config import Config
from .deploy import DeploymentPolicy
from .environment import CooperativeEnv


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('runs/deployment_demo'))
    args=p.parse_args()
    policy=DeploymentPolicy.from_checkpoint(args.checkpoint)
    env=CooperativeEnv(Config.from_dict(policy.environment_config))
    policy.validate_environment(env)
    obs,_=env.reset();slow,mask=env.slow_state()
    payload={'observations':obs.tolist(),'slow_state':slow.tolist(),'mask':mask.tolist(),
             'config_fingerprint':policy.config_fingerprint,'observation_schema':policy.schema}
    args.output.mkdir(parents=True,exist_ok=True)
    input_path=args.output/'observations.jsonl';output_path=args.output/'commands.jsonl'
    input_path.write_text(json.dumps(payload)+'\n',encoding='utf-8')
    subprocess.run([sys.executable,'-m','usv_auv.deploy',str(args.checkpoint),'--input',str(input_path),
                    '--output',str(output_path)],check=True)
    command=json.loads(output_path.read_text(encoding='utf-8'))
    np.testing.assert_allclose(command['actions'],policy.act(obs))
    physical=policy.physical_commands(command['actions'],obs)
    for name,value in physical.items():np.testing.assert_allclose(command[name],value)
    assert command['action_encoding']==policy.schema['action_encoding']
    assert mask[command['topology_action']]
    env.step(command['actions'],command['topology_action'])
    np.testing.assert_allclose(env.executed_velocities,physical['relative_water_velocity_mps'])
    print(json.dumps({'export_roundtrip':'passed','one_inference_step':'passed','output':str(output_path),
                      'training_updates':0},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
