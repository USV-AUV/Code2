"""Extend a completed experiment to an explicit TOTAL budget in a new directory.

All old run files stay read-only. Learning state is resumed, not reinitialized;
physical simulation starts a new episode under the unchanged configuration.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import sys
import traceback

from .run_experiment import atomic_json, keep_system_awake, launch_child, utc_now


def extension_plan(checkpoint, previous, cfg, total_steps):
    if previous.get('stage') != 'complete':
        raise ValueError('Extension requires a completed source workflow')
    if checkpoint.get('format') != 'usv-auv-topology-usde-training-v1':
        raise ValueError('Use a full training checkpoint, not an inference model')
    start = checkpoint['global_step']
    if type(total_steps) is not int or type(start) is not int or not 0 < start < total_steps:
        raise ValueError('The new TOTAL budget must exceed the completed global step')
    if start != previous['total_steps'] or start != previous['training_summary']['global_step']:
        raise ValueError('The source milestone is not the completed final checkpoint')
    if checkpoint['environment_config'] != cfg.to_dict():
        raise ValueError('Frozen environment differs from the checkpoint')
    if any(item.get('config_fingerprint') != cfg.fingerprint for item in (checkpoint,previous)):
        raise ValueError('Configuration fingerprint mismatch')
    if checkpoint['seed'] != cfg.seed or previous['seed'] != cfg.seed or not checkpoint.get('run_id'):
        raise ValueError('Missing or inconsistent training identity')
    if previous.get('run_id',checkpoint['run_id']) != checkpoint['run_id']:
        raise ValueError('Source workflow belongs to another training run')
    if start not in checkpoint['milestones']:
        raise ValueError('Completed source step must be an immutable milestone')
    evaluation = previous['evaluation']
    if evaluation['seed_start'] <= total_steps + cfg.seed + 1:
        raise ValueError('Test seeds overlap the conservative training reset range')
    if evaluation['episodes'] < 2 or evaluation['steps'] < 1:
        raise ValueError('Invalid paired evaluation protocol')
    return dict(start_step=start,target_step=total_steps,additional_steps=total_steps-start,
                early_step=start,run_id=checkpoint['run_id'])


def extend(source: Path, output: Path, total_steps: int):
    import torch
    from .config import Config
    from .deploy import load_checkpoint
    from .train import file_digest, milestone_identity, milestone_path, validate_milestone

    source, output = Path(source).resolve(), Path(output).resolve()
    if source == output or source in output.parents or output.exists():
        raise ValueError('Use a new output directory outside the completed source run')
    previous = json.loads((source/'workflow_status.json').read_text(encoding='utf-8'))
    cfg = Config.load(source/'frozen_config.json')
    source_checkpoint = milestone_path(source,previous['total_steps'])/'checkpoint.pt'
    checkpoint = load_checkpoint(source_checkpoint)
    plan = extension_plan(checkpoint,previous,cfg,total_steps)
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; extension may not fall back to CPU')
    history = sorted(step for step in checkpoint['milestones'] if step <= plan['start_step'])
    protected = {}
    for step in history:
        directory = milestone_path(source,step)
        validate_milestone(directory,milestone_identity({**checkpoint,'global_step':step}))
        for name in ('checkpoint.pt','policy.pt','metadata.json'):
            protected[str((directory/name).relative_to(source))] = file_digest(directory/name)
    for name in ('workflow_status.json','summary.json','frozen_config.json','comparison/comparison.json','comparison/comparison.md'):
        protected[name] = file_digest(source/name)
    output.mkdir(parents=True,exist_ok=False)
    cfg.save(output/'frozen_config.json')
    for step in history:
        shutil.copytree(milestone_path(source,step),milestone_path(output,step))
        validate_milestone(milestone_path(output,step),milestone_identity({**checkpoint,'global_step':step}))
    sources = {p.name:file_digest(p)['sha256'] for p in sorted(Path(__file__).resolve().parent.glob('*.py'))}
    atomic_json(output/'source_hashes.json',sources)
    extension = dict(plan,created_at=utc_now(),source_run=str(source),source_checkpoint=str(source_checkpoint),
                     source_checkpoint_digest=file_digest(source_checkpoint),protected_source_files=protected,
                     physical_resume='new episode; learning/optimizer/replay/RNG state restored',
                     source_sha256=sources,evaluation=previous['evaluation'],
                     scope='Only extend the step budget; no algorithm or environment retuning.')
    atomic_json(output/'extension_manifest.json',extension)
    status = dict(format='usv-auv-experiment-v1',workflow_pid=os.getpid(),child_pid=None,
                  stage='starting',started_at=utc_now(),output=str(output),total_steps=total_steps,
                  early_step=plan['early_step'],resume_from_step=plan['start_step'],
                  additional_steps=plan['additional_steps'],run_id=plan['run_id'],source_run=str(source),
                  extension_manifest=str(output/'extension_manifest.json'),
                  config_fingerprint=cfg.fingerprint,seed=cfg.seed,python=sys.executable,
                  torch=torch.__version__,cuda=torch.version.cuda,gpu=torch.cuda.get_device_name(0),
                  evaluation=previous['evaluation'],monitor_interval_seconds=1200,automatic_retry=False)
    atomic_json(output/'workflow_status.json',status)
    try:
        with (output/'training.jsonl').open('a',encoding='utf-8') as log:
            log.write(json.dumps(dict(event='authorized_extension',**extension),ensure_ascii=False)+'\n')
        with keep_system_awake() as awake:
            status['temporary_system_sleep_inhibition'] = awake
            command = [sys.executable,'-u','-m','usv_auv.train','--resume',str(source_checkpoint),
                       '--config',str(output/'frozen_config.json'),'--output',str(output),
                       '--steps',str(plan['additional_steps']),'--device','cuda',
                       '--milestones',str(plan['early_step']),str(total_steps),'--log-every','1000']
            launch_child(command,output,status,'training','train')
            summary = json.loads((output/'summary.json').read_text(encoding='utf-8'))
            if summary['global_step'] != total_steps or not all(n>0 for n in summary['td3_updates']) or summary['ddqn_updates']<=0:
                raise RuntimeError('Wrong final step or an inactive learner')
            for name,digest in protected.items():
                if file_digest(source/name) != digest:
                    raise RuntimeError(f'Completed source artifact changed: {name}')
            for step in history:
                for name in ('checkpoint.pt','policy.pt','metadata.json'):
                    relative=str((milestone_path(source,step)/name).relative_to(source))
                    if file_digest(milestone_path(output,step)/name) != protected[relative]:
                        raise RuntimeError('Historical milestone copy changed during extension')
            final = load_checkpoint(milestone_path(output,total_steps)/'checkpoint.pt')
            if final['global_step'] != total_steps or final['run_id'] != plan['run_id']:
                raise RuntimeError('Final milestone step or run identity mismatch')
            validate_milestone(milestone_path(output,total_steps),milestone_identity(final))
            early = milestone_path(output,plan['early_step'])/'policy.pt'
            late = milestone_path(output,total_steps)/'policy.pt'
            status['training_summary'] = summary
            status['milestone_paths'] = dict(early=str(early),late=str(late))
            evaluation = status['evaluation']
            command = [sys.executable,'-u','-m','usv_auv.compare_checkpoints','--early',str(early),
                       '--late',str(late),'--output',str(output/'comparison'),
                       '--episodes',str(evaluation['episodes']),'--steps',str(evaluation['steps']),
                       '--seed',str(evaluation['seed_start']),'--device','cuda',
                       '--expected-steps',str(plan['early_step']),str(total_steps)]
            launch_child(command,output,status,'comparing','comparison')
        comparison = output/'comparison'/'comparison.json'
        report = json.loads(comparison.read_text(encoding='utf-8'))
        if not report['workflow_milestone_evidence_valid']:
            raise RuntimeError('The comparison failed its requested milestone/provenance checks')
        status.update(stage='complete',completed_at=utc_now(),comparison_json=str(comparison),child_pid=None)
        atomic_json(output/'workflow_status.json',status)
        return status
    except BaseException as error:
        status.update(stage='failed',failed_at=utc_now(),error=f'{type(error).__name__}: {error}')
        atomic_json(output/'workflow_status.json',status)
        (output/'workflow_error.txt').write_text(traceback.format_exc(),encoding='utf-8')
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--total-steps',type=int,required=True)
    args=parser.parse_args()
    print(json.dumps(extend(args.source,args.output,args.total_steps),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
