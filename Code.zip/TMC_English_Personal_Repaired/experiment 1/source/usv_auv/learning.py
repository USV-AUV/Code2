"""Independent TD3 policies and masked Double DQN with resumable state.

Replay uses CPU arrays and copies inputs; only network updates need CUDA.
Checkpoints contain optimizer and NumPy state: load trusted project files only.
"""
from __future__ import annotations

import copy
import random
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


def resolve_device(name: str = "cuda") -> torch.device:
    device = torch.device(name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for default training. Check the CUDA PyTorch environment; use --device cpu only explicitly.")
    if device.type == "cuda":
        torch.empty(1, device=device)  # Validate an explicitly selected GPU index.
    return device


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def rng_state() -> dict[str, Any]:
    return {"python": random.getstate(), "numpy": np.random.get_state(),
            "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}


def restore_rng(state: dict[str, Any]) -> None:
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"].cpu())
    if state.get("cuda") is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all([s.cpu() for s in state["cuda"]])


def _vector(value: Any, dimension: int, name: str) -> np.ndarray:
    result = np.asarray(value, dtype=np.float32)
    if result.shape != (dimension,) or not np.isfinite(result).all():
        raise ValueError(f"{name} must be a finite vector of shape ({dimension},), got {result.shape}")
    return result


def _mask(value: Any, n_actions: int, allow_empty: bool = False) -> np.ndarray:
    result = np.asarray(value, dtype=bool)
    if result.shape != (n_actions,):
        raise ValueError(f"mask must have shape ({n_actions},)")
    if not allow_empty and not result.any():
        raise ValueError("At least KEEP/RECOVER must be valid; refusing an empty argmax")
    return result


class ReplayBuffer:
    """Ring buffer, with bootstrap stopped only by true termination."""

    def __init__(self, capacity: int, observation_dim: int, action_dim: int = 2,
                 seed: int = 0) -> None:
        if capacity < 1:
            raise ValueError("capacity must be positive")
        self.capacity, self.observation_dim, self.action_dim = capacity, observation_dim, action_dim
        self.rng = np.random.default_rng(seed)
        self.position = self.size = 0
        self.arrays = {
            "observations": np.zeros((capacity, observation_dim), np.float32),
            "actions": np.zeros((capacity, action_dim), np.float32),
            "rewards": np.zeros((capacity, 1), np.float32),
            "next_observations": np.zeros((capacity, observation_dim), np.float32),
            "terminated": np.zeros((capacity, 1), np.float32),
            "truncated": np.zeros((capacity, 1), np.float32),
        }

    def __len__(self) -> int:
        return self.size

    def clear(self) -> None:
        self.position = self.size = 0

    def add(self, observation: Any, action: Any, reward: float,
            next_observation: Any, terminated: bool, truncated: bool = False) -> None:
        observation = _vector(observation, self.observation_dim, "observation")
        next_observation = _vector(next_observation, self.observation_dim, "next_observation")
        action = _vector(action, self.action_dim, "action")
        if np.any(np.abs(action) > 1.000001):
            raise ValueError("Replay actions must remain the original normalized actor commands")
        if not np.isfinite(reward):
            raise ValueError("reward must be finite")
        row = {"observations": observation, "actions": action, "rewards": reward,
               "next_observations": next_observation, "terminated": float(terminated),
               "truncated": float(truncated)}
        for name, value in row.items():
            self.arrays[name][self.position] = value
        self.position = (self.position + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int, device: torch.device) -> dict[str, torch.Tensor]:
        if self.size < batch_size:
            raise ValueError("not enough replay samples")
        indices = self.rng.integers(self.size, size=batch_size)
        return {key: torch.as_tensor(array[indices], device=device)
                for key, array in self.arrays.items()}

    def state_dict(self) -> dict[str, Any]:
        return {"capacity": self.capacity, "observation_dim": self.observation_dim,
                "action_dim": self.action_dim, "position": self.position, "size": self.size,
                "rng": copy.deepcopy(self.rng.bit_generator.state),
                "arrays": {key: array[:self.size].copy() for key, array in self.arrays.items()}}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        for key in ("capacity", "observation_dim", "action_dim"):
            if state[key] != getattr(self, key):
                raise ValueError(f"replay {key} mismatch")
        self.size, self.position = state["size"], state["position"]
        if not 0 <= self.size <= self.capacity or not 0 <= self.position < self.capacity:
            raise ValueError("invalid replay bounds")
        for key, values in state["arrays"].items():
            self.arrays[key][:self.size] = values
        self.rng.bit_generator.state = state["rng"]


class TopologyReplay:
    def __init__(self, capacity: int, observation_dim: int, n_actions: int,
                 seed: int = 0) -> None:
        self.capacity, self.observation_dim, self.n_actions = capacity, observation_dim, n_actions
        if capacity < 1:
            raise ValueError("capacity must be positive")
        self.position = self.size = 0
        self.rng = np.random.default_rng(seed)
        self.arrays = {
            "observations": np.zeros((capacity, observation_dim), np.float32),
            "next_observations": np.zeros((capacity, observation_dim), np.float32),
            "masks": np.zeros((capacity, n_actions), bool),
            "next_masks": np.zeros((capacity, n_actions), bool),
            "actions": np.zeros((capacity, 1), np.int64),
            "rewards": np.zeros((capacity, 1), np.float32),
            "discounts": np.zeros((capacity, 1), np.float32),
            "durations": np.zeros((capacity, 1), np.int64),
            "terminated": np.zeros((capacity, 1), np.float32),
            "truncated": np.zeros((capacity, 1), np.float32),
        }

    def __len__(self) -> int:
        return self.size

    def clear(self) -> None:
        self.position = self.size = 0

    def add(self, observation: Any, mask: Any, requested_action: int, discounted_reward: float,
            next_observation: Any, next_mask: Any, duration: int, gamma: float,
            terminated: bool, truncated: bool = False) -> None:
        observation = _vector(observation, self.observation_dim, "slow observation")
        next_observation = _vector(next_observation, self.observation_dim, "next slow observation")
        mask = _mask(mask, self.n_actions)
        next_mask = _mask(next_mask, self.n_actions, allow_empty=terminated)
        if not 0 <= requested_action < self.n_actions or not mask[requested_action]:
            raise ValueError("The requested topology action was masked at decision time")
        if duration < 1 or not 0 <= gamma <= 1 or not np.isfinite(discounted_reward):
            raise ValueError("invalid slow transition duration, gamma, or reward")
        row = {"observations": observation, "masks": mask, "actions": requested_action,
               "rewards": discounted_reward, "next_observations": next_observation,
               "next_masks": next_mask, "discounts": gamma ** duration,
               "durations": duration, "terminated": float(terminated),
               "truncated": float(truncated)}
        for name, value in row.items():
            self.arrays[name][self.position] = value
        self.position = (self.position + 1) % self.capacity
        self.size = min(self.capacity, self.size + 1)

    def sample(self, batch_size: int, device: torch.device) -> dict[str, torch.Tensor]:
        if self.size < batch_size:
            raise ValueError("not enough topology samples")
        indices = self.rng.integers(self.size, size=batch_size)
        return {key: torch.as_tensor(array[indices], device=device)
                for key, array in self.arrays.items()}

    def state_dict(self) -> dict[str, Any]:
        return {"capacity": self.capacity, "observation_dim": self.observation_dim,
                "n_actions": self.n_actions, "size": self.size, "position": self.position,
                "rng": copy.deepcopy(self.rng.bit_generator.state),
                "arrays": {key: values[:self.size].copy() for key, values in self.arrays.items()}}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        for key in ("capacity", "observation_dim", "n_actions"):
            if state[key] != getattr(self, key):
                raise ValueError(f"topology replay {key} mismatch")
        self.size, self.position = state["size"], state["position"]
        if not 0 <= self.size <= self.capacity or not 0 <= self.position < self.capacity:
            raise ValueError("invalid topology replay bounds")
        for key, values in state["arrays"].items():
            self.arrays[key][:self.size] = values
        self.rng.bit_generator.state = state["rng"]


def mlp(input_dim: int, output_dim: int, hidden_dim: int, bounded: bool = False) -> nn.Sequential:
    layers: list[nn.Module] = [nn.Linear(input_dim, hidden_dim), nn.ReLU(),
                              nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
                              nn.Linear(hidden_dim, output_dim)]
    if bounded:
        layers.append(nn.Tanh())
    return nn.Sequential(*layers)


class TwinCritic(nn.Module):
    def __init__(self, observation_dim: int, action_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.q1 = mlp(observation_dim + action_dim, 1, hidden_dim)
        self.q2 = mlp(observation_dim + action_dim, 1, hidden_dim)

    def forward(self, observations: torch.Tensor, actions: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        joined = torch.cat((observations, actions), dim=-1)
        return self.q1(joined), self.q2(joined)


@dataclass
class LearningConfig:
    hidden_dim: int = 128
    gamma: float = 0.99
    tau: float = 0.005
    actor_lr: float = 3e-4
    critic_lr: float = 3e-4
    topology_lr: float = 3e-4
    policy_noise: float = 0.2
    noise_clip: float = 0.5
    policy_delay: int = 2
    replay_capacity: int = 20_000
    topology_capacity: int = 5_000
    batch_size: int = 32
    topology_batch_size: int = 8
    gradient_clip: float = 10.0

    def __post_init__(self) -> None:
        if not 0 <= self.gamma <= 1 or not 0 < self.tau <= 1:
            raise ValueError("gamma/tau outside valid range")
        if min(self.hidden_dim, self.policy_delay, self.batch_size, self.topology_batch_size) < 1:
            raise ValueError("network and update sizes must be positive")
        if self.replay_capacity < self.batch_size or self.topology_capacity < self.topology_batch_size:
            raise ValueError("replay capacity smaller than batch size")


def _soft_update(online: nn.Module, target: nn.Module, tau: float) -> None:
    with torch.no_grad():
        for source, destination in zip(online.parameters(), target.parameters()):
            destination.lerp_(source, tau)


def _finite_loss(loss: torch.Tensor) -> None:
    if not torch.isfinite(loss):
        raise FloatingPointError("non-finite learning loss")


class TD3Agent:
    def __init__(self, observation_dim: int, action_dim: int = 2,
                 config: LearningConfig | None = None, device: str = "cuda", seed: int = 0) -> None:
        self.config = config or LearningConfig()
        self.device = resolve_device(device)
        self.observation_dim, self.action_dim = observation_dim, action_dim
        self.actor = mlp(observation_dim, action_dim, self.config.hidden_dim, True).to(self.device)
        self.critic = TwinCritic(observation_dim, action_dim, self.config.hidden_dim).to(self.device)
        self.actor_target = copy.deepcopy(self.actor).requires_grad_(False)
        self.critic_target = copy.deepcopy(self.critic).requires_grad_(False)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=self.config.actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=self.config.critic_lr)
        self.replay = ReplayBuffer(self.config.replay_capacity, observation_dim, action_dim, seed)
        self.rng = np.random.default_rng(seed + 1)
        self.updates = 0

    def act(self, observation: Any, noise_std: float = 0.0) -> np.ndarray:
        observation = _vector(observation, self.observation_dim, "observation")
        with torch.no_grad():
            action = self.actor(torch.as_tensor(observation, device=self.device).unsqueeze(0))[0].cpu().numpy()
        if noise_std:
            action = action + self.rng.normal(0, noise_std, self.action_dim)
        return np.clip(action, -1, 1).astype(np.float32)

    def update(self) -> dict[str, float]:
        c = self.config
        if len(self.replay) < c.batch_size:
            return {}
        batch = self.replay.sample(c.batch_size, self.device)
        with torch.no_grad():
            noise = (torch.randn_like(batch["actions"]) * c.policy_noise).clamp(-c.noise_clip, c.noise_clip)
            next_actions = (self.actor_target(batch["next_observations"]) + noise).clamp(-1, 1)
            q1, q2 = self.critic_target(batch["next_observations"], next_actions)
            target = batch["rewards"] + (1 - batch["terminated"]) * c.gamma * torch.minimum(q1, q2)
        q1, q2 = self.critic(batch["observations"], batch["actions"])
        critic_loss = F.mse_loss(q1, target) + F.mse_loss(q2, target)
        _finite_loss(critic_loss)
        self.critic_optimizer.zero_grad(set_to_none=True)
        critic_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), c.gradient_clip)
        self.critic_optimizer.step()
        self.updates += 1
        result = {"critic_loss": float(critic_loss.detach().cpu())}
        if self.updates % c.policy_delay == 0:
            self.critic.requires_grad_(False)
            actions = self.actor(batch["observations"])
            actor_loss = -self.critic.q1(torch.cat((batch["observations"], actions), -1)).mean()
            _finite_loss(actor_loss)
            self.actor_optimizer.zero_grad(set_to_none=True)
            actor_loss.backward()
            nn.utils.clip_grad_norm_(self.actor.parameters(), c.gradient_clip)
            self.actor_optimizer.step()
            self.critic.requires_grad_(True)
            _soft_update(self.actor, self.actor_target, c.tau)
            _soft_update(self.critic, self.critic_target, c.tau)
            result["actor_loss"] = float(actor_loss.detach().cpu())
        return result

    def state_dict(self, include_replay: bool = True) -> dict[str, Any]:
        state = {"config": asdict(self.config), "observation_dim": self.observation_dim,
                 "action_dim": self.action_dim, "actor": self.actor.state_dict(),
                 "critic": self.critic.state_dict(), "actor_target": self.actor_target.state_dict(),
                 "critic_target": self.critic_target.state_dict(),
                 "actor_optimizer": self.actor_optimizer.state_dict(),
                 "critic_optimizer": self.critic_optimizer.state_dict(), "updates": self.updates,
                 "rng": copy.deepcopy(self.rng.bit_generator.state)}
        if include_replay:
            state["replay"] = self.replay.state_dict()
        return state

    def load_state_dict(self, state: dict[str, Any], load_replay: bool = True) -> None:
        if state["observation_dim"] != self.observation_dim or state["action_dim"] != self.action_dim:
            raise ValueError("TD3 checkpoint dimensions do not match environment")
        if state["config"] != asdict(self.config):
            raise ValueError("TD3 learning configuration differs from checkpoint")
        for name in ("actor", "critic", "actor_target", "critic_target"):
            getattr(self, name).load_state_dict(state[name])
        self.actor_optimizer.load_state_dict(state["actor_optimizer"])
        self.critic_optimizer.load_state_dict(state["critic_optimizer"])
        self.updates = state["updates"]
        self.rng.bit_generator.state = state["rng"]
        if load_replay and "replay" in state:
            self.replay.load_state_dict(state["replay"])


class MaskedDoubleDQN:
    def __init__(self, observation_dim: int, n_actions: int,
                 config: LearningConfig | None = None, device: str = "cuda", seed: int = 0) -> None:
        self.config = config or LearningConfig()
        self.device = resolve_device(device)
        self.observation_dim, self.n_actions = observation_dim, n_actions
        self.online = mlp(observation_dim, n_actions, self.config.hidden_dim).to(self.device)
        self.target = copy.deepcopy(self.online).requires_grad_(False)
        self.optimizer = torch.optim.Adam(self.online.parameters(), lr=self.config.topology_lr)
        self.replay = TopologyReplay(self.config.topology_capacity, observation_dim, n_actions, seed)
        self.rng = np.random.default_rng(seed + 1)
        self.updates = 0

    def act(self, observation: Any, mask: Any, epsilon: float = 0.0) -> int:
        observation = _vector(observation, self.observation_dim, "slow observation")
        mask = _mask(mask, self.n_actions)
        if not 0 <= epsilon <= 1:
            raise ValueError("epsilon must be in [0,1]")
        if epsilon and self.rng.random() < epsilon:
            return int(self.rng.choice(np.flatnonzero(mask)))
        with torch.no_grad():
            q = self.online(torch.as_tensor(observation, device=self.device))
            q = q.masked_fill(~torch.as_tensor(mask, device=self.device), -torch.inf)
        return int(q.argmax().item())

    def update(self) -> dict[str, float]:
        c = self.config
        if len(self.replay) < c.topology_batch_size:
            return {}
        batch = self.replay.sample(c.topology_batch_size, self.device)
        with torch.no_grad():
            next_masks = batch["next_masks"].clone()
            empty = ~next_masks.any(dim=1)
            if torch.any(empty & (batch["terminated"].flatten() == 0)):
                raise ValueError("non-terminal next topology mask is empty")
            next_masks[empty, 0] = True  # Terminal rows never bootstrap.
            next_online = self.online(batch["next_observations"]).masked_fill(~next_masks, -torch.inf)
            next_action = next_online.argmax(dim=1, keepdim=True)
            next_q = self.target(batch["next_observations"]).gather(1, next_action)
            target = batch["rewards"] + (1 - batch["terminated"]) * batch["discounts"] * next_q
        current = self.online(batch["observations"]).gather(1, batch["actions"])
        loss = F.smooth_l1_loss(current, target)
        _finite_loss(loss)
        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(self.online.parameters(), c.gradient_clip)
        self.optimizer.step()
        _soft_update(self.online, self.target, c.tau)
        self.updates += 1
        return {"topology_loss": float(loss.detach().cpu())}

    def state_dict(self, include_replay: bool = True) -> dict[str, Any]:
        state = {"config": asdict(self.config), "observation_dim": self.observation_dim,
                 "n_actions": self.n_actions, "online": self.online.state_dict(),
                 "target": self.target.state_dict(), "optimizer": self.optimizer.state_dict(),
                 "updates": self.updates, "rng": copy.deepcopy(self.rng.bit_generator.state)}
        if include_replay:
            state["replay"] = self.replay.state_dict()
        return state

    def load_state_dict(self, state: dict[str, Any], load_replay: bool = True) -> None:
        if state["observation_dim"] != self.observation_dim or state["n_actions"] != self.n_actions:
            raise ValueError("DDQN checkpoint dimensions do not match environment")
        if state["config"] != asdict(self.config):
            raise ValueError("DDQN learning configuration differs from checkpoint")
        self.online.load_state_dict(state["online"])
        self.target.load_state_dict(state["target"])
        self.optimizer.load_state_dict(state["optimizer"])
        self.updates = state["updates"]
        self.rng.bit_generator.state = state["rng"]
        if load_replay and "replay" in state:
            self.replay.load_state_dict(state["replay"])
