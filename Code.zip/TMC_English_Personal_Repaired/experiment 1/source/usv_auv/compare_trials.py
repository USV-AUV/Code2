"""Frozen equal-budget research trials; no training or automatic tuning.

Distinct run IDs and policy action frames are allowed. Physics is checked
separately from reward/training settings and the service handshake protocol.
Development selection is not an untouched-test or multi-training-seed claim.
"""
from __future__ import annotations

import argparse
import copy
import csv
import gc
import json
import math
from pathlib import Path
import time
from typing import Any, Mapping, Sequence
import uuid

import numpy as np

from .compare_checkpoints import (
    BOOTSTRAP_SAMPLES, BOOTSTRAP_SEED, _atomic_json, _code_hashes, _fingerprint,
    _json_safe, _metric, _sha256, _utc_now, _validate_record,
    load_milestone_metadata, paired_metric_statistics, summarize_paired_episodes,
)
from .actions import ACTION_ENCODINGS

METHOD_KEYS = frozenset({
    "seed", "action_frame", "gamma", "hidden_dim", "batch_size", "replay_size",
    "learning_rate", "tau", "policy_delay", "policy_noise", "noise_clip",
    "exploration_noise", "warmup_steps", "td3_pretrain_steps", "topology_pretrain_steps",
    "alternating_block_steps", "checkpoint_interval", "usde_kappa", "navigation_history_seconds",
})
PROTOCOL_KEYS = frozenset({"service_grant_aware"})
HOLDOUT_START = 9_200_000
HOLDOUT_RESERVED_COUNT = 1_000


def _method_key(key: str) -> bool:
    return key in METHOD_KEYS or key.startswith("reward_")


def _normal_config(raw: Mapping[str, Any]) -> dict[str, Any]:
    from .config import Config
    config = Config.from_dict(dict(raw)).to_dict()
    config.setdefault("action_frame", "global")
    config.setdefault("service_grant_aware", False)
    return config


def _physics(config: Mapping[str, Any]) -> dict[str, Any]:
    # Unknown/new config fields are physical by default: fail closed on a
    # difference instead of silently classifying an easier task as a method.
    return {key: value for key, value in config.items() if not _method_key(key) and key not in PROTOCOL_KEYS}


def _action_schema(checkpoint: Mapping[str, Any]) -> dict[str, Any]:
    config, schema = checkpoint["environment_config"], copy.deepcopy(checkpoint["observation_schema"])
    frame = config.get("action_frame", "global")
    if frame not in ACTION_ENCODINGS:
        raise ValueError(f"Unsupported policy action_frame: {frame}")
    encoding = schema.get("action_encoding", ACTION_ENCODINGS["global"])
    if encoding != ACTION_ENCODINGS[frame]:
        raise ValueError("Checkpoint action_encoding conflicts with action_frame; legacy means global only")
    schema["action_encoding"] = encoding
    return schema


def validate_trial_pair(
    reference: Mapping[str, Any], candidate: Mapping[str, Any], *, expected_step: int = 100_000,
    common_physics_config: Mapping[str, Any] | None = None,
    common_service_grant_aware: bool | None = None,
) -> dict[str, Any]:
    """Validate equal budgets without pretending two training runs are one run."""
    if type(expected_step) is not int or expected_step < 1:
        raise ValueError("expected_step must be a positive integer")
    if common_service_grant_aware is not None and type(common_service_grant_aware) is not bool:
        raise ValueError("common_service_grant_aware must be a Boolean or None")
    originals, schemas = {}, {}
    for label, checkpoint in (("reference", reference), ("candidate", candidate)):
        for key in ("environment_config", "config_fingerprint", "observation_schema", "global_step", "seed", "run_id"):
            if key not in checkpoint:
                raise ValueError(f"{label} checkpoint/metadata missing {key}")
        if _fingerprint(checkpoint["environment_config"]) != checkpoint["config_fingerprint"]:
            raise ValueError(f"{label} checkpoint configuration fingerprint is inconsistent")
        if type(checkpoint["global_step"]) is not int or checkpoint["global_step"] != expected_step:
            raise ValueError(f"Both trial checkpoints must have exactly {expected_step} training steps")
        if type(checkpoint["seed"]) is not int or checkpoint["seed"] < 0:
            raise ValueError("Training seeds must be nonnegative integers")
        if not isinstance(checkpoint["run_id"], str) or not checkpoint["run_id"]:
            raise ValueError("Each trial must retain its real training run_id")
        originals[label] = _normal_config(checkpoint["environment_config"])
        schemas[label] = _action_schema(checkpoint)
    base_schemas = [{k: v for k, v in schemas[label].items() if k != "action_encoding"}
                    for label in ("reference", "candidate")]
    if base_schemas[0] != base_schemas[1]:
        raise ValueError("Trial observation fields/dimensions and topology action ordering must agree")
    evaluated = copy.deepcopy(originals)
    if common_physics_config is not None:
        physical = _physics(_normal_config(common_physics_config))
        for config in evaluated.values():
            config.update(copy.deepcopy(physical))
    if common_service_grant_aware is not None:
        for config in evaluated.values():
            config["service_grant_aware"] = common_service_grant_aware
    left_physics, right_physics = (_physics(evaluated[label]) for label in ("reference", "candidate"))
    if left_physics != right_physics:
        differences = sorted(key for key in left_physics.keys() | right_physics.keys()
                             if left_physics.get(key) != right_physics.get(key))
        raise ValueError(f"Evaluation physics must be identical; different fields: {differences}")
    changes = {label: {key: {"trained": originals[label].get(key), "evaluated": value}
                       for key, value in evaluated[label].items() if originals[label].get(key) != value}
               for label in originals}
    protocol_equal = all(evaluated["reference"][key] == evaluated["candidate"][key] for key in PROTOCOL_KEYS)
    transfer = any(changes.values())
    comparison_kind = ("transfer_diagnostic" if transfer else
                       "common_protocol_equal_budget" if protocol_equal else "protocol_and_method_bundle")
    return {
        "expected_training_steps": [expected_step, expected_step],
        "training_steps": {"reference": reference["global_step"], "candidate": candidate["global_step"]},
        "training_run_ids": {"reference": reference["run_id"], "candidate": candidate["run_id"]},
        "training_seeds": {"reference": reference["seed"], "candidate": candidate["seed"]},
        "same_training_seed": reference["seed"] == candidate["seed"],
        "training_configurations": originals, "evaluation_configurations": evaluated,
        "original_config_fingerprints": {"reference": reference["config_fingerprint"], "candidate": candidate["config_fingerprint"]},
        "method_parameters": {label: {key: value for key, value in config.items() if _method_key(key)}
                              for label, config in originals.items()},
        "training_protocol_parameters": {label: {key: config[key] for key in PROTOCOL_KEYS}
                                         for label, config in originals.items()},
        "evaluation_protocol_parameters": {label: {key: config[key] for key in PROTOCOL_KEYS}
                                           for label, config in evaluated.items()},
        "evaluation_overrides": changes, "transfer_diagnostic": transfer,
        "common_service_protocol": protocol_equal, "comparison_kind": comparison_kind,
        "method_comparison_eligible": protocol_equal and not transfer,
        "common_physical_configuration": left_physics,
        "physical_fingerprint": _fingerprint(left_physics), "policy_schemas": schemas,
        "learning_configurations": {"reference": reference.get("learning_config"), "candidate": candidate.get("learning_config")},
    }


def summarize_trial_episodes(
    reference: Sequence[Mapping[str, Any]], candidate: Sequence[Mapping[str, Any]], *,
    packet_bits: int, min_mean_packets: float = 20.0, min_relative_percent: float = 50.0,
) -> dict[str, Any]:
    if type(packet_bits) is not int or packet_bits < 1:
        raise ValueError("packet_bits must be a positive integer")
    if any(not math.isfinite(value) or value < 0 for value in (min_mean_packets, min_relative_percent)):
        raise ValueError("Acceptance thresholds must be finite and nonnegative")
    for row in (*reference, *candidate):
        for ratio in ("unique_collection_fraction", "acknowledged_fraction_of_collected"):
            value = row.get(ratio)
            if value is not None and (not math.isfinite(value) or not 0 <= value <= 1):
                raise ValueError(f"Invalid episode ratio: {ratio}")
    # Rewards may have different units/weights. Validate and preserve raw reward
    # in records, but remove its comparison from all reported statistics.
    result = summarize_paired_episodes(reference, candidate)
    result["metrics"].pop("return", None)
    result["reward_comparison"] = "omitted: different method reward scales are not comparable"
    left = {row["seed"]: row for row in reference}
    right = {row["seed"]: row for row in candidate}
    seeds = result["paired_seeds"]
    for records in (left, right):
        for row in records.values():
            packet_count = float(row["collected_bits"]) / packet_bits
            if not math.isclose(packet_count, round(packet_count), abs_tol=1e-8):
                raise ValueError("Unique collected bits must represent complete data packets")
    packets = paired_metric_statistics([left[s]["collected_bits"] / packet_bits for s in seeds],
                                       [right[s]["collected_bits"] / packet_bits for s in seeds])
    zero = paired_metric_statistics([float(left[s]["collected_bits"] == 0) for s in seeds],
                                    [float(right[s]["collected_bits"] == 0) for s in seeds], seed=BOOTSTRAP_SEED + 201)
    survived = paired_metric_statistics([float(left[s]["survived_full_horizon"]) for s in seeds],
                                        [float(right[s]["survived_full_horizon"]) for s in seeds], seed=BOOTSTRAP_SEED + 202)
    result["collection_packets"] = {"packet_bits": packet_bits, "statistics": packets,
                                    "reference_total": sum(left[s]["collected_bits"] for s in seeds) / packet_bits,
                                    "candidate_total": sum(right[s]["collected_bits"] for s in seeds) / packet_bits}
    result["zero_collection"] = {"reference_count": sum(left[s]["collected_bits"] == 0 for s in seeds),
                                 "candidate_count": sum(right[s]["collected_bits"] == 0 for s in seeds), "rate_statistics": zero}
    result["full_horizon"] = {"reference_count": sum(left[s]["survived_full_horizon"] for s in seeds),
                              "candidate_count": sum(right[s]["survived_full_horizon"] for s in seeds), "rate_statistics": survived}
    for key in ("unique_collection_fraction", "acknowledged_fraction_of_collected"):
        valid = [s for s in seeds if left[s].get(key) is not None and right[s].get(key) is not None]
        result[key] = {"valid_pairs": len(valid), "excluded_undefined_pairs": len(seeds) - len(valid),
                       "statistics": paired_metric_statistics([left[s][key] for s in valid], [right[s][key] for s in valid],
                                                              seed=BOOTSTRAP_SEED + 203) if valid else None}
    zero_reference = packets["early_mean"] == 0
    relative_ok = packets["relative_percent"] is not None and packets["relative_percent"] >= min_relative_percent
    checks = {"enough_pairs": len(seeds) >= 2, "absolute_task_target": packets["late_mean"] >= min_mean_packets,
              "relative_improvement": None if zero_reference else relative_ok, "paired_ci_positive": packets["ci95"][0] > 0,
              "safety_not_worse_in_sample": not result["safety"]["late_has_more_failures"]}
    passed = all(value for value in checks.values() if value is not None)
    result["primary_endpoint"] = {"metric": "unique_collected_packets", "minimum_mean_packets": min_mean_packets,
                                   "minimum_relative_percent": min_relative_percent, "checks": checks,
                                   "relative_criterion": "not_applicable_zero_reference" if zero_reference else "minimum_relative_percent",
                                   "improvement_mode": "absolute_improvement" if zero_reference else "relative_and_absolute_improvement",
                                   "criterion_met": passed, "statistics": packets}
    result["interpretation"] = (
        "Prespecified collection and sample safety checks passed; confirm the comparison protocol and split identity."
        if passed else "Prespecified collection and sample safety checks were not met.")
    result["warnings"].extend([
        "Equal environment steps do not imply equal gradient updates; training and reward configurations remain method-specific.",
        "Zero-payload and full-horizon completion rates are reported separately; equal observed failures do not establish non-inferiority.",
        "Collection fractions depend on the number of arrivals before termination; they do not replace absolute accepted-packet counts.",
        "STATE AoI measures the age of AUV state received at the USV, not the age of sensor DATA.",
    ])
    return result


def _diagnostic_sample(env, actions) -> dict[str, Any] | None:
    """Evaluation-only truth diagnostics; never supplied to a policy/planner."""
    if not all(hasattr(env, key) for key in ("auv_positions", "sensor_positions", "targets", "executed_velocities")):
        return None
    positions = np.asarray(env.auv_positions, dtype=float)
    targets = np.asarray(env.targets, dtype=int)
    distances = np.linalg.norm(positions - np.asarray(env.sensor_positions)[targets], axis=1)
    speeds = np.linalg.norm(np.asarray(env.executed_velocities, dtype=float), axis=1)
    if not np.isfinite(distances).all() or not np.isfinite(speeds).all():
        raise ValueError("Nonfinite evaluation-only motion diagnostics")
    return {"target_horizontal_distance_m": distances,
            "inside_collection_radius": distances <= env.cfg.collection_radius,
            "water_relative_speed_mps": speeds,
            "direction_action_saturated": np.abs(np.asarray(actions)[:, 1]) > .99}


def _evaluate_trial(checkpoint, label, output, protocol, evaluation_config, progress_path, milestone):
    from .config import Config
    from .deploy import DeploymentPolicy
    from .environment import CooperativeEnv
    from .learning import seed_all
    policy = DeploymentPolicy(dict(checkpoint), protocol["device"])
    cfg = Config.from_dict(evaluation_config)
    seed_all(protocol["seed"])
    env = CooperativeEnv(cfg)
    # Physics and explicit protocol changes were independently checked above.
    # Action encoding / observation ordering remain mandatory even for transfer.
    output.mkdir(parents=True, exist_ok=True)
    records = []
    offset = 0 if label == "reference" else protocol["episodes"]

    def progress(done, step=0):
        _atomic_json(progress_path, {"status": "evaluating", "policy": label, "model_step": checkpoint["global_step"],
                                   "episode_done": done, "episodes_total": protocol["episodes"], "step_in_episode": step,
                                   "overall_episode_done": offset + done, "overall_episodes_total": 2 * protocol["episodes"],
                                   "updated_at": _utc_now()})
    try:
        policy.validate_environment(env, check_config=False)
        with (output / "evaluation.jsonl").open("w", encoding="utf-8") as trace, (output / "episodes.jsonl").open("w", encoding="utf-8") as episode_log:
            progress(0)
            for episode in range(protocol["episodes"]):
                seed = protocol["seed"] + episode
                observations, info = env.reset(seed=seed)
                initial_time = previous_time = float(info["time"])
                total_reward = accumulated_aoi = 0.0
                diagnostic_sums = {}
                diagnostic_duration = 0.0
                for index in range(protocol["steps"]):
                    topology_action = None
                    if env.step_count % cfg.slow_period == 0:
                        slow_state, mask = env.slow_state()
                        topology_action = policy.topology_action(slow_state, mask)
                    actions = policy.act(observations)
                    observations, reward, terminated, truncated, info = env.step(actions, topology_action=topology_action)
                    now = float(info["time"])
                    interval = now - previous_time
                    if not math.isfinite(interval) or interval <= 0 or not math.isfinite(float(reward)):
                        raise ValueError("Invalid episode time advance or reward")
                    total_reward += float(reward)
                    accumulated_aoi += interval * _metric(info, "mean_aoi_s")
                    previous_time = now
                    diagnostic = _diagnostic_sample(env, actions)
                    if diagnostic is not None:
                        diagnostic_duration += interval
                        for key, values in diagnostic.items():
                            diagnostic_sums[key] = diagnostic_sums.get(key, np.zeros(cfg.n_auv)) + interval * np.asarray(values, dtype=float)
                    trace.write(json.dumps(_json_safe({"episode": episode, "seed": seed, "step": index + 1,
                                                       "time": now, "reward": float(reward), "actions": actions,
                                                       "topology_request": topology_action, "terminated": bool(terminated),
                                                       "truncated": bool(truncated), "info": info,
                                                       "evaluation_only_diagnostics": diagnostic}), ensure_ascii=False, allow_nan=False) + "\n")
                    if (index + 1) % 100 == 0:
                        trace.flush()
                        progress(episode, index + 1)
                    if terminated or truncated:
                        break
                duration = previous_time - initial_time
                collected = _metric(info, "collected_bits")
                acknowledged = _metric(info, "ack_released_bits")
                initial_bits, arrival_bits = _metric(info, "initial_bits"), _metric(info, "arrival_bits", 0.0)
                available = initial_bits + arrival_bits
                if collected > available:
                    raise ValueError("Unique collected data exceeds initial plus arrived data")
                record = _validate_record({
                    "episode": episode, "seed": seed, "steps": index + 1, "duration_s": duration,
                    "terminated": bool(terminated), "truncated": bool(truncated),
                    "termination_reason": str(info.get("termination_reason", "")),
                    "evaluation_limit_reached": not (terminated or truncated) and index + 1 == protocol["steps"],
                    "survived_full_horizon": not terminated and index + 1 >= min(protocol["steps"], cfg.episode_steps),
                    "collected_bits": collected, "ack_released_bits": acknowledged, "overflow_bits": _metric(info, "overflow_bits"),
                    "total_energy_j": _metric(info, "total_energy_j"), "time_mean_aoi_s": accumulated_aoi / duration,
                    "final_mean_aoi_s": _metric(info, "mean_aoi_s"), "return": total_reward,
                    "config_successes": _metric(info, "network_config_successes", 0.0),
                    "initial_bits": initial_bits, "arrival_bits": arrival_bits, "available_bits": available,
                    "collected_packets": collected / cfg.data_packet_bits,
                    "unique_collection_fraction": collected / available if available else None,
                    "acknowledged_fraction_of_collected": acknowledged / collected if collected else None,
                })
                record["diagnostic_sampling"] = "right-endpoint fast-step samples weighted by actual elapsed seconds; truth not fed to policy"
                for source, destination in (("target_horizontal_distance_m", "mean_target_horizontal_distance_m"),
                                            ("inside_collection_radius", "target_range_time_fraction"),
                                            ("water_relative_speed_mps", "mean_water_relative_speed_mps"),
                                            ("direction_action_saturated", "direction_saturation_fraction")):
                    values = diagnostic_sums[source] / diagnostic_duration if diagnostic_duration else None
                    record[destination] = float(values.mean()) if values is not None else None
                    record[destination + "_per_auv"] = values.tolist() if values is not None else None
                for key in ("collection_attempts", "service_requests", "service_grants_received",
                            "service_request_retries", "service_renewal_requests"):
                    record[key] = _metric(info, key) if key in info.get("metrics", {}) else None
                records.append(record)
                episode_log.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
                episode_log.flush()
                trace.flush()
                progress(episode + 1)
                print(json.dumps({"event": "episode_complete", "policy": label, "episode_done": episode + 1,
                                  "episodes_total": protocol["episodes"], "collected_packets": record["collected_packets"],
                                  "terminated": bool(terminated)}, ensure_ascii=False), flush=True)
        _atomic_json(output / "evaluation_summary.json", {"policy": label, "training_steps": checkpoint["global_step"],
                                                         "evaluation_config": evaluation_config, "protocol": protocol, "episodes": records})
        milestone("trial_evaluation_complete", policy=label, episodes=len(records))
        return records
    finally:
        env.close()
        del env, policy
        gc.collect()


def _load_trial(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    from .deploy import load_checkpoint
    checkpoint = load_checkpoint(path)
    digest = _sha256(path)
    metadata = load_milestone_metadata(path, checkpoint, digest)
    if metadata is None:
        raise ValueError("Use an immutable milestone checkpoint with sibling metadata.json and verified SHA256")
    if metadata.get("learning_config") != checkpoint.get("learning_config"):
        raise ValueError("Milestone learning configuration disagrees with checkpoint")
    checkpoint = {**checkpoint, "seed": metadata["seed"], "run_id": metadata["run_id"]}
    metadata_path = path.parent / "metadata.json"
    return checkpoint, {"path": str(path), "sha256": digest, "bytes": path.stat().st_size,
                        "metadata_path": str(metadata_path), "metadata_sha256": _sha256(metadata_path),
                        "verified_milestone_metadata": metadata,
                        "raw_training_configuration": checkpoint["environment_config"],
                        "checkpoint_manifest": checkpoint.get("manifest")}


def _source_evidence(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {"available": False, "note": "Training source snapshot not supplied; evaluation source hashes are separate."}
    path = Path(path).resolve()
    return {"available": True, "path": str(path), "sha256": _sha256(path),
            "content": json.loads(path.read_text(encoding="utf-8"))}


def render_trial_markdown(report: Mapping[str, Any]) -> str:
    """Readable English report of the prespecified, paired trial comparison."""
    summary, protocol, pair = report["comparison"], report["protocol"], report["trials"]
    stats = summary["collection_packets"]["statistics"]
    stage = ("Development set (used for model selection, not independent confirmation)"
             if protocol["stage"] == "development" else
             "Declared holdout set (independence must be supported by the evaluation protocol)")
    relative_requirement = (
        "relative-percent threshold does not apply when the reference mean is zero; "
        if summary["primary_endpoint"]["relative_criterion"] == "not_applicable_zero_reference" else
        f"relative improvement at least +{summary['primary_endpoint']['minimum_relative_percent']:g}%; ")
    lines = [f"# Matched-Budget Comparison at {protocol['expected_step']} Steps", "",
        summary["interpretation"], "",
        f"Evaluation split: {stage}; {protocol['episodes']} paired scenarios, up to {protocol['steps']} steps per episode.",
        f"Reference provenance: {protocol['reference_origin']}. Different run IDs are retained as distinct experiments.",
        f"Comparison type: {pair['comparison_kind']}. Matching a physical interface is not the same as retraining a baseline.", "",
        f"DATA payload size: {summary['collection_packets']['packet_bits']} bits; unique accepted packets: {stats['early_mean']:.4f} versus {stats['late_mean']:.4f}.",
        f"Paired difference: {stats['absolute_difference']:+.4f} packets, 95% interval [{stats['ci95'][0]:.4f}, {stats['ci95'][1]:.4f}]; "
        + (f"relative change {stats['relative_percent']:+.2f}%." if stats['relative_percent'] is not None else "relative change undefined."),
        f"Prespecified gate: candidate mean at least {summary['primary_endpoint']['minimum_mean_packets']:g} packets; "
        f"{relative_requirement}paired difference interval lower bound above zero, and no additional observed safety failures.",
        f"Numerical gate: {summary['primary_endpoint']['criterion_met']}; complete evidence gate: {report['acceptance']['accepted']}.", "",
        "| Metric | Reference | Candidate |", "|---|---:|---:|",
        f"| Zero-payload episodes | {summary['zero_collection']['reference_count']} | {summary['zero_collection']['candidate_count']} |",
        f"| Full-horizon completions | {summary['full_horizon']['reference_count']} | {summary['full_horizon']['candidate_count']} |",
        f"| Safety failures | {summary['safety']['early_failure_count']} | {summary['safety']['late_failure_count']} |"]
    for key, label in (("duration_s", "Executed duration (s)"), ("total_energy_j", "Energy (J)"),
                       ("time_mean_aoi_s", "Time-mean STATE AoI (s)"), ("bits_per_joule", "Accepted bits per J")):
        item = summary["metrics"][key]["statistics"]
        if item:
            lines.append(f"| {label} | {item['early_mean']:.6g} | {item['late_mean']:.6g} |")
    lines.extend(["", "Return values are not compared across reward scales; episode records retain them for diagnostics.",
                  "Each actor action is decoded using the global or target-direction frame stored in its own training metadata.", ""])
    if summary["primary_endpoint"]["relative_criterion"] == "not_applicable_zero_reference":
        lines.extend(["With a zero reference collection mean, only the absolute improvement branch can be evaluated; no percentage threshold is claimed.", ""])
    lines.extend(f"- {warning}" for warning in summary["warnings"])
    lines.extend(["", "Configuration, source identities, paired coverage, and decision checks are recorded in comparison.json/provenance.json.",
                  "Reference and candidate folders contain episodes and trajectories; paired_episodes.csv never compares incompatible reward scales.", ""])
    return "\n".join(lines)

def compare_trials(
    reference_path: Path, candidate_path: Path, output: Path, *, expected_step: int = 100_000,
    episodes: int | None = None, steps: int = 1200, seed: int | None = None, device: str = "cuda",
    stage: str = "development", common_physics_config: Mapping[str, Any] | None = None,
    common_service_grant_aware: bool | None = None, min_mean_packets: float = 20.0,
    min_relative_percent: float = 50.0, reference_origin: str = "rebuilt_previous_method_100k_not_historical_weights",
    reference_source_evidence: Path | None = None, candidate_source_evidence: Path | None = None,
) -> dict[str, Any]:
    if stage not in ("development", "holdout"):
        raise ValueError("stage must be development or holdout")
    if any(not math.isfinite(value) or value < 0 for value in (min_mean_packets, min_relative_percent)):
        raise ValueError("Acceptance thresholds must be finite and nonnegative")
    episodes = (20 if stage == "development" else 30) if episodes is None else episodes
    seed = (9_100_000 if stage == "development" else HOLDOUT_START) if seed is None else seed
    if any(type(value) is not int or value < 1 for value in (episodes, steps)):
        raise ValueError("episodes and steps must be positive integers")
    if type(seed) is not int or seed < 0 or seed + episodes > 2**32:
        raise ValueError("Test seeds must fit uint32")
    if stage == "development" and seed < HOLDOUT_START + HOLDOUT_RESERVED_COUNT and seed + episodes > HOLDOUT_START:
        raise ValueError("Development evaluation must not consume the reserved holdout seeds")
    if stage == "holdout" and not (HOLDOUT_START <= seed and seed + episodes <= HOLDOUT_START + HOLDOUT_RESERVED_COUNT):
        raise ValueError("Holdout seeds must lie inside the explicitly reserved holdout block")
    reference_path, candidate_path, output = Path(reference_path).resolve(), Path(candidate_path).resolve(), Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError("Comparison output must be fresh; never overwrite previous trials")
    reference, reference_artifact = _load_trial(reference_path)
    candidate, candidate_artifact = _load_trial(candidate_path)
    pair = validate_trial_pair(reference, candidate, expected_step=expected_step, common_physics_config=common_physics_config,
                               common_service_grant_aware=common_service_grant_aware)
    bound = max(checkpoint["seed"] + checkpoint["global_step"] for checkpoint in (reference, candidate))
    if seed <= bound:
        raise ValueError(f"Test seeds must be above training seed + actual progress: {bound}")
    if steps > pair["common_physical_configuration"]["episode_steps"]:
        raise ValueError("Requested test horizon exceeds the configured episode horizon")
    output.mkdir(parents=True, exist_ok=True)
    protocol = {"stage": stage, "episodes": episodes, "steps": steps, "seed": seed, "device": device,
                "test_seeds": list(range(seed, seed + episodes)), "expected_step": expected_step,
                "training_reset_seed_upper_bound": bound, "reference_origin": reference_origin,
                "minimum_mean_packets": min_mean_packets, "minimum_relative_percent": min_relative_percent,
                "bootstrap_samples": BOOTSTRAP_SAMPLES, "bootstrap_seed": BOOTSTRAP_SEED,
                "holdout_unseen_status": "procedural declaration; cannot be inferred from model files",
                "same_scenario_seeds_not_identical_packet_random_outcomes": True}
    provenance = {"run_id": str(uuid.uuid4()), "started_at": _utc_now(), "protocol": protocol, "trials": pair,
                  "reference": reference_artifact, "candidate": candidate_artifact, "code_sha256": _code_hashes(),
                  "training_source_evidence": {"reference": _source_evidence(reference_source_evidence),
                                               "candidate": _source_evidence(candidate_source_evidence)}}
    _atomic_json(output / "provenance.json", provenance)
    progress_path = output / "comparison_progress.json"

    def milestone(event, **extra):
        with (output / "milestones.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(_json_safe({"time": _utc_now(), "event": event, "run_id": provenance["run_id"], **extra}),
                                    ensure_ascii=False, allow_nan=False) + "\n")
    start = time.monotonic()
    milestone("equal_budget_comparison_started", expected_step=expected_step)
    try:
        left = _evaluate_trial(reference, "reference", output / "reference", protocol, pair["evaluation_configurations"]["reference"], progress_path, milestone)
        right = _evaluate_trial(candidate, "candidate", output / "candidate", protocol, pair["evaluation_configurations"]["candidate"], progress_path, milestone)
        summary = summarize_trial_episodes(left, right, packet_bits=pair["common_physical_configuration"]["data_packet_bits"],
                                           min_mean_packets=min_mean_packets, min_relative_percent=min_relative_percent)
        unchanged = _code_hashes() == provenance["code_sha256"]
        weights_unchanged = all(_sha256(Path(artifact["path"])) == artifact["sha256"] and
                                _sha256(Path(artifact["metadata_path"])) == artifact["metadata_sha256"]
                                for artifact in (reference_artifact, candidate_artifact))
        sources_unchanged = all(not item["available"] or _sha256(Path(item["path"])) == item["sha256"]
                                for item in provenance["training_source_evidence"].values())
        full_horizon = steps == pair["common_physical_configuration"]["episode_steps"]
        accepted = bool(summary["primary_endpoint"]["criterion_met"] and pair["method_comparison_eligible"]
                        and unchanged and weights_unchanged and sources_unchanged and full_horizon)
        summary["warnings"].append(" ,  . " if stage == "development" else
                                    " ;  ,  ,  . ")
        if pair["comparison_kind"] != "common_protocol_equal_budget":
            summary["warnings"].append(" :  / ,   TD3. ")
        if not full_horizon:
            summary["warnings"].append(" task ;  ,  task . ")
        if not (unchanged and weights_unchanged and sources_unchanged):
            summary["warnings"].append(" ,  ,  . ")
        if not all(item["available"] for item in provenance["training_source_evidence"].values()):
            summary["warnings"].append("training;  / , training. ")
        summary["interpretation"] = (" , independent;  . " if accepted and stage == "development" else
                                      " ;  , training. " if accepted else
                                      "complete;  ,  , collection acknowledged. ")
        if summary["primary_endpoint"]["relative_criterion"] == "not_applicable_zero_reference":
            summary["interpretation"] += " collection,  ,  N/A. "
        report = {"format": "usv-auv-equal-budget-trials-v1", "completed_at": _utc_now(), "elapsed_seconds": time.monotonic() - start,
                  "protocol": protocol, "trials": pair, "comparison": summary, "reference_episodes": left, "candidate_episodes": right,
                  "source_files_unchanged": unchanged, "weights_and_metadata_unchanged": weights_unchanged,
                  "training_source_evidence_unchanged": sources_unchanged,
                  "acceptance": {"accepted": accepted, "stage": stage, "numeric_criteria_met": summary["primary_endpoint"]["criterion_met"],
                                 "method_comparison_eligible": pair["method_comparison_eligible"], "full_configured_horizon": full_horizon}}
        _atomic_json(output / "comparison.json", report)
        (output / "comparison.md").write_text(render_trial_markdown(report), encoding="utf-8")
        right_by_seed = {row["seed"]: row for row in right}
        rows = []
        for row in left:
            joined = {"seed": row["seed"]}
            for prefix, raw in (("reference", row), ("candidate", right_by_seed[row["seed"]])):
                joined.update({f"{prefix}_{key}": value for key, value in raw.items() if key not in ("seed", "return")})
            rows.append(joined)
        with (output / "paired_episodes.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        milestone("equal_budget_comparison_complete", accepted=accepted, stage=stage)
        _atomic_json(progress_path, {"status": "completed", "model_step": expected_step, "episode_done": episodes,
                                    "episodes_total": episodes, "overall_episode_done": 2 * episodes, "overall_episodes_total": 2 * episodes,
                                    "accepted": accepted, "updated_at": _utc_now()})
        return report
    except Exception as error:
        milestone("equal_budget_comparison_failed", error=repr(error))
        _atomic_json(progress_path, {"status": "failed", "error": repr(error), "updated_at": _utc_now()})
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-step", type=int, default=100_000)
    parser.add_argument("--episodes", type=int)
    parser.add_argument("--steps", type=int, default=1200)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--stage", choices=("development", "holdout"), default="development")
    parser.add_argument("--common-physics-config", type=Path)
    parser.add_argument("--common-service-grant-aware", choices=("true", "false"))
    parser.add_argument("--min-mean-packets", type=float, default=20.0)
    parser.add_argument("--min-relative-percent", type=float, default=50.0)
    parser.add_argument("--reference-origin", default="rebuilt_previous_method_100k_not_historical_weights")
    parser.add_argument("--reference-source-evidence", type=Path)
    parser.add_argument("--candidate-source-evidence", type=Path)
    args = parser.parse_args()
    physical = json.loads(args.common_physics_config.read_text(encoding="utf-8")) if args.common_physics_config else None
    common_protocol = None if args.common_service_grant_aware is None else args.common_service_grant_aware == "true"
    report = compare_trials(args.reference, args.candidate, args.output, expected_step=args.expected_step, episodes=args.episodes,
                            steps=args.steps, seed=args.seed, device=args.device, stage=args.stage, common_physics_config=physical,
                            common_service_grant_aware=common_protocol, min_mean_packets=args.min_mean_packets,
                            min_relative_percent=args.min_relative_percent, reference_origin=args.reference_origin,
                            reference_source_evidence=args.reference_source_evidence, candidate_source_evidence=args.candidate_source_evidence)
    print(json.dumps({"status": "completed", "accepted": report["acceptance"]["accepted"],
                      "interpretation": report["comparison"]["interpretation"]}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
