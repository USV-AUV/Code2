"""One fresh, bounded GPU training trial with immutable code/config evidence."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import traceback

from .config import Config
from .run_experiment import atomic_json, keep_system_awake, launch_child, utc_now
from .train import file_digest, milestone_identity, milestone_path, validate_milestone


def run_trial(config: Path, output: Path, steps: int, label: str):
    import torch
    from .deploy import load_checkpoint

    output = output.resolve()
    if output.exists():
        raise FileExistsError('A trial needs a new output directory; never overwrite a prior attempt')
    if type(steps) is not int or steps < 1:
        raise ValueError('Positive explicit environment-step budget required')
    if not torch.cuda.is_available():
        raise RuntimeError('GPU training required; no CPU fallback')
    cfg = Config.load(config)
    output.mkdir(parents=True, exist_ok=False)
    cfg.save(output / 'frozen_config.json')
    # The offline cross-trial comparator is not imported by training. It has
    # its own frozen-code provenance at evaluation time, after trials finish.
    sources = {p.name: file_digest(p) for p in sorted(Path(__file__).parent.glob('*.py'))
               if p.name != 'compare_trials.py'}
    atomic_json(output / 'source_hashes.json', sources)
    status = dict(stage='starting', label=label, output=str(output), workflow_pid=os.getpid(),
                  child_pid=None, started_at=utc_now(), total_steps=steps, seed=cfg.seed,
                  config_fingerprint=cfg.fingerprint, device='cuda', gpu=torch.cuda.get_device_name(0),
                  training_semantics='fresh random initialization; all interaction counted; no demonstrations',
                  source_hashes=str(output / 'source_hashes.json'), automatic_retry=False)
    status['training_hash_exclusions'] = ['compare_trials.py (offline evaluation only)']
    atomic_json(output / 'workflow_status.json', status)
    try:
        with keep_system_awake() as awake:
            status['temporary_system_sleep_inhibition'] = awake
            command = [sys.executable, '-u', '-m', 'usv_auv.train', '--config', str(output / 'frozen_config.json'),
                       '--output', str(output), '--steps', str(steps), '--milestones', str(steps),
                       '--seed', str(cfg.seed), '--device', 'cuda', '--log-every', '1000']
            launch_child(command, output, status, 'training', 'train')
        summary = json.loads((output / 'summary.json').read_text(encoding='utf-8'))
        if summary['global_step'] != steps or not all(n > 0 for n in summary['td3_updates']) or summary['ddqn_updates'] <= 0:
            raise RuntimeError('Wrong training budget or inactive learner')
        for name, digest in sources.items():
            if file_digest(Path(__file__).parent / name) != digest:
                raise RuntimeError(f'Source changed during this trial: {name}')
        checkpoint = load_checkpoint(milestone_path(output, steps) / 'checkpoint.pt')
        metadata = validate_milestone(milestone_path(output, steps), milestone_identity(checkpoint))
        status.update(stage='complete', completed_at=utc_now(), child_pid=None,
                      run_id=metadata['run_id'], training_summary=summary,
                      inference=str(milestone_path(output, steps) / 'policy.pt'), source_files_unchanged=True)
        atomic_json(output / 'workflow_status.json', status)
        return status
    except BaseException as error:
        status.update(stage='failed', failed_at=utc_now(), error=f'{type(error).__name__}: {error}')
        atomic_json(output / 'workflow_status.json', status)
        (output / 'workflow_error.txt').write_text(traceback.format_exc(), encoding='utf-8')
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--steps', type=int, default=100000)
    parser.add_argument('--label', required=True)
    args = parser.parse_args()
    print(json.dumps(run_trial(args.config, args.output, args.steps, args.label), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
