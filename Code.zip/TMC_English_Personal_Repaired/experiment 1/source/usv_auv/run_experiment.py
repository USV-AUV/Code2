"""One bounded foreground workflow: train, preserve milestones, then compare.

Launch this process detached to let training run while the assistant is idle.
This module never retries or changes learning settings after a failed run.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path, payload):
    path=Path(path)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(payload,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    os.replace(temporary,path)


@contextmanager
def keep_system_awake():
    """Temporary Windows sleep inhibition; never changes saved power settings."""
    active=False
    if os.name=='nt':
        import ctypes
        active=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
    try:
        yield active
    finally:
        if active:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


def launch_child(command,output,status,stage,stem):
    stdout=output/f'{stem}.stdout.log';stderr=output/f'{stem}.stderr.log'
    child_environment=os.environ.copy()
    child_environment['PYTHONIOENCODING']='utf-8'
    with stdout.open('w',encoding='utf-8') as out,stderr.open('w',encoding='utf-8') as err:
        process=subprocess.Popen(command,stdout=out,stderr=err,env=child_environment,
                                 cwd=str(Path(__file__).resolve().parents[1]))
        status.update(stage=stage,child_pid=process.pid,stage_started_at=utc_now(),command=command,
                      stdout=str(stdout),stderr=str(stderr))
        atomic_json(output/'workflow_status.json',status)
        code=process.wait()  # Parent is idle, not a polling loop or an LLM task.
    status.update(child_exit_code=code,child_pid=None,stage_ended_at=utc_now())
    atomic_json(output/'workflow_status.json',status)
    if code!=0:
        raise RuntimeError(f'{stage} exited with {code}; inspect {stderr}')


def run(args):
    from .config import Config
    from .deploy import load_checkpoint
    import torch
    output=args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError('Use a new empty output directory; this workflow never overwrites an existing run')
    if not 0<args.early_step<args.steps:
        raise ValueError('Require 0 < early_step < total training steps')
    if args.eval_episodes<2 or args.eval_steps<1 or args.eval_seed<=args.steps+args.seed:
        raise ValueError('Use >=2 evaluation seeds in a range disjoint from possible training episode seeds')
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable. Formal training is not allowed to fall back to CPU')
    cfg=Config.load(args.config)
    if cfg.seed!=args.seed:
        raise ValueError('Keep training seed explicit and identical to configuration for this run')
    output.mkdir(parents=True,exist_ok=True)
    cfg.save(output/'frozen_config.json')
    source_root=Path(__file__).resolve().parent
    sources={str(p.relative_to(source_root)):hashlib.sha256(p.read_bytes()).hexdigest()
             for p in sorted(source_root.glob('*.py'))}
    atomic_json(output/'source_hashes.json',sources)
    status=dict(format='usv-auv-experiment-v1',workflow_pid=os.getpid(),stage='starting',
                started_at=utc_now(),output=str(output),total_steps=args.steps,early_step=args.early_step,
                config_fingerprint=cfg.fingerprint,python=sys.executable,torch=torch.__version__,
                cuda=torch.version.cuda,gpu=torch.cuda.get_device_name(0),seed=args.seed,
                evaluation=dict(seed_start=args.eval_seed,episodes=args.eval_episodes,steps=args.eval_steps),
                monitor_interval_seconds=1200,automatic_retry=False)
    atomic_json(output/'workflow_status.json',status)
    try:
        with keep_system_awake() as awake:
            status['temporary_system_sleep_inhibition']=awake
            command=[sys.executable,'-u','-m','usv_auv.train','--config',str(output/'frozen_config.json'),
                     '--output',str(output),'--steps',str(args.steps),'--device','cuda','--seed',str(args.seed),
                     '--milestones',str(args.early_step),str(args.steps),'--log-every','1000']
            launch_child(command,output,status,'training','train')
            early=output/'milestones'/f'step_{args.early_step:07d}'/'policy.pt'
            late=output/'milestones'/f'step_{args.steps:07d}'/'policy.pt'
            for expected,path in ((args.early_step,early),(args.steps,late)):
                saved=load_checkpoint(path)
                if saved.get('global_step')!=expected or saved.get('config_fingerprint')!=cfg.fingerprint:
                    raise RuntimeError(f'Milestone provenance mismatch: {path}')
            summary=json.loads((output/'summary.json').read_text(encoding='utf-8'))
            if summary['global_step']!=args.steps or not all(n>0 for n in summary['td3_updates']) or summary['ddqn_updates']<=0:
                raise RuntimeError('Training stopped at wrong step or either learner did not update')
            status['training_summary']=summary
            status['milestone_paths']={'early':str(early),'late':str(late)}
            command=[sys.executable,'-u','-m','usv_auv.compare_checkpoints','--early',str(early),'--late',str(late),
                     '--output',str(output/'comparison'),'--episodes',str(args.eval_episodes),
                     '--steps',str(args.eval_steps),'--seed',str(args.eval_seed),'--device','cuda']
            launch_child(command,output,status,'comparing','comparison')
        comparison=output/'comparison'/'comparison.json'
        if not comparison.is_file():
            raise RuntimeError('Comparison process exited without comparison.json')
        status.update(stage='complete',completed_at=utc_now(),comparison_json=str(comparison),child_pid=None)
        atomic_json(output/'workflow_status.json',status)
        print(json.dumps(status,ensure_ascii=False),flush=True)
        return status
    except BaseException as error:
        status.update(stage='failed',failed_at=utc_now(),error=f'{type(error).__name__}: {error}')
        atomic_json(output/'workflow_status.json',status)
        (output/'workflow_error.txt').write_text(traceback.format_exc(),encoding='utf-8')
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=Path('configs/research.json'))
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--steps',type=int,default=1_000_000)
    parser.add_argument('--early-step',type=int,default=450_000)
    parser.add_argument('--seed',type=int,default=7)
    parser.add_argument('--eval-episodes',type=int,default=30)
    parser.add_argument('--eval-steps',type=int,default=1200)
    parser.add_argument('--eval-seed',type=int,default=9_000_000)
    run(parser.parse_args())


if __name__=='__main__':main()
