"""Finite-candidate USV planning from received observations only.

This module has no environment or truth-state argument.  Link success and FIM
are planning approximations at predicted positions, not received measurements
or guarantees of connectivity.  Every candidate satisfies a USV speed bound;
the environment must still move toward the returned target over physical time.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Mapping, Sequence

import numpy as np


def _xy(value: Sequence[float] | np.ndarray, name: str) -> np.ndarray:
    array = np.array(value, dtype=float, copy=True)
    if array.shape != (2,) or not np.all(np.isfinite(array)):
        raise ValueError(f"{name} must be a finite two-vector")
    return array


def usbl_position_fim(
    auv_xy: Sequence[float],
    usv_xy: Sequence[float],
    depth: float,
    range_sigma: float,
    bearing_sigma: float,
) -> np.ndarray:
    """Known-depth horizontal FIM for a local range-plus-direction model.

    ``range_sigma`` is in metres. ``bearing_sigma`` is the small-angle standard
    deviation, in radians, in each of the two orthogonal tangent directions of
    the 3-D acoustic unit direction.  This is not a horizontal-azimuth-only
    sensor.  The model remains finite directly above an AUV of positive depth.

    The simulator uses this same geometry to generate a locally linearized XY
    fix with covariance FIM^-1; the planner uses it only for *expected* direct
    measurements.  It is not an exact nonlinear acoustic localization solver.
    """
    auv, usv = _xy(auv_xy, "auv_xy"), _xy(usv_xy, "usv_xy")
    if not math.isfinite(depth) or depth < 0:
        raise ValueError("depth must be finite and nonnegative")
    for name, value in (("range_sigma", range_sigma), ("bearing_sigma", bearing_sigma)):
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be finite and positive")
    horizontal = auv - usv
    r_squared = max(float(np.dot(horizontal, horizontal) + depth ** 2), 1.0e-8)
    horizontal_unit = horizontal / math.sqrt(r_squared)
    radial = np.outer(horizontal_unit, horizontal_unit)
    information = radial / range_sigma ** 2
    information += (np.eye(2) - radial) / (bearing_sigma ** 2 * r_squared)
    return 0.5 * (information + information.T)


def sample_usbl_fix(
    auv_xy: Sequence[float],
    usv_xy: Sequence[float],
    depth: float,
    range_sigma: float,
    bearing_sigma: float,
    rng: np.random.Generator,
) -> np.ndarray:
    """Generate a physical local-linearization fix at its measurement time.

    This function belongs to the sensor simulation, never to actor inputs.
    Draw XY noise with the inverse of :func:`usbl_position_fim`, without
    clipping the noisy fix back into the operational area.  Delivery latency
    and source timestamps are handled by the packet layer.

    ``range_sigma == 0`` explicitly disables *all* localization noise for
    deterministic integration tests.  It is not the physical limiting case of
    exact range with noisy bearings.  Positive range_sigma uses the common
    FIM model, and bearing_sigma must then be strictly positive.
    """
    position = _xy(auv_xy, "auv_xy")
    _xy(usv_xy, "usv_xy")
    if not math.isfinite(depth) or depth < 0:
        raise ValueError("depth must be finite and nonnegative")
    if not math.isfinite(range_sigma) or range_sigma < 0:
        raise ValueError("range_sigma must be finite and nonnegative")
    if not math.isfinite(bearing_sigma) or bearing_sigma < 0:
        raise ValueError("bearing_sigma must be finite and nonnegative")
    if range_sigma == 0:
        return position
    information = usbl_position_fim(position, usv_xy, depth, range_sigma, bearing_sigma)
    eigenvalues, eigenvectors = np.linalg.eigh(information)
    # Numerical floor only; ordinary finite known-depth geometries are SPD.
    eigenvalues = np.maximum(eigenvalues, 1e-12)
    noise = eigenvectors @ (rng.normal(size=2) / np.sqrt(eigenvalues))
    return position + noise


@dataclass(frozen=True)
class ReceivedState:
    """A source-timestamped state that has already arrived at the USV.

    ``velocity`` is the water-relative action fixed at ``source_time``.  The
    disturbance can be held during a missing sample; use ``disturbance_valid``
    for whether an initialized estimate is available, and ``disturbance_age``
    to describe how old its last valid motion measurement is.
    """

    node_id: int
    position: Sequence[float]
    velocity: Sequence[float]
    disturbance: Sequence[float]
    source_time: float
    disturbance_valid: bool = True
    disturbance_age: float = 0.0
    uncertainty: float = 0.0
    task_weight: float = 1.0
    localization_available: bool = True

    def __post_init__(self) -> None:
        for field_name in ("position", "velocity", "disturbance"):
            value = _xy(getattr(self, field_name), field_name)
            value.flags.writeable = False
            object.__setattr__(self, field_name, value)
        if not math.isfinite(self.source_time):
            raise ValueError("source_time must be finite")
        for field_name in ("disturbance_age", "uncertainty", "task_weight"):
            value = getattr(self, field_name)
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"{field_name} must be finite and nonnegative")

    def to_dict(self) -> dict:
        result = asdict(self)
        for name in ("position", "velocity", "disturbance"):
            result[name] = result[name].tolist()
        return result


@dataclass(frozen=True)
class ObservedLink:
    """A directed link report already received by the USV.

    The probability is an observed/estimated success fraction, not a true
    failure mask.  ``delay`` is a one-way reported delay in seconds, including
    any declared transmission/queuing overhead.  A reference distance, when
    available, is the distance estimate associated with that report.
    """

    source: int
    target: int
    success_probability: float
    delay: float
    report_time: float
    reference_distance: float | None = None

    def __post_init__(self) -> None:
        if not math.isfinite(self.success_probability) or not 0 <= self.success_probability <= 1:
            raise ValueError("success_probability must be in [0, 1]")
        if not math.isfinite(self.delay) or self.delay < 0:
            raise ValueError("delay must be finite and nonnegative")
        if not math.isfinite(self.report_time):
            raise ValueError("report_time must be finite")
        if self.reference_distance is not None:
            if not math.isfinite(self.reference_distance) or self.reference_distance < 0:
                raise ValueError("reference_distance must be finite and nonnegative")

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class PlannerConfig:
    root_id: int = 0
    bounds: tuple[tuple[float, float], tuple[float, float]] = ((0.0, 200.0), (0.0, 200.0))
    usv_max_speed: float = 1.5
    auv_depth: float = 70.0
    candidate_rings: int = 2
    candidate_angles: int = 16
    max_hops: int = 2
    localization_weight: float = 1.0
    route_weight: float = 1.0
    movement_weight: float = 0.1
    movement_scale: float = 100.0
    information_scale: float = 1.0
    age_scale: float = 20.0
    route_delay_cap: float = 60.0
    link_report_ttl: float = 30.0
    max_state_age: float = 120.0
    max_prediction_time: float = 60.0
    uncertainty_growth: float = 0.2
    distance_scale: float = 100.0
    sound_speed: float = 1500.0
    relay_delay: float = 0.02
    range_sigma: float = 1.0
    bearing_sigma: float = math.radians(2.0)

    def __post_init__(self) -> None:
        for name in (
            "movement_scale", "information_scale", "age_scale", "route_delay_cap",
            "link_report_ttl", "max_state_age", "max_prediction_time", "distance_scale",
            "sound_speed", "range_sigma", "bearing_sigma",
        ):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) <= 0:
                raise ValueError(f"{name} must be finite and positive")
        for name in (
            "usv_max_speed", "auv_depth", "localization_weight", "route_weight", "movement_weight",
            "uncertainty_growth", "relay_delay",
        ):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) < 0:
                raise ValueError(f"{name} must be finite and nonnegative")
        for name in ("candidate_rings", "candidate_angles", "max_hops"):
            value = getattr(self, name)
            if not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if len(self.bounds) != 2 or any(
            len(bound) != 2 or not all(math.isfinite(v) for v in bound) or bound[0] >= bound[1]
            for bound in self.bounds
        ):
            raise ValueError("bounds must contain two finite increasing pairs")

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class PlanResult:
    target: np.ndarray
    score: float
    components: Mapping[str, float]
    predicted_positions: Mapping[int, np.ndarray]
    candidates: np.ndarray
    candidate_scores: np.ndarray

    def to_dict(self) -> dict:
        return {
            "target": self.target.tolist(), "score": self.score,
            "components": dict(self.components),
            "predicted_positions": {str(node): point.tolist() for node, point in self.predicted_positions.items()},
            "candidates": self.candidates.tolist(),
            "candidate_scores": self.candidate_scores.tolist(),
        }


def reachable_candidates(
    current_position: Sequence[float], horizon: float, config: PlannerConfig
) -> np.ndarray:
    """Deterministic equal-budget candidate set, including staying in place."""
    current = _xy(current_position, "current_position")
    if not math.isfinite(horizon) or horizon <= 0:
        raise ValueError("horizon must be finite and positive")
    lower = np.array([b[0] for b in config.bounds])
    upper = np.array([b[1] for b in config.bounds])
    if np.any(current < lower) or np.any(current > upper):
        raise ValueError("current_position lies outside planner bounds")
    radius = horizon * config.usv_max_speed
    result = [current.copy()]
    seen = {tuple(np.round(current, 12))}
    for ring in range(1, config.candidate_rings + 1):
        for index in range(config.candidate_angles):
            angle = 2 * math.pi * index / config.candidate_angles
            point = current + radius * ring / config.candidate_rings * np.array(
                [math.cos(angle), math.sin(angle)]
            )
            # Projection onto a box containing the current point cannot make
            # the distance from that point exceed the reachable radius.
            point = np.clip(point, lower, upper)
            key = tuple(np.round(point, 12))
            if key not in seen:
                result.append(point)
                seen.add(key)
    return np.array(result)


def _tree_path(node: int, parents: Mapping[int, int], config: PlannerConfig) -> list[tuple[int, int]] | None:
    path: list[tuple[int, int]] = []
    visited: set[int] = set()
    current = node
    while current != config.root_id:
        if current in visited or current not in parents or len(path) >= config.max_hops:
            return None
        visited.add(current)
        parent = parents[current]
        path.append((current, parent))
        current = parent
    return path


def plan_usv(
    current_position: Sequence[float],
    now: float,
    horizon: float,
    states: Sequence[ReceivedState] | Mapping[int, ReceivedState],
    links: Sequence[ObservedLink] | Mapping[tuple[int, int], ObservedLink],
    parents: Mapping[int, int],
    config: PlannerConfig | None = None,
) -> PlanResult:
    """Minimize a normalized finite-candidate objective using received data.

    ``parents`` must be the USV's acknowledged active route, not the policy's
    requested but uninstalled route.  Future-timestamped and expired reports
    are treated as unavailable.  Staleness/uncertainty attenuation is a fixed
    conservative scoring model, not a statistically calibrated confidence.
    """
    config = config or PlannerConfig()
    if not math.isfinite(now):
        raise ValueError("now must be finite")
    current = _xy(current_position, "current_position")
    candidates = reachable_candidates(current, horizon, config)
    state_values = states.values() if isinstance(states, Mapping) else states
    received: dict[int, ReceivedState] = {}
    for state in state_values:
        if 0 <= now - state.source_time <= config.max_state_age and state.node_id != config.root_id:
            previous = received.get(state.node_id)
            if previous is None or previous.source_time < state.source_time:
                received[state.node_id] = state
    link_values = links.values() if isinstance(links, Mapping) else links
    reports: dict[tuple[int, int], ObservedLink] = {}
    for link in link_values:
        if 0 <= now - link.report_time <= config.link_report_ttl:
            key = (link.source, link.target)
            previous = reports.get(key)
            if previous is None or previous.report_time < link.report_time:
                reports[key] = link

    predicted: dict[int, np.ndarray] = {}
    uncertainty: dict[int, float] = {}
    for node, state in received.items():
        age = now + horizon - state.source_time
        used_time = min(age, config.max_prediction_time)
        drift = np.asarray(state.disturbance) if state.disturbance_valid else np.zeros(2)
        predicted[node] = np.asarray(state.position) + used_time * (np.asarray(state.velocity) + drift)
        # Keep growing the uncertainty after capping extrapolation time.
        uncertainty[node] = state.uncertainty + config.uncertainty_growth * (age + state.disturbance_age)

    def point3(node: int, root_position: np.ndarray) -> np.ndarray | None:
        if node == config.root_id:
            return np.array([root_position[0], root_position[1], 0.0])
        if node not in predicted:
            return None
        return np.array([predicted[node][0], predicted[node][1], -config.auv_depth])

    def edge_score(source: int, target: int, root_position: np.ndarray) -> tuple[float, float]:
        report = reports.get((source, target))
        left, right = point3(source, root_position), point3(target, root_position)
        if report is None or left is None or right is None:
            return 0.0, config.route_delay_cap
        distance = float(np.linalg.norm(left - right))
        if report.reference_distance is None:
            ref_left, ref_right = point3(source, current), point3(target, current)
            reference = float(np.linalg.norm(ref_left - ref_right))
        else:
            reference = report.reference_distance
        exponent = np.clip((reference - distance) / config.distance_scale, -50.0, 50.0)
        geometry_success = min(1.0, report.success_probability * math.exp(float(exponent)))
        report_age = now - report.report_time
        stale_factor = math.exp(-report_age / config.link_report_ttl)
        state_factor = math.exp(
            -(uncertainty.get(source, 0.0) + uncertainty.get(target, 0.0)) / config.distance_scale
        )
        probability = geometry_success * stale_factor * state_factor
        delay = np.clip(report.delay + (distance - reference) / config.sound_speed, 0.0, config.route_delay_cap)
        return float(probability), float(delay)

    nodes = sorted(set(parents) | set(received))
    nodes = [node for node in nodes if node != config.root_id]
    weights = {node: received[node].task_weight if node in received else 1.0 for node in nodes}
    total_weight = max(sum(weights.values()), 1.0e-12)

    def evaluate(candidate: np.ndarray) -> tuple[float, dict[str, float]]:
        localization = 0.0
        route = 0.0
        for node in nodes:
            weight = weights[node] / total_weight
            path = _tree_path(node, parents, config)
            if path is None:
                route += weight * (1.0 + config.route_delay_cap / config.age_scale)
            else:
                p_up, p_down = 1.0, 1.0
                delay_up, delay_down = 0.0, 0.0
                for child, parent in path:
                    success, delay = edge_score(child, parent, candidate)
                    p_up *= success
                    delay_up += delay
                    success, delay = edge_score(parent, child, candidate)
                    p_down *= success
                    delay_down += delay
                relay_time = max(len(path) - 1, 0) * config.relay_delay
                if p_up <= 0.0:
                    delay_up = config.route_delay_cap
                if p_down <= 0.0:
                    delay_down = config.route_delay_cap
                mean_delay = 0.5 * (
                    min(delay_up + relay_time, config.route_delay_cap)
                    + min(delay_down + relay_time, config.route_delay_cap)
                )
                route += weight * (1.0 - 0.5 * (p_up + p_down) + mean_delay / config.age_scale)

            state = received.get(node)
            if state is None or not state.localization_available:
                continue
            # A relayed position packet adds no direct localization Fisher
            # information.  Only an explicit opportunity and both direct
            # acoustic directions can contribute an anticipated measurement.
            p_up, _ = edge_score(node, config.root_id, candidate)
            p_down, _ = edge_score(config.root_id, node, candidate)
            if p_up <= 0.0 or p_down <= 0.0:
                continue
            fim = usbl_position_fim(
                predicted[node], candidate, config.auv_depth,
                config.range_sigma, config.bearing_sigma,
            )
            expected_fim = p_up * p_down * fim
            _, logdet = np.linalg.slogdet(np.eye(2) + expected_fim / config.information_scale)
            localization -= weight * float(logdet)
        movement = float(np.sum((candidate - current) ** 2)) / config.movement_scale ** 2
        components = {"localization": localization, "route": route, "movement": movement}
        score = (
            config.localization_weight * localization
            + config.route_weight * route
            + config.movement_weight * movement
        )
        return float(score), components

    evaluated = [evaluate(candidate) for candidate in candidates]
    scores = np.array([item[0] for item in evaluated])
    best = int(np.argmin(scores))
    return PlanResult(
        candidates[best].copy(), float(scores[best]), evaluated[best][1],
        {node: position.copy() for node, position in predicted.items()}, candidates.copy(), scores,
    )
