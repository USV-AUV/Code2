"""Single, validated configuration shared by training, evaluation and inference."""
from dataclasses import asdict, dataclass, fields
import hashlib
import json
import math
from pathlib import Path


@dataclass
class Config:
    seed: int = 7
    n_auv: int = 2
    n_sensors: int = 30
    area_size: float = 200.0
    auv_depth: float = 70.0
    sensor_depth: float = 100.0
    dt: float = 1.0
    substeps: int = 10
    slow_period: int = 5
    episode_steps: int = 1200
    max_speed: float = 2.2
    # Policy coordinates only: neither option changes physical speed authority.
    action_frame: str = 'global'
    # Local grant-aware service protocol. Physical slots/PER/ACK remain unchanged.
    service_grant_aware: bool = False
    usv_speed: float = 1.0
    min_separation: float = 3.0
    collection_radius: float = 6.0
    # Synthetic smooth current. No white-noise physical acceleration.
    current_x: float = 0.20
    current_y: float = 0.04
    current_amplitude: float = 0.10
    current_period: float = 120.0
    vortex_speed: float = 0.12
    vortex_radius: float = 40.0
    displacement_sigma: float = 0.025
    displacement_dropout: float = 0.01
    initial_position_sigma: float = 0.5
    usbl_sigma: float = 0.7
    usbl_bearing_sigma: float = math.radians(2.0)
    usde_kappa: float = 5.0
    navigation_history_seconds: float = 600.0
    # Bits, seconds, metres, watts and joules only.
    data_packet_bits: int = 2048
    data_header_bits: int = 256
    buffer_packets: int = 80
    initial_packets: int = 4
    arrival_rate: float = 0.002
    service_ack_timeout: float = 80.0
    grant_ttl: float = 100.0
    target_min_dwell: float = 30.0
    target_max_dwell: float = 300.0
    slot_duration: float = 0.6
    tdma_sensors_per_group: int = 3
    sound_speed: float = 1500.0
    guard_time: float = 0.04
    processing_delay: float = 0.02
    bit_rate: float = 16000.0
    bandwidth_hz: float = 8000.0
    snr_db_at_100m: float = 18.0
    spreading_db: float = 15.0
    absorption_db_per_km: float = 4.0
    base_per: float = 0.015
    burst_bad_per: float = 0.70
    burst_good_to_bad: float = 0.003
    burst_bad_to_good: float = 0.2
    link_range: float = 350.0
    hello_period: float = 20.0
    report_ttl: float = 90.0
    state_period: float = 5.0
    state_ttl: float = 90.0
    config_timeout: float = 100.0
    route_lease: float = 300.0
    switch_dwell: float = 15.0
    max_retries: int = 3
    queue_limit: int = 128
    control_packet_bits: int = 512
    state_packet_bits: int = 1536
    # Explicit endpoint outages. JSON may override this entire list.
    faults: list | None = None
    propulsion_idle_w: float = 12.0
    propulsion_c2: float = 2.0
    propulsion_c3: float = 1.0
    usv_idle_w: float = 15.0
    tx_power_w: float = 5.0
    rx_power_w: float = 1.0
    listen_power_w: float = 0.05
    reward_data_scale: float = 2048.0
    reward_overflow_scale: float = 2048.0
    reward_energy_scale: float = 100.0
    reward_age_scale: float = 120.0
    reward_data_weight: float = 1.0
    reward_overflow_weight: float = 2.0
    reward_energy_weight: float = 0.03
    reward_age_weight: float = 0.02
    reward_safety_weight: float = 5.0
    reward_progress_weight: float = 0.25
    gamma: float = 0.99
    hidden_dim: int = 128
    batch_size: int = 64
    replay_size: int = 100000
    learning_rate: float = 0.0003
    tau: float = 0.005
    policy_delay: int = 2
    policy_noise: float = 0.2
    noise_clip: float = 0.5
    exploration_noise: float = 0.15
    warmup_steps: int = 1000
    td3_pretrain_steps: int = 5000
    topology_pretrain_steps: int = 3000
    alternating_block_steps: int = 5000
    checkpoint_interval: int = 10000

    def __post_init__(self):
        if self.faults is None:
            self.faults = [{"src": 0, "dst": 1, "start": 200.0, "end": 350.0, "bidirectional": True}]
        self.validate()

    def validate(self):
        if self.action_frame not in ('global', 'target'):
            raise ValueError('action_frame must be global or target')
        if type(self.service_grant_aware) is not bool:
            raise ValueError('service_grant_aware must be boolean')
        if type(self.n_auv) is not int or not 2 <= self.n_auv <= 4:
            raise ValueError("First implementation supports 2..4 AUVs")
        for name in ("n_sensors", "substeps", "slow_period", "episode_steps", "buffer_packets", "data_packet_bits", "hidden_dim", "batch_size", "replay_size", "queue_limit", "control_packet_bits", "state_packet_bits", "policy_delay", "alternating_block_steps", "checkpoint_interval", "tdma_sensors_per_group"):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        for name in ("area_size", "dt", "max_speed", "usv_speed", "current_period", "vortex_radius", "usde_kappa", "slot_duration", "sound_speed", "bit_rate", "bandwidth_hz", "report_ttl", "route_lease", "state_ttl", "config_timeout", "service_ack_timeout", "grant_ttl", "reward_data_scale", "reward_overflow_scale", "reward_energy_scale", "reward_age_scale"):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if not 0 < self.auv_depth < self.sensor_depth:
            raise ValueError("Need 0 < auv_depth < sensor_depth")
        if not 0 <= self.initial_packets <= self.buffer_packets:
            raise ValueError("initial_packets must fit the buffer")
        for name in ("base_per", "burst_bad_per", "burst_good_to_bad", "burst_bad_to_good", "displacement_dropout"):
            if not 0 <= getattr(self, name) <= 1:
                raise ValueError(f"{name} must be in [0,1]")
        for name in ("initial_packets", "seed", "max_retries", "warmup_steps", "td3_pretrain_steps", "topology_pretrain_steps", "data_header_bits"):
            if type(getattr(self,name)) is not int or getattr(self,name)<0:
                raise ValueError(f"{name} must be a nonnegative integer")
        for name in ("arrival_rate", "displacement_sigma", "initial_position_sigma", "usbl_sigma", "usbl_bearing_sigma", "guard_time", "processing_delay", "min_separation", "propulsion_idle_w", "propulsion_c2", "propulsion_c3", "usv_idle_w", "tx_power_w", "rx_power_w", "listen_power_w", "switch_dwell", "target_min_dwell", "policy_noise", "noise_clip", "exploration_noise"):
            if not math.isfinite(getattr(self,name)) or getattr(self,name)<0:
                raise ValueError(f"{name} must be finite and nonnegative")
        for name in ("collection_radius", "hello_period", "state_period", "navigation_history_seconds", "learning_rate", "link_range", "target_max_dwell"):
            if not math.isfinite(getattr(self,name)) or getattr(self,name)<=0:
                raise ValueError(f"{name} must be finite and positive")
        if self.target_max_dwell < self.target_min_dwell:
            raise ValueError('target_max_dwell must be at least target_min_dwell')
        for name in ("current_x", "current_y", "current_amplitude", "vortex_speed", "snr_db_at_100m", "spreading_db", "absorption_db_per_km"):
            if not math.isfinite(getattr(self,name)):
                raise ValueError(f"{name} must be finite")
        for name in ("reward_data_weight", "reward_overflow_weight", "reward_energy_weight", "reward_age_weight", "reward_safety_weight", "reward_progress_weight"):
            if not math.isfinite(getattr(self,name)) or getattr(self,name)<0:
                raise ValueError(f"{name} must be finite and nonnegative")
        if not 0 < self.gamma <= 1 or not 0 < self.tau <= 1:
            raise ValueError("Invalid discount or target update rate")
        max_distance = math.sqrt(2*self.area_size**2+self.sensor_depth**2)
        max_bits = max(self.data_packet_bits+self.data_header_bits, self.state_packet_bits, self.control_packet_bits)
        # Header + fixed-width state records and discovery metadata must fit.
        if max_bits < max(8*(40+48*self.n_auv),128+64*2*self.n_auv):
            raise ValueError("Declared packet limit cannot carry COORD/discovery schema")
        bound = max_bits/self.bit_rate+max_distance/self.sound_speed+self.guard_time+self.processing_delay
        if self.slot_duration < bound:
            raise ValueError(f"slot_duration must be at least {bound:.4f}s for declared packets/rate/geometry")
        for fault in self.faults:
            if not {"src", "dst", "start", "end"} <= fault.keys() or fault["end"] <= fault["start"]:
                raise ValueError("Each fault needs src,dst,start,end and end>start")
            if any(type(fault[k]) is not int or not 0<=fault[k]<1+self.n_auv+self.n_sensors for k in ('src','dst')) or fault['src']==fault['dst']:
                raise ValueError("Fault endpoints must be distinct physical node IDs")
            if not all(math.isfinite(fault[k]) and fault[k]>=0 for k in ('start','end')):
                raise ValueError("Fault times must be finite and nonnegative")

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        unknown = set(data)-{f.name for f in fields(cls)}
        if unknown:
            raise ValueError(f"Unknown configuration fields: {sorted(unknown)}")
        return cls(**data)

    @classmethod
    def load(cls, path=None):
        return cls() if path is None else cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))

    def save(self, path):
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")

    @property
    def fingerprint(self):
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True).encode()).hexdigest()[:16]
