"""Explicitly authorized recovery of a failed run, then frozen comparison.

The stored target is a TOTAL global-step budget. Earlier evidence and the
recovery checkpoint are copied before any live status or latest model changes.
There is no retry loop, hyperparameter override, or physical-state fabrication.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys
import traceback
import uuid

from .run_experiment import atomic_json, keep_system_awake, launch_child, utc_now


def recovery_plan(checkpoint, previous, cfg):
    if previous.get('stage') != 'failed':
        raise ValueError('Only an explicitly stopped, failed workflow may be resumed')
    if checkpoint.get('format') != 'usv-auv-topology-usde-training-v1':
        raise ValueError('Recovery requires a complete training checkpoint')
    if checkpoint['environment_config'] != cfg.to_dict():
        raise ValueError('The frozen environment and checkpoint differ')
    if any(item.get('config_fingerprint') != cfg.fingerprint for item in (checkpoint, previous)):
        raise ValueError('Configuration fingerprint differs')
    if checkpoint['seed'] != previous['seed'] or checkpoint['seed'] != cfg.seed:
        raise ValueError('Training seed differs')
    if not checkpoint.get('run_id'):
        raise ValueError('Missing original training run identity')
    start, target, early = checkpoint['global_step'], previous['total_steps'], previous['early_step']
    if any(type(n) is not int for n in (start, target, early)) or not 0 < early <= start < target:
        raise ValueError('Require 0 < preserved early step <= recovery step < original total target')
    if early not in checkpoint['milestones'] or target not in checkpoint['milestones']:
        raise ValueError('Recovery may not invent or change the stored milestone plan')
    return dict(start_step=start, target_step=target, early_step=early,
                additional_steps=target-start, run_id=checkpoint['run_id'])


def resume(output: Path):
    import torch
    from .config import Config
    from .deploy import load_checkpoint
    from .train import file_digest, milestone_identity, milestone_path, validate_milestone

    output = Path(output).resolve()
    previous = json.loads((output/'workflow_status.json').read_text(encoding='utf-8'))
    cfg = Config.load(output/'frozen_config.json')
    checkpoint_path = output/'checkpoint_latest.pt'
    checkpoint = load_checkpoint(checkpoint_path)
    plan = recovery_plan(checkpoint, previous, cfg)
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; recovery must not fall back to CPU')
    if (output/'comparison').exists() or milestone_path(output, plan['target_step']).exists():
        raise ValueError('Final milestone/comparison already exists; refusing to overwrite it')
    # Validate every already-past immutable checkpoint, including the 450k model.
    for step in checkpoint['milestones']:
        if step <= plan['start_step']:
            validate_milestone(milestone_path(output, step),
                               milestone_identity({**checkpoint, 'global_step': step}))
    early_dir = milestone_path(output, plan['early_step'])
    early_files = {name:file_digest(early_dir/name) for name in ('checkpoint.pt','policy.pt','metadata.json')}
    recovery_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]
    archive = output/'recovery'/recovery_id
    archive.mkdir(parents=True, exist_ok=False)
    before = archive/'before'; before.mkdir()
    for source in output.iterdir():
        if source.is_file():
            shutil.copy2(source, before/source.name)
    preserved_checkpoint = before/'checkpoint_latest.pt'
    if file_digest(preserved_checkpoint) != file_digest(checkpoint_path):
        raise RuntimeError('Recovery checkpoint copy failed verification')
    source_root = Path(__file__).resolve().parent
    sources = {p.name:file_digest(p)['sha256'] for p in sorted(source_root.glob('*.py'))}
    original_sources = json.loads((output/'source_hashes.json').read_text(encoding='utf-8'))
    failed_progress = json.loads((before/'progress.json').read_text(encoding='utf-8'))
    recovery = dict(plan, recovery_id=recovery_id, authorized_reason='USV floating-point boundary repair',
                    archived_at=utc_now(), archive=str(archive), checkpoint=str(preserved_checkpoint),
                    checkpoint_digest=file_digest(preserved_checkpoint), early_files=early_files,
                    failed_global_step=failed_progress['global_step'],
                    discarded_unsaved_steps=max(0,failed_progress['global_step']-plan['start_step']),
                    physical_resume='new episode; learning/optimizer/RNG state restored',
                    source_sha256=sources, original_source_sha256=original_sources,
                    changed_source_files=[name for name,value in sources.items() if original_sources.get(name)!=value],
                    evaluation_note='Both frozen milestones evaluated with the same repaired code and original configuration.')
    atomic_json(archive/'recovery_manifest.json', recovery)
    status = {key:previous[key] for key in ('format','started_at','total_steps','early_step','config_fingerprint',
                                           'seed','evaluation','monitor_interval_seconds')}
    status.update(stage='starting', workflow_pid=os.getpid(), child_pid=None, output=str(output),
                  python=sys.executable, torch=torch.__version__, cuda=torch.version.cuda,
                  gpu=torch.cuda.get_device_name(0), run_id=plan['run_id'], resumed_at=utc_now(),
                  recovery_manifest=str(archive/'recovery_manifest.json'), resume_from_step=plan['start_step'],
                  additional_steps=plan['additional_steps'], automatic_retry=False)
    atomic_json(output/'workflow_status.json', status)
    try:
        with (output/'training.jsonl').open('a', encoding='utf-8') as log:
            log.write(json.dumps(dict(event='authorized_recovery', **recovery),ensure_ascii=False)+'\n')
        with keep_system_awake() as awake:
            status['temporary_system_sleep_inhibition'] = awake
            command = [sys.executable,'-u','-m','usv_auv.train','--resume',str(preserved_checkpoint),
                       '--config',str(output/'frozen_config.json'),'--output',str(output),
                       '--steps',str(plan['additional_steps']),'--device','cuda',
                       '--milestones',str(plan['early_step']),str(plan['target_step']),'--log-every','1000']
            launch_child(command,output,status,'training','train_resume_'+recovery_id)
            summary = json.loads((output/'summary.json').read_text(encoding='utf-8'))
            if summary['global_step'] != plan['target_step'] or not all(n>0 for n in summary['td3_updates']) or summary['ddqn_updates']<=0:
                raise RuntimeError('Training stopped at the wrong step or a learner did not update')
            if any(file_digest(early_dir/name)!=digest for name,digest in early_files.items()):
                raise RuntimeError('Preserved early milestone changed during recovery')
            final = load_checkpoint(output/'checkpoint_latest.pt')
            if final['global_step'] != plan['target_step'] or final['run_id'] != plan['run_id']:
                raise RuntimeError('Final training checkpoint has incorrect step/run identity')
            late_dir = milestone_path(output, plan['target_step'])
            validate_milestone(late_dir, milestone_identity(final))
            status['training_summary'] = summary
            status['milestone_paths'] = dict(early=str(early_dir/'policy.pt'),late=str(late_dir/'policy.pt'))
            evaluation = status['evaluation']
            command = [sys.executable,'-u','-m','usv_auv.compare_checkpoints',
                       '--early',str(early_dir/'policy.pt'),'--late',str(late_dir/'policy.pt'),
                       '--output',str(output/'comparison'),'--episodes',str(evaluation['episodes']),
                       '--steps',str(evaluation['steps']),'--seed',str(evaluation['seed_start']),'--device','cuda']
            launch_child(command,output,status,'comparing','comparison_resume_'+recovery_id)
        comparison = output/'comparison'/'comparison.json'
        if not comparison.is_file():
            raise RuntimeError('Comparison finished without its report')
        status.update(stage='complete',completed_at=utc_now(),comparison_json=str(comparison),child_pid=None)
        atomic_json(output/'workflow_status.json',status)
        return status
    except BaseException as error:
        status.update(stage='failed',failed_at=utc_now(),error=f'{type(error).__name__}: {error}')
        atomic_json(output/'workflow_status.json',status)
        (output/'workflow_error.txt').write_text(traceback.format_exc(),encoding='utf-8')
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(resume(args.output),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
