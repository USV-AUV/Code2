"""Shared final water-relative velocity encoding for simulation and deployment.

The target frame is only a state-dependent angular coordinate system. Every
direction and speed in the original feasible disk remains available to TD3.
It neither tracks a reference nor subtracts any disturbance estimate.
"""
from __future__ import annotations

from typing import Any

import numpy as np


ACTION_ENCODINGS = {
    "global": "speed-world-heading-v1",
    "target": "speed-target-relative-heading-v1",
}


def action_encoding(action_frame: str = "global") -> str:
    if action_frame not in ACTION_ENCODINGS:
        raise ValueError("action_frame must be 'global' or 'target'")
    return ACTION_ENCODINGS[action_frame]


def normalized_action_schema(schema: dict[str, Any], action_frame: str | None = None) -> dict[str, Any]:
    """Legacy schema without a marker means global, never target-relative."""
    result = dict(schema)
    result.setdefault("action_encoding", ACTION_ENCODINGS["global"])
    if result["action_encoding"] not in ACTION_ENCODINGS.values():
        raise ValueError("Unknown checkpoint action_encoding")
    if action_frame is not None and result["action_encoding"] != action_encoding(action_frame):
        raise ValueError("Checkpoint action_encoding disagrees with its configuration")
    return result


def _maximum_speed(max_speed: float) -> float:
    result = float(max_speed)
    if not np.isfinite(result) or result <= 0:
        raise ValueError("max_speed must be finite and positive")
    return result


def target_bearings(observations: Any, n_auv: int) -> np.ndarray:
    """Use the target displacement that the actor actually saw at this tick.

    Fields 2:4 are target_dx/target_dy, scaled by the same positive area size.
    A zero displacement has a deterministic zero reference bearing. No true
    position, current estimate, live target lookup, or refreshed observation
    is accepted by this function.
    """
    if observations is None:
        raise ValueError("target-relative actions require the same-step actor observations")
    values = np.asarray(observations, dtype=float)
    if values.ndim != 2 or values.shape[0] != n_auv or values.shape[1] < 4 or not np.all(np.isfinite(values)):
        raise ValueError("target-relative actions require finite (n_auv, observation_dim>=4) observations")
    goal = values[:, 2:4]
    bearing = np.arctan2(goal[:, 1], goal[:, 0])
    return np.where(np.all(goal == 0., axis=1), 0., bearing)


def physical_commands(normalized_actions: Any, max_speed: float,
                      action_frame: str = "global", observations: Any = None) -> dict[str, np.ndarray]:
    """Decode raw TD3 actions; output is the final world-direction water velocity.

    Global: theta=pi*a_angle. Target: theta=bearing(observation)+pi*a_angle.
    Target angles may be outside [-pi,pi]; their sine/cosine define the same
    world direction. This avoids adding an unnecessary discontinuous wrap.
    """
    action_encoding(action_frame)
    maximum = _maximum_speed(max_speed)
    actions = np.asarray(normalized_actions, dtype=float)
    if actions.ndim != 2 or actions.shape[1] != 2 or not np.all(np.isfinite(actions)):
        raise ValueError("Actions must be a finite (n_auv,2) array")
    if np.any(np.abs(actions) > 1. + 1e-6):
        raise ValueError("Normalized action outside [-1,1]")
    actions = np.clip(actions, -1., 1.)
    speed = (actions[:, 0] + 1.) * .5 * maximum
    bearing = target_bearings(observations, len(actions)) if action_frame == "target" else 0.
    direction = bearing + np.pi * actions[:, 1]
    velocity = speed[:, None] * np.column_stack((np.cos(direction), np.sin(direction)))
    return {"speed_mps": speed, "direction_rad": direction,
            "relative_water_velocity_mps": velocity}


def decode_actions(normalized_actions: Any, max_speed: float,
                   action_frame: str = "global", observations: Any = None) -> np.ndarray:
    return physical_commands(normalized_actions, max_speed, action_frame, observations)["relative_water_velocity_mps"]


def encode_velocity(water_velocity: Any, max_speed: float,
                    action_frame: str = "global", observations: Any = None) -> np.ndarray:
    """Encode an already-final feasible water velocity, without compensation.

    This inverse is useful for explicit cross-frame adapters and tests. Zero
    speed has no direction; its canonical angular action is zero.
    """
    action_encoding(action_frame)
    maximum = _maximum_speed(max_speed)
    velocity = np.asarray(water_velocity, dtype=float)
    if velocity.ndim != 2 or velocity.shape[1] != 2 or not np.all(np.isfinite(velocity)):
        raise ValueError("water_velocity must be a finite (n_auv,2) array")
    speed = np.linalg.norm(velocity, axis=1)
    if np.any(speed > maximum * (1. + 1e-6)):
        raise ValueError("water_velocity exceeds max_speed")
    bearing = target_bearings(observations, len(velocity)) if action_frame == "target" else 0.
    relative = np.arctan2(velocity[:, 1], velocity[:, 0]) - bearing
    wrapped = (relative + np.pi) % (2. * np.pi) - np.pi
    angular_action = np.where(speed == 0., 0., wrapped / np.pi)
    return np.column_stack((2. * np.clip(speed / maximum, 0., 1.) - 1., angular_action))
