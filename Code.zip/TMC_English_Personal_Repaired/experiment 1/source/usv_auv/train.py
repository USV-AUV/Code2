"""Foreground training of the complete method. Default: 200 CUDA steps.

--steps is the number of additional environment steps in this invocation.
The phase schedule is fixed at the first invocation and preserved on resume.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass, fields
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import numpy as np
import torch

from .deploy import config_fingerprint, environment_schema, inference_payload, load_checkpoint
from .learning import (LearningConfig, MaskedDoubleDQN, TD3Agent, resolve_device,
                       restore_rng, rng_state, seed_all)


@dataclass
class PhaseSchedule:
    td3_curriculum_steps: int
    topology_only_steps: int
    alternating_block_steps: int

    def phase(self, step: int) -> str:
        if step < self.td3_curriculum_steps:
            return "td3_curriculum"
        boundary = self.td3_curriculum_steps + self.topology_only_steps
        if step < boundary:
            return "topology_only"
        block = (step - boundary) // self.alternating_block_steps
        return "alternate_td3" if block % 2 == 0 else "alternate_topology"


def store_completed_macro(duration: int, period: int, terminated: bool, truncated: bool) -> bool:
    """A truncated partial fixed macro has no subsequent decision-state value."""
    if not 1 <= duration <= period:
        raise ValueError("macro duration outside the fixed decision interval")
    if terminated or duration == period:
        return True
    if truncated:
        return False
    raise ValueError("the macro action has not completed")


def load_environment_config(path: Path | None = None, values: dict[str, Any] | None = None):
    from .config import Config
    data = values or {}
    if path is not None:
        data = json.loads(path.read_text(encoding="utf-8"))
    names = {field.name for field in fields(Config)}
    unknown = set(data) - names
    if unknown:
        raise ValueError(f"Unknown environment configuration fields: {sorted(unknown)}")
    return Config(**data)


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def atomic_save(payload: dict[str, Any], destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, destination)


def atomic_json(payload: dict[str, Any], destination: Path) -> None:
    """Publish a complete JSON document; never expose a partly written file."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(json_safe(payload), handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, destination)


def require_finite(name: str, value: Any) -> None:
    """Small observed arrays/scalars only, not a per-step model/replay scan."""
    if isinstance(value, dict):
        for key, item in value.items():
            require_finite(f"{name}.{key}", item)
        return
    finite = torch.isfinite(value).all().item() if isinstance(value, torch.Tensor) else np.isfinite(value).all()
    if not finite:
        raise FloatingPointError(f"non-finite {name}; training stopped before checkpoint publication")


def resolve_milestones(requested: list[int], previous: list[int] | None = None) -> list[int]:
    for values in (requested, previous or []):
        if any(type(value) is not int or value <= 0 for value in values):
            raise ValueError("--milestones must contain positive integer global steps")
        if len(values) != len(set(values)):
            raise ValueError("--milestones must not contain duplicate steps")
    return sorted(set(requested) | set(previous or []))


def milestone_path(output: Path, step: int) -> Path:
    if type(step) is not int or step <= 0:
        raise ValueError("milestone step must be a positive integer")
    return output / "milestones" / f"step_{step:07d}"


def milestone_identity(checkpoint: dict[str, Any]) -> dict[str, Any]:
    """Match immutable run/settings metadata before reusing a destination."""
    if checkpoint["config_fingerprint"] != config_fingerprint(checkpoint["environment_config"]):
        raise ValueError("Milestone environment fingerprint mismatch")
    return {"format": "usv-auv-topology-usde-milestone-v1",
            "global_step": checkpoint["global_step"],
            "config_fingerprint": checkpoint["config_fingerprint"],
            "learning_config": checkpoint["learning_config"],
            "observation_schema": checkpoint["observation_schema"],
            "schedule": checkpoint["schedule"], "seed": checkpoint["seed"],
            "run_id": checkpoint["run_id"], "warmup_steps": checkpoint["warmup_steps"],
            "action_noise": checkpoint["action_noise"]}


def file_digest(path: Path) -> dict[str, Any]:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def validate_milestone(destination: Path, identity: dict[str, Any]) -> dict[str, Any]:
    """Read-only verification: inconsistent/existing artifacts are never overwritten."""
    try:
        metadata = json.loads((destination / "metadata.json").read_text(encoding="utf-8"))
        if any(metadata.get(key) != json_safe(value) for key, value in identity.items()):
            raise ValueError("step, configuration, schema, or run identity differs")
        for name in ("checkpoint.pt", "policy.pt"):
            if metadata["files"][name] != file_digest(destination / name):
                raise ValueError(f"{name} checksum or size differs")
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"Refusing to overwrite inconsistent milestone {destination}: {exc}") from exc
    return metadata


def save_milestone(checkpoint: dict[str, Any], output: Path) -> Path:
    """Atomically publish full state, inference state and metadata as one bundle."""
    destination = milestone_path(output, checkpoint["global_step"])
    identity = milestone_identity(checkpoint)
    if destination.exists():
        validate_milestone(destination, identity)
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f".{destination.name}.", dir=destination.parent) as temporary:
        staging = Path(temporary)
        atomic_save(checkpoint, staging / "checkpoint.pt")
        atomic_save(inference_payload(checkpoint), staging / "policy.pt")
        metadata = {**identity, "training_stage": checkpoint.get("training_stage"),
                    "files": {name: file_digest(staging / name) for name in ("checkpoint.pt", "policy.pt")}}
        atomic_json(metadata, staging / "metadata.json")
        try:
            os.rename(staging, destination)
        except FileExistsError:
            validate_milestone(destination, identity)
    return destination


def train(args: argparse.Namespace) -> dict[str, Any]:
    from .environment import CooperativeEnv
    if args.steps < 1:
        raise ValueError("--steps must be positive")
    if args.log_every < 1:
        raise ValueError("--log-every must be positive")
    device = resolve_device(args.device)
    saved = load_checkpoint(args.resume) if args.resume else None
    if saved and saved.get("format") != "usv-auv-topology-usde-training-v1":
        raise ValueError("--resume requires a full training checkpoint, not an inference export")
    milestones = resolve_milestones(getattr(args, "milestones", []), saved.get("milestones", []) if saved else [])
    run_id = saved.get("run_id") if saved else None
    run_id = run_id or str(uuid.uuid4())
    cfg = load_environment_config(args.config, saved["environment_config"] if saved else None)
    if saved and asdict(cfg) != saved["environment_config"]:
        raise ValueError("Resume environment differs from checkpoint; start a separately named training run")
    learning = LearningConfig(**saved["learning_config"]) if saved else LearningConfig(
        hidden_dim=args.hidden_dim or cfg.hidden_dim, gamma=cfg.gamma, tau=cfg.tau,
        actor_lr=cfg.learning_rate, critic_lr=cfg.learning_rate, topology_lr=cfg.learning_rate,
        policy_noise=cfg.policy_noise, noise_clip=cfg.noise_clip, policy_delay=cfg.policy_delay,
        batch_size=args.batch_size or cfg.batch_size, topology_batch_size=args.topology_batch_size,
        replay_capacity=args.replay_capacity or cfg.replay_size, topology_capacity=args.topology_capacity)
    if learning.gamma != cfg.gamma:
        raise ValueError("Learning discount must match environment reward shaping discount")
    seed = int(saved["seed"]) if saved else (args.seed if args.seed is not None else cfg.seed)
    seed_all(seed)
    env = CooperativeEnv(cfg)
    episode = int(saved.get("episode", 0)) if saved else 0
    observations, initial_info = env.reset(seed=seed + episode)
    observations = np.asarray(observations, np.float32)
    require_finite("initial observations", observations)
    agents = [TD3Agent(observations.shape[1], 2, learning, str(device), seed + 101 * (i + 1))
              for i in range(observations.shape[0])]
    slow_state, slow_mask = env.slow_state()
    require_finite("initial slow observations", slow_state)
    topology = MaskedDoubleDQN(len(slow_state), env.network.n_actions, learning, str(device), seed + 10001)
    period = int(cfg.slow_period)
    if period < 1:
        raise ValueError("slow_period must be positive")
    schedule = PhaseSchedule(**saved["schedule"]) if saved else PhaseSchedule(
        args.td3_steps if args.td3_steps is not None else cfg.td3_pretrain_steps,
        args.topology_steps if args.topology_steps is not None else cfg.topology_pretrain_steps,
        args.alternating_block if args.alternating_block is not None else cfg.alternating_block_steps)
    if any(value < 1 or value % period for value in asdict(schedule).values()):
        raise ValueError("Phase durations must be positive multiples of slow_period")
    global_step = int(saved["global_step"]) if saved else 0
    slow_decisions = int(saved.get("slow_decisions", 0)) if saved else 0
    phase = schedule.phase(global_step)
    pending: dict[str, Any] | None = None
    episode_return = 0.0
    discarded_partial_macros = int(saved.get("discarded_partial_macros", 0)) if saved else 0
    resume_mode = "fresh"
    if saved:
        if saved.get("config_fingerprint") != config_fingerprint(asdict(cfg)):
            raise ValueError("Checkpoint configuration fingerprint mismatch")
        if saved.get("observation_schema") != environment_schema(env):
            raise ValueError("Resume observation schema or topology action ordering differs")
        for agent, state in zip(agents, saved["agents"]):
            agent.load_state_dict(state)
        if len(saved["agents"]) != len(agents):
            raise ValueError("AUV count mismatch")
        topology.load_state_dict(saved["topology"])
        if saved.get("environment_state") is not None and callable(getattr(env, "load_state_dict", None)):
            env.load_state_dict(saved["environment_state"])
            observations = np.asarray(saved["observations"], np.float32)
            pending = saved.get("pending_slow")
            episode_return = saved.get("episode_return", 0.0)
            phase = saved.get("training_stage", phase)
            resume_mode = "environment_snapshot"
        else:
            # Preserve learning progress but never connect a partial slow transition
            # from an old physical trajectory to a newly initialized episode.
            episode += 1
            observations, initial_info = env.reset(seed=seed + episode)
            observations = np.asarray(observations, np.float32)
            if saved.get("pending_slow") is not None:
                discarded_partial_macros += 1
            # Preserve the actually active phase so the next macro boundary
            # performs the same replay reset that an uninterrupted run would.
            phase = saved.get("training_stage", phase)
            resume_mode = "new_episode_learning_resume"
        restore_rng(saved["rng"])
    require_finite("resumed observations", observations)
    args.output.mkdir(parents=True, exist_ok=True)
    configured_warmup = args.warmup_steps if args.warmup_steps is not None else cfg.warmup_steps
    warmup = int(saved["warmup_steps"]) if saved else configured_warmup
    if warmup < 0:
        raise ValueError("warmup_steps must be nonnegative")
    action_noise = (args.action_noise if args.action_noise is not None else
                    saved.get("action_noise", cfg.exploration_noise) if saved else cfg.exploration_noise)
    checkpoint_every = args.checkpoint_every if args.checkpoint_every is not None else cfg.checkpoint_interval
    exploration_rng = np.random.default_rng(seed + 33333)
    if saved and "exploration_rng" in saved:
        exploration_rng.bit_generator.state = saved["exploration_rng"]
    manifest = {"environment_config": asdict(cfg), "learning_config": asdict(learning),
                "config_fingerprint": cfg.fingerprint, "observation_schema": environment_schema(env),
                "schedule": asdict(schedule), "seed": seed, "device": str(device),
                "warmup_steps": warmup, "action_noise": action_noise,
                "run_id": run_id, "milestones": milestones,
                "gpu": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
                "torch": torch.__version__, "additional_steps": args.steps, "resume_mode": resume_mode,
                "scope": "Simulation research implementation; no sea-trial or comparative performance claim."}
    log_path = args.output / "training.jsonl"
    started = time.monotonic()
    previous_elapsed = float(saved.get("elapsed_seconds", 0.0)) if saved else 0.0
    latest_info = initial_info
    latest_losses: dict[str, float] = {}
    stop_at = global_step + args.steps

    def payload() -> dict[str, Any]:
        environment_state = env.state_dict() if callable(getattr(env, "state_dict", None)) else None
        return {"format": "usv-auv-topology-usde-training-v1", "environment_config": asdict(cfg),
                "config_fingerprint": cfg.fingerprint, "observation_schema": environment_schema(env),
                "learning_config": asdict(learning), "agents": [agent.state_dict() for agent in agents],
                "topology": topology.state_dict(), "schedule": asdict(schedule), "seed": seed,
                "global_step": global_step, "episode": episode, "slow_decisions": slow_decisions,
                "training_stage": phase, "warmup_steps": warmup, "rng": rng_state(),
                "run_id": run_id, "milestones": milestones,
                "elapsed_seconds": previous_elapsed + time.monotonic() - started,
                "action_noise": action_noise,
                "exploration_rng": copy.deepcopy(exploration_rng.bit_generator.state),
                "environment_state": environment_state, "observations": np.asarray(observations).copy(),
                "pending_slow": copy.deepcopy(pending), "episode_return": episode_return,
                "discarded_partial_macros": discarded_partial_macros,
                "resume_semantics": "Exact physical snapshot if supported; otherwise start a new episode.",
                "manifest": manifest}

    # Validate all pre-existing requested destinations before advancing training.
    # A missed past milestone cannot be reconstructed from a later checkpoint.
    identity_base = {**manifest, "global_step": global_step}
    for milestone in milestones:
        destination = milestone_path(args.output, milestone)
        if destination.exists():
            validate_milestone(destination, milestone_identity({**identity_base, "global_step": milestone}))
        elif milestone < global_step:
            raise ValueError(f"Milestone {milestone} is already past and missing in {args.output}; "
                             "resume using its original output directory, not a reconstructed checkpoint")
    atomic_json(manifest, args.output / "manifest.json")
    print(json.dumps(manifest, ensure_ascii=False), flush=True)
    if global_step in milestones:
        save_milestone(payload(), args.output)

    def progress_record(status: str = "running") -> dict[str, Any]:
        return {"event": "progress", "status": status, "global_step": global_step, "stage": phase,
                "target_step": stop_at, "run_id": run_id,
                "elapsed_seconds": previous_elapsed + time.monotonic() - started,
                "invocation_elapsed_seconds": time.monotonic() - started,
                "td3_updates": [agent.updates for agent in agents],
                "discarded_partial_macros": discarded_partial_macros,
                "ddqn_updates": topology.updates, "losses": dict(latest_losses),
                "metrics": json_safe(latest_info.get("metrics", {})), "info": json_safe(latest_info)}

    atomic_json(progress_record(), args.output / "progress.json")

    @contextmanager
    def report_failure():
        try:
            yield
        except Exception as exc:
            record = progress_record("failed")
            record["error"] = f"{type(exc).__name__}: {exc}"
            try:
                atomic_json(record, args.output / "progress.json")
            except (TypeError, ValueError):
                # A malformed diagnostic/NaN metric must not hide the original
                # failure or replace a valid checkpoint with damaged weights.
                for name in ("info", "metrics", "losses"):
                    record[name] = {}
                atomic_json(record, args.output / "progress.json")
            raise

    with report_failure(), log_path.open("a", encoding="utf-8") as log:
        while global_step < stop_at:
            requested_topology = None
            if pending is None:
                next_phase = schedule.phase(global_step)
                if next_phase != phase:
                    # Phase changes alter the other learner's behavior. Avoid
                    # claiming a stationary replay population across these blocks.
                    for agent in agents:
                        agent.replay.clear()
                    topology.replay.clear()
                    phase = next_phase
                slow_state, slow_mask = env.slow_state()
                require_finite("slow observations", slow_state)
                if phase == "td3_curriculum":
                    valid = np.flatnonzero(slow_mask)
                    if not len(valid):
                        raise ValueError("empty topology mask during curriculum")
                    requested_topology = int(valid[slow_decisions % len(valid)])
                else:
                    epsilon = max(.05, .5 * np.exp(-topology.updates / 2000)) if phase in ("topology_only", "alternate_topology") else 0.0
                    requested_topology = topology.act(slow_state, slow_mask, epsilon)
                pending = {"state": np.asarray(slow_state).copy(), "mask": np.asarray(slow_mask).copy(),
                           "action": requested_topology, "reward": 0.0, "duration": 0}
                slow_decisions += 1
            update_td3 = phase in ("td3_curriculum", "alternate_td3")
            update_topology = phase in ("topology_only", "alternate_topology")
            if global_step < warmup and update_td3:
                actions = exploration_rng.uniform(-1, 1, (len(agents), 2)).astype(np.float32)
            else:
                actions = np.stack([agent.act(observations[i], action_noise if update_td3 else 0.0)
                                    for i, agent in enumerate(agents)])
            original_actions = actions.copy()
            require_finite("actions", original_actions)
            next_observations, reward, terminated, truncated, latest_info = env.step(
                actions.copy(), topology_action=requested_topology)
            next_observations = np.asarray(next_observations, np.float32)
            require_finite("reward", reward)
            require_finite("next observations", next_observations)
            for i, agent in enumerate(agents):
                agent.replay.add(observations[i], original_actions[i], float(reward),
                                 next_observations[i], bool(terminated), bool(truncated))
                if update_td3 and global_step >= warmup:
                    losses = agent.update()
                    require_finite(f"auv_{i} losses", losses)
                    latest_losses.update({f"auv_{i}_{key}": value for key, value in losses.items()})
            pending["reward"] += learning.gamma ** pending["duration"] * float(reward)
            pending["duration"] += 1
            global_step += 1
            episode_return += float(reward)
            observations = next_observations
            if pending["duration"] == period or terminated or truncated:
                if store_completed_macro(pending["duration"], period, bool(terminated), bool(truncated)):
                    next_slow, next_mask = env.slow_state()
                    require_finite("next slow observations", next_slow)
                    topology.replay.add(pending["state"], pending["mask"], pending["action"],
                                        pending["reward"], next_slow, next_mask, pending["duration"],
                                        learning.gamma, bool(terminated), bool(truncated))
                    if update_topology:
                        losses = topology.update()
                        require_finite("topology losses", losses)
                        latest_losses.update(losses)
                else:
                    # Administrative truncation inside a fixed macro action is
                    # not a new topology decision epoch. There is no valid
                    # next DDQN state to bootstrap until the macro finishes.
                    discarded_partial_macros += 1
                pending = None
            if terminated or truncated:
                record = {"event": "episode_end", "global_step": global_step, "episode": episode,
                          "return": episode_return, "terminated": bool(terminated),
                          "truncated": bool(truncated), "info": json_safe(latest_info)}
                log.write(json.dumps(record, ensure_ascii=False) + "\n")
                episode += 1
                observations, _ = env.reset(seed=seed + episode)
                observations = np.asarray(observations, np.float32)
                require_finite("reset observations", observations)
                episode_return = 0.0
            if global_step % args.log_every == 0 or global_step == stop_at:
                record = progress_record()
                log.write(json.dumps(record, ensure_ascii=False) + "\n")
                log.flush()
                atomic_json(record, args.output / "progress.json")
                print(json.dumps({key: value for key, value in record.items() if key != "info"}), flush=True)
            milestone_due = global_step in milestones
            checkpoint_due = checkpoint_every and global_step % checkpoint_every == 0
            if milestone_due or checkpoint_due:
                snapshot = payload()
                if milestone_due:
                    save_milestone(snapshot, args.output)
                if checkpoint_due:
                    atomic_save(snapshot, args.output / "checkpoint_latest.pt")
                del snapshot
    final = payload()
    atomic_save(final, args.output / "checkpoint_latest.pt")
    atomic_save(inference_payload(final), args.output / "policy_inference.pt")
    summary = {"global_step": global_step, "td3_updates": [agent.updates for agent in agents],
               "ddqn_updates": topology.updates, "seconds": time.monotonic() - started,
               "checkpoint": str(args.output / "checkpoint_latest.pt"),
               "inference": str(args.output / "policy_inference.pt"), "resume_mode": resume_mode}
    summary["discarded_partial_macros"] = discarded_partial_macros
    summary["milestones"] = milestones
    summary["elapsed_seconds"] = previous_elapsed + time.monotonic() - started
    atomic_json(summary, args.output / "summary.json")
    atomic_json(progress_record("completed"), args.output / "progress.json")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--output", type=Path, default=Path("runs/smoke"))
    parser.add_argument("--resume", type=Path, help="Trusted full training checkpoint")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--steps", type=int, default=200, help="Additional foreground environment steps")
    parser.add_argument("--milestones", type=int, nargs="*", default=[],
                        help="Immutable exact global-step checkpoints; merged with the saved plan on resume")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--hidden-dim", type=int)
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--topology-batch-size", type=int, default=8)
    parser.add_argument("--replay-capacity", type=int)
    parser.add_argument("--topology-capacity", type=int, default=5_000)
    parser.add_argument("--warmup-steps", type=int)
    parser.add_argument("--td3-steps", type=int)
    parser.add_argument("--topology-steps", type=int)
    parser.add_argument("--alternating-block", type=int)
    parser.add_argument("--action-noise", type=float)
    parser.add_argument("--log-every", type=int, default=25)
    parser.add_argument("--checkpoint-every", type=int)
    args = parser.parse_args()
    if args.log_every < 1 or (args.checkpoint_every is not None and args.checkpoint_every < 0) or (args.action_noise is not None and args.action_noise < 0):
        parser.error("invalid logging, checkpoint, or exploration setting")
    print(json.dumps(train(args), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
