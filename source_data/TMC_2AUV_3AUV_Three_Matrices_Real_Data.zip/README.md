# 2-AUV and 3-AUV: aligned report age, reported quality and executed topology

This package combines the existing user-provided report-age matrix series with archived replay local/confirmed parent-vector series, **without inventing missing measurements**.

Files:
- `2auv_full_matrix_series.json` and `3auv_full_matrix_series.json`: all 1201 sampled matrices (t=0,...,1200) per run; null on T diagonal means ∞; parent vectors can be null at t=0 when not recorded.
- `2auv_key_matrices.txt` and `3auv_key_matrices.txt`: main event matrices written out in readable form.

Do not confuse reported link quality Q with a physically guaranteed link. Do not interpret a current requested parent vector as a route that has already been installed. Output includes local and confirmed parent vectors, not a full time-resolved request trace.

Source archives: `TMC_Real_ReportAge_Heatmaps_Python_Data.zip`, `TMC_2AUV_OldZIP_Style_Favorable_Reproducible.zip`, and `TMC_3AUV_OldZIP_Style_Representative_Reproducible.zip`, which were generated from the original C07 simulator and frozen-policy replays.
